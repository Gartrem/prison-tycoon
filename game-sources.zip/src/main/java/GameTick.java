import java.util.TimerTask;

// $VF: renamed from: a
public final class GameTick extends TimerTask {
   // $VF: renamed from: run () void
   public final void run() {
      GameCore.method_388();
      GameCore.field_45.method_1653();
   }
}
