package javax.microedition.lcdui;
public final class Graphics {
  private final Image image; private int tx,ty,cx,cy,cw,ch; private int color=0xff000000;private Font font=Font.getFont(0,0,0);private boolean textImageMode;private boolean preserveDarkText;
  public Graphics(Image image){this.image=image;cw=image.width;ch=image.height;}
  public boolean remaster(String kind,int[] args){return web.Browser.remaster(image.handle,kind,new int[]{tx,ty,cx,cy,cw,ch},args);}
  private void draw(int op,int[] args,String text){web.Browser.draw(image.handle,op,new int[]{tx,ty,cx,cy,cw,ch,color,font.size,font.bold?1:0,textImageMode?1:0,preserveDarkText?1:0},args,text);}
  public int getTranslateX(){return tx;} public int getTranslateY(){return ty;}
  public void translate(int x,int y){tx+=x;ty+=y;}
  public int getClipX(){return cx-tx;} public int getClipY(){return cy-ty;}public int getClipWidth(){return cw;}public int getClipHeight(){return ch;}
  public void setClip(int x,int y,int w,int h){cx=x+tx;cy=y+ty;cw=Math.max(0,w);ch=Math.max(0,h);}
  public void clipRect(int x,int y,int w,int h){int nx=Math.max(cx,x+tx),ny=Math.max(cy,y+ty);cw=Math.max(0,Math.min(cx+cw,x+tx+w)-nx);ch=Math.max(0,Math.min(cy+ch,y+ty+h)-ny);cx=nx;cy=ny;}
  public void setColor(int color){this.color=0xff000000|(color&0xffffff);}public void setColor(int r,int g,int b){setColor((r<<16)|(g<<8)|b);}public int getColor(){return color&0xffffff;} public void setARGBColor(int color){this.color=color;}
  public void setFont(Font font){this.font=font;} public Font getFont(){return font;}
  public void setTextImageMode(boolean enabled){textImageMode=enabled;}
  public void setPreserveDarkText(boolean enabled){preserveDarkText=enabled;}
  public void fillRect(int x,int y,int w,int h){draw(0,new int[]{x,y,w,h},null);}
  public void drawRect(int x,int y,int w,int h){draw(1,new int[]{x,y,w,h},null);}
  public void drawLine(int x,int y,int x2,int y2){draw(2,new int[]{x,y,x2,y2},null);}
  public void drawArc(int x,int y,int w,int h,int start,int arc){draw(3,new int[]{x,y,w,h,start,arc},null);}
  public void fillArc(int x,int y,int w,int h,int start,int arc){draw(4,new int[]{x,y,w,h,start,arc},null);}
  public void drawImage(Image im,int x,int y,int anchor){drawRegion(im,0,0,im.width,im.height,0,x,y,anchor);}
  public void drawRegion(Image im,int sx,int sy,int w,int h,int transform,int x,int y,int anchor){draw(5,new int[]{im.handle,sx,sy,w,h,transform,x,y,anchor},null);}
  public void drawString(String text,int x,int y,int anchor){draw(6,new int[]{x,y,anchor},text);}
  public void drawChar(char c,int x,int y,int anchor){drawString(String.valueOf(c),x,y,anchor);}
  public void drawCyrillic(char c,int x,int y,int width,int height,Image reference){draw(8,new int[]{c,x,y,width,height,reference.handle},null);}
  public void drawModernText(String text,int x,int y,int width,int height){draw(9,new int[]{x,y,width,height},text);}
  public void drawChars(char[] c,int off,int len,int x,int y,int a){drawString(new String(c,off,len),x,y,a);}
  public void drawSubstring(String s,int off,int len,int x,int y,int a){drawString(s.substring(off,off+len),x,y,a);}
  public void fillTriangle(int x,int y,int x2,int y2,int x3,int y3,int argb){int old=color;color=argb;draw(7,new int[]{x,y,x2,y2,x3,y3},null);color=old;}
}
