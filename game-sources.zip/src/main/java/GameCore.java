import com.nokia.mid.ui.DirectUtils;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Timer;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.midlet.MIDlet;
import javax.microedition.rms.RecordStore;

public class GameCore extends MIDlet implements Runnable {
   // $VF: renamed from: a int
   public static int field_44 = 60;
   // $VF: renamed from: a d
   public static GameScreen field_45;
   // $VF: renamed from: a javax.microedition.lcdui.Display
   public static Display field_46;
   // $VF: renamed from: a GameCore
   public static GameCore field_47;
   // $VF: renamed from: a java.lang.Object
   public static final Object field_48 = new Object();
   // $VF: renamed from: a byte[]
   public static byte[] field_49;
   // $VF: renamed from: b int
   public static int field_50;
   // $VF: renamed from: a javax.microedition.lcdui.Graphics
   public static Graphics field_51;
   // $VF: renamed from: c int
   public static int field_52;
   // $VF: renamed from: d int
   public static int field_53;
   // $VF: renamed from: e int
   public static int field_54;
   // $VF: renamed from: f int
   public static int field_55;
   // $VF: renamed from: ad int[]
   private static int[] field_56 = new int[72];
   // $VF: renamed from: fl int
   private static int field_57;
   // $VF: renamed from: ae int[]
   private static final int[] field_58 = new int[16];
   // $VF: renamed from: fm int
   private static int field_59;
   // $VF: renamed from: g int
   public static int field_60;
   // $VF: renamed from: a java.lang.Object[]
   public static final Object[] field_61 = new Object[54];
   // $VF: renamed from: a c[]
   public static final AudioSpec[] field_62 = new AudioSpec[54];
   // $VF: renamed from: a b[]
   public static final SoundChannel[] field_63 = new SoundChannel[54];
   // $VF: renamed from: a boolean[]
   private static boolean[] field_64 = new boolean[]{true, true, false};
   // $VF: renamed from: M boolean
   private static boolean field_65;
   // $VF: renamed from: N boolean
   private static boolean field_66;
   // $VF: renamed from: af int[]
   private static int[] field_67 = new int[]{3, 3, 0};
   // $VF: renamed from: ag int[]
   private static int[] field_68 = new int[]{3, 3, 0};
   // $VF: renamed from: b boolean[]
   private static boolean[] field_69 = new boolean[3];
   // $VF: renamed from: ah int[]
   private static int[] field_70 = new int[]{-1, -1, -1};
   // $VF: renamed from: a java.lang.String[]
   public static final String[] field_71 = new String[421];
   // $VF: renamed from: ai int[]
   private static final int[] field_72 = new int[421];
   // $VF: renamed from: a java.lang.String
   public static String field_73;
   // $VF: renamed from: a int[]
   public static final int[] field_74 = new int[129];
   // $VF: renamed from: b int[]
   public static int[] field_75;
   // $VF: renamed from: b byte[]
   public static final byte[] field_76;
   // $VF: renamed from: a java.io.DataInputStream
   public static DataInputStream field_77;
   // $VF: renamed from: h int
   public static int field_78;
   // $VF: renamed from: i int
   public static int field_79;
   // $VF: renamed from: j int
   public static int field_80;
   // $VF: renamed from: k int
   public static int field_81;
   // $VF: renamed from: c int[]
   public static int[] field_82;
   // $VF: renamed from: a boolean
   public static boolean field_83;
   // $VF: renamed from: O boolean
   private static boolean field_84;
   // $VF: renamed from: P boolean
   private static boolean field_85;
   // $VF: renamed from: Q boolean
   private static boolean field_86;
   // $VF: renamed from: b long
   private static long field_87;
   // $VF: renamed from: R boolean
   private static boolean field_88;
   // $VF: renamed from: S boolean
   private static boolean field_89;
   // $VF: renamed from: a short[][]
   private static short[][] field_90;
   // $VF: renamed from: k byte[][]
   private static byte[][] field_91;
   // $VF: renamed from: l byte[][]
   private static byte[][] field_92;
   // $VF: renamed from: m byte[][]
   private static byte[][] field_93;
   // $VF: renamed from: b javax.microedition.lcdui.Image[]
   private static Image[] field_94;
   // $VF: renamed from: ae byte[]
   private static byte[] field_95;
   // $VF: renamed from: fn int
   private static int field_96;
   // $VF: renamed from: T boolean
   private static boolean field_97;
   // $VF: renamed from: af byte[]
   private static byte[] field_98;
   // $VF: renamed from: fo int
   private static int field_99;
   // $VF: renamed from: fp int
   private static int field_100;
   // $VF: renamed from: U boolean
   private static boolean field_101;
   // $VF: renamed from: a byte[][][]
   private static byte[][][] field_102;
   // $VF: renamed from: b byte[][][]
   private static byte[][][] field_103;
   // $VF: renamed from: n byte[][]
   private static byte[][] field_104;
   // $VF: renamed from: c byte[][][]
   private static byte[][][] field_105;
   // $VF: renamed from: a javax.microedition.lcdui.Font[]
   private static Font[] field_106;
   // $VF: renamed from: b java.lang.String
   public static String field_107;
   // $VF: renamed from: l int
   public static int field_108;
   // $VF: renamed from: m int
   public static int field_109;
   // $VF: renamed from: fq int
   private static int field_110;
   // $VF: renamed from: c long
   private static long field_111;
   // $VF: renamed from: d long
   private static long field_112;
   // $VF: renamed from: e long
   private static long field_113;
   // $VF: renamed from: ag byte[]
   private static byte[] field_114;
   // $VF: renamed from: ah byte[]
   private static byte[] field_115;
   // $VF: renamed from: ai byte[]
   private static byte[] field_116;
   // $VF: renamed from: fr int
   private static int field_117;
   // $VF: renamed from: fs int
   private static int field_118;
   // $VF: renamed from: n int
   public static int field_119;
   // $VF: renamed from: o int
   public static int field_120;
   // $VF: renamed from: a byte[][]
   public static byte[][] field_121;
   // $VF: renamed from: b byte[][]
   public static byte[][] field_122;
   // $VF: renamed from: a short[]
   public static short[] field_123;
   // $VF: renamed from: c byte[]
   public static byte[] field_124;
   // $VF: renamed from: d int[]
   public static int[] field_125;
   // $VF: renamed from: ft int
   private static int field_126;
   // $VF: renamed from: a java.util.Timer
   private Timer field_127;
   // $VF: renamed from: a a
   private GameTick field_128;
   // $VF: renamed from: fu int
   private static int field_129;
   // $VF: renamed from: p java.lang.String
   private static String field_130;
   // $VF: renamed from: fv int
   private static int field_131;
   // $VF: renamed from: q java.lang.String
   private static String field_132;
   // $VF: renamed from: V boolean
   private static boolean field_133;
   // $VF: renamed from: fw int
   private static int field_134;
   // $VF: renamed from: fx int
   private static int field_135;
   // $VF: renamed from: fy int
   private static int field_136;
   // $VF: renamed from: fz int
   private static int field_137;
   // $VF: renamed from: a f[]
   private static final RichTextLayout[] field_138;
   // $VF: renamed from: c short[]
   private static short[] field_139;
   // $VF: renamed from: a char
   private static char field_140;
   // $VF: renamed from: fA int
   private static int field_141;
   // $VF: renamed from: p int
   public static int field_142;
   // $VF: renamed from: q int
   public static int field_143;
   // $VF: renamed from: r int
   public static int field_144;
   // $VF: renamed from: s int
   public static int field_145;
   // $VF: renamed from: t int
   public static int field_146;
   // $VF: renamed from: a java.lang.Thread[]
   private static Thread[] field_147;
   // $VF: renamed from: fB int
   private static int field_148;
   // $VF: renamed from: b java.lang.String[]
   public static final String[] field_149;
   // $VF: renamed from: u int
   public static int field_150;
   // $VF: renamed from: fC int
   private static int field_151;
   // $VF: renamed from: fD int
   private static int field_152;
   // $VF: renamed from: W boolean
   private static boolean field_153;
   // $VF: renamed from: fE int
   private static int field_154;
   // $VF: renamed from: v int
   public static int field_155;
   // $VF: renamed from: w int
   public static volatile int field_156;
   // $VF: renamed from: X boolean
   private static boolean field_157;
   // $VF: renamed from: Y boolean
   private static boolean field_158;
   // $VF: renamed from: Z boolean
   private static boolean field_159;
   // $VF: renamed from: b boolean
   public static volatile boolean field_160;
   // $VF: renamed from: o byte[][]
   private static byte[][] field_161;
   // $VF: renamed from: aj int[]
   private static int[] field_162;
   // $VF: renamed from: b e
   private static final GameClock field_163;
   // $VF: renamed from: fF int
   private static int field_164;
   // $VF: renamed from: fG int
   private static int field_165;
   // $VF: renamed from: ak int[]
   private static int[] field_166;
   // $VF: renamed from: al int[]
   private static int[] field_167;
   // $VF: renamed from: fH int
   private static int field_168;
   // $VF: renamed from: fI int
   private static int field_169;
   // $VF: renamed from: fJ int
   private static int field_170;
   // $VF: renamed from: fK int
   private static int field_171;
   // $VF: renamed from: aa boolean
   private static boolean field_172;
   // $VF: renamed from: ab boolean
   private static boolean field_173;
   // $VF: renamed from: ac boolean
   private static boolean field_174;
   // $VF: renamed from: a f
   private static RichTextLayout field_175;
   // $VF: renamed from: fL int
   private static int field_176;
   // $VF: renamed from: fM int
   private static int field_177;
   // $VF: renamed from: ad boolean
   private static boolean field_178;
   // $VF: renamed from: ae boolean
   private static boolean field_179;
   // $VF: renamed from: af boolean
   private static boolean field_180;
   // $VF: renamed from: ag boolean
   private static boolean field_181;
   // $VF: renamed from: fN int
   private static int field_182;
   // $VF: renamed from: am int[]
   private static int[] field_183;
   // $VF: renamed from: r java.lang.String
   private static String field_184;
   // $VF: renamed from: x int
   public static int field_185;
   // $VF: renamed from: a java.lang.StringBuffer
   public static StringBuffer field_186;
   // $VF: renamed from: b java.lang.StringBuffer
   public static StringBuffer field_187;
   // $VF: renamed from: y int
   public static int field_188;
   // $VF: renamed from: z int
   public static int field_189;
   // $VF: renamed from: A int
   public static int field_190;
   // $VF: renamed from: B int
   public static int field_191;
   // $VF: renamed from: e int[]
   public static int[] field_192;
   // $VF: renamed from: f int[]
   public static int[] field_193;
   // $VF: renamed from: C int
   public static int field_194;
   // $VF: renamed from: D int
   public static int field_195;
   // $VF: renamed from: E int
   public static int field_196;
   // $VF: renamed from: F int
   public static int field_197;
   // $VF: renamed from: G int
   public static int field_198;
   // $VF: renamed from: ah boolean
   private static boolean field_199;
   // $VF: renamed from: s java.lang.String
   private static String field_200;
   // $VF: renamed from: t java.lang.String
   private static String field_201;
   // $VF: renamed from: fO int
   private static int field_202;
   // $VF: renamed from: c boolean
   public static boolean field_203;
   // $VF: renamed from: c long[]
   private static long[] field_204;
   // $VF: renamed from: d long[]
   private static long[] field_205;
   // $VF: renamed from: fP int
   private static int field_206;
   // $VF: renamed from: fQ int
   private static int field_207;
   // $VF: renamed from: fR int
   private static int field_208;
   // $VF: renamed from: fS int
   private static int field_209;
   // $VF: renamed from: fT int
   private static int field_210;
   // $VF: renamed from: fU int
   private static int field_211;
   // $VF: renamed from: a byte
   public static byte field_212;
   // $VF: renamed from: H int
   public static int field_213;
   // $VF: renamed from: b byte
   public static byte field_214;
   // $VF: renamed from: c byte
   public static byte field_215;
   // $VF: renamed from: I int
   public static int field_216;
   // $VF: renamed from: J int
   public static int field_217;
   // $VF: renamed from: d byte[]
   public static byte[] field_218;
   // $VF: renamed from: K int
   public static int field_219;
   // $VF: renamed from: d byte
   public static byte field_220;
   // $VF: renamed from: e byte
   public static byte field_221;
   // $VF: renamed from: f byte
   public static byte field_222;
   // $VF: renamed from: g byte
   public static byte field_223;
   // $VF: renamed from: h byte
   public static byte field_224;
   // $VF: renamed from: i byte
   public static byte field_225;
   // $VF: renamed from: j byte
   public static byte field_226;
   // $VF: renamed from: k byte
   public static byte field_227;
   // $VF: renamed from: l byte
   public static byte field_228;
   // $VF: renamed from: L int
   public static int field_229;
   // $VF: renamed from: M int
   public static int field_230;
   // $VF: renamed from: N int
   public static int field_231;
   // $VF: renamed from: O int
   public static int field_232;
   // $VF: renamed from: P int
   public static int field_233;
   // $VF: renamed from: Q int
   public static int field_234;
   // $VF: renamed from: R int
   public static int field_235;
   // $VF: renamed from: S int
   public static int field_236;
   // $VF: renamed from: T int
   public static int field_237;
   // $VF: renamed from: U int
   public static int field_238;
   // $VF: renamed from: d boolean
   public static boolean field_239;
   // $VF: renamed from: V int
   public static int field_240;
   // $VF: renamed from: W int
   public static int field_241;
   // $VF: renamed from: X int
   public static int field_242;
   // $VF: renamed from: Y int
   public static int field_243;
   // $VF: renamed from: e boolean
   public static boolean field_244;
   // $VF: renamed from: Z int
   public static int field_245;
   // $VF: renamed from: aa int
   public static int field_246;
   // $VF: renamed from: ab int
   public static final int field_247;
   // $VF: renamed from: ac int
   public static final int field_248;
   // $VF: renamed from: a long[]
   public static long[] field_249;
   // $VF: renamed from: b long[]
   public static long[] field_250;
   // $VF: renamed from: ad int
   public static int field_251;
   // $VF: renamed from: ae int
   public static int field_252;
   // $VF: renamed from: m byte
   public static byte field_253;
   // $VF: renamed from: n byte
   public static byte field_254;
   // $VF: renamed from: af int
   public static int field_255;
   // $VF: renamed from: ag int
   public static int field_256;
   // $VF: renamed from: ah int
   public static int field_257;
   // $VF: renamed from: fV int
   private static int field_258;
   // $VF: renamed from: o byte
   public static byte field_259;
   // $VF: renamed from: p byte
   public static byte field_260;
   // $VF: renamed from: ai int
   public static int field_261;
   // $VF: renamed from: aj int
   public static int field_262;
   // $VF: renamed from: ak int
   public static int field_263;
   // $VF: renamed from: al int
   public static int field_264;
   // $VF: renamed from: am int
   public static int field_265;
   // $VF: renamed from: an int
   public static int field_266;
   // $VF: renamed from: f boolean
   public static boolean field_267;
   // $VF: renamed from: g boolean
   public static boolean field_268;
   // $VF: renamed from: h boolean
   public static boolean field_269;
   // $VF: renamed from: ao int
   public static int field_270;
   // $VF: renamed from: a long
   public static long field_271;
   // $VF: renamed from: ap int
   public static int field_272;
   // $VF: renamed from: aq int
   public static int field_273;
   // $VF: renamed from: q byte
   public static byte field_274;
   // $VF: renamed from: ar int
   public static int field_275;
   // $VF: renamed from: i boolean
   public static boolean field_276;
   // $VF: renamed from: j boolean
   public static boolean field_277;
   // $VF: renamed from: as int
   public static int field_278;
   // $VF: renamed from: at int
   public static int field_279;
   // $VF: renamed from: au int
   public static int field_280;
   // $VF: renamed from: av int
   public static int field_281;
   // $VF: renamed from: aw int
   public static int field_282;
   // $VF: renamed from: ax int
   public static int field_283;
   // $VF: renamed from: ay int
   public static int field_284;
   // $VF: renamed from: az int
   public static int field_285;
   // $VF: renamed from: aA int
   public static int field_286;
   // $VF: renamed from: aB int
   public static int field_287;
   // $VF: renamed from: aC int
   public static int field_288;
   // $VF: renamed from: aD int
   public static int field_289;
   // $VF: renamed from: aE int
   public static int field_290;
   // $VF: renamed from: aF int
   public static int field_291;
   // $VF: renamed from: r byte
   public static byte field_292;
   // $VF: renamed from: s byte
   public static byte field_293;
   // $VF: renamed from: t byte
   public static byte field_294;
   // $VF: renamed from: u byte
   public static byte field_295;
   // $VF: renamed from: v byte
   public static byte field_296;
   // $VF: renamed from: w byte
   public static byte field_297;
   // $VF: renamed from: c byte[][]
   public static byte[][] field_298;
   // $VF: renamed from: g int[]
   public static int[] field_299;
   // $VF: renamed from: e byte[]
   public static byte[] field_300;
   // $VF: renamed from: f byte[]
   public static byte[] field_301;
   // $VF: renamed from: h int[]
   public static int[] field_302;
   // $VF: renamed from: i int[]
   public static int[] field_303;
   // $VF: renamed from: j int[]
   public static int[] field_304;
   // $VF: renamed from: k int[]
   public static int[] field_305;
   // $VF: renamed from: g byte[]
   public static byte[] field_306;
   // $VF: renamed from: h byte[]
   public static byte[] field_307;
   // $VF: renamed from: i byte[]
   public static byte[] field_308;
   // $VF: renamed from: j byte[]
   public static byte[] field_309;
   // $VF: renamed from: l int[]
   public static int[] field_310;
   // $VF: renamed from: m int[]
   public static int[] field_311;
   // $VF: renamed from: n int[]
   public static int[] field_312;
   // $VF: renamed from: o int[]
   public static int[] field_313;
   // $VF: renamed from: k byte[]
   public static byte[] field_314;
   // $VF: renamed from: l byte[]
   public static byte[] field_315;
   // $VF: renamed from: m byte[]
   public static byte[] field_316;
   // $VF: renamed from: p int[]
   public static int[] field_317;
   // $VF: renamed from: q int[]
   public static int[] field_318;
   // $VF: renamed from: r int[]
   public static int[] field_319;
   // $VF: renamed from: s int[]
   public static int[] field_320;
   // $VF: renamed from: t int[]
   public static int[] field_321;
   // $VF: renamed from: n byte[]
   public static byte[] field_322;
   // $VF: renamed from: d byte[][]
   public static byte[][] field_323;
   // $VF: renamed from: e byte[][]
   public static byte[][] field_324;
   // $VF: renamed from: u int[]
   public static int[] field_325;
   // $VF: renamed from: v int[]
   public static int[] field_326;
   // $VF: renamed from: w int[]
   public static int[] field_327;
   // $VF: renamed from: o byte[]
   public static byte[] field_328;
   // $VF: renamed from: p byte[]
   public static byte[] field_329;
   // $VF: renamed from: q byte[]
   public static byte[] field_330;
   // $VF: renamed from: x int[]
   public static int[] field_331;
   // $VF: renamed from: y int[]
   public static int[] field_332;
   // $VF: renamed from: z int[]
   public static int[] field_333;
   // $VF: renamed from: r byte[]
   public static byte[] field_334;
   // $VF: renamed from: s byte[]
   public static byte[] field_335;
   // $VF: renamed from: t byte[]
   public static byte[] field_336;
   // $VF: renamed from: u byte[]
   public static byte[] field_337;
   // $VF: renamed from: v byte[]
   public static byte[] field_338;
   // $VF: renamed from: w byte[]
   public static byte[] field_339;
   // $VF: renamed from: x byte[]
   public static byte[] field_340;
   // $VF: renamed from: y byte[]
   public static byte[] field_341;
   // $VF: renamed from: z byte[]
   public static byte[] field_342;
   // $VF: renamed from: A int[]
   public static int[] field_343;
   // $VF: renamed from: A byte[]
   public static byte[] field_344;
   // $VF: renamed from: B byte[]
   public static byte[] field_345;
   // $VF: renamed from: x byte
   public static byte field_346;
   // $VF: renamed from: k boolean
   public static boolean field_347;
   // $VF: renamed from: aG int
   public static int field_348;
   // $VF: renamed from: aH int
   public static int field_349;
   // $VF: renamed from: aI int
   public static int field_350;
   // $VF: renamed from: fW int
   private static int field_351;
   // $VF: renamed from: fX int
   private static int field_352;
   // $VF: renamed from: fY int
   private static int field_353;
   // $VF: renamed from: fZ int
   private static int field_354;
   // $VF: renamed from: C byte[]
   public static final byte[] field_355;
   // $VF: renamed from: D byte[]
   public static byte[] field_356;
   // $VF: renamed from: E byte[]
   public static byte[] field_357;
   // $VF: renamed from: aJ int
   public static int field_358;
   // $VF: renamed from: aK int
   public static int field_359;
   // $VF: renamed from: aL int
   public static int field_360;
   // $VF: renamed from: l boolean
   public static boolean field_361;
   // $VF: renamed from: aM int
   public static int field_362;
   // $VF: renamed from: aN int
   public static int field_363;
   // $VF: renamed from: y byte
   public static byte field_364;
   // $VF: renamed from: F byte[]
   public static final byte[] field_365;
   // $VF: renamed from: aO int
   public static int field_366;
   // $VF: renamed from: B int[]
   public static final int[] field_367;
   // $VF: renamed from: aP int
   public static int field_368;
   // $VF: renamed from: aQ int
   public static int field_369;
   // $VF: renamed from: b short[]
   public static final short[] field_370;
   // $VF: renamed from: G byte[]
   public static final byte[] field_371;
   // $VF: renamed from: aR int
   public static int field_372;
   // $VF: renamed from: z byte
   public static byte field_373;
   // $VF: renamed from: aS int
   public static int field_374;
   // $VF: renamed from: aT int
   public static int field_375;
   // $VF: renamed from: aU int
   public static int field_376;
   // $VF: renamed from: aV int
   public static int field_377;
   // $VF: renamed from: aW int
   public static int field_378;
   // $VF: renamed from: aX int
   public static int field_379;
   // $VF: renamed from: aY int
   public static int field_380;
   // $VF: renamed from: aZ int
   public static int field_381;
   // $VF: renamed from: ba int
   public static int field_382;
   // $VF: renamed from: c java.lang.String
   public static String field_383;
   // $VF: renamed from: H byte[]
   public static byte[] field_384;
   // $VF: renamed from: I byte[]
   public static byte[] field_385;
   // $VF: renamed from: C int[]
   public static int[] field_386;
   // $VF: renamed from: bb int
   public static int field_387;
   // $VF: renamed from: bc int
   public static int field_388;
   // $VF: renamed from: bd int
   public static int field_389;
   // $VF: renamed from: be int
   public static int field_390;
   // $VF: renamed from: bf int
   public static int field_391;
   // $VF: renamed from: bg int
   public static int field_392;
   // $VF: renamed from: m boolean
   public static boolean field_393;
   // $VF: renamed from: bh int
   public static int field_394;
   // $VF: renamed from: bi int
   public static int field_395;
   // $VF: renamed from: f byte[][]
   public static byte[][] field_396;
   // $VF: renamed from: g byte[][]
   public static byte[][] field_397;
   // $VF: renamed from: h byte[][]
   public static byte[][] field_398;
   // $VF: renamed from: i byte[][]
   public static byte[][] field_399;
   // $VF: renamed from: j byte[][]
   public static byte[][] field_400;
   // $VF: renamed from: a int[][]
   public static int[][] field_401;
   // $VF: renamed from: b int[][]
   public static int[][] field_402;
   // $VF: renamed from: c int[][]
   public static int[][] field_403;
   // $VF: renamed from: D int[]
   public static final int[] field_404;
   // $VF: renamed from: E int[]
   public static final int[] field_405;
   // $VF: renamed from: bj int
   public static int field_406;
   // $VF: renamed from: A byte
   public static byte field_407;
   // $VF: renamed from: B byte
   public static byte field_408;
   // $VF: renamed from: J byte[]
   public static byte[] field_409;
   // $VF: renamed from: K byte[]
   public static byte[] field_410;
   // $VF: renamed from: c java.lang.String[]
   public static String[] field_411;
   // $VF: renamed from: L byte[]
   public static byte[] field_412;
   // $VF: renamed from: M byte[]
   public static byte[] field_413;
   // $VF: renamed from: bk int
   public static int field_414;
   // $VF: renamed from: C byte
   public static byte field_415;
   // $VF: renamed from: D byte
   public static byte field_416;
   // $VF: renamed from: bl int
   public static int field_417;
   // $VF: renamed from: N byte[]
   public static byte[] field_418;
   // $VF: renamed from: bm int
   public static int field_419;
   // $VF: renamed from: bn int
   public static int field_420;
   // $VF: renamed from: O byte[]
   public static byte[] field_421;
   // $VF: renamed from: bo int
   public static int field_422;
   // $VF: renamed from: bp int
   public static int field_423;
   // $VF: renamed from: bq int
   public static int field_424;
   // $VF: renamed from: br int
   public static int field_425;
   // $VF: renamed from: bs int
   public static int field_426;
   // $VF: renamed from: bt int
   public static int field_427;
   // $VF: renamed from: bu int
   public static int field_428;
   // $VF: renamed from: E byte
   public static byte field_429;
   // $VF: renamed from: bv int
   public static int field_430;
   // $VF: renamed from: bw int
   public static int field_431;
   // $VF: renamed from: bx int
   public static int field_432;
   // $VF: renamed from: F int[]
   public static int[] field_433;
   // $VF: renamed from: G int[]
   public static int[] field_434;
   // $VF: renamed from: by int
   public static int field_435;
   // $VF: renamed from: bz int
   public static int field_436;
   // $VF: renamed from: bA int
   public static int field_437;
   // $VF: renamed from: bB int
   public static int field_438;
   // $VF: renamed from: bC int
   public static int field_439;
   // $VF: renamed from: bD int
   public static int field_440;
   // $VF: renamed from: bE int
   public static int field_441;
   // $VF: renamed from: bF int
   public static int field_442;
   // $VF: renamed from: bG int
   public static int field_443;
   // $VF: renamed from: bH int
   public static int field_444;
   // $VF: renamed from: bI int
   public static int field_445;
   // $VF: renamed from: P byte[]
   public static byte[] field_446;
   // $VF: renamed from: Q byte[]
   public static byte[] field_447;
   // $VF: renamed from: H int[]
   public static int[] field_448;
   // $VF: renamed from: R byte[]
   public static byte[] field_449;
   // $VF: renamed from: S byte[]
   public static byte[] field_450;
   // $VF: renamed from: I int[]
   public static int[] field_451;
   // $VF: renamed from: bJ int
   public static int field_452;
   // $VF: renamed from: bK int
   public static int field_453;
   // $VF: renamed from: bL int
   public static int field_454;
   // $VF: renamed from: bM int
   public static int field_455;
   // $VF: renamed from: bN int
   public static int field_456;
   // $VF: renamed from: bO int
   public static int field_457;
   // $VF: renamed from: bP int
   public static int field_458;
   // $VF: renamed from: bQ int
   public static int field_459;
   // $VF: renamed from: bR int
   public static int field_460;
   // $VF: renamed from: bS int
   public static int field_461;
   // $VF: renamed from: F byte
   public static byte field_462;
   // $VF: renamed from: n boolean
   public static boolean field_463;
   // $VF: renamed from: o boolean
   public static boolean field_464;
   // $VF: renamed from: bT int
   public static int field_465;
   // $VF: renamed from: bU int
   public static int field_466;
   // $VF: renamed from: bV int
   public static int field_467;
   // $VF: renamed from: J int[]
   public static int[] field_468;
   // $VF: renamed from: bW int
   public static int field_469;
   // $VF: renamed from: bX int
   public static int field_470;
   // $VF: renamed from: bY int
   public static int field_471;
   // $VF: renamed from: bZ int
   public static int field_472;
   // $VF: renamed from: p boolean
   public static boolean field_473;
   // $VF: renamed from: ca int
   public static int field_474;
   // $VF: renamed from: cb int
   public static int field_475;
   // $VF: renamed from: q boolean
   public static boolean field_476;
   // $VF: renamed from: cc int
   public static int field_477;
   // $VF: renamed from: T byte[]
   public static byte[] field_478;
   // $VF: renamed from: cd int
   public static int field_479;
   // $VF: renamed from: ce int
   public static int field_480;
   // $VF: renamed from: cf int
   public static int field_481;
   // $VF: renamed from: d java.lang.String
   public static String field_482;
   // $VF: renamed from: cg int
   public static int field_483;
   // $VF: renamed from: ch int
   public static int field_484;
   // $VF: renamed from: ci int
   public static int field_485;
   // $VF: renamed from: cj int
   public static int field_486;
   // $VF: renamed from: ck int
   public static int field_487;
   // $VF: renamed from: r boolean
   public static boolean field_488;
   // $VF: renamed from: s boolean
   public static boolean field_489;
   // $VF: renamed from: cl int
   public static int field_490;
   // $VF: renamed from: t boolean
   public static boolean field_491;
   // $VF: renamed from: cm int
   public static int field_492;
   // $VF: renamed from: u boolean
   public static boolean field_493;
   // $VF: renamed from: aj byte[]
   private static byte[] field_494;
   // $VF: renamed from: an int[]
   private static int[] field_495;
   // $VF: renamed from: ao int[]
   private static int[] field_496;
   // $VF: renamed from: ap int[]
   private static int[] field_497;
   // $VF: renamed from: aq int[]
   private static int[] field_498;
   // $VF: renamed from: ar int[]
   private static int[] field_499;
   // $VF: renamed from: ga int
   private static int field_500;
   // $VF: renamed from: K int[]
   public static int[] field_501;
   // $VF: renamed from: L int[]
   public static int[] field_502;
   // $VF: renamed from: M int[]
   public static int[] field_503;
   // $VF: renamed from: N int[]
   public static int[] field_504;
   // $VF: renamed from: O int[]
   public static int[] field_505;
   // $VF: renamed from: P int[]
   public static int[] field_506;
   // $VF: renamed from: Q int[]
   public static int[] field_507;
   // $VF: renamed from: R int[]
   public static int[] field_508;
   // $VF: renamed from: S int[]
   public static int[] field_509;
   // $VF: renamed from: cn int
   public static int field_510;
   // $VF: renamed from: a e
   public static GameClock field_511;
   // $VF: renamed from: co int
   public static int field_512;
   // $VF: renamed from: v boolean
   public static boolean field_513;
   // $VF: renamed from: cp int
   public static int field_514;
   // $VF: renamed from: cq int
   public static int field_515;
   // $VF: renamed from: cr int
   public static int field_516;
   // $VF: renamed from: cs int
   public static int field_517;
   // $VF: renamed from: ct int
   public static int field_518;
   // $VF: renamed from: cu int
   public static int field_519;
   // $VF: renamed from: cv int
   public static int field_520;
   // $VF: renamed from: cw int
   public static int field_521;
   // $VF: renamed from: cx int
   public static int field_522;
   // $VF: renamed from: cy int
   public static int field_523;
   // $VF: renamed from: cz int
   public static int field_524;
   // $VF: renamed from: cA int
   public static int field_525;
   // $VF: renamed from: cB int
   public static int field_526;
   // $VF: renamed from: cC int
   public static int field_527;
   // $VF: renamed from: cD int
   public static int field_528;
   // $VF: renamed from: cE int
   public static int field_529;
   // $VF: renamed from: cF int
   public static int field_530;
   // $VF: renamed from: gb int
   private static int field_531;
   // $VF: renamed from: gc int
   private static int field_532;
   // $VF: renamed from: gd int
   private static int field_533;
   // $VF: renamed from: ge int
   private static int field_534;
   // $VF: renamed from: gf int
   private static int field_535;
   // $VF: renamed from: gg int
   private static int field_536;
   // $VF: renamed from: cG int
   public static int field_537;
   // $VF: renamed from: cH int
   public static int field_538;
   // $VF: renamed from: cI int
   public static int field_539;
   // $VF: renamed from: cJ int
   public static int field_540;
   // $VF: renamed from: cK int
   public static int field_541;
   // $VF: renamed from: cL int
   public static int field_542;
   // $VF: renamed from: cM int
   public static int field_543;
   // $VF: renamed from: cN int
   public static int field_544;
   // $VF: renamed from: T int[]
   public static int[] field_545;
   // $VF: renamed from: U int[]
   public static int[] field_546;
   // $VF: renamed from: cO int
   public static int field_547;
   // $VF: renamed from: cP int
   public static int field_548;
   // $VF: renamed from: cQ int
   public static final int field_549;
   // $VF: renamed from: cR int
   public static final int field_550;
   // $VF: renamed from: cS int
   public static final int field_551;
   // $VF: renamed from: cT int
   public static final int field_552;
   // $VF: renamed from: cU int
   public static final int field_553;
   // $VF: renamed from: cV int
   public static final int field_554;
   // $VF: renamed from: cW int
   public static final int field_555;
   // $VF: renamed from: cX int
   public static final int field_556;
   // $VF: renamed from: cY int
   public static final int field_557;
   // $VF: renamed from: cZ int
   public static final int field_558;
   // $VF: renamed from: da int
   public static final int field_559;
   // $VF: renamed from: db int
   public static final int field_560;
   // $VF: renamed from: dc int
   public static final int field_561;
   // $VF: renamed from: dd int
   public static final int field_562;
   // $VF: renamed from: de int
   public static final int field_563;
   // $VF: renamed from: df int
   public static final int field_564;
   // $VF: renamed from: dg int
   public static final int field_565;
   // $VF: renamed from: dh int
   public static final int field_566;
   // $VF: renamed from: di int
   public static final int field_567;
   // $VF: renamed from: dj int
   public static final int field_568;
   // $VF: renamed from: dk int
   public static final int field_569;
   // $VF: renamed from: dl int
   public static final int field_570;
   // $VF: renamed from: dm int
   public static final int field_571;
   // $VF: renamed from: dn int
   public static final int field_572;
   // $VF: renamed from: do int
   public static final int field_573;
   // $VF: renamed from: dp int
   public static final int field_574;
   // $VF: renamed from: dq int
   public static final int field_575;
   // $VF: renamed from: U byte[]
   public static final byte[] field_576;
   // $VF: renamed from: dr int
   public static final int field_577;
   // $VF: renamed from: ds int
   public static final int field_578;
   // $VF: renamed from: dt int
   public static final int field_579;
   // $VF: renamed from: du int
   public static final int field_580;
   // $VF: renamed from: dv int
   public static final int field_581;
   // $VF: renamed from: dw int
   public static final int field_582;
   // $VF: renamed from: dx int
   public static final int field_583;
   // $VF: renamed from: dy int
   public static final int field_584;
   // $VF: renamed from: dz int
   public static final int field_585;
   // $VF: renamed from: dA int
   public static final int field_586;
   // $VF: renamed from: dB int
   public static final int field_587;
   // $VF: renamed from: dC int
   public static final int field_588;
   // $VF: renamed from: dD int
   public static final int field_589;
   // $VF: renamed from: dE int
   public static final int field_590;
   // $VF: renamed from: dF int
   public static final int field_591;
   // $VF: renamed from: dG int
   public static final int field_592;
   // $VF: renamed from: dH int
   public static final int field_593;
   // $VF: renamed from: dI int
   public static final int field_594;
   // $VF: renamed from: dJ int
   public static final int field_595;
   // $VF: renamed from: dK int
   public static final int field_596;
   // $VF: renamed from: V int[]
   public static int[] field_597;
   // $VF: renamed from: dL int
   public static int field_598;
   // $VF: renamed from: dM int
   public static int field_599;
   // $VF: renamed from: dN int
   public static int field_600;
   // $VF: renamed from: dO int
   public static int field_601;
   // $VF: renamed from: dP int
   public static int field_602;
   // $VF: renamed from: dQ int
   public static int field_603;
   // $VF: renamed from: dR int
   public static int field_604;
   // $VF: renamed from: dS int
   public static int field_605;
   // $VF: renamed from: dT int
   public static int field_606;
   // $VF: renamed from: a javax.microedition.lcdui.Image
   public static Image field_607;
   // $VF: renamed from: b javax.microedition.lcdui.Graphics
   public static Graphics field_608;
   // $VF: renamed from: dU int
   public static int field_609;
   // $VF: renamed from: dV int
   public static int field_610;
   // $VF: renamed from: w boolean
   public static boolean field_611;
   // $VF: renamed from: x boolean
   public static boolean field_612;
   // $VF: renamed from: dW int
   public static int field_613;
   // $VF: renamed from: dX int
   public static int field_614;
   // $VF: renamed from: y boolean
   public static boolean field_615;
   // $VF: renamed from: dY int
   public static int field_616;
   // $VF: renamed from: dZ int
   public static int field_617;
   // $VF: renamed from: z boolean
   public static boolean field_618;
   // $VF: renamed from: ea int
   public static int field_619;
   // $VF: renamed from: eb int
   public static int field_620;
   // $VF: renamed from: ec int
   public static int field_621;
   // $VF: renamed from: ed int
   public static int field_622;
   // $VF: renamed from: e java.lang.String
   public static String field_623;
   // $VF: renamed from: f java.lang.String
   public static String field_624;
   // $VF: renamed from: g java.lang.String
   public static String field_625;
   // $VF: renamed from: h java.lang.String
   public static String field_626;
   // $VF: renamed from: i java.lang.String
   public static String field_627;
   // $VF: renamed from: j java.lang.String
   public static String field_628;
   // $VF: renamed from: ee int
   public static int field_629;
   // $VF: renamed from: A boolean
   public static boolean field_630;
   // $VF: renamed from: B boolean
   public static boolean field_631;
   // $VF: renamed from: k java.lang.String
   public static String field_632;
   // $VF: renamed from: l java.lang.String
   public static String field_633;
   // $VF: renamed from: C boolean
   public static boolean field_634;
   // $VF: renamed from: b javax.microedition.lcdui.Image
   public static Image field_635;
   // $VF: renamed from: gh int
   private static int field_636;
   // $VF: renamed from: D boolean
   public static boolean field_637;
   // $VF: renamed from: E boolean
   public static boolean field_638;
   // $VF: renamed from: m java.lang.String
   public static String field_639;
   // $VF: renamed from: d java.lang.String[]
   public static String[] field_640;
   // $VF: renamed from: a javax.microedition.lcdui.Image[]
   public static Image[] field_641;
   // $VF: renamed from: e java.lang.String[]
   public static String[] field_642;
   // $VF: renamed from: ef int
   public static int field_643;
   // $VF: renamed from: eg int
   public static int field_644;
   // $VF: renamed from: eh int
   public static int field_645;
   // $VF: renamed from: ei int
   public static int field_646;
   // $VF: renamed from: ej int
   public static int field_647;
   // $VF: renamed from: ek int
   public static int field_648;
   // $VF: renamed from: F boolean
   public static boolean field_649;
   // $VF: renamed from: G boolean
   public static boolean field_650;
   // $VF: renamed from: n java.lang.String
   public static String field_651;
   // $VF: renamed from: o java.lang.String
   public static String field_652;
   // $VF: renamed from: el int
   public static int field_653;
   // $VF: renamed from: V byte[]
   public static final byte[] field_654;
   // $VF: renamed from: W byte[]
   public static final byte[] field_655;
   // $VF: renamed from: em int
   public static int field_656;
   // $VF: renamed from: W int[]
   public static final int[] field_657;
   // $VF: renamed from: X int[]
   public static final int[] field_658;
   // $VF: renamed from: Y int[]
   public static final int[] field_659;
   // $VF: renamed from: Z int[]
   public static final int[] field_660;
   // $VF: renamed from: X byte[]
   public static byte[] field_661;
   // $VF: renamed from: aa int[]
   public static final int[] field_662;
   // $VF: renamed from: ab int[]
   public static final int[] field_663;
   // $VF: renamed from: Y byte[]
   public static final byte[] field_664;
   // $VF: renamed from: ac int[]
   public static final int[] field_665;
   // $VF: renamed from: Z byte[]
   public static final byte[] field_666;
   // $VF: renamed from: aa byte[]
   public static final byte[] field_667;
   // $VF: renamed from: ab byte[]
   public static byte[] field_668;
   // $VF: renamed from: en int
   public static int field_669;
   // $VF: renamed from: eo int
   public static int field_670;
   // $VF: renamed from: ep int
   public static int field_671;
   // $VF: renamed from: eq int
   public static final int field_672;
   // $VF: renamed from: er int
   public static final int field_673;
   // $VF: renamed from: es int
   public static final int field_674;
   // $VF: renamed from: et int
   public static final int field_675;
   // $VF: renamed from: eu int
   public static final int field_676;
   // $VF: renamed from: ev int
   public static final int field_677;
   // $VF: renamed from: ew int
   public static final int field_678;
   // $VF: renamed from: ex int
   public static final int field_679;
   // $VF: renamed from: ey int
   public static final int field_680;
   // $VF: renamed from: ez int
   public static final int field_681;
   // $VF: renamed from: eA int
   public static final int field_682;
   // $VF: renamed from: eB int
   public static final int field_683;
   // $VF: renamed from: eC int
   public static final int field_684;
   // $VF: renamed from: eD int
   public static final int field_685;
   // $VF: renamed from: eE int
   public static final int field_686;
   // $VF: renamed from: eF int
   public static final int field_687;
   // $VF: renamed from: eG int
   public static final int field_688;
   // $VF: renamed from: eH int
   public static final int field_689;
   // $VF: renamed from: eI int
   public static final int field_690;
   // $VF: renamed from: eJ int
   public static final int field_691;
   // $VF: renamed from: eK int
   public static final int field_692;
   // $VF: renamed from: eL int
   public static final int field_693;
   // $VF: renamed from: eM int
   public static final int field_694;
   // $VF: renamed from: eN int
   public static final int field_695;
   // $VF: renamed from: eO int
   public static final int field_696;
   // $VF: renamed from: eP int
   public static final int field_697;
   // $VF: renamed from: eQ int
   public static final int field_698;
   // $VF: renamed from: eR int
   public static final int field_699;
   // $VF: renamed from: eS int
   public static final int field_700;
   // $VF: renamed from: eT int
   public static final int field_701;
   // $VF: renamed from: eU int
   public static final int field_702;
   // $VF: renamed from: eV int
   public static final int field_703;
   // $VF: renamed from: eW int
   public static final int field_704;
   // $VF: renamed from: eX int
   public static final int field_705;
   // $VF: renamed from: eY int
   public static final int field_706;
   // $VF: renamed from: eZ int
   public static final int field_707;
   // $VF: renamed from: fa int
   public static final int field_708;
   // $VF: renamed from: fb int
   public static final int field_709;
   // $VF: renamed from: fc int
   public static final int field_710;
   // $VF: renamed from: fd int
   public static final int field_711;
   // $VF: renamed from: fe int
   public static int field_712;
   // $VF: renamed from: H boolean
   public static boolean field_713;
   // $VF: renamed from: I boolean
   public static boolean field_714;
   // $VF: renamed from: J boolean
   public static boolean field_715;
   // $VF: renamed from: K boolean
   public static boolean field_716;
   // $VF: renamed from: L boolean
   public static boolean field_717;
   // $VF: renamed from: c javax.microedition.lcdui.Image
   public static Image field_718;
   // Russian title artwork used by the browser edition.
   public static Image russianLogo;
   // $VF: renamed from: ac byte[]
   public static final byte[] field_719;
   // $VF: renamed from: ff int
   public static int field_720;
   // $VF: renamed from: G byte
   public static byte field_721;
   // $VF: renamed from: ad byte[]
   public static byte[] field_722;
   // $VF: renamed from: H byte
   public static byte field_723;
   // $VF: renamed from: I byte
   public static byte field_724;
   // $VF: renamed from: J byte
   public static byte field_725;
   // $VF: renamed from: fg int
   public static int field_726;
   // $VF: renamed from: fh int
   public static int field_727;
   // $VF: renamed from: fi int
   public static int field_728;
   // $VF: renamed from: gi int
   private static int field_729;
   // $VF: renamed from: fj int
   public static int field_730;
   // $VF: renamed from: a java.lang.String[][]
   public static String[][] field_731;
   // $VF: renamed from: fk int
   public static int field_732;

   // $VF: renamed from: a (java.lang.String) void
   public static void method_51(String var0) {
      if (var0.equals("la")) {
         method_305();
      } else if (var0.equals("gd")) {
         method_507();
      } else {
         if (var0.equals("gf")) {
            method_588();
         }
      }
   }

   // $VF: renamed from: a (java.lang.String, byte[], int) int
   public static int method_52(String var0, byte[] var1, int var2) {
      if (var0.equals("la")) {
         return method_306(var1, var2);
      } else if (var0.equals("gd")) {
         return method_506(var1, var2);
      } else {
         return var0.equals("gf" + field_479) ? method_587(var1, var2) : 0;
      }
   }

   // $VF: renamed from: b (java.lang.String, byte[], int) int
   public static int method_53(String var0, byte[] var1, int var2) {
      if (var0.equals("la")) {
         var2 = method_307(var1, var2);
      } else if (var0.equals("gd")) {
         var2 = method_505(var1, var2);
      } else if (var0.equals("gf" + field_479)) {
         var2 = method_586(var1, var2);
      } else {
         var2 = 0;
      }

      return var2;
   }

   // $VF: renamed from: a () void
   public static void method_54() {
      method_1023();
      field_615 = false;
      field_715 = true;
      field_716 = true;
      method_1204();
      method_458();
      method_1205();
      method_1207();
      method_1062();
      method_481();
      method_1406();
      method_1418();
      method_1429();
      field_471 = -1;
      method_1457();
      method_1456();
      field_475 = -1;
      field_476 = false;
      method_1098();
      method_1595();
      method_1438();
      field_197 = -1;
      field_198 = -1;
      field_717 = false;
      method_1143();
   }

   // $VF: renamed from: b () void
   public static final void method_55() {
      method_423(80);
   }

   // $VF: renamed from: a () javax.microedition.midlet.MIDlet
   public final MIDlet method_56() {
      return this;
   }

   // $VF: renamed from: c () void
   public static final void method_57() {
      field_47.destroyApp(true);
      field_47.notifyDestroyed();
   }

   // $VF: renamed from: a (GameCore) void
   public static final void method_58(GameCore var0) {
      field_47 = var0;
      field_46 = Display.getDisplay(var0.method_56());
      field_45 = new GameScreen();
   }

   // $VF: renamed from: d () void
   public static final void method_59() {
      if (field_49 == null) {
         field_49 = new byte[2048];
      } else {
         field_49 = null;
      }

      field_50 = method_401();
      method_413(true);
   }

   // $VF: renamed from: a () long
   public static final long method_60() {
      int var0 = field_57;
      return field_57 < 6 ? method_67(0, 0, 240, 320) : method_67(field_56[var0 - 6], field_56[var0 - 5], field_56[var0 - 2], field_56[var0 - 1]);
   }

   // $VF: renamed from: a (long) void
   public static final void method_61(long var0) {
      method_62(var0, 0, 0);
   }

   // $VF: renamed from: a (long, int, int) void
   public static final void method_62(long var0, int var2, int var3) {
      int var4 = (int)var0 & 65535;
      int var5 = (int)(var0 >> 16) & 65535;
      int var6 = ((int)(var0 >> 32) & 65535) - field_55;
      int var7;
      method_74((var7 = ((int)(var0 >> 48) & 65535) - field_54) + var2, var6 + var3, var5, var4, var7, var6);
   }

   // $VF: renamed from: a (int, int, int, int) void
   public static final void method_63(int var0, int var1, int var2, int var3) {
      method_74(var0, var1, var2, var3, var0, var1);
   }

   // $VF: renamed from: e () void
   public static final void method_64() {
      field_57 -= 2;
      int var0 = field_56[--field_57];
      int var1 = field_56[--field_57];
      int var2 = field_56[--field_57];
      int var3 = field_56[--field_57];
      int var4 = field_53 = field_56[field_57 - 1];
      int var5 = field_52 = field_56[field_57 - 2];
      field_51.translate(-var3, -var2);
      method_310(field_51, 0, 0, var5, var4);
      field_54 -= var1;
      field_55 -= var0;
   }

   // $VF: renamed from: a (int) void
   public static final void method_65(int var0) {
      method_313(field_51, var0);
      method_315(field_51, 0, 0, field_52, field_53);
   }

   // $VF: renamed from: a (int, java.lang.String, int) int
   public static final int method_66(int var0, String var1, int var2) {
      if (var1 == null) {
         return 0;
      } else {
         int var3 = 0;
         int var4 = 0;
         if ((var2 & 8) != 0) {
            var3 = 0 + field_52;
         } else if ((var2 & 1) != 0) {
            var3 = 0 + (field_52 >> 1);
         }

         if ((var2 & 32) != 0) {
            var4 = 0 + field_53;
         } else if ((var2 & 2) != 0) {
            var4 = 0 + (field_53 >> 1);
         } else if ((var2 & 64) != 0) {
            var4 = 0 + method_210(var0);
         }

         return method_203(var0, var1, var3, var4, var2);
      }
   }

   // $VF: renamed from: a (int, int, int, int) long
   public static final long method_67(int var0, int var1, int var2, int var3) {
      return (long)var0 << 48 | (long)var1 << 32 | var2 << 16 | var3;
   }

   // $VF: renamed from: a (long) int
   public static final int method_68(long var0) {
      return (int)(var0 >> 48) & 65535;
   }

   // $VF: renamed from: b (long) int
   public static final int method_69(long var0) {
      return (int)(var0 >> 32) & 65535;
   }

   // $VF: renamed from: c (long) int
   public static final int method_70(long var0) {
      return (int)(var0 >> 16) & 65535;
   }

   // $VF: renamed from: d (long) int
   public static final int method_71(long var0) {
      return (int)var0 & 65535;
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics) void
   public static void method_72(Graphics var0) {
      field_51 = var0;
      method_75();
      method_310(field_51, 0, 0, 240, 320);
   }

   // $VF: renamed from: f () void
   public static void method_73() {
      if (field_50 > 0) {
         if (field_50 >= method_401() - 2500) {
            field_51.setColor(16777215);
            field_51.fillRect(0, 0, 240, 320);
            field_51.setColor(0);
            field_51.drawString("TST " + (field_49 != null), 120, 160, 17);
            method_413(true);
         } else {
            field_50 = 0;
         }
      }

      field_51 = null;
   }

   // $VF: renamed from: b (int, int, int, int, int, int) void
   private static final void method_74(int var0, int var1, int var2, int var3, int var4, int var5) {
      field_56[field_57++] = var0;
      field_56[field_57++] = var1;
      field_56[field_57++] = var4;
      field_56[field_57++] = var5;
      field_52 = field_56[field_57++] = var2;
      field_53 = field_56[field_57++] = var3;
      field_51.translate(var0, var1);
      method_311(field_51, 0, 0, var2, var3);
      field_54 += var4;
      field_55 += var5;
   }

   // $VF: renamed from: hi () void
   private static final void method_75() {
      field_57 = 0;
      field_54 = 0;
      field_55 = 0;
      field_52 = field_56[field_57++] = 240;
      field_53 = field_56[field_57++] = 320;
   }

   // $VF: renamed from: a (int, int, int) void
   public static final void method_76(int var0, int var1, int var2) {
      if (method_106(1, var0)) {
         method_96(2, var0, var1, var2);
      }
   }

   // $VF: renamed from: b (int) void
   public static final void method_77(int var0) {
      method_96(5, 63, 0, var0);
   }

   // $VF: renamed from: a (int, int) void
   public static final void method_78(int var0, int var1) {
      if (method_106(0, var0)) {
         method_96(1, var0, var1, 0);
      }
   }

   // $VF: renamed from: g () void
   public static final void method_79() {
      method_103();
      method_80();
   }

   // $VF: renamed from: h () void
   public static final void method_80() {
      method_96(7, 63, 0, 0);
   }

   // $VF: renamed from: a () int
   public static final int method_81() {
      return field_67[1];
   }

   // $VF: renamed from: b () int
   public static final int method_82() {
      return field_67[0];
   }

   // $VF: renamed from: c (int) void
   public static final void method_83(int var0) {
      method_108(var0, 1);
   }

   // $VF: renamed from: d (int) void
   public static final void method_84(int var0) {
      method_108(var0, 0);
   }

   // $VF: renamed from: a (int) boolean
   public static final boolean method_85(int var0) {
      return field_62[var0].field_31 == 1;
   }

   // $VF: renamed from: b (int) boolean
   public static final boolean method_86(int var0) {
      return field_62[var0].field_31 == 2;
   }

   // $VF: renamed from: c (int) boolean
   public static final boolean method_87(int var0) {
      return field_62[var0].field_31 == 0;
   }

   // $VF: renamed from: a (boolean) void
   public static final void method_88(boolean var0) {
      method_126(var0, 1);
   }

   // $VF: renamed from: b (boolean) void
   public static final void method_89(boolean var0) {
      method_126(var0, 0);
   }

   // $VF: renamed from: c (boolean) void
   public static final void method_90(boolean var0) {
      method_126(var0, 1);
      method_126(var0, 0);
   }

   // $VF: renamed from: a () boolean
   public static final boolean method_91() {
      return method_92() || method_93() || method_94();
   }

   // $VF: renamed from: b () boolean
   public static final boolean method_92() {
      return method_102(1);
   }

   // $VF: renamed from: c () boolean
   public static final boolean method_93() {
      return method_102(2);
   }

   // $VF: renamed from: d () boolean
   public static final boolean method_94() {
      return method_102(0);
   }

   // $VF: renamed from: bh (int) void
   private static final void method_95(int var0) {
      if (field_59 < 16) {
         field_58[field_59++] = var0;
      }
   }

   // $VF: renamed from: h (int, int, int, int) void
   private static final void method_96(int var0, int var1, int var2, int var3) {
      method_95(method_97(var0, var1, var2, var3));
   }

   // $VF: renamed from: i (int, int, int, int) int
   private static final int method_97(int var0, int var1, int var2, int var3) {
      return var0 << 28 | var1 << 22 | var2 << 15 | var3 << 0;
   }

   // $VF: renamed from: o (int, int, int) void
   private static final void method_98(int var0, int var1, int var2) {
      for (int var3 = 0; var3 < var0; var3++) {
         if ((var1 == -1 || (field_58[var3] & -268435456) >> 28 == var1) && (var2 == -1 || (field_58[var3] & 264241152) >> 22 == var2)) {
            field_58[var3] = 0;
         }
      }
   }

   // $VF: renamed from: hj () void
   private static final void method_99() {
      for (int var0 = field_59 - 1; var0 >= 0; var0--) {
         int var1;
         if ((var1 = (field_58[var0] & 264241152) >> 22) == 63) {
            var1 = -1;
         }

         switch ((field_58[var0] & -268435456) >> 28) {
            case 1:
               method_98(var0, 1, var1);
               break;
            case 2:
               method_98(var0, 2, var1);
            case 3:
            case 6:
            default:
               break;
            case 4:
               method_98(var0, 1, var1);
               method_98(var0, 4, var1);
               break;
            case 5:
               method_98(var0, 2, -1);
               method_98(var0, 5, var1);
               break;
            case 7:
               method_98(var0, -1, -1);
         }
      }
   }

   // $VF: renamed from: hk () void
   private static final void method_100() {
      int var0 = field_59;

      for (int var1 = 0; var1 < var0; var1++) {
         switch ((field_58[var1] & -268435456) >> 28) {
            case 1:
               method_104(field_58[var1]);
               field_58[var1] = 0;
               break;
            case 2:
               if (method_104(field_58[var1])) {
                  field_58[var1] = 0;
               }
            case 3:
            case 6:
            default:
               break;
            case 4:
               method_105(field_58[var1]);
               field_58[var1] = 0;
               break;
            case 5:
               method_105(field_58[var1]);
               field_58[var1] = 0;
               break;
            case 7:
               method_103();
               field_58[var1] = 0;
         }
      }
   }

   // $VF: renamed from: i () void
   public static final void method_101() {
      if (field_59 != 0) {
         field_60 = 0;

         for (int var0 = 0; var0 < 54; var0++) {
            if (field_63[var0] != null && field_63[var0].method_36(true)) {
               field_60++;
            }
         }

         method_99();
         method_100();
         int var5 = field_59;
         field_59 = 0;

         for (int var1 = 0; var1 < var5; var1++) {
            if (field_58[var1] != 0) {
               field_59++;
            } else {
               for (int var2 = var1 + 1; var2 < var5; var2++) {
                  field_58[var2 - 1] = field_58[var2];
               }

               field_58[var5 - 1] = 0;
               var5--;
               var1--;
            }
         }
      }

      for (int var6 = 0; var6 < 54; var6++) {
         SoundChannel var8;
         if ((var8 = field_63[var6]) != null && var8.field_36 != null && var8.method_42() && var8.field_36.field_33) {
            int var9 = var8.field_36.field_31;
            int var3 = var8.field_36.field_29;
            int var4 = var8.field_42;
            method_105(method_97(4 + var9, var3, 0, 0));
            method_104(method_97(1 + var9, var3, var4, 0));
         }

         if (var8 != null && var8.method_36(true)) {
            var8.method_41();
         }
      }

      for (int var7 = 0; var7 < 3; var7++) {
         field_69[var7] = false;
      }
   }

   // $VF: renamed from: ab (int) boolean
   private static final boolean method_102(int var0) {
      return field_64[var0];
   }

   // $VF: renamed from: hl () void
   private static final void method_103() {
      for (int var0 = 0; var0 < 54; var0++) {
         if (field_63[var0] != null && field_63[var0].method_36(true)) {
            field_63[var0].method_37(0);
         }
      }

      field_60 = 0;
      field_70[1] = -1;
   }

   // $VF: renamed from: ac (int) boolean
   private static final boolean method_104(int var0) {
      int var1 = (var0 & 264241152) >> 22;
      int var2 = (var0 & 4161536) >> 15;
      int var3 = (var0 & 32767) >> 0;
      int var4;
      int var5 = (var4 = (var0 & -268435456) >> 28) - 1;
      if (field_62[var1] == null) {
         return true;
      } else {
         if (var4 == 1) {
            if (field_66) {
               return true;
            }

            if (field_63[var1] != null && field_63[var1].method_36(true)) {
               field_63[var1].method_37(0);
               field_60--;
            }
         } else {
            if (var1 == field_70[1] || var1 == field_70[2]) {
               if (field_66) {
                  return false;
               }

               SoundChannel var7;
               if ((var7 = method_125(var1)) != null) {
                  var7.method_32(var3, var2);
                  return true;
               }

               return false;
            }

            for (int var6 = 0; var6 < 54; var6++) {
               if (field_63[var6] != null && field_63[var6].method_36(true) && field_63[var6].field_36.field_29 == var1) {
                  method_125(var1).method_32(var3, var2);
                  field_70[var5] = var1;
                  return true;
               }
            }
         }

         if (!field_66 && method_127(var5)) {
            if (var5 != 0 && field_70[var5] != -1 && method_125(field_70[var5]).method_38() > field_62[var1].field_32) {
               return true;
            } else {
               if (field_60 >= 4) {
                  method_107(var1);
               }

               if (field_60 < 4) {
                  if (field_63[var1].method_33(var3, var2)) {
                     field_60++;
                     if (var5 != 0) {
                        field_70[var5] = var1;
                     }

                     return true;
                  } else {
                     return false;
                  }
               } else {
                  return true;
               }
            }
         } else {
            return !field_62[var1].field_33;
         }
      }
   }

   // $VF: renamed from: bi (int) void
   private static final void method_105(int var0) {
      int var1 = (var0 & 264241152) >> 22;
      int var2 = (var0 & 32767) >> 0;
      int var4 = ((var0 & -268435456) >> 28) - 4;

      for (int var5 = 0; var5 < 54; var5++) {
         if (field_63[var5] != null
            && field_63[var5].method_36(true)
            && field_63[var5].field_36.field_31 == var4
            && (var1 == 63 || field_63[var5].field_36.field_29 == var1)) {
            field_63[var5].method_37(var2);
            field_60--;
         }
      }

      if (var4 != 0) {
         field_70[var4] = -1;
      }
   }

   // $VF: renamed from: l (int, int) boolean
   private static boolean method_106(int var0, int var1) {
      return field_62[var1] == null ? false : var0 == 1 && method_85(var1) || var0 == 2 && method_86(var1) || var0 == 0 && method_87(var1);
   }

   // $VF: renamed from: a (int) b
   private static final SoundChannel method_107(int var0) {
      AudioSpec var1;
      int var2 = (var1 = field_62[var0]).field_32;
      int var3 = var1.field_31;
      int var4 = -1;
      int var5 = Integer.MAX_VALUE;

      for (int var6 = 0; var6 < 54; var6++) {
         if (field_63[var6] != null && field_63[var6].method_36(true)) {
            int var7 = field_63[var6].method_38();
            int var8 = field_63[var6].field_36.field_31;
            if (field_63[var6].field_36.field_31 == 0 && var7 <= var2 && var7 <= var5
               || var8 != 0 && var3 == 0 && var7 < var2 && var7 < var5
               || var8 != 0 && var3 != 0 && var7 <= var2 && var7 < var5) {
               var4 = var6;
               var5 = var7;
            }
         }
      }

      if (var4 == -1) {
         return null;
      } else {
         boolean var14 = field_63[var4].field_36.field_33;
         int var15 = field_63[var4].field_36.field_29;
         int var16 = field_63[var4].field_36.field_31;
         int var9 = field_63[var4].field_42;
         method_105(method_97(4 + var16, var15, 0, 0));
         if (var14 && var16 != var3) {
            boolean var10 = true;

            for (int var11 = 0; var11 < field_59; var11++) {
               int var12 = (field_58[var11] & -268435456) >> 28;
               int var13 = (field_58[var11] & 264241152) >> 22;
               if (var12 == 7 || var12 == 4 + var16 && (var13 == -1 || var13 == var15) || var12 == 1 + var16 && var13 == var15) {
                  var10 = false;
                  break;
               }
            }

            if (var10) {
               method_96(1 + var16, var15, var9, 0);
            }
         }

         return field_63[var4];
      }
   }

   // $VF: renamed from: M (int, int) void
   private static final void method_108(int var0, int var1) {
      if (field_67[var1] != var0) {
         int var2 = field_67[var1];
         if (var0 == 0 && var2 != 0) {
            method_126(false, var1);
            field_67[var1] = var0;
         } else if (var0 != 0 && var2 == 0) {
            field_68[var1] = var0;
            method_126(true, var1);
         } else {
            field_69[var1] = true;
            field_67[var1] = var0;
         }
      }
   }

   // $VF: renamed from: d (int) boolean
   public static boolean method_109(int var0) {
      return field_69[var0];
   }

   // $VF: renamed from: j () void
   public static final void method_110() {
      if (!field_65) {
         DataInputStream var0 = null;

         try {
            InputStream var1 = web.Resources.open(method_176("/audio"));
            (var0 = new DataInputStream(var1)).skipBytes(3);
            int var2 = var0.readUnsignedByte();
            int var3 = 4;

            for (int var4 = 0; var4 < var2; var4++) {
               var3++;
               if (var0.readBoolean()) {
                  boolean var5 = var0.readBoolean();
                  int var6 = var0.readUnsignedByte();
                  int var7 = var0.readUnsignedByte();
                  int var8 = var0.readUnsignedByte();
                  boolean var9 = var0.readBoolean();
                  byte var10 = var0.readByte();
                  var3 += 6;
                  int var11 = var10;
                  if (var10 == -1) {
                     var11 = var4;
                  }

                  int var12 = var3;
                  if (var11 != var4) {
                     var12 = field_62[var11].field_35;
                  }

                  field_62[var4] = method_131(var4, var6, var7, var8, var5, var9, var11, var12);
                  if (var10 == -1) {
                     int var13 = var0.readInt();
                     var0.skipBytes(var13);
                     var3 += 4 + var13;
                  }
               }
            }

            var0.close();
         } catch (Exception var14) {
         var14.printStackTrace();
         }

         field_65 = true;
      }
   }

   // $VF: renamed from: k () void
   public static void method_111() {
      method_110();
   }

   // $VF: renamed from: c () int
   public static final int method_112() {
      int var0 = 0;

      for (int var1 = 0; var1 < 54; var1++) {
         boolean var2;
         if (var2 = method_123(var1)) {
            var0++;
         }

         if (!var2) {
            field_61[var1] = null;
            if (field_63[var1] != null) {
               field_63[var1].method_48();
               field_63[var1] = null;
            }
         }
      }

      return var0;
   }

   // $VF: renamed from: l () void
   public static final void method_113() {
      if (field_77 == null) {
         field_77 = new DataInputStream(web.Resources.open(method_176("/audio")));
         field_81 = 0;
         field_80 = 0;
      }
   }

   // $VF: renamed from: a (c) byte[]
   private static final byte[] method_114(AudioSpec var0) {
      try {
         field_77.skipBytes(var0.field_35 - field_81);
         int var1;
         byte[] var2 = new byte[var1 = field_77.readInt()];
         method_169(field_77, var2, 0, var1);
         field_81 = var0.field_35 + 4 + var1;
         return var2;
      } catch (Exception var3) {
         var3.printStackTrace();
         return null;
      }
   }

   // $VF: renamed from: a (int) java.lang.Object
   public static final Object method_115(int var0) {
      return method_114(field_62[var0]);
   }

   // $VF: renamed from: ad (int) boolean
   private static final boolean method_116(int var0) {
      for (int var1 = var0 + 1; var1 < 54; var1++) {
         if (method_117(var0, var1)) {
            return true;
         }
      }

      return false;
   }

   // $VF: renamed from: m (int, int) boolean
   private static final boolean method_117(int var0, int var1) {
      return field_61[var1] == null && field_62[var1] != null && field_62[var1].field_34 == var0;
   }

   // $VF: renamed from: a (int, java.lang.Object) void
   private static void method_118(int var0, Object var1) {
      field_61[var0] = var1;
      if (field_63[var0] != null) {
         field_63[var0].method_48();
      }

      field_63[var0] = method_130();
      field_63[var0].method_29(field_62[var0]);
   }

   // $VF: renamed from: e () boolean
   public static final boolean method_119() {
      if (field_80 < 54) {
         boolean var0 = method_123(field_80);
         boolean var1 = field_61[field_80] == null && var0;
         boolean var2 = method_116(field_80);
         if (var1 || var2) {
            Object var3;
            if (!var1 && (!var2 || field_61[field_80] != null)) {
               var3 = field_61[field_80];
            } else {
               var3 = method_115(field_80);
            }

            if (var1) {
               method_118(field_80, var3);
            }

            if (var2) {
               for (int var4 = field_80 + 1; var4 < 54; var4++) {
                  if (method_117(field_80, var4)) {
                     method_118(var4, var3);
                  }
               }
            }
         }

         if (var0) {
            field_75[1]++;
         }

         field_80++;
      }

      if (field_80 == 54) {
         method_124();
         return true;
      } else {
         return false;
      }
   }

   // $VF: renamed from: m () void
   public static final void method_120() {
      field_66 = true;

      for (int var0 = 0; var0 < 54; var0++) {
         if (field_63[var0] != null) {
            field_63[var0].method_30(true);
         }
      }
   }

   // $VF: renamed from: n () void
   public static final void method_121() {
      field_66 = false;

      for (int var0 = 0; var0 < 54; var0++) {
         if (field_63[var0] != null) {
            field_63[var0].method_31();
         }
      }
   }

   // $VF: renamed from: e (int) void
   public static final void method_122(int var0) {
      if (var0 == 1 || var0 == 2) {
         int var1;
         if ((var1 = field_70[var0]) != -1) {
            AudioSpec var2;
            if ((var2 = field_62[var1]) != null) {
               SoundChannel var3;
               if ((var3 = method_125(var1)) != null) {
                  int var4 = var3.field_42;
                  method_96(4 + var0, 63, 0, 0);
                  if (var2.field_33) {
                     method_96(1 + var0, var1, var4, 0);
                  }
               }
            }
         }
      }
   }

   // $VF: renamed from: ae (int) boolean
   private static boolean method_123(int var0) {
      return field_62[var0] != null && method_173(method_260(7, var0, 0));
   }

   // $VF: renamed from: o () void
   public static void method_124() {
      if (field_77 != null) {
         try {
            field_77.close();
         } catch (Exception var0) {
         var0.printStackTrace();
         }

         field_77 = null;
      }
   }

   // $VF: renamed from: b (int) b
   private static final SoundChannel method_125(int var0) {
      for (int var1 = 0; var1 < 54; var1++) {
         SoundChannel var2;
         if ((var2 = field_63[var1]) != null && var2.field_36 != null && var2.field_36.field_29 == var0 && var2.method_36(true)) {
            return var2;
         }
      }

      return null;
   }

   // $VF: renamed from: b (boolean, int) void
   private static final void method_126(boolean var0, int var1) {
      if (var0 != method_102(var1)) {
         field_64[var1] = var0;
         if (var0) {
            if (field_68[var1] != 0) {
               field_67[var1] = field_68[var1];
            } else {
               field_67[var1] = 3;
            }

            if (var1 != 0) {
               for (int var2 = 0; var2 < 54; var2++) {
                  if (field_63[var2] != null && field_63[var2].field_36 != null && field_63[var2].field_36.field_31 == var1) {
                     field_63[var2].method_31();
                     field_69[var1] = true;
                  }
               }

               return;
            }
         } else {
            field_68[var1] = field_67[var1];
            field_67[var1] = 0;
            if (var1 == 0) {
               method_96(4, 63, 0, 0);
               return;
            }

            for (int var3 = 0; var3 < 54; var3++) {
               if (field_63[var3] != null && field_63[var3].field_36 != null && field_63[var3].field_36.field_31 == var1) {
                  field_63[var3].method_30(false);
                  field_69[var1] = false;
               }
            }
         }
      }
   }

   // $VF: renamed from: af (int) boolean
   private static final boolean method_127(int var0) {
      return field_64[var0] && field_67[var0] != 0;
   }

   // $VF: renamed from: a (int) int
   public static final int method_128(int var0) {
      return field_67[var0];
   }

   // $VF: renamed from: f () boolean
   public static boolean method_129() {
      for (int var0 = 0; var0 < 54; var0++) {
         if (field_63[var0] != null && field_63[var0].method_36(true)) {
            return true;
         }
      }

      return false;
   }

   // $VF: renamed from: a () b
   public static SoundChannel method_130() {
      return new GameAudio();
   }

   // $VF: renamed from: a (int, int, int, int, boolean, boolean, int, int) c
   public static AudioSpec method_131(int var0, int var1, int var2, int var3, boolean var4, boolean var5, int var6, int var7) {
      return new AudioSpec(var0, var1, var2, var3, var4, var6, var7);
   }

   // $VF: renamed from: a (int) long
   public static final long method_132(int var0) {
      switch (var0) {
         case 5:
            return 33778259933265943L;
         case 22:
            return 15728960L;
         case 24:
            return 562954263855156L;
         case 42:
            return 13792522976231462L;
         case 77:
            return 13229989634899989L;
         case 79:
            return 13229989634900010L;
         case 84:
            return 10133404115271722L;
         case 89:
            return 10133451359912117L;
         case 91:
            return 10133687583113342L;
         case 93:
            return 10133451359911974L;
         case 100:
            return 9007723252285517L;
         case 102:
            return 6193102335508502L;
         case 105:
            return 6192780212961447L;
         default:
            return -1L;
      }
   }

   // $VF: renamed from: a (int) java.lang.String
   public static final String method_133(int var0) {
      return var0 < 0 ? null : field_71[var0];
   }

   // $VF: renamed from: b (int) java.lang.String
   public static final String method_134(int var0) {
      return var0 >= 56 ? method_293(3 + var0 - 56) : field_71[8 + var0];
   }

   // $VF: renamed from: p () void
   public static final void method_135() {
      try {
         DataInputStream var0;
         (var0 = new DataInputStream(web.Resources.open("/pris" + method_286()))).readUnsignedByte();
         var0.readUnsignedByte();
         var0.readUnsignedByte();
         int var1 = var0.readUnsignedShort();
         int var2 = 5;

         for (int var3 = 0; var3 < var1; var3++) {
            int var4 = var0.readUnsignedShort();
            var2 += 2;
            field_72[var4] = var2;
            int var5 = var0.readUnsignedShort();
            var0.skipBytes(var5);
            var2 += 2 + var5;
         }

         var0.close();
      } catch (Exception var6) {
         var6.printStackTrace();
      }
   }

   // $VF: renamed from: d () int
   public static final int method_136() {
      int var0 = 0;

      for (int var1 = 0; var1 < 421; var1++) {
         if (method_173(method_260(5, var1, 0))) {
            if (field_71[var1] == null && field_72[var1] != 0) {
               var0++;
            }
         } else {
            field_71[var1] = null;
         }
      }

      return var0;
   }

   // $VF: renamed from: q () void
   public static final void method_137() {
      if (field_77 == null) {
         field_77 = new DataInputStream(web.Resources.open("/pris" + method_286()));
         field_81 = 0;
         field_80 = -1;
         method_141();
      }
   }

   // $VF: renamed from: g () boolean
   public static final boolean method_138() {
      boolean var0 = false;

      while (field_80 < 421 && !var0) {
         try {
            field_77.skipBytes(field_72[field_80] - field_81);
            int var1 = field_77.readUnsignedShort();
            if (field_71[field_80] == null) {
               field_71[field_80] = field_77.readUTF();
               field_75[1]++;
               var0 = true;
            } else {
               field_77.skipBytes(var1);
            }

            field_81 = field_72[field_80] + 2 + var1;
            method_141();
         } catch (Exception var3) {
         var3.printStackTrace();
         }
      }

      if (field_80 == 421) {
         try {
            field_77.close();
         } catch (Exception var2) {
         var2.printStackTrace();
         }

         field_77 = null;
         return true;
      } else {
         return false;
      }
   }

   // $VF: renamed from: r () void
   public static final void method_139() {
      if (field_73 != null) {
         field_73 = null;
         method_413(true);
      } else {
         field_79 = field_78;
         field_78 = -1;
         method_136();
         method_137();

         while (!method_138()) {
         }

         StringBuffer var0 = new StringBuffer();
         StringBuffer var1 = new StringBuffer();

         try {
            DataInputStream var2;
            for (short var3 = (var2 = new DataInputStream(web.Resources.open(method_176("/$check")))).readShort();
               var3 != -1;
               var3 = var2.readShort()
            ) {
               byte var4 = var2.readByte();

               for (int var5 = 0; var5 < var4; var5++) {
                  byte var6 = var2.readByte();
                  int var7 = var2.readUnsignedByte();
                  byte var8;
                  byte var9 = var8 = var2.readByte();
                  if (var6 != 0) {
                     var9 = var2.readByte();
                  }

                  String var10 = method_133(var3);
                  var1.setLength(0);
                  int var11;
                  if (var10 != null && (var11 = method_142(var10, var9, var8, var7, var6 != 0, var6 == 2)) != 0) {
                     if (var1.length() != 0) {
                        var1.append(",");
                     }

                     var1.append(var5);
                     var1.append(":");
                     var1.append(var11);
                  }
               }

               if (var1.length() != 0) {
                  if (var0.length() != 0) {
                     var0.append("; ");
                  }

                  var0.append((int)var3);
                  var0.append("=");
                  var0.append((Object)var1);
               }
            }

            var2.close();
            System.gc();

            try {
               Thread.sleep(50L);
            } catch (Exception var12) {
         var12.printStackTrace();
            }
         } catch (Exception var13) {
         var13.printStackTrace();
         }

         field_78 = field_79;
         method_136();
         method_137();

         while (!method_138()) {
         }

         field_73 = var0.toString();
      }
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int) void
   public static final void method_140(Graphics var0, int var1, int var2) {
      if (field_73 != null) {
         if (field_73.length() > 0) {
            Graphics var3 = field_51;
            field_51 = var0;
            method_61(15728960L);
            method_65(16711680);
            int var4 = method_381(true, true);
            method_331(var0, 0, 0, field_52, field_53, field_73, var4, var4, 20);
            method_64();
            field_51 = var3;
            return;
         }

         method_313(var0, 65280);
         method_315(var0, 0, 0, var1, var2 >> 1);
      }
   }

   // $VF: renamed from: hm () void
   private static void method_141() {
      field_80++;

      while (field_80 < 421 && (!method_173(method_260(5, field_80, 0)) || field_72[field_80] == 0)) {
         field_80++;
      }
   }

   // $VF: renamed from: a (java.lang.String, int, int, int, boolean, boolean) int
   private static final int method_142(String var0, int var1, int var2, int var3, boolean var4, boolean var5) {
      long var6;
      int var8 = (int)(var6 = method_132(var3)) & 65535;
      int var9 = (int)(var6 >> 16) & 65535;
      if (var4) {
         if (!var5) {
            int var10000 = method_333(var9, var8, var0, var1, var2);
            boolean var10 = false;
            if (var10000 > var8) {
               return 5;
            }
         } else {
            int var13 = method_211(var0.indexOf("{h}") >= 0 ? var1 : var2);
            boolean var11 = false;
            if (var13 > var8 && var8 > 0) {
               return 5;
            }
         }

         int var12;
         if ((var12 = method_143(var0, var9, var1, var2, var5)) != 0) {
            return var12;
         }
      } else {
         if (method_213(var2) == 1 && method_212(var0, 0, var0.length(), var2)) {
            return 2;
         }

         if (method_208(var2, var0) > var9 && var9 > 0) {
            return 4;
         }

         if (method_211(var2) > var8 && var8 > 0) {
            return 5;
         }
      }

      return 0;
   }

   // $VF: renamed from: a (java.lang.String, int, int, int, boolean) int
   private static final int method_143(String var0, int var1, int var2, int var3, boolean var4) {
      int var5 = var0.length();
      int var6 = 0;
      int var7 = -1;
      int var8 = 0;

      int var9;
      while (var6 < var5 && (var9 = method_334(var7 = method_336(var7, var0, var6, var2, var3), var1, var0, var6)) != 0) {
         var8++;
         if (method_213(var7) == 1 && method_212(var0, var6, var9, var7)) {
            return 2;
         }

         if ((var6 += var9) >= var5) {
            break;
         }

         char var10;
         if ((var10 = var0.charAt(var6 - 1)) != ' ' && var10 != '-' && var10 != 173 && var10 != 8203 && var10 != '|') {
            return 3;
         }
      }

      return (!var4 || var8 <= 256) && (var4 || var8 <= 20) ? 0 : 6;
   }

   // $VF: renamed from: a (java.lang.String) java.lang.String
   public static final String method_144(String var0) {
      return method_145(var0, "\\u");
   }

   // $VF: renamed from: a (java.lang.String, java.lang.String) java.lang.String
   public static final String method_145(String var0, String var1) {
      StringBuffer var2 = new StringBuffer();
      if (var0 != null) {
         int var3 = var0.indexOf(var1);
         int var4 = -2;

         for (int var5 = var0.length(); var3 < var5 && var3 >= 0; var3 = var0.indexOf(var1, var3 + 1)) {
            if (var3 > 0) {
               var2.append(var0.substring(var4 >= 0 ? var4 + 6 : 0, var3));
            }

            var2.append(method_146(var0.substring(var3 + 2, var3 + 6)));
            var4 = var3;
         }

         if (var4 > 0) {
            var2.append(var0.substring(var4 + 6));
         } else if (var4 == -2) {
            var2.append(var0);
         }
      }

      return var2.toString();
   }

   // $VF: renamed from: b (java.lang.String) java.lang.String
   public static final String method_146(String var0) {
      return String.valueOf((char)Short.parseShort(var0.trim(), 16));
   }

   // $VF: renamed from: b (int) int
   public static final int method_147(int var0) {
      if (var0 == 0) {
         return 0;
      } else {
         return var0 < 0 ? -1 : 1;
      }
   }

   // $VF: renamed from: a (int, int) int
   public static final int method_148(int var0, int var1) {
      return var0 > var1 ? var0 : var1;
   }

   // $VF: renamed from: b (int, int) int
   public static final int method_149(int var0, int var1) {
      return var0 < var1 ? var0 : var1;
   }

   // $VF: renamed from: a (int, int, int) int
   public static final int method_150(int var0, int var1, int var2) {
      if (var0 < var1) {
         return var1;
      } else {
         return var0 > var2 ? var2 : var0;
      }
   }

   // $VF: renamed from: c (int, int) int
   public static final int method_151(int var0, int var1) {
      var0 &= 511;
      long var2 = 0L;
      switch (var0 >> 7) {
         case 0:
            var2 = field_74[var0];
            break;
         case 1:
            var2 = field_74[256 - var0];
            break;
         case 2:
            var2 = -field_74[var0 - 256];
            break;
         case 3:
            var2 = -field_74[512 - var0];
      }

      return (int)(var2 * var1 >> 16);
   }

   // $VF: renamed from: c (int) int
   public static final int method_152(int var0) {
      int var1;
      return ((var1 = GameClock.method_22()) < 0 ? -var1 : var1) % var0;
   }

   // $VF: renamed from: a (java.lang.StringBuffer, int, java.lang.String) void
   public static final void method_153(StringBuffer var0, int var1, String var2) {
      for (int var3 = 0; var3 < var0.length(); var3++) {
         if (var0.charAt(var3) == '{') {
            int var4 = 0;

            for (int var5 = var3 + 1; var5 < var3 + 4 && var5 < var0.length(); var5++) {
               int var6;
               if ((var6 = var0.charAt(var5) - '0') < 0 || var6 >= 10) {
                  if (var6 == 77 && var4 == var1) {
                     var0.delete(var3, ++var5);
                     var0.insert(var3, var2);
                     var3 += var2.length() - 1;
                  }
                  break;
               }

               var4 = var4 * 10 + var6;
            }
         }
      }
   }

   // $VF: renamed from: a (java.lang.String, int, char) java.lang.String
   public static final String method_154(String var0, int var1, char var2) {
      int var3 = 0;
      int var4 = var0.length();

      while (var3 <= var4 - 1) {
         int var5;
         if ((var5 = var0.indexOf(var2, var3)) == -1) {
            var5 = var4;
         }

         if (var1 == 0) {
            return var0.substring(var3, var5);
         }

         var1--;
         var3 = var5 + 1;
      }

      return null;
   }

   // $VF: renamed from: d (int) int
   public static final int method_155(int var0) {
      int var1;
      for (var1 = 0; var0 != 0; var1++) {
         var0 &= ~(-var0);
      }

      return var1;
   }

   // $VF: renamed from: c (java.lang.String) java.lang.String
   public static final String method_156(String var0) {
      String var1;
      if ((var1 = field_47.getAppProperty(var0)) != null) {
         var1 = method_145(var1, "\\u");
      }

      return var1;
   }

   // $VF: renamed from: d (int, int) int
   public static final int method_157(int var0, int var1) {
      byte var2 = 0;
      if (var0 < 0) {
         var2 = 8;
      } else if (var0 > 0) {
         var2 = 2;
      }

      if (var1 < 0) {
         var2 |= 1;
      } else if (var1 > 0) {
         var2 |= 4;
      }

      return var2;
   }

   // $VF: renamed from: e (int, int) int
   public static final int method_158(int var0, int var1) {
      int var2 = method_157(var0, var1);
      return (var0 < 0 ? -var0 : var0) >= (var1 < 0 ? -var1 : var1) ? var2 & 10 : var2 & 5;
   }

   // $VF: renamed from: e (int) int
   public static final int method_159(int var0) {
      switch (var0) {
         case 1:
            return 0;
         case 2:
            return 1;
         case 3:
         case 5:
         case 6:
         case 7:
         default:
            return -1;
         case 4:
            return 2;
         case 8:
            return 3;
      }
   }

   // $VF: renamed from: f (int) int
   public static final int method_160(int var0) {
      return ((var0 & 2) >> 1) - ((var0 & 8) >> 3);
   }

   // $VF: renamed from: g (int) int
   public static final int method_161(int var0) {
      return ((var0 & 4) >> 2) - (var0 & 1);
   }

   // $VF: renamed from: e (long) int
   public static final int method_162(long var0) {
      if (var0 == 0L) {
         return 0;
      } else {
         int var2 = (int)(var0 >> 32);
         int var3;
         int var4 = (var3 = (int)var0) < 0 ? -var3 : var3;
         int var5;
         if (var2 >= 0) {
            int var6 = method_267(var2 - var4, var2 + var4);
            var5 = 64 - method_269(var6);
         } else {
            int var9 = method_267(var2 + var4, var4 - var2);
            var5 = 192 - method_269(var9);
         }

         if (var3 < 0) {
            var5 = 512 - var5;
         }

         return var5;
      }
   }

   // $VF: renamed from: a (long, long, long, int) boolean
   public static final boolean method_163(long var0, long var2, long var4, int var6) {
      int var7 = (int)(var4 >> 32) - (int)(var2 >> 32);
      int var8 = (int)var4 - (int)var2;
      int var9 = (int)(var0 >> 32);
      int var10 = (int)var0;
      if (var9 < 0) {
         var8 += var6;
         if (var10 < 0) {
            var7 -= var6;
         } else {
            var7 += var6;
         }
      } else {
         var8 -= var6;
         if (var10 < 0) {
            var7 -= var6;
         } else {
            var7 += var6;
         }
      }

      if (var7 == 0) {
         if (var9 > 0) {
            return var8 > 0;
         } else {
            return var9 < 0 ? var8 < 0 : false;
         }
      } else {
         int var11 = method_267(var8, var7);
         if (var9 == 0) {
            return var10 < 0 ? var7 > 0 : var7 < 0;
         } else {
            int var12 = method_267(var10, var9);
            return (var7 <= 0 || var9 <= 0) && (var7 >= 0 || var9 >= 0) ? var11 < var12 : var11 > var12;
         }
      }
   }

   // $VF: renamed from: e (int) boolean
   public static final boolean method_164(int var0) {
      return method_174(var0, null, true, true);
   }

   // $VF: renamed from: a (int, int[]) boolean
   public static final boolean method_165(int var0, int[] var1) {
      return method_174(var0, var1, true, true);
   }

   // $VF: renamed from: e () int
   public static final int method_166() {
      return field_78;
   }

   // $VF: renamed from: s () void
   public static final void method_167() {
      field_89 = true;
   }

   // $VF: renamed from: a (java.lang.String) int
   public static final int method_168(String var0) {
      int var1 = 0;

      try {
         DataInputStream var2;
         var1 = (var2 = new DataInputStream(web.Resources.open(var0))).read(field_76);
         var2.close();
      } catch (Exception var3) {
         var3.printStackTrace();
      }

      return var1;
   }

   // $VF: renamed from: a (java.io.DataInputStream, byte[], int, int) int
   public static final int method_169(DataInputStream var0, byte[] var1, int var2, int var3) throws Exception {
      var0.readFully(var1, var2, var3);
      return var3;
   }

   // $VF: renamed from: a (int[], int[]) boolean
   private static final boolean method_170(int[] var0, int[] var1) {
      if (var1 == null && var0 == null) {
         return false;
      } else if (var1 != null && var0 != null && var1.length == var0.length) {
         for (int var3 = var1.length - 1; var3 >= 0; var3--) {
            if (var1[var3] != var0[var3]) {
               return true;
            }
         }

         return false;
      } else {
         return true;
      }
   }

   // $VF: renamed from: a (int, int) boolean
   public static final boolean method_171(int var0, int var1) {
      return (method_260(8, var0, 0) & var1) != 0;
   }

   // $VF: renamed from: h () boolean
   public static final boolean method_172() {
      return false;
   }

   // $VF: renamed from: f (int) boolean
   public static final boolean method_173(int var0) {
      return method_171(var0, field_78);
   }

   // $VF: renamed from: a (int, int[], boolean, boolean) boolean
   private static final boolean method_174(int var0, int[] var1, boolean var2, boolean var3) {
      if (method_129()) {
         field_75[0] = 1;
         field_75[1] = 0;
         return false;
      } else {
         long var4 = GameClock.method_21();
         if (!field_88) {
            field_87 = var4;
            method_264(var0);
            int var11;
            field_86 = (var11 = method_1627()) == 0;
            if (!field_86) {
               field_75[0] = var11;
               field_75[1] = 0;
            } else {
               field_75[0] = 1;
               field_75[1] = 0;
            }

            field_88 = true;
            return false;
         } else if (field_89 || var0 != field_78 || method_170(var1, field_82)) {
            field_89 = false;
            field_78 = var0;
            if (var1 != null) {
               if (field_82 == null || field_82.length != var1.length) {
                  field_82 = new int[var1.length];
               }

               System.arraycopy(var1, 0, field_82, 0, var1.length);
            } else {
               field_82 = null;
            }

            int var10;
            if (field_86) {
               var10 = 0;
            } else {
               var10 = field_75[0];
            }

            int var7;
            field_84 = (var7 = method_187()) == 0;
            var7 += 0;
            int var8;
            field_85 = (var8 = method_112()) == 0;
            int var9;
            field_83 = (var9 = method_136()) == 0;
            field_75[0] = var10 + var7 + var8 + var9;
            if (var3) {
               System.gc();
            }

            return false;
         } else if (field_83 && field_84 && field_85 && field_86) {
            if (var4 - field_87 < 1000L) {
               return false;
            } else {
               field_88 = false;
               return true;
            }
         } else {
            int var6 = field_44;

            while (method_175() && var2 && GameClock.method_21() - var4 < var6) {
            }

            return false;
         }
      }
   }

   // $VF: renamed from: bx () boolean
   private static boolean method_175() {
      if (!field_84) {
         field_84 = method_188();
         return true;
      } else if (!field_85) {
         method_113();
         field_85 = method_119();
         return true;
      } else if (!field_83) {
         method_137();
         field_83 = method_138();
         return true;
      } else if (!field_86) {
         field_86 = field_47.method_1626();
         return true;
      } else {
         return false;
      }
   }

   // $VF: renamed from: d (java.lang.String) java.lang.String
   public static String method_176(String var0) {
      if (var0.startsWith("/")) {
         var0 = var0.substring(1);
      }

      return "/" + var0;
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int, int) void
   public static final void method_177(Graphics var0, int var1, int var2, int var3) {
      method_200(var0, var1, var2, var3, 0);
   }

   // $VF: renamed from: ag (int) boolean
   private static final boolean method_178(int var0) {
      return field_90[var0] != null;
   }

   // $VF: renamed from: h (int) int
   public static final int method_179(int var0) {
      return field_90[var0][7] & 65535;
   }

   // $VF: renamed from: a (short[]) int
   private static final int method_180(short[] var0) {
      short var1;
      return ((var1 = var0[2]) & 128) != 0 ? (var1 & 127) * 10 : var1 & 127;
   }

   // $VF: renamed from: i (int) int
   public static final int method_181(int var0) {
      return field_90[var0][5] & 65535;
   }

   // $VF: renamed from: j (int) int
   public static final int method_182(int var0) {
      return field_90[var0][6] & 65535;
   }

   // $VF: renamed from: k (int) int
   public static final int method_183(int var0) {
      return field_90[var0][3];
   }

   // $VF: renamed from: l (int) int
   public static final int method_184(int var0) {
      return field_90[var0][4];
   }

   // $VF: renamed from: a (int, int) javax.microedition.lcdui.Image
   public static final Image method_185(int var0, int var1) {
      int var2 = method_196(field_90[var0], var1);
      return field_94[var2];
   }

   // $VF: renamed from: t () void
   public static final void method_186() {
      try {
         field_90 = new short[177][];
         DataInputStream var0;
         (var0 = new DataInputStream(web.Resources.open(method_176("/outfits")))).skipBytes(3);
         field_96 = var0.readUnsignedShort();
         field_91 = new byte[field_96][];
         field_95 = new byte[field_96];
         field_94 = new Image[field_96];

         for (int var1 = 0; var1 < field_96; var1++) {
            byte[] var3 = new byte[5];
            method_169(var0, var3, 2, 3);
            field_91[var1] = var3;
         }

         int var13 = var0.readUnsignedShort();
         var0.readByte();

         for (int var2 = 0; var2 < var13; var2++) {
            byte[] var15 = new byte[14];
            method_169(var0, var15, 0, 14);
            int var4 = var0.readUnsignedShort();
            byte[] var5 = new byte[4 * var4 << 1];
            method_169(var0, var5, 0, 4 * var4 << 1);
            int var6;
            byte[] var7 = new byte[(var6 = var0.readUnsignedShort()) << 1];
            method_169(var0, var7, 0, var6 << 1);
            short[] var8 = new short[8 + 4 * var4 + 1 + var6];
            field_90[var2] = var8;

            for (int var9 = 0; var9 < 7; var9++) {
               var8[var9] = method_255(var15, var9 << 1);
            }

            var8[7] = (short)var4;

            for (int var21 = 0; var21 < 4 * var4; var21++) {
               var8[8 + var21] = method_255(var5, var21 << 1);
            }

            var8[8 + 4 * var4] = (short)var6;

            for (int var22 = 0; var22 < var6; var22++) {
               var8[8 + 4 * var4 + 1 + var22] = method_255(var7, var22 << 1);
            }

            int var23 = method_195(var2);

            for (int var10 = 0; var10 < var23; var10++) {
               int var11 = method_196(var8, var10);
               field_91[var11][0] = var15[0];
               field_91[var11][1] = var15[1];
            }
         }

         int var14;
         field_92 = new byte[var14 = var0.readUnsignedShort()][];
         field_93 = new byte[var14][];

         for (int var16 = 0; var16 < var14; var16++) {
            int var17;
            byte[] var18 = new byte[var17 = var0.readUnsignedShort() * 3];
            method_169(var0, var18, 0, var17);
            field_92[var16] = var18;
            int var19;
            if ((var19 = var0.readUnsignedShort()) > 0) {
               byte[] var20 = new byte[var19];
               method_169(var0, var20, 0, var19);
               field_93[var16] = var20;
            }
         }

         var0.close();
      } catch (Exception var12) {
         var12.printStackTrace();
      }
   }

   // $VF: renamed from: f () int
   public static final int method_187() {
      int var0 = 0;

      for (int var1 = 0; var1 < field_96; var1++) {
         field_95[var1] = 0;
      }

      for (int var7 = 0; var7 < 177; var7++) {
         if (method_192(var7)) {
            int var2 = method_195(var7);
            short[] var4 = field_90[var7];

            for (int var5 = 0; var5 < var2; var5++) {
               int var6 = method_196(var4, var5);
               field_95[var6] = 1;
            }
         }
      }

      for (int var3 = 0; var3 < field_96; var3++) {
         if (field_95[var3] == 0) {
            field_94[var3] = null;
         } else if (field_94[var3] == null) {
            var0++;
         }
      }

      field_80 = 0;
      field_97 = true;
      return var0;
   }

   // $VF: renamed from: i () boolean
   public static final boolean method_188() {
      boolean var0 = false;

      while (field_80 < field_96 && !var0) {
         var0 = method_190();
      }

      if (field_80 == field_96) {
         try {
            field_77.close();
         } catch (Exception var1) {
         var1.printStackTrace();
         }

         field_77 = null;
         return true;
      } else {
         return false;
      }
   }

   // $VF: renamed from: a (byte[]) byte[]
   public static byte[] method_189(byte[] var0) {
      return var0;
   }

   // $VF: renamed from: by () boolean
   private static boolean method_190() {
      boolean var0 = false;

      try {
         if (field_77 == null) {
            field_77 = new DataInputStream(web.Resources.open(method_176("/images")));
            field_77.skipBytes(5);
         }

         int var1 = method_194(field_80);
         if (field_80 != 0 && var1 != method_194(field_80 - 1)) {
            field_101 = false;
            if (field_97) {
               int var2 = method_197();
               field_77.skipBytes(var2);
            }

            field_97 = true;
         }

         boolean var4 = method_193(var1, field_80);
         if (field_95[field_80] == 1 && field_94[field_80] == null) {
            field_97 = false;
            field_94[field_80] = method_198(var4);
            var0 = true;
         }
      } catch (Exception var3) {
         var3.printStackTrace();
      }

      field_80++;
      return var0;
   }

   // $VF: renamed from: ah (int) boolean
   private static boolean method_191(int var0) {
      if (field_82 != null) {
         for (int var2 = field_82.length - 1; var2 >= 0; var2--) {
            if (field_82[var2] == var0) {
               return true;
            }
         }
      }

      return false;
   }

   // $VF: renamed from: ai (int) boolean
   private static boolean method_192(int var0) {
      return method_178(var0) && (method_173(method_260(6, var0, 0)) || method_191(var0));
   }

   // $VF: renamed from: n (int, int) boolean
   private static boolean method_193(int var0, int var1) {
      if (!field_101 || var1 <= 0 || var0 != method_194(var1 - 1)) {
         return false;
      } else {
         return field_94[var1 - 1] != null ? true : method_193(var0, var1 - 1);
      }
   }

   // $VF: renamed from: T (int) int
   private static int method_194(int var0) {
      byte[] var1;
      return ((var1 = field_91[var0])[3] & 0xFF) << 8 | var1[4] & 0xFF;
   }

   // $VF: renamed from: U (int) int
   private static int method_195(int var0) {
      return field_90[var0][8 + method_179(var0) * 4];
   }

   // $VF: renamed from: a (short[], int) int
   private static final int method_196(short[] var0, int var1) {
      int var2 = 8 + (var0[7] & '\uffff') * 4;
      short var3 = var0[var2];
      int var4 = var1 % var3;
      return var0[var2 + 1 + var4];
   }

   // $VF: renamed from: ae () int
   private static int method_197() throws Exception {
      field_99 = field_77.readUnsignedShort();
      field_100 = field_77.readUnsignedShort();
      return field_99 * field_100;
   }

   // $VF: renamed from: a (boolean) javax.microedition.lcdui.Image
   private static Image method_198(boolean var0) throws Exception {
      Image var1 = null;
      var1 = method_199(var0);
      field_75[1]++;
      return var1;
   }

   // $VF: renamed from: b (boolean) javax.microedition.lcdui.Image
   private static final Image method_199(boolean var0) throws Exception {
      byte[] var1;
      int var2 = ((var1 = field_91[field_80])[0] & 255) << 8 | var1[1] & 255;
      int var3 = var1[2] & 255;
      if (!var0) {
         field_99 = field_77.readUnsignedShort();
         field_100 = field_77.readUnsignedShort();
         field_101 = true;
         field_98 = field_76;
         method_169(field_77, field_98, 0, field_99 * field_100);
      }

      byte[] var4 = field_92[var2];
      Object var5 = null;
      var5 = field_93[var2];
      return method_275(field_98, field_99, field_100, var4, (byte[])var5, var3);
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int, int, int) void
   public static final void method_200(Graphics var0, int var1, int var2, int var3, int var4) {
      if (RemasterArt.suppressSprite(var1)) return;
      drawOriginalSprite(var0, var1, var2, var3, var4);
   }

   private static void drawOriginalSprite(Graphics var0, int var1, int var2, int var3, int var4) {
      short[] var5 = field_90[var1];
      var2 += var5[3];
      var3 += var5[4];
      int var6 = var5[5] & '\uffff';
      int var7 = var5[6] & '\uffff';
      short var8 = var5[1];
      int var9 = var5[7] & '\uffff';
      int var10 = method_180(var5);
      int var11 = var4;
      short var12 = 0;
      if (var9 > 0) {
         var11 = var4 / var10 % var9;
         int var13 = 8 + var11 * 4;
         var12 = var5[1 + var13];
         var2 += var5[2 + var13];
         var3 += var5[3 + var13];
         var11 = var5[0 + var13] & '\uffff';
      }

      boolean var21 = true;
      Image var14 = null;
      int var17 = var9 * 4 + 13;
      if (var5.length <= var17) {
         int var15 = (var14 = field_94[method_196(var5, 0)]).getWidth();
         int var16 = var14.getHeight();
         if (var6 == 0 || var7 == 0 || var15 <= var6 && var16 <= var7 || var16 <= var6 && var15 <= var7) {
            var21 = false;
         }
      } else {
         var21 = false;
      }

      if (var21) {
         if ((var8 & 8) > 0) {
            var2 -= var6;
         } else if ((var8 & 1) > 0) {
            var2 -= var6 >> 1;
         }

         if ((var8 & 32) > 0) {
            var3 -= var7;
         } else if ((var8 & 2) > 0) {
            var3 -= var7 >> 1;
         }

         if (!RemasterArt.sprite(var0, var1, var2, var3, var6, var7, var4, var12))
            method_273(var0, var2, var3, var6, var7, var14, var11, var12);
      } else {
         var14 = field_94[method_196(var5, var11)];
         int artWidth = var14.getWidth(), artHeight = var14.getHeight();
         int artX = var2 - ((var8 & 8) != 0 ? artWidth : (var8 & 1) != 0 ? artWidth / 2 : 0);
         int artY = var3 - ((var8 & 32) != 0 ? artHeight : (var8 & 2) != 0 ? artHeight / 2 : 0);
         if (RemasterArt.sprite(var0, var1, artX, artY, artWidth, artHeight, var4, var12)) return;
         if (var12 == 0) {
            var0.drawImage(var14, var2, var3, var8);
         } else {
            method_272(var0, var14, var2, var3, var8, var12);
         }
      }
   }

   // $VF: renamed from: b (int, int) void
   public static final void method_201(int var0, int var1) {
      byte[] var2;
      (var2 = new byte[7])[0] = 0;
      var2[1] = 0;
      var2[2] = (byte)method_321(var1);
      var2[3] = (byte)method_322(var1);
      var2[4] = (byte)method_323(var1);
      var2[5] = 0;
      var2[6] = 0;
      field_104[var0] = var2;
      field_106[var0] = Font.getFont(0, 0, 0);
   }

   // $VF: renamed from: f (int, int) int
   public static final int method_202(int var0, int var1) {
      if (var1 == 7) {
         return method_220(field_104[var0]);
      } else {
         return var1 == 10 ? method_219(field_104[var0]) : field_104[var0][var1];
      }
   }

   // $VF: renamed from: a (int, java.lang.String, int, int, int) int
   public static final int method_203(int var0, String var1, int var2, int var3, int var4) {
      return method_205(var0, field_51, var1, var2, var3, var4);
   }

   // $VF: renamed from: a (int, javax.microedition.lcdui.Graphics, java.lang.Object, int, int, int, int, int) int
   public static final int method_204(int var0, Graphics var1, Object var2, int var3, int var4, int var5, int var6, int var7) {
      if (var1 == field_51 && var4 > 0 && var2 instanceof String) {
         web.Browser.recordText(((String)var2).substring(var3,var3+var4),var5+var1.getTranslateX(),var6+var1.getTranslateY());
      }
      byte var8;
      if ((var8 = field_104[var0][0]) == 0) {
         return method_217(var0, var1, var2, var3, var4, var5, var6, var7);
      } else {
         return var8 == 1 ? method_221(var0, var1, var2, var3, var4, var5, var6, var7) : 0;
      }
   }

   // $VF: renamed from: a (int, javax.microedition.lcdui.Graphics, java.lang.String, int, int, int) int
   public static final int method_205(int var0, Graphics var1, String var2, int var3, int var4, int var5) {
      return method_204(var0, var1, var2, 0, var2.length(), var3, var4, var5);
   }

   // $VF: renamed from: a (int, char) int
   public static final int method_206(int var0, char var1) {
      byte var2;
      if ((var2 = field_104[var0][0]) == 0) {
         return method_218(var0, var1);
      } else if (var2 == 1) {
         byte[] var3;
         boolean var4 = (var3 = field_104[var0])[12] != 0;
         return method_224(var3, field_105[var0], var1, var4);
      } else {
         return 0;
      }
   }

   // $VF: renamed from: b (int, char) int
   public static final int method_207(int var0, char var1) {
      if (RussianFont.supports(var1)) return 0;
      byte var2;
      if ((var2 = field_104[var0][0]) == 0) {
         return 0;
      } else if (var2 == 1) {
         byte var3 = field_104[var0][13];
         return method_225(field_104[var0], field_102[var3], var1);
      } else {
         return 0;
      }
   }

   // $VF: renamed from: a (int, java.lang.Object) int
   public static final int method_208(int var0, Object var1) {
      return var1 instanceof String ? method_209(var0, var1, 0, ((String)var1).length()) : method_209(var0, var1, 0, ((char[])var1).length);
   }

   // $VF: renamed from: a (int, java.lang.Object, int, int) int
   public static final int method_209(int var0, Object var1, int var2, int var3) {
      byte var4;
      if ((var4 = field_104[var0][0]) != 0) {
         return var4 == 1 ? method_226(var0, var1, var2, var3) : 0;
      } else if (var3 == 0) {
         return 0;
      } else {
         boolean var5 = var1 instanceof String;
         int var6 = var2 + var3;
         boolean var8 = (var5 ? ((String)var1).charAt(var2) : ((char[])var1)[var2]) == '{';

         while (var2 < var6 && var8) {
            var2++;
            if (!(var8 = (var5 ? ((String)var1).charAt(var2) : ((char[])var1)[var2]) != '}')) {
               if (++var2 < var6) {
                  var8 = (var5 ? ((String)var1).charAt(var2) : ((char[])var1)[var2]) == '{';
               }
            }
         }

         var3 = var6 - var2;
         if ((var5 ? ((String)var1).charAt(var2 + var3 - 1) : ((char[])var1)[var2 + var3 - 1]) == ' ') {
            var3--;
         }

         byte var9 = field_104[var0][5];
         int var10;
         if (var1 instanceof String) {
            var10 = field_106[var0].substringWidth((String)var1, var2, var3);
         } else {
            var10 = field_106[var0].charsWidth((char[])var1, var2, var3);
         }

         return var10 + var9 * (var3 - 1);
      }
   }

   // $VF: renamed from: m (int) int
   public static final int method_210(int var0) {
      byte var1;
      if ((var1 = field_104[var0][0]) == 0) {
         return field_106[var0].getBaselinePosition() + field_104[var0][6];
      } else {
         return var1 == 1 ? method_228(var0) : 0;
      }
   }

   // $VF: renamed from: n (int) int
   public static final int method_211(int var0) {
      byte var1;
      if ((var1 = field_104[var0][0]) == 0) {
         return field_106[var0].getHeight();
      } else {
         return var1 == 1 ? method_227(var0) : 0;
      }
   }

   // $VF: renamed from: a (java.lang.String, int, int, int) boolean
   public static final boolean method_212(String var0, int var1, int var2, int var3) {
      byte var4 = field_104[var3][13];
      byte[][] var5 = field_102[var4];

      for (int var6 = var1; var6 < var1 + var2; var6++) {
         char var7;
         if ((var7 = var0.charAt(var6)) != '{' && var7 != '}' && var7 != '|' && var7 != 173 && var7 != 8203 && !RussianFont.supports(var7) && method_222(var5, var7) == -2) {
            return true;
         }
      }

      return false;
   }

   // $VF: renamed from: o (int) int
   public static final int method_213(int var0) {
      return field_104[var0][0];
   }

   // $VF: renamed from: a (int, byte[][][], int, int) int
   private static final int method_214(int var0, byte[][][] var1, int var2, int var3) {
      short var4 = method_255(field_76, var2);
      var2 += 2;
      if (var4 > 0) {
         var1[var0] = new byte[var4][];

         for (int var5 = 0; var5 < var4; var5++) {
            int var6;
            if ((var6 = field_76[var2++] & 255) != 0) {
               int var7 = field_76[var2++] & 255;
               byte[] var8 = new byte[64];
               var1[var0][var5] = var8;

               for (int var9 = 0; var9 < 64; var9++) {
                  var8[var9] = (byte)var3;
               }

               System.arraycopy(field_76, var2, var8, var7, var6);
               var2 += var6;
            }
         }
      }

      return var2;
   }

   // $VF: renamed from: u () void
   public static final void method_215() {
      method_168(method_176("/fnt"));
      int var13 = 3;
      var13++;
      byte var1;
      field_102 = new byte[var1 = field_76[3]][][];
      field_103 = new byte[var1][][];

      for (int var2 = 0; var2 < var1; var2++) {
         var13 += 2;
         var13 = method_214(var2, field_102, var13, -2);
         var13 = method_214(var2, field_103, var13, -1);
         int var3 = 5; // The original fnt resource contains five language patch tables.

         for (int var4 = 0; var4 < var3; var4++) {
            byte var5 = method_252(field_76, var13);
            var13++;

            for (int var6 = 0; var6 < var5; var6++) {
               if (var4 == method_298("en,de,es,fr,it", method_286())) {
                  char var7 = method_253(field_76, var13);
                  var13 += 2;
                  byte var8 = method_252(field_76, var13);
                  byte var9 = method_252(field_76, ++var13);
                  var13++;
                  method_216(var7, field_102[var2], var8, -2);
                  method_216(var7, field_103[var2], var9, -1);
               } else {
                  var13 += 4;
               }
            }
         }
      }

      byte var19;
      field_105 = new byte[var19 = field_76[var13++]][][];

      for (int var21 = 0; var21 < var19; var21++) {
         var13 += 2;
         short var22 = method_255(field_76, var13);
         var13 += 2;
         field_104[var21] = new byte[var22];
         System.arraycopy(field_76, var13, field_104[var21], 0, var22);
         var13 += var22;
         if (field_104[var21][0] == 1 && field_104[var21][12] == 1) {
            var13 = method_214(var21, field_105, var13, field_104[var21][1]);
         }
      }

      for (int var18 = 0; var18 < 7; var18++) {
         if (field_104[var18][0] == 0) {
            var19 = field_104[var18][1];
            field_106[var18] = Font.getFont(var19 & 96, var19 & 7, var19 & 24);
         }
      }
   }

   // $VF: renamed from: a (char, byte[][], byte, int) void
   private static final void method_216(char var0, byte[][] var1, byte var2, int var3) {
      if (var1[var0 >> 6] == null) {
         var1[var0 >> 6] = new byte[64];

         for (int var4 = 0; var4 < 64; var4++) {
            var1[var0 >> 6][var4] = (byte)var3;
         }
      }

      var1[var0 >> 6][var0 & '?'] = var2;
   }

   // $VF: renamed from: b (int, javax.microedition.lcdui.Graphics, java.lang.Object, int, int, int, int, int) int
   private static final int method_217(int var0, Graphics var1, Object var2, int var3, int var4, int var5, int var6, int var7) {
      if (var4 == 0) {
         return 0;
      } else {
         byte[] var8 = field_104[var0];
         method_313(var1, (var8[2] & 255) << 16 | (var8[3] & 255) << 8 | var8[4] & 255);
         Font var9 = field_106[var0];
         var1.setFont(var9);
         if ((var7 & 2) != 0) {
            var7 = var7 ^ 2 | 16;
            var6 -= method_211(var0) / 2;
         }

         var6 += var8[6];
         boolean var10 = var2 instanceof String;
         byte var11;
         if ((var11 = var8[5]) != 0) {
            int var16;
            for (var16 = var5; var4 > 0; var4--) {
               char var13 = var10 ? ((String)var2).charAt(var3) : ((char[])var2)[var3];
               var1.drawChar(var13, var5, var6, var7);
               var5 += var9.charWidth(var13) + var11;
               var3++;
            }

            return var5 - var16 - var11;
         } else if (var10) {
            String var15 = (String)var2;
            var1.drawSubstring(var15, var3, var4, var5, var6, var7);
            return var9.substringWidth(var15, var3, var4);
         } else {
            char[] var12 = (char[])var2;
            var1.drawChars(var12, var3, var4, var5, var6, var7);
            return var9.charsWidth(var12, var3, var4);
         }
      }
   }

   // $VF: renamed from: c (int, char) int
   private static final int method_218(int var0, char var1) {
      return field_106[var0].charWidth(var1);
   }

   // $VF: renamed from: b (byte[]) int
   private static final int method_219(byte[] var0) {
      return var0[10] & 0xFF | (var0[11] & 0xFF) << 8;
   }

   // $VF: renamed from: c (byte[]) int
   private static final int method_220(byte[] var0) {
      return var0[7] & 0xFF | (var0[8] & 0xFF) << 8;
   }

   // $VF: renamed from: c (int, javax.microedition.lcdui.Graphics, java.lang.Object, int, int, int, int, int) int
   private static final int method_221(int var0, Graphics var1, Object var2, int var3, int var4, int var5, int var6, int var7) {
      if (var4 == 0) {
         return 0;
      } else {
         byte[] var8 = field_104[var0];
         var6 += var8[3];
         int var9 = method_220(var8);
         int var10 = method_227(var0);
         byte var11 = var8[6];
         if ((var7 & 8) > 0) {
            var5 -= method_226(var0, var2, var3, var4);
         } else if ((var7 & 1) > 0) {
            var5 -= method_226(var0, var2, var3, var4) >> 1;
         }

         if ((var7 & 32) > 0) {
            var6 -= var10;
         } else if ((var7 & 2) > 0) {
            var6 -= var10 >> 1;
         } else if ((var7 & 64) > 0) {
            var6 -= var10 - var8[4];
         }

         // Keep original wrapping and anchors, with smooth complete text runs.
         if (var4 > 0) {
            String modernText = var2 instanceof String ? ((String)var2).substring(var3,var3+var4) : new String((char[])var2,var3,var4);
            int modernWidth = method_226(var0,var2,var3,var4);
            var1.drawModernText(modernText,var5,var6,modernWidth,var10);
            return modernWidth;
         }
         int var12 = var5;
         byte var13 = var8[13];
         boolean var14 = var8[12] != 0;
         byte[][] var15 = field_102[var13];
         byte[][] var16 = field_105[var0];
         byte[][] var17 = field_103[var13];
         boolean var18;
         int var19;
         if (var18 = var8[9] != 0) {
            var19 = method_219(var8);
         } else {
            var19 = 0;
         }

         byte var20 = var8[14];
         boolean var21;
         String var22;
         char[] var23;
         if (var21 = var2 instanceof String) {
            var22 = (String)var2;
            var23 = null;
         } else {
            var22 = null;
            var23 = (char[])var2;
         }

         var4 += var3;

         for (int var24 = -1; var3 < var4; var3++) {
            char var25;
            if ((var25 = var21 ? var22.charAt(var3) : var23[var3]) != 173) {
               int var26 = method_224(var8, var16, var25, var14);
               if (RussianFont.supports(var25)) {
                  var1.drawCyrillic(var25, var5, var6, var26, method_182(var9), method_185(var9, 0));
                  var5 += var26;
                  if (var3 != var4 - 1) var5 -= var20;
                  var24 = 0;
                  continue;
               }
               int var27;
               switch (var27 = method_222(var15, var25)) {
                  case -2:
                     method_313(var1, 16711680);
                     method_315(var1, var5, var6, method_181(var9), var10);
                     break;
                  case -1:
                     if (var24 != -1) {
                        var5 += var20;
                     }
                     break;
                  default:
                     var1.setTextImageMode(true);
                     method_200(var1, var9, var5, var6, var27);
                     var1.setTextImageMode(false);
                     int var28;
                     if (var18 && (var28 = method_223(var17, var25)) != -1) {
                        method_200(var1, var19, var5, var6 + var11, var28);
                     }

                     if (var3 != var4 - 1) {
                        var5 -= var20;
                     }
               }

               var5 = var5 + var26 + method_225(var8, var15, var25);
               var24 = var27;
            }
         }

         return var5 - var12;
      }
   }

   // $VF: renamed from: a (byte[][], char) int
   private static final int method_222(byte[][] var0, char var1) {
      if (var1 == ' ') {
         return -1;
      } else {
         int var2;
         return (var2 = var1 >> 6) < var0.length && var0[var2] != null ? var0[var2][var1 & 63] : -2;
      }
   }

   // $VF: renamed from: b (byte[][], char) int
   private static final int method_223(byte[][] var0, char var1) {
      int var2;
      return (var2 = var1 >> 6) < var0.length && var0[var2] != null ? var0[var2][var1 & 63] : -1;
   }

   // $VF: renamed from: a (byte[], byte[][], char, boolean) int
   private static final int method_224(byte[] var0, byte[][] var1, char var2, boolean var3) {
      if (RussianFont.supports(var2)) return RussianFont.width(var0, var2);
      if (var2 == ' ') {
         return 0;
      } else if (var3) {
         int var4;
         return (var4 = var2 >> 6) < var1.length && var1[var4] != null ? var1[var4][var2 & 63] : var0[1];
      } else {
         return var0[1];
      }
   }

   // $VF: renamed from: a (byte[], byte[][], char) int
   private static final int method_225(byte[] var0, byte[][] var1, char var2) {
      if (RussianFont.supports(var2)) return 0;
      int var3 = var2 >> 6;
      return var2 != 32 && var3 < var1.length && var1[var3] != null ? 0 : var0[2];
   }

   // $VF: renamed from: b (int, java.lang.Object, int, int) int
   private static final int method_226(int var0, Object var1, int var2, int var3) {
      if (var3 == 0) {
         return 0;
      } else {
         int var4 = 0;
         byte var5 = 0;
         var5 = field_104[var0][14];
         byte[] var6;
         byte var7 = (var6 = field_104[var0])[13];
         boolean var8 = var6[12] != 0;
         byte[][] var9 = field_105[var0];
         byte[][] var10 = field_102[var7];
         boolean var11;
         String var12;
         char[] var13;
         if (var11 = var1 instanceof String) {
            var12 = (String)var1;
            var13 = null;
         } else {
            var12 = null;
            var13 = (char[])var1;
         }

         char var14 = ' ';

         for (int var15 = 0; var15 < var3; var15++) {
            char var16;
            if ((var16 = var11 ? var12.charAt(var2 + var15) : var13[var2 + var15]) != '|') {
               if (var16 == '{') {
                  while (true) {
                     var15++;
                     if ((var11 ? var12.charAt(var2 + var15) : var13[var2 + var15]) == '}' || var15 >= var3) {
                        break;
                     }
                  }
               } else {
                  if (var16 == 173 || var16 == 8203) {
                     var15++;
                  }

                  var4 = var4 + method_224(var6, var9, var16, var8) + method_225(var6, var10, var16);
                  if (var16 != ' ' && var15 < var3 - 1) {
                     var4 -= var5;
                  } else if (var16 == ' ' && var14 != ' ') {
                     var4 += var5;
                  }

                  var14 = var16;
               }
            }
         }

         return var4;
      }
   }

   // $VF: renamed from: V (int) int
   private static final int method_227(int var0) {
      byte[] var1;
      return method_182(method_220(var1 = field_104[var0])) + var1[3] + var1[4];
   }

   // $VF: renamed from: W (int) int
   private static final int method_228(int var0) {
      byte[] var1;
      return method_182(method_220(var1 = field_104[var0])) + var1[3] + field_104[var0][5];
   }

   // $VF: renamed from: v () void
   public static final void method_229() {
      field_108++;
      field_109 = 0;
      if (field_108 >= 7) {
         field_108 = -1;
         field_107 = null;
         method_413(true);
      } else if (field_104[field_108][0] == 1
         && method_185(method_220(field_104[field_108]), 0) != null
         && method_185(method_219(field_104[field_108]), 0) != null) {
         byte var1 = field_104[field_108][13];
         byte[][] var2 = field_102[var1];
         StringBuffer var3 = new StringBuffer();

         for (int var4 = 0; var4 < var2.length; var4++) {
            if (var2[var4] != null) {
               for (int var5 = 0; var5 < 64; var5++) {
                  int var6 = (var4 << 6) + var5;
                  int var7;
                  if ((var7 = method_222(var2, (char)var6)) != -1 && var7 != -2) {
                     var3.append((char)var6);
                  }
               }
            }
         }

         field_107 = var3.toString();
      } else {
         method_229();
      }
   }

   // $VF: renamed from: b (javax.microedition.lcdui.Graphics, int, int) void
   public static final void method_230(Graphics var0, int var1, int var2) {
      if (field_107 != null) {
         method_313(var0, 6710886);
         method_315(var0, 0, 0, var1, var2);
         int var3 = (method_211(field_108) + 0) * 20;
         method_331(var0, 0, -field_109 * 320 / 2, var1, var3, field_107, field_108, field_108, 6);
      }
   }

   // $VF: renamed from: g () int
   public static final int method_231() {
      return method_472();
   }

   // $VF: renamed from: g (int) boolean
   public static final boolean method_232(int var0) {
      if (var0 >= -255 && var0 <= 255) {
         int var1 = (var0 & 511) >> 3;
         int var2 = var0 & 7;
         return (field_114[var1] & 1 << var2) != 0;
      } else {
         return false;
      }
   }

   // $VF: renamed from: h (int) boolean
   public static final boolean method_233(int var0) {
      return (field_111 & 1L << var0) > 0L;
   }

   // $VF: renamed from: f (int) void
   public static final void method_234(int var0) {
      field_111 &= ~(1L << var0);
   }

   // $VF: renamed from: g (int) void
   public static final void method_235(int var0) {
      if (var0 >= -255 && var0 <= 255) {
         int var1 = (var0 & 511) >> 3;
         int var2 = var0 & 7;
         field_114[var1] = (byte)(field_114[var1] & ~(1 << var2));
      }
   }

   // $VF: renamed from: w () void
   public static final void method_236() {
      field_111 = 0L;
   }

   // $VF: renamed from: x () void
   public static final void method_237() {
      int var0 = 64;

      while (--var0 >= 0) {
         field_114[var0] = 0;
      }
   }

   // $VF: renamed from: h () int
   public static final int method_238() {
      return field_117;
   }

   // $VF: renamed from: i () int
   public static final int method_239() {
      return field_118;
   }

   // $VF: renamed from: y () void
   public static final void method_240() {
      field_117 = 0;
      field_118 = 0;
   }

   // $VF: renamed from: g (int, int) int
   public static final int method_241(int var0, int var1) {
      int var2 = method_401();
      int var3 = method_238();
      int var4 = method_239();
      return var0 != var3 || var3 >= var4 && var2 - var3 >= var1 ? var3 : -var3;
   }

   // $VF: renamed from: z () void
   public static final void method_242() {
      field_111 = field_111 & ~field_113;
      field_113 = 0L;
      field_112 = 0L;

      for (int var0 = 64; --var0 >= 0; field_115[var0] = 0) {
         field_114[var0] = (byte)(field_114[var0] & ~field_116[var0]);
         field_116[var0] = 0;
      }
   }

   // $VF: renamed from: h (int) void
   public static final void method_243(int var0) {
      synchronized (field_48) {
         if (var0 != 0) {
            field_117 = method_401();
            if (var0 >= -255 && var0 <= 255) {
               int var2 = (var0 & 511) >> 3;
               int var3 = var0 & 7;
               field_115[var2] = (byte)(field_115[var2] | 1 << var3);
               field_114[var2] = (byte)(field_114[var2] | 1 << var3);
               field_116[var2] = (byte)(field_116[var2] & ~(1 << var3));
            }

            if (!method_285(var0)) {
               int var6;
               if ((var6 = method_247(var0)) == 8) {
                  var6 = 0;
               }

               if (method_473(var0)) {
                  var6 = 8;
               }

               if (var6 != 0) {
                  field_112 |= 1L << var6;
                  field_111 |= 1L << var6;
                  field_113 &= ~(1L << var6);
               }

               method_248(var0);
               if (!method_424()) {
                  if (!method_450()) {
                     if (var6 == 0 || !method_422(var6)) {
                        method_425(68);
                     }
                  }
               }
            }
         }
      }
   }

   // $VF: renamed from: i (int) void
   public static final void method_244(int var0) {
      synchronized (field_48) {
         if (var0 != 0) {
            field_118 = method_401();
            if (var0 >= -255 && var0 <= 255) {
               int var2 = (var0 & 511) >> 3;
               int var3 = var0 & 7;
               if ((field_115[var2] & var3) != 0) {
                  field_116[var2] = (byte)(field_116[var2] | 1 << var3);
               } else {
                  field_114[var2] = (byte)(field_114[var2] & ~(1 << var3));
               }
            }

            int var6;
            if ((var6 = method_247(var0)) == 8) {
               var6 = 0;
            }

            if (method_473(var0)) {
               var6 = 8;
            }

            if (var6 != 0) {
               if ((field_112 & 1L << var6) != 0L) {
                  field_113 |= 1L << var6;
               } else {
                  field_111 &= ~(1L << var6);
               }
            }
         }
      }
   }

   // $VF: renamed from: a (int, int, boolean, int) int
   public static final int method_245(int var0, int var1, boolean var2, int var3) {
      if (var3 != 0) {
         var0 += var3;
         var1--;
         if (var0 < 0) {
            var0 = var2 ? var1 : 0;
         }

         if (var0 > var1) {
            var0 = var2 ? 0 : var1;
         }

         method_236();
         method_237();
      }

      return var0;
   }

   // $VF: renamed from: a (int, int, boolean) int
   public static final int method_246(int var0, int var1, boolean var2) {
      return method_245(var0, var1, var2, method_161(method_231()));
   }

   // $VF: renamed from: p (int) int
   public static final int method_247(int var0) {
      if (var0 == 0) {
         return 8;
      } else if (var0 == -6) {
         return 0;
      } else {
         return var0 == -7 ? 0 : field_45.getGameAction(var0);
      }
   }

   // $VF: renamed from: bj (int) void
   private static final void method_248(int var0) {
      if (var0 == 42) {
         field_110 = 0;
      } else if (var0 != 35) {
         if (var0 >= 48 && var0 <= 57) {
            field_110 <<= 4;
            field_110 |= var0 - 48;
         }
      } else if (field_110 == 0) {
         field_110 = -1;
      } else {
         method_1142(field_110);
         if (field_110 == 2168) {
            method_59();
         } else if (field_110 == 1927 && method_286() != null) {
            method_139();
         } else if (field_110 == 872) {
            method_229();
         } else if (field_110 == 13954) {
            field_109++;
         } else if (field_110 == 13960) {
            field_109--;
         }

         field_110 = -1;
      }
   }

   // $VF: renamed from: b (java.lang.String) void
   public static final void method_249(String var0) {
      String var1 = "pris" + var0;

      try {
         RecordStore var2;
         if ((var2 = RecordStore.openRecordStore(var1, false)) == null) {
            method_51(var0);
         } else if (var2.getNumRecords() == 0) {
            method_51(var0);
         } else {
            var2.getRecord(1, field_76, 0);
            method_52(var0, field_76, 0);
            var2.closeRecordStore();
         }
      } catch (Exception var3) {
         var3.printStackTrace();
         method_51(var0);
      }
   }

   // $VF: renamed from: c (java.lang.String) void
   public static final void method_250(String var0) {
      String var1 = "pris" + var0;

      try {
         int var2 = 0;
         var2 = method_53(var0, field_76, 0);
         RecordStore var3;
         if ((var3 = RecordStore.openRecordStore(var1, true)).getNumRecords() == 0) {
            var3.addRecord(field_76, 0, var2);
         } else {
            var3.setRecord(1, field_76, 0, var2);
         }

         var3.closeRecordStore();
      } catch (Exception var4) {
         var4.printStackTrace();
      }
   }

   // $VF: renamed from: a (byte[], int) boolean
   public static final boolean method_251(byte[] var0, int var1) {
      return var0[var1] != 0;
   }

   // $VF: renamed from: a (byte[], int) byte
   public static final byte method_252(byte[] var0, int var1) {
      return var0[var1];
   }

   // $VF: renamed from: a (byte[], int) char
   public static final char method_253(byte[] var0, int var1) {
      return (char)(var0[var1] << '\b' | var0[var1 + 1] & 255);
   }

   // $VF: renamed from: a (byte[], int) int
   public static final int method_254(byte[] var0, int var1) {
      return var0[var1] << 24 | (var0[var1 + 1] & 0xFF) << 16 | (var0[var1 + 2] & 0xFF) << 8 | var0[var1 + 3] & 0xFF;
   }

   // $VF: renamed from: a (byte[], int) short
   public static final short method_255(byte[] var0, int var1) {
      return (short)(var0[var1] << 8 | var0[var1 + 1] & 255);
   }

   // $VF: renamed from: b (byte[], int) int
   public static final int method_256(byte[] var0, int var1) {
      return (var0[var1] & 0xFF) << 8 | var0[var1 + 1] & 0xFF;
   }

   // $VF: renamed from: a (byte[], int, boolean) int
   public static final int method_257(byte[] var0, int var1, boolean var2) {
      var0[var1++] = (byte)(var2 ? 1 : 0);
      return var1;
   }

   // $VF: renamed from: a (byte[], int, int) int
   public static final int method_258(byte[] var0, int var1, int var2) {
      var0[var1++] = (byte)var2;
      return var1;
   }

   // $VF: renamed from: b (byte[], int, int) int
   public static final int method_259(byte[] var0, int var1, int var2) {
      var0[var1++] = (byte)(var2 >> 24);
      var0[var1++] = (byte)(var2 >> 16);
      var0[var1++] = (byte)(var2 >> 8);
      var0[var1++] = (byte)var2;
      return var1;
   }

   // $VF: renamed from: b (int, int, int) int
   public static final int method_260(int var0, int var1, int var2) {
      byte[] var3 = field_121[var0];
      int var4 = field_123[var0] & '\uffff';
      byte var5 = field_122[var0][var2];
      int var6 = method_265(var0, var4, var2) + var1 * var5;
      int var7 = 0;

      for (int var8 = 0; var8 < var5; var8++) {
         var7 <<= 8;
         short var9 = var3[var6 + var8];
         if (var8 > 0) {
            var9 &= 255;
         }

         var7 |= var9;
      }

      return var7;
   }

   // $VF: renamed from: q (int) int
   public static final int method_261(int var0) {
      return field_123[var0] & 65535;
   }

   // $VF: renamed from: A () void
   public static final void method_262() {
      method_168(method_176("/dbmeta"));
      int var0 = 3;
      var0++;
      field_119 = field_76[3] & 255;
      var0++;
      field_120 = field_76[4] & 255;
      int var1;
      field_122 = new byte[var1 = field_119 + field_120][];
      field_123 = new short[var1];

      for (int var2 = 0; var2 < var1; var2++) {
         int var3;
         byte[] var4 = new byte[var3 = field_76[var0++] & 255];

         for (int var5 = 0; var5 < var3; var5++) {
            var4[var5] = field_76[var0++];
         }

         field_122[var2] = var4;
         short var11 = (short)((short)((field_76[var0++] & 255) << 8) | field_76[var0++] & 255);
         field_123[var2] = var11;
      }

      field_124 = new byte[var1];

      for (int var10 = 0; var10 < var1; var10++) {
         field_124[var10] = method_252(field_76, var0++);
      }

      field_121 = new byte[var1][];
      method_263(null);
   }

   // $VF: renamed from: a (byte[]) void
   public static final void method_263(byte[] var0) {
      int var1;
      int var2;
      String var3;
      if (var0 == null) {
         var1 = field_119;
         var2 = 0;
         var3 = "/db";
      } else {
         var1 = field_120;
         var2 = field_119;
         var3 = "/dbgame";
      }

      boolean var4 = false;
      int var5 = 4;

      for (int var6 = 0; var6 < var1; var6++) {
         boolean var7 = field_124[var6] == 0 || method_172();
         if (field_121[var2 + var6] == null && var7) {
            if (!var4) {
               method_168(method_176(var3));
               var4 = true;

               for (int var8 = 0; var8 < var6; var8++) {
                  var5 += method_256(field_76, var5) + 2;
               }
            }

            int var10;
            byte[] var9 = new byte[var10 = method_256(field_76, var5)];
            System.arraycopy(field_76, var5 + 2, var9, 0, var10);
            field_121[var2 + var6] = var9;
         } else if (!var7) {
            field_121[var2 + var6] = null;
         }

         if (var4) {
            var5 += method_256(field_76, var5) + 2;
         }
      }
   }

   // $VF: renamed from: j (int) void
   public static final void method_264(int var0) {
      int var1 = var0 == 0 ? field_119 : field_120;
      int var2 = var0 == 0 ? 0 : field_119;
      String var3 = var0 == 0 ? "/db" : "/dbgame";
      boolean var4 = false;
      int var5 = 4;

      for (int var6 = 0; var6 < var1; var6++) {
         boolean var7 = field_124[var6] == 0 || method_171(field_124[var6], var0);
         if (field_121[var2 + var6] == null && var7) {
            if (!var4) {
               method_168(method_176(var3));
               var4 = true;

               for (int var8 = 0; var8 < var6; var8++) {
                  var5 += method_256(field_76, var5) + 2;
               }
            }

            int var10;
            byte[] var9 = new byte[var10 = method_256(field_76, var5)];
            System.arraycopy(field_76, var5 + 2, var9, 0, var10);
            field_121[var2 + var6] = var9;
         } else if (!var7) {
            field_121[var2 + var6] = null;
         }

         if (var4) {
            var5 += method_256(field_76, var5) + 2;
         }
      }
   }

   // $VF: renamed from: j (int, int, int) int
   private static final int method_265(int var0, int var1, int var2) {
      int var3 = 0;

      for (int var4 = 0; var4 < var2; var4++) {
         byte var5 = field_122[var0][var4];
         var3 += var1 * var5;
      }

      return var3;
   }

   // $VF: renamed from: h (int, int) int
   public static final int method_266(int var0, int var1) {
      return (int)((long)var0 * var1 >> 12);
   }

   // $VF: renamed from: i (int, int) int
   public static final int method_267(int var0, int var1) {
      return (int)(((long)var0 << 12) / var1);
   }

   // $VF: renamed from: j (int, int) int
   public static final int method_268(int var0, int var1) {
      return (var0 << 12) / var1;
   }

   // $VF: renamed from: r (int) int
   public static final int method_269(int var0) {
      return -((65519 * (var0 * (var0 * var0 >> 12) >> 12) >> 12) - (327664 * var0 >> 12)) >> 12;
   }

   // $VF: renamed from: a (int, int, int, int, int) boolean
   public static final boolean method_270(int var0, int var1, int var2, int var3, int var4) {
      long var5 = var0 - var2;
      long var7 = var1 - var3;
      long var9 = var4;
      return var5 * var5 + var7 * var7 <= var9 * var9;
   }

   // $VF: renamed from: a (java.lang.String) javax.microedition.lcdui.Image
   public static final Image method_271(String var0) {
      try {
         return Image.createImage(var0);
      } catch (Exception var2) {
         var2.printStackTrace();
         return null;
      }
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, javax.microedition.lcdui.Image, int, int, int, int) void
   public static final void method_272(Graphics var0, Image var1, int var2, int var3, int var4, int var5) {
      method_274(var0, var1, 0, 0, var1.getWidth(), var1.getHeight(), var5, var2, var3, var4);
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int, int, int, javax.microedition.lcdui.Image, int, int) void
   public static final void method_273(Graphics var0, int var1, int var2, int var3, int var4, Image var5, int var6, int var7) {
      int var8 = var5.getWidth();
      int var10 = (var3 > var8 ? var3 : var8) / var3;
      int var11 = var6 % var10 * var3;
      int var12 = var6 / var10 * var4;
      method_274(var0, var5, var11, var12, var3, var4, var7, var1, var2, 20);
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, javax.microedition.lcdui.Image, int, int, int, int, int, int, int, int) void
   public static final void method_274(Graphics var0, Image var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9) {
      if ((var9 & 1) != 0) {
         var9 = var9 & -2 | 4;
         var7 -= (var6 > 3 ? var5 : var4) >> 1;
      }

      if ((var9 & 2) != 0) {
         var9 = var9 & -3 | 16;
         var8 -= (var6 > 3 ? var4 : var5) >> 1;
      }

      var0.drawRegion(var1, var2, var3, var4, var5, var6, var7, var8, var9);
   }

   // $VF: renamed from: a (byte[], int, int, byte[], byte[], int) javax.microedition.lcdui.Image
   public static final Image method_275(byte[] var0, int var1, int var2, byte[] var3, byte[] var4, int var5) {
      boolean var6 = method_276(field_125, var0, var1, var2, var3, var4, var5);
      return Image.createRGBImage(field_125, var6 ? var2 : var1, var6 ? var1 : var2, var4 != null);
   }

   // $VF: renamed from: a (int[], byte[], int, int, byte[], byte[], int) boolean
   private static final boolean method_276(int[] var0, byte[] var1, int var2, int var3, byte[] var4, byte[] var5, int var6) {
      int var7 = 0;
      if (var5 != null) {
         var7 = (var5[0] & 255) << 24 | (var5[1] & 255) << 16 | (var5[2] & 255) << 8 | var5[3] & 255;
      }

      boolean var8;
      int var9 = (var8 = (var6 & 3) == 1 || (var6 & 3) == 3) ? var3 : var2;
      int var10 = var8 ? var2 : var3;
      byte[] var11 = method_189(var1);

      for (int var12 = 0; var12 < var10; var12++) {
         for (int var13 = 0; var13 < var9; var13++) {
            int var14 = var12 * var9;
            int var15;
            int var16 = (var15 = var11[var14 + var13] & 255) + 8;
            int var17 = var15 * 3;
            int var18;
            if (var15 < var7) {
               var18 = (var5[var16] & 255) << 24;
            } else {
               var18 = -16777216;
            }

            var18 = var18 | (var4[var17] & 255) << 16 | (var4[var17 + 1] & 255) << 8 | var4[var17 + 2] & 255;
            var0[var14 + var13] = var18;
         }
      }

      return var8;
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int, int, int, int, int) void
   public static final void method_277(Graphics var0, int var1, int var2, int var3, int var4, int var5, int var6) {
      int var7;
      if (((var7 = var0.getColor() | 0xFF000000) & 16777215) == (field_126 & 16777215)) {
         var7 = field_126;
      }

      DirectUtils.getDirectGraphics(var0).fillTriangle(var1, var2, var3, var4, var5, var6, var7);
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int, int, int, int) void
   public static final void method_278(Graphics var0, int var1, int var2, int var3, int var4, int var5) {
      int var6 = var0.getColor();
      method_279(var0, var5);
      method_315(var0, var1, var2, var3, var4);
      method_313(var0, var6);
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int) void
   public static final void method_279(Graphics var0, int var1) {
      field_126 = var1;
      DirectUtils.getDirectGraphics(var0).setARGBColor(var1);
   }

   // $VF: renamed from: B () void
   public final void method_280() {
      this.field_127 = new Timer();
   }

   // $VF: renamed from: C () void
   public final void method_281() {
      this.field_128 = new GameTick();
      this.field_127.schedule(this.field_128, field_44, field_44);
   }

   // $VF: renamed from: D () void
   public final void method_282() {
      if (this.field_128 != null) {
         this.field_128.cancel();
         this.field_128 = null;
      }
   }

   // $VF: renamed from: E () void
   public final void method_283() {
      if (this.field_128 != null) {
         this.field_128.cancel();
         this.field_128 = null;
      }
   }

   // $VF: renamed from: c (javax.microedition.lcdui.Graphics, int, int) void
   public static void method_284(Graphics var0, int var1, int var2) {
      if (!method_394()) {
         method_434();
         method_435();
         method_242();
      }

      method_310(var0, 0, 0, var1, var2);
      method_433(var0);
      method_424();
   }

   // $VF: renamed from: i (int) boolean
   public static boolean method_285(int var0) {
      if (method_394()) {
         if (var0 == -6) {
            method_391();
         }

         return true;
      } else if (var0 == -6) {
         return method_407(0) ? true : method_407(5);
      } else if (var0 == -7) {
         return method_407(1) ? true : method_407(3);
      } else {
         return var0 == 0 ? method_407(3) : false;
      }
   }

   // $VF: renamed from: a () java.lang.String
   public static String method_286() {
      return field_130;
   }

   // $VF: renamed from: j () int
   public static int method_287() {
      return field_131;
   }

   // $VF: renamed from: k () int
   public static int method_288() {
      return field_129;
   }

   // $VF: renamed from: j () boolean
   public static boolean method_289() {
      return method_403() == 10;
   }

   // $VF: renamed from: F () void
   public static void method_290() {
      if (method_415() || method_378()) {
         method_61(15728960L);
         method_65(16777215);
         method_64();
         method_379(false);
         method_370();
      }
   }

   // $VF: renamed from: G () void
   public final void method_291() {
      method_292(field_131);
   }

   // $VF: renamed from: k (int) void
   public static void method_292(int var0) {
      boolean var1 = field_130 == null;
      method_304(var0);
      method_250("la");
      if (!var1) {
         method_215();
         method_135();

         for (int var2 = 0; var2 < 421; var2++) {
            field_71[var2] = null;
         }

         System.gc();
      }
   }

   // $VF: renamed from: c (int) java.lang.String
   public static String method_293(int var0) {
      if (field_130 == null || "ru".equals(field_130)) return RussianFont.SYSTEM_TEXT[var0];
      int var1;
      if (field_130 == null) {
         var1 = 0;
      } else {
         var1 = method_298("en,de,es,fr,it", field_130);
      }

      return method_154(field_149[var0], var1, ',');
   }

   // $VF: renamed from: r (int) java.lang.String
   private static String method_294(int var0) {
      String var1 = method_154(field_132, var0, ',');
      return method_154("English,Deutsch,Español,Français,Italiano,Русский", method_298("en,de,es,fr,it,ru", var1), ',');
   }

   // $VF: renamed from: a () java.lang.String[]
   public static String[] method_295() {
      String[] var0 = new String[field_129];

      for (int var1 = 0; var1 < field_129; var1++) {
         var0[var1] = method_294(var1);
      }

      return var0;
   }

   // $VF: renamed from: H () void
   public static void method_296() {
      int var0;
      if ((var0 = method_161(method_231())) != 0) {
         method_304(field_131 + var0);
         method_237();
         method_236();
         method_413(true);
      }
   }

   // $VF: renamed from: hn () void
   private static void method_297() {
      String var0;
      if ((var0 = field_47.getAppProperty("Multi-Language-Options")) == null) {
         field_132 = "en,de,es,fr,it";
      } else {
         String var5;
         int var1 = method_299(var5 = var0.trim());
         StringBuffer var2 = new StringBuffer();

         for (int var3 = 0; var3 < var1; var3++) {
            String var4 = method_154(var5, var3, ',');
            if (method_298("en,de,es,fr,it,ru", var4) != -1) {
               if (var2.length() != 0) {
                  var2.append(",");
               }

               var2.append(var4);
            }
         }

         field_132 = var2.toString();
      }
   }

   // $VF: renamed from: a (java.lang.String, java.lang.String) int
   private static int method_298(String var0, String var1) {
      int var2 = method_299(var0);

      for (int var3 = 0; var3 < var2; var3++) {
         if (method_154(var0, var3, ',').equals(var1)) {
            return var3;
         }
      }

      return -1;
   }

   // $VF: renamed from: c (java.lang.String) int
   private static int method_299(String var0) {
      int var1 = 0;
      int var2 = -1;

      do {
         if ((var2 = var0.indexOf(",", var2 + 1)) != 0) {
            var1++;
         }
      } while (var2 != -1);

      return var1;
   }

   // $VF: renamed from: I () void
   public static final void method_300() {
      field_133 = method_302();
   }

   // $VF: renamed from: k () boolean
   public static boolean method_301() {
      return field_133;
   }

   // $VF: renamed from: bz () boolean
   private static boolean method_302() {
      method_297();
      field_129 = method_299(field_132);
      field_131 = -1;
      if (field_129 == 1) {
         method_304(0);
         return false;
      } else {
         method_249("la");
         if (field_131 >= 0 && field_131 < field_129) {
            method_304(field_131);
            return false;
         } else {
            method_303();
            if (field_131 == -1) {
               method_304(0);
            }

            return true;
         }
      }
   }

   // $VF: renamed from: ho () void
   private static void method_303() {
      field_131 = -1;
   }

   // $VF: renamed from: l (int) void
   public static void method_304(int var0) {
      if (var0 < 0) {
         var0 = field_129 - 1;
      }

      if (var0 >= field_129) {
         var0 = 0;
      }

      field_131 = var0;
      field_130 = method_154(field_132, field_131, ',');
   }

   // $VF: renamed from: J () void
   public static void method_305() {
      field_131 = -1;
   }

   // $VF: renamed from: c (byte[], int) int
   public static int method_306(byte[] var0, int var1) {
      field_131 = var0[var1++];
      return var1;
   }

   // $VF: renamed from: d (byte[], int) int
   public static int method_307(byte[] var0, int var1) {
      var0[var1++] = (byte)field_131;
      return var1;
   }

   // $VF: renamed from: b (javax.microedition.lcdui.Graphics) void
   public static final void method_308(Graphics var0) {
      field_134 = var0.getClipX();
      field_135 = var0.getClipY();
      field_136 = var0.getClipWidth();
      field_137 = var0.getClipHeight();
   }

   // $VF: renamed from: c (javax.microedition.lcdui.Graphics) void
   public static final void method_309(Graphics var0) {
      method_310(var0, field_134, field_135, field_136, field_137);
   }

   // $VF: renamed from: b (javax.microedition.lcdui.Graphics, int, int, int, int) void
   public static final void method_310(Graphics var0, int var1, int var2, int var3, int var4) {
      var0.setClip(var1, var2, var3, var4);
   }

   // $VF: renamed from: c (javax.microedition.lcdui.Graphics, int, int, int, int) void
   public static final void method_311(Graphics var0, int var1, int var2, int var3, int var4) {
      var0.clipRect(var1, var2, var3, var4);
   }

   // $VF: renamed from: d (javax.microedition.lcdui.Graphics, int, int, int, int) void
   public static final void method_312(Graphics var0, int var1, int var2, int var3, int var4) {
      var0.drawLine(var1, var2, var3, var4);
   }

   // $VF: renamed from: b (javax.microedition.lcdui.Graphics, int) void
   public static final void method_313(Graphics var0, int var1) {
      method_279(var0, ~var1);
      var0.setColor(var1);
   }

   // $VF: renamed from: e (javax.microedition.lcdui.Graphics, int, int, int, int) void
   public static final void method_314(Graphics var0, int var1, int var2, int var3, int var4) {
      var0.drawRect(var1, var2, var3, var4);
   }

   // $VF: renamed from: f (javax.microedition.lcdui.Graphics, int, int, int, int) void
   public static final void method_315(Graphics var0, int var1, int var2, int var3, int var4) {
      if (var3 > 0 && var4 > 0) {
         var0.fillRect(var1, var2, var3, var4);
      }
   }

   // $VF: renamed from: g (javax.microedition.lcdui.Graphics, int, int, int, int) void
   public static final void method_316(Graphics var0, int var1, int var2, int var3, int var4) {
      var0.drawArc(var1, var2, var3, var4, 0, 360);
   }

   // $VF: renamed from: h (javax.microedition.lcdui.Graphics, int, int, int, int) void
   public static final void method_317(Graphics var0, int var1, int var2, int var3, int var4) {
      var0.fillArc(var1, var2, var3, var4, 0, 360);
   }

   // $VF: renamed from: b (javax.microedition.lcdui.Graphics, int, int, int, int, int, int) void
   public static final void method_318(Graphics var0, int var1, int var2, int var3, int var4, int var5, int var6) {
      var0.drawArc(var1, var2, var3, var4, var5, var6);
   }

   // $VF: renamed from: b (javax.microedition.lcdui.Graphics, int, int, int) void
   public static final void method_319(Graphics var0, int var1, int var2, int var3) {
      var0.drawLine(var1, var2, var3, var2);
   }

   // $VF: renamed from: c (javax.microedition.lcdui.Graphics, int, int, int) void
   public static final void method_320(Graphics var0, int var1, int var2, int var3) {
      var0.drawLine(var1, var2, var1, var3);
   }

   // $VF: renamed from: s (int) int
   public static final int method_321(int var0) {
      return var0 >> 16 & 0xFF;
   }

   // $VF: renamed from: t (int) int
   public static final int method_322(int var0) {
      return var0 >> 8 & 0xFF;
   }

   // $VF: renamed from: u (int) int
   public static final int method_323(int var0) {
      return var0 & 0xFF;
   }

   // $VF: renamed from: a (int, int, int, int) int
   public static final int method_324(int var0, int var1, int var2, int var3) {
      return method_325(var0, var2, (var3 << 8) / (var1 + var3));
   }

   // $VF: renamed from: c (int, int, int) int
   public static final int method_325(int var0, int var1, int var2) {
      int var3 = (var0 & 16711935) + (((var1 & 16711935) - (var0 & 16711935)) * var2 >> 8);
      var0 = (var0 & 0xFF00) + (((var1 & 0xFF00) - (var0 & 0xFF00)) * var2 >> 8);
      return var3 & 16711935 | var0 & 0xFF00;
   }

   // $VF: renamed from: k (int, int) int
   public static final int method_326(int var0, int var1) {
      int var2 = (var0 & 16711935) * var1;
      var0 = (var0 & 0xFF00) * var1;
      return (var2 & -16711936 | var0 & 0xFF0000) >>> 8;
   }

   // $VF: renamed from: a () f
   public static final RichTextLayout method_327() {
      int var0;
      return ((var0 = method_260(0, method_403(), 2)) & 0xFF) != 1 ? null : field_138[var0 >> 8 & 0xFF];
   }

   // $VF: renamed from: a (int) f
   public static final RichTextLayout method_328(int var0) {
      return field_138[var0];
   }

   // $VF: renamed from: K () void
   public static final void method_329() {
      RichTextLayout var0;
      method_419(var0 = method_327());
      int var1 = method_260(0, method_403(), 2) >> 16 & 0xFF;
      var0.method_8(var1 == 0 ? field_47.method_344() : method_133(314 + var1));
   }

   // $VF: renamed from: a (f, int, long, int, int, int) void
   public static final void method_330(RichTextLayout var0, int var1, long var2, int var4, int var5, int var6) {
      var0.method_7(var2, var4, var5, var6);
      field_138[var1] = var0;
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int, int, int, java.lang.String, int, int, int) void
   public static final void method_331(Graphics var0, int var1, int var2, int var3, int var4, String var5, int var6, int var7, int var8) {
      method_332(var0, var1, var2, var3, var4, var5, var6, var7, var8, true);
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int, int, int, java.lang.String, int, int, int, boolean) void
   public static final void method_332(Graphics var0, int var1, int var2, int var3, int var4, String var5, int var6, int var7, int var8, boolean var9) {
      boolean var10 = false;
      if (var9) {
         var10 = method_338(var5);
      }

      int var11 = method_333(var3, var4, var5, var6, var7);
      int var12 = 0;
      short var13 = 0;

      for (int var14 = -1; var12 < 20; var12++) {
         short var15;
         if ((var15 = field_139[var12]) < 0) {
            return;
         }

         int var16 = method_211(var14 = method_336(var14, var5, var13, var6, var7)) + 0;
         if (var12 == 0) {
            if ((var8 & 2) != 0) {
               var2 += var4 - var11 >> 1;
               var8 = var8 & -3 | 16;
            } else if ((var8 & 32) != 0) {
               var2 = var2 + var4 - var11;
               var8 = var8 & -33 | 16;
            }
         }

         method_339(var0, var14, var5, var13, var15, -1, var1, var2, var8, var10, var3);
         var2 += var16;
         var13 += var15;
      }
   }

   // $VF: renamed from: a (int, int, java.lang.String, int, int) int
   public static final int method_333(int var0, int var1, String var2, int var3, int var4) {
      int var5 = 0;
      short var6 = 0;
      int var7 = 0;
      int var8 = -1;

      for (int var9 = var2.length(); var7 < 20 && var6 < var9 && var5 < var1; var7++) {
         int var10 = method_211(var8 = method_336(var8, var2, var6, var3, var4)) + 0;
         field_139[var7] = (short)method_334(var8, var0, var2, var6);
         var5 += var10;
         var6 += field_139[var7];
      }

      if (var7 >= 20) {
         return var1 + 1;
      } else {
         while (var7 < 20) {
            field_139[var7] = -1;
            var7++;
         }

         return var5;
      }
   }

   // $VF: renamed from: a (int, int, java.lang.String, int) int
   public static final int method_334(int var0, int var1, String var2, int var3) {
      int var4;
      if ((var4 = var2.length()) >= 1 && var3 < var4) {
         int var5 = -1;
         boolean var6 = false;
         int var7 = var3;
         int var8 = 0;
         int var9 = 0;
         int var10 = 0;
         int var11 = 0;
         if (var0 < 7 && method_213(var0) == 1) {
            var11 = method_202(var0, 14);
         }

         method_340(var2, var3 - 2);
         int var10000 = 'i' == field_140 ? 24 : 0;

         label161:
         while (true) {
            var8 = var10000;

            while (!var6 && var8 < var1 && var7 < var4) {
               char var12;
               if ((var12 = var2.charAt(var7)) == '{') {
                  var10 = 0;
                  var7++;

                  for (; var12 != '}' && var7 < var4; var7++) {
                     if ((var12 = var2.charAt(var7)) == 't') {
                        var8 = (var8 / 24 + 1) * 24;
                     }
                  }
               } else {
                  var8 += var9;
                  var9 = method_207(var0, var12);
                  var8 += method_206(var0, var12);
                  if (var12 == ' ' || var12 == '\t') {
                     var10 = 0;
                     if (var7 < var4 - 1) {
                        char var18;
                        if ((var18 = var2.charAt(var7 + 1)) >= '0' && var18 <= '9') {
                           char var14;
                           if (var7 > 0 && ((var14 = var2.charAt(var7 - 1)) < '0' || var14 > '9')) {
                              var5 = var7;
                              if (var8 > field_141) {
                                 field_141 = var8;
                              }
                           }
                        } else if (var18 != ':' && var18 != '?' && var18 != '!') {
                           var5 = var7;
                           if (var8 > field_141) {
                              field_141 = var8;
                           }
                        }
                     } else {
                        var5 = var7;
                        if (var8 > field_141) {
                           field_141 = var8;
                        }
                     }

                     var7++;
                  } else if (var7 > 0 && var12 == '-' && var8 < var1) {
                     var10 = 0;
                     char var13;
                     if ((var13 = var2.charAt(var7 - 1)) != ' ' && var13 != '}') {
                        var5 = var7;
                        if (var8 > field_141) {
                           field_141 = var8;
                        }
                     }

                     var7++;
                  } else {
                     if ((var12 == 173 || var12 == 8203) && var8 < var1) {
                        var10 = 0;
                        var5 = var7;
                        if (var8 > field_141) {
                           field_141 = var8;
                        }

                        var7++;
                        var10000 = var8 - (method_206(var0, var12) + var9);
                        continue label161;
                     }

                     if (var12 == '|') {
                        var10 = 0;
                        var6 = true;
                        var7++;
                     } else if (0 < var8 && var8 < var1) {
                        var8 -= var10;
                        var10 = var11;
                        var7++;
                     }
                  }
               }
            }

            if (!var6 && var7 < var4) {
               char var17;
               if ((var17 = var2.charAt(var7)) != ' ' && var17 != '\t') {
                  if (var5 > -1) {
                     var7 = var5 + 1;
                  }
               } else {
                  while ((var17 == ' ' || var17 == '\t') && var7 < var4) {
                     var17 = var2.charAt(var7);
                     var7++;
                  }
               }
            }

            if (var8 < var1 && var8 > field_141) {
               field_141 = var8;
            }

            return var7 - var3;
         }
      } else {
         return 0;
      }
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int, java.lang.String, int, short[], int, int, int, int, int, int, boolean) void
   public static final void method_335(
      Graphics var0, int var1, int var2, String var3, int var4, short[] var5, int var6, int var7, int var8, int var9, int var10, int var11, boolean var12
   ) {
      int var13 = var4;
      int var14 = -1;

      for (int var15 = 0; var15 < var8; var15++) {
         short var16 = var5[var7 + var15];
         method_340(var3, var13 + var16 - 2);
         var14 = method_336(var14, var3, var13, var9, var10);
         int var17 = method_70(method_60());
         method_339(var0, var14, var3, var13, var16, var6, var1, var2, var11, var12, var17);
         var2 = var2 + method_211(var14) + 0;
         var13 += var16;
      }
   }

   // $VF: renamed from: b (int, java.lang.String, int, int, int) int
   public static final int method_336(int var0, String var1, int var2, int var3, int var4) {
      int var5 = var1.length();
      if (var0 >= 0) {
         if (var2 > 0 && var1.charAt(var2 - 1) != '|') {
            return var0;
         } else {
            return var5 - var2 > 2 && var1.charAt(var2) == 123 && var1.charAt(var2 + 1) == 104 && var1.charAt(var2 + 2) == 125 ? var3 : var4;
         }
      } else {
         if (var5 - var2 > 2) {
            char var6 = var1.charAt(var2 + 1);
            char var7 = var1.charAt(var2 + 2);

            for (int var8 = var2; var8 >= 0; var8--) {
               char var9;
               if ((var9 = var1.charAt(var8)) == '{' && var6 == 'h' && var7 == '}' && (var8 == 0 || var1.charAt(var8 - 1) == '|')) {
                  return var3;
               }

               if (var9 == '|') {
                  return var4;
               }

               var7 = var6;
               var6 = var9;
            }
         }

         return var4;
      }
   }

   // $VF: renamed from: a (java.lang.String, char, int, int) int
   public static final int method_337(String var0, char var1, int var2, int var3) {
      for (int var4 = var0.indexOf(123, var2); var4 >= var2 && var4 < var3 - 2; var4 = var0.indexOf(123, var4 + 3)) {
         if (var0.charAt(var4 + 1) == var1 && var0.charAt(var4 + 2) == '}') {
            return var4;
         }
      }

      return -1;
   }

   // $VF: renamed from: a (java.lang.String) boolean
   public static final boolean method_338(String var0) {
      return var0.indexOf(173) >= 0 || var0.indexOf(8203) >= 0;
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, java.lang.String, int, int, int, int, int, int, boolean, int) void
   private static final void method_339(
      Graphics var0, int var1, String var2, int var3, int var4, int var5, int var6, int var7, int var8, boolean var9, int var10
   ) {
      int var11 = var4;

      char var12;
      while (var11 > 0 && ((var12 = var2.charAt(var3 + var11 - 1)) == 32 || var12 == 9 || var12 == 124)) {
         var11--;
      }

      if (var5 >= 0) {
         var4 = var5;
      }

      while (var4 > 0 && ((var12 = var2.charAt(var3 + var4 - 1)) == ' ' || var12 == '\t' || var12 == '|')) {
         var4--;
      }

      if (var9) {
         StringBuffer var19 = new StringBuffer();

         for (int var13 = 0; var13 < var4; var13++) {
            char var14;
            if ((var14 = var2.charAt(var3 + var13)) != 173 && var14 != 8203) {
               var19.append(var14);
            } else if (var13 == var4 - 1) {
               if (var14 == 173) {
                  var19.append('-');
               } else {
                  var19.append(' ');
               }
            }
         }

         var2 = var19.toString();
         var3 = 0;
         var11 = var4 = var2.length();
      }

      var12 = (char) (var3 + var4);
      int var21;
      if ((var21 = method_337(var2, 'r', var3, var12)) >= var3) {
         var12 = (char) (var21 + 3);
      }

      if (field_140 != 0) {
         if (field_140 == 'c') {
            var8 = (var8 | 1) & -13;
         } else {
            var8 = (var8 | 4) & -10;
            if (field_140 == 'i') {
               int var22 = var2.indexOf("{i}", var3);
               boolean var10000 = var3 < var22 && var22 < var3 + var4 ? var2.charAt(var22 - 1) != '}' : false;
               boolean var15 = false;
               if (!var10000) {
                  var6 += 24;
               }
            }
         }
      }

      if ((var8 & 1) != 0) {
         var6 += var10 - method_209(var1, var2, var3, var11) >> 1;
         var8 = var8 & -2 | 4;
      } else if ((var8 & 8) != 0) {
         var6 += var10;
      }

      int var24 = var3;

      for (int var16 = var2.indexOf(123, var3); var16 >= 0 && var16 < var12; var16 = var2.indexOf(123, ++var24)) {
         var6 += method_204(var1, var0, var2, var24, var16 - var24, var6, var7, var8);
         if ((var24 = var2.indexOf(125, var24)) < 0 || var24 >= var12) {
            var24 = var12;
            break;
         }

         if (var2.charAt(var24 - 1) == 't') {
            var6 = (var6 / 24 + 1) * 24;
         }
      }

      method_204(var1, var0, var2, var24, var12 - var24, var6, var7, var8);
      if (var12 < var3 + var4) {
         char var17 = field_140;
         field_140 = 0;
         method_339(var0, var1, var2, var12, var4 + var3 - var12, var5, 0, var7, 24, var9, var10);
         field_140 = var17;
      }
   }

   // $VF: renamed from: a (java.lang.String, int) void
   private static final void method_340(String var0, int var1) {
      for (int var2 = var1; var2 >= 0; var2--) {
         char var3;
         if ((var3 = var0.charAt(var2)) == '|') {
            field_140 = 0;
            return;
         }

         if (var3 == '}' && var2 > 1 && var0.charAt(var2 - 2) == '{' && ((var3 = var0.charAt(var2 - 1)) == 'l' || var3 == 'c' || var3 == 'i')) {
            field_140 = var3;
            return;
         }
      }

      field_140 = 0;
   }

   // $VF: renamed from: b () f
   public static RichTextLayout method_341() {
      return new RichTextLayout(0);
   }

   // $VF: renamed from: c () f
   public static RichTextLayout method_342() {
      RichTextLayout var0;
      (var0 = new RichTextLayout(0)).field_8 = true;
      return var0;
   }

   // $VF: renamed from: L () void
   public static void method_343() {
      method_330(method_341(), 0, 10133451359912117L, 1, 2, 11);
      method_330(method_341(), 1, 10133687583113342L, 1, 2, 11);
      method_330(method_342(), 2, 10133404115271722L, 1, 1, 11);
   }

   // $VF: renamed from: b () java.lang.String
   public final String method_344() {
      switch (method_403()) {
         case 2:
            return method_1318();
         case 3:
            return method_1319();
         case 4:
         case 5:
         case 6:
         case 7:
         case 9:
         case 10:
         case 11:
         case 12:
         case 14:
         case 15:
         case 16:
         case 17:
         case 18:
         case 23:
         case 24:
         case 25:
         case 26:
         case 27:
         case 28:
         case 29:
         case 30:
         case 31:
         case 32:
         case 33:
         case 34:
         case 35:
         case 36:
         case 40:
         case 45:
         case 47:
         case 48:
         case 49:
         case 50:
         case 51:
         case 52:
         case 53:
         case 54:
         case 55:
         case 56:
         case 61:
         case 62:
         case 63:
         case 64:
         case 65:
         case 69:
         case 70:
         case 71:
         case 72:
         case 73:
         case 75:
         case 77:
         case 78:
         case 80:
         case 81:
         case 82:
         case 85:
         case 86:
         case 87:
         case 88:
         case 89:
         case 90:
         case 91:
         case 93:
         case 94:
         case 95:
         case 96:
         case 97:
         case 98:
         case 99:
         case 100:
         case 101:
         case 102:
         case 104:
         case 105:
         case 106:
         case 107:
         case 108:
         case 109:
         case 110:
         case 111:
         case 112:
         case 113:
         default:
            return null;
         case 8:
            return method_1313();
         case 13:
            return method_1305();
         case 19:
            return method_1146();
         case 20:
            return method_1193();
         case 21:
            return method_1192();
         case 22:
            return method_1312();
         case 37:
            return method_1306();
         case 38:
            return method_1613();
         case 39:
            return method_1619();
         case 41:
            return method_1620();
         case 42:
            return method_1606();
         case 43:
            return method_1152();
         case 44:
            return method_1310();
         case 46:
            return method_1308();
         case 57:
            return method_1398();
         case 58:
            return method_1397();
         case 59:
            return method_1396();
         case 60:
            return method_1135();
         case 66:
            return method_1197();
         case 67:
            return method_1153();
         case 68:
            return method_1311();
         case 74:
            return method_492();
         case 76:
            return method_491();
         case 79:
            return method_493();
         case 83:
            return method_1309();
         case 84:
            return method_1307();
         case 92:
            return method_1317();
         case 103:
            return method_1314();
         case 114:
            return this.method_1316();
      }
   }

   // $VF: renamed from: l () int
   public static final int method_345() {
      switch (method_403()) {
         case 23:
            return field_142;
         case 28:
            return field_143;
         case 54:
            return field_144;
         case 61:
            return field_146;
         case 101:
            return field_145;
         default:
            return method_409();
      }
   }

   // $VF: renamed from: m (int) void
   public static final void method_346(int var0) {
      int var1 = method_345();
      switch (method_403()) {
         case 23:
            field_142 = var0;
            break;
         case 28:
            field_143 = var0;
            break;
         case 54:
            field_144 = var0;
            break;
         case 61:
            field_146 = var0;
            break;
         case 101:
            field_145 = var0;
            break;
         default:
            method_410(var0);
      }

      if (var0 != var1) {
         method_437();
      }
   }

   // $VF: renamed from: m () int
   public static final int method_347() {
      switch (method_403()) {
         case 23:
            return method_509();
         case 28:
            return method_1201();
         case 54:
            return method_1128();
         case 61:
            return method_1335();
         case 101:
            return method_1336();
         default:
            return method_408();
      }
   }

   // $VF: renamed from: v (int) int
   public static final int method_348(int var0) {
      switch (method_403()) {
         case 28:
            return method_1175();
         default:
            return method_1341(var0);
      }
   }

   // $VF: renamed from: d (int) java.lang.String
   public static final String method_349(int var0) {
      switch (method_403()) {
         case 23:
            return method_510(var0);
         case 28:
            return method_1126(var0);
         case 54:
            return method_1134(var0);
         case 61:
            return method_1334(var0);
         case 101:
            return method_1337(var0);
         default:
            return method_411(var0);
      }
   }

   // $VF: renamed from: n (int) void
   public final void method_350(int var1) {
      switch (var1) {
         case 0:
            return;
         case 1:
            method_356();
         case 2:
         case 3:
      }
   }

   // $VF: renamed from: run () void
   public final void run() {
      if (field_147 != null) {
         int var1;
         synchronized (field_147) {
            if ((var1 = method_355()) == -1) {
               return;
            }
         }

         try {
            this.method_350(var1);
         } catch (Exception var6) {
         var6.printStackTrace();
         }

         if (field_147 != null) {
            synchronized (field_147) {
               if (!method_351(var1)) {
                  method_352(var1);
               }
            }
         }
      }
   }

   // $VF: renamed from: j (int) boolean
   public static final boolean method_351(int var0) {
      if (field_147 == null) {
         return true;
      } else {
         synchronized (field_147) {
            return field_147[var0] != Thread.currentThread();
         }
      }
   }

   // $VF: renamed from: o (int) void
   public static final void method_352(int var0) {
      synchronized (field_147) {
         field_147[var0] = null;
      }
   }

   // $VF: renamed from: p (int) void
   public static final void method_353(int var0) {
      method_354(var0, 1);
   }

   // $VF: renamed from: c (int, int) void
   public static final void method_354(int var0, int var1) {
      Thread var2;
      (var2 = new Thread(field_47)).setPriority(var1);
      synchronized (field_147) {
         field_147[var0] = var2;
      }

      var2.start();
   }

   // $VF: renamed from: af () int
   private static final int method_355() {
      Thread var0 = Thread.currentThread();

      for (int var1 = 0; var1 < 4; var1++) {
         if (field_147[var1] == var0) {
            return var1;
         }
      }

      return -1;
   }

   public void destroyApp(boolean var1) {
      this.method_399();
   }

   public void startApp() {
      this.method_400();
   }

   // $VF: renamed from: M () void
   public static void method_356() {
      try {
         Thread.sleep(500L);
      } catch (Exception var1) {
         var1.printStackTrace();
      }

      method_300();
      field_148 = 1;
      method_215();
      field_148 = 2;
      method_186();
      field_148 = 3;
      method_343();
      field_148 = 4;
      method_111();
      field_148 = 5;
      method_135();
      field_148 = 6;
      field_148 = 7;

      while (!method_164(1)) {
         field_148 = 7 + 12 * field_75[1] / field_75[0];

         try {
            Thread.sleep(10L);
         } catch (Exception var0) {
         var0.printStackTrace();
         }
      }

      field_148 = 20;
      field_160 = true;
      method_437();
   }

   // $VF: renamed from: N () void
   public static final void method_357() {
      field_149[0] = "Game suspended,Spiel unterbrochen,Partida suspendida,Jeu interrompu,Gioco sospeso";
      field_149[1] = "Enable Sounds?,Ton an?,ВїActivar sonido?,Activer le son ?,Abilitare il suono?";
      field_149[2] = "Loading,Laden,Cargando,Chargement,Caricamento";
      field_149[3] = "Select,WГ¤hlen,Selec.,SГ©lect.,Selez.";
      field_149[4] = "Exit,Been.,Salir,Quit.,Esci";
      field_149[5] = "Continue,Weiter,ContinГєa,Contin.,Continua";
      field_149[6] = "Yes,Ja,SГ­,Oui,SГ¬";
      field_149[7] = "No,Nein,No,Non,No";
      field_149[8] = "More,Mehr,MГЎs,Plus,Altro";
      field_149[9] = "Back,ZurГјck,AtrГЎs,Retour,Ind.";
      field_149[10] = "Accept,Akzept,Aceptar,Accepter,Accetta";
      field_149[11] = "Start,Start,Com.,Lancer,Avvia";
      field_149[12] = "The game is not playable in this mode. Please rotate your display.,In diesem Format ist das Spiel nicht spielbar. Bitte das Bildschirmformat wechseln.,No es posible jugar en este modo. Por favor cambia a vista normal.,Le jeu ne fonctionne pas dans ce mode. Basculer l'affichage S.V.P.,Non ГЁ possibile usare il gioco in questa modalitГ . Ruota lo schermo per continuare.";
      field_149[13] = "st,.,Вє,er,Вє";
      field_149[14] = "nd,.,Вє,e,Вє";
      field_149[15] = "rd,.,Вє,e,Вє";
      field_149[16] = "th,.,Вє,e,Вє";
      method_201(5, 27302);
      method_201(6, 16777215);
   }

   // $VF: renamed from: O () void
   public static final void method_358() {
      method_442();
   }

   // $VF: renamed from: P () void
   public static void method_359() {
      method_365();
   }

   // $VF: renamed from: Q () void
   public static void method_360() {
      method_365();
   }

   // $VF: renamed from: R () void
   public static void method_361() {
      method_365();
      method_374(null, field_148, 20);
   }

   // $VF: renamed from: S () void
   public static void method_362() {
      method_353(1);
   }

   // $VF: renamed from: T () void
   public static void method_363() {
      if (field_160 && method_402() >= 200) {
         method_423(69);
      }
   }

   // $VF: renamed from: U () void
   public static void method_364() {
      if (method_164(2)) {
         method_423(81);
      }
   }

   // $VF: renamed from: hp () void
   private static final void method_365() {
      if (method_415()) {
         method_61(15728960L);
         method_65(16777215);
         method_64();
      }
   }

   // $VF: renamed from: V () void
   public static void method_366() {
      Graphics var0 = field_51;
      if (method_415()) {
         method_61(15728960L);
         method_65(16777215);
         if (!var0.remaster("sound-icon",new int[]{120,107,64,64})) {
            method_61(30118290661244954L);
            method_177(var0, 176, field_52 / 2, field_53 / 2);
            method_64();
         }
         method_61(5911605884092507L);
         int var1;
         method_203(var1 = method_381(true, false), ".", 2048, 2048, 0);
         Font previousFont = var0.getFont();
         int previousColor = var0.getColor();
         var0.setPreserveDarkText(true);
         var0.setColor(0);
         var0.setFont(Font.getFont(0, 1, 16));
         var0.drawString(method_293(1), field_52 / 2, 5, 1);
         var0.setPreserveDarkText(false);
         var0.setFont(previousFont);
         var0.setColor(previousColor);
         method_64();
         method_370();
         method_64();
      }
   }

   // $VF: renamed from: W () void
   public static void method_367() {
      method_90(true);
   }

   // $VF: renamed from: X () void
   public static void method_368() {
      method_90(false);
   }

   // $VF: renamed from: Y () void
   public static void method_369() {
      method_365();
   }

   // $VF: renamed from: Z () void
   public static final void method_370() {
      method_371(false, null, null, false);
   }

   // $VF: renamed from: a (boolean, java.lang.String, java.lang.String, boolean) boolean
   public static final boolean method_371(boolean var0, String var1, String var2, boolean var3) {
      return method_372(var0, var1, var2, var3, false);
   }

   // $VF: renamed from: a (boolean, java.lang.String, java.lang.String, boolean, boolean) boolean
   public static final boolean method_372(boolean var0, String var1, String var2, boolean var3, boolean var4) {
      boolean var5 = false;
      int var6 = method_381(true, var3);
      String var7;
      String var8;
      if (var0) {
         var7 = var1;
         var8 = var2;
      } else {
         var7 = method_405();
         var8 = method_406();
      }

      int var9 = 0;
      if (var4) {
         boolean var10 = false;
         var9 = method_211(var6) + 10;
      }

      if (var7 != null) {
         int var15 = method_208(var6, var7) + 17;
         int var11 = method_148(var9, 23);
         int var12 = method_149(0, 23 - var11);
         long var13 = method_67(4, 294 + var12, var15, var11);
         var5 = false | method_373(var3, var13, var7);
      }

      if (var8 != null) {
         int var16 = method_208(var6, var8) + 17;
         int var17 = method_148(var9, 23);
         int var18 = method_149(0, 23 - var17);
         long var19 = method_67(236 - var16, 294 + var18, var16, var17);
         var5 |= method_373(var3, var19, var8);
      }

      return var5;
   }

   // $VF: renamed from: a (boolean, long, java.lang.String) boolean
   public static boolean method_373(boolean var0, long var1, String var3) {
      method_61(var1);
      if(RemasterArt.button(field_51,0,0,field_52,field_53,false,var3)){
         method_64();
         return false;
      }
      method_377(false, false);
      method_66(method_381(true, var0), var3, 3);
      RemasterArt.button(field_51,0,0,field_52,field_53,false,var3);
      method_64();
      return false;
   }

   // $VF: renamed from: b (java.lang.String, int, int) void
   private static final void method_374(String var0, int var1, int var2) {
      if (var2 == 0) {
         var1 = 1;
         var2 = 1;
      }

      if (var0 != null && field_160) {
         method_61(5911446970302486L);
         method_66(method_381(true, false), var0, 3);
         method_64();
      }

      method_61(5911567229386765L);
      method_377(false, false);
      method_308(field_51);
      method_310(field_51, 0, 0, (198 + 1386 * var1 / var2) / 8, 13);
      method_377(true, false);
      method_309(field_51);
      method_64();
   }

   // $VF: renamed from: a (long, boolean, boolean) void
   private static final void method_375(long var0, boolean var2, boolean var3) {
      Graphics var4 = field_51;
      method_61(var0);
      int var5 = field_52 / 2;
      int var6 = var3 ? 0 : field_53 - 1;
      int var7 = method_71(var0);

      for (int var8 = 0; var8 < var7; var8++) {
         int var9 = var8 * 2;
         int var10 = var5 - var8;
         int var11 = var3 ? var8 : -var8;
         method_313(var4, var2 ? 2202329 : 8179711);
         method_319(var4, var10, var6 + var11, var10 + var9);
         if (var8 > 0) {
            method_313(var4, var2 ? 29106 : 16777215);
            method_319(var4, var10 + 1, var6 + var11, var10 + var9 - 1);
         }
      }

      method_64();
   }

   // $VF: renamed from: a (long, long, int, boolean) boolean
   private static final boolean method_376(long var0, long var2, int var4, boolean var5) {
      method_62(var0, 0, var4);
      method_377(false, false);
      method_375(var2, true, var5);
      method_64();
      return false;
   }

   // $VF: renamed from: d (boolean, boolean) void
   private static final void method_377(boolean var0, boolean var1) {
      Graphics var2 = field_51;
      method_313(field_51, 14279409);
      method_315(var2, 0, 2, 1, field_53 - 3);
      method_315(var2, 1, field_53 - 2, 1, 2);
      method_315(var2, 2, field_53 - 1, field_52 - 4, 1);
      method_315(var2, field_52 - 2, field_53 - 2, 1, 2);
      method_315(var2, field_52 - 1, 2, 1, field_53 - 3);
      method_313(var2, 11387106);
      method_315(var2, 2, field_53 - 2, field_52 - 4, 1);
      method_313(var2, var0 ? 6400478 : 11387106);
      method_315(var2, 1, field_53 - 3, 1, 1);
      method_315(var2, field_52 - 2, field_53 - 3, 1, 1);
      if (var0) {
         method_313(var2, 6405867);
         method_315(var2, 1, 0, 1, 1);
         method_315(var2, field_52 - 2, 0, 1, 1);
      }

      method_313(var2, var0 ? 29106 : 10479103);
      method_315(var2, 2, 0, field_52 - 4, 1);
      method_315(var2, 1, 1, field_52 - 2, field_53 - 4);
      method_315(var2, 2, field_53 - 3, field_52 - 4, 1);
      method_313(var2, var0 ? 2202329 : 12841215);
      method_315(var2, 4, 1, field_52 - 8, 1);
      if (var1) {
         method_315(var2, 3, 2, field_52 - 6, 2);
         method_315(var2, 4, 4, field_52 - 8, 2);
         method_315(var2, 5, 6, field_52 - 10, 1);
         method_315(var2, 7, 7, field_52 - 14, 1);
      } else {
         method_315(var2, 3, 2, field_52 - 6, 1);
         method_315(var2, 4, 3, field_52 - 8, 1);
         method_315(var2, 6, 4, field_52 - 12, 1);
      }
   }

   // $VF: renamed from: l () boolean
   public static final boolean method_378() {
      return (method_289() ? method_287() : method_345()) != field_151;
   }

   // $VF: renamed from: d (boolean) void
   public static final void method_379(boolean var0) {
      boolean var1 = method_289();
      int var2 = method_347();
      int var3 = method_345();
      short var4 = 185;
      int var5 = var0 ? 217 : 67;
      if (var1) {
         var2 = method_288();
         var3 = method_287();
         var4 = 262;
      }

      int var6;
      int var7 = method_149(var6 = var4 / 25, var2) * 25 - 2;
      if (var1) {
         var5 = 160 - (var7 >> 1);
      }

      if (field_151 != var3) {
         if (var3 < field_150) {
            field_150 = var3;
         }

         if (var3 >= field_150 + var6) {
            field_150 = var3 - var6 + 1;
         }
      }

      if (field_150 + var6 > var2) {
         field_150 = method_148(0, var6 - var6);
      }

      int var8 = method_149(var6, var2);
      int var10 = 0;
      if (field_150 > 0) {
         var10 = var5 - 2 - 13 - 52;
         method_376(31243945754427405L, 32932808498806788L, var10, true);
      }

      if (field_150 + var6 < var2) {
         var10 = var5 + var7 + 2 - 254;
         method_376(31244813337821197L, 32933680377167876L, var10, false);
      }

      for (int var11 = 0; var11 < var8; var11++) {
         long var12 = method_67(21, var5 + var11 * 25, 198, 23);
         String var14;
         if (var1) {
            var14 = method_295()[var11 + field_150];
         } else {
            var14 = method_349(var11 + field_150);
         }

         method_380(var12, var11 + field_150, var14, var3, false);
      }

      field_151 = var3;
   }

   // $VF: renamed from: a (long, int, java.lang.String, int, boolean) void
   public static final void method_380(long var0, int var2, String var3, int var4, boolean var5) {
      method_61(var0);
      boolean var6;
      method_377(var6 = var2 == var4, true);
      method_203(method_381(!var6, var5), var3, field_52 / 2, field_53 / 2, 3);
      method_64();
   }

   // $VF: renamed from: a (boolean, boolean) int
   public static final int method_381(boolean var0, boolean var1) {
      if (var1) {
         return var0 ? 5 : 6;
      } else {
         return var0 ? 3 : 4;
      }
   }

   // $VF: renamed from: m () boolean
   public static boolean method_382() {
      return true;
   }

   // $VF: renamed from: hq () void
   private final void method_383() {
      if (field_152 < 2) {
         method_387();
         field_152++;
         method_413(true);
         method_386();
      } else {
         if (!field_153) {
            field_153 = true;
            method_437();
         }
      }
   }

   // $VF: renamed from: n () boolean
   public static boolean method_384() {
      return field_160 && field_153;
   }

   // $VF: renamed from: aa () void
   public final void method_385() {
      boolean var1 = false;
      switch (field_152) {
         case 0:
            var1 = method_1582(method_401() - field_154);
            break;
         case 1:
            var1 = method_1583(method_401() - field_154);
            break;
         case 2:
            var1 = method_1585(method_401() - field_154);
      }

      if (var1) {
         this.method_383();
      }
   }

   // $VF: renamed from: ab () void
   public static void method_386() {
      // The browser edition opens directly on its own title artwork.
      field_152 = 2;
      field_154 = method_401();
   }

   // $VF: renamed from: ac () void
   public static void method_387() {
      switch (field_152) {
         case 0:
            method_1586();
            return;
         case 1:
            method_1587();
            return;
         case 2:
            method_1588();
      }
   }

   public void pauseApp() {
      synchronized (field_48) {
         method_397();
      }
   }

   // $VF: renamed from: ad () void
   public static final void method_388() {
      synchronized (field_48) {
         field_155++;
         method_101();
      }
   }

   // $VF: renamed from: ae () void
   public static final void method_389() {
      synchronized (field_48) {
         if (field_159) {
            method_391();
         }

         field_45.method_1653();
      }
   }

   // $VF: renamed from: af () void
   public static final void method_390() {
      synchronized (field_48) {
         method_397();
      }
   }

   // $VF: renamed from: ag () void
   public static final void method_391() {
      method_395();
   }

   // $VF: renamed from: d (javax.microedition.lcdui.Graphics, int, int) void
   public static final void method_392(Graphics var0, int var1, int var2) {
      synchronized (field_48) {
         if (method_394()) {
            if (field_159) {
               method_284(var0, var1, var2);
            } else {
               method_72(var0);
               method_393(var0);
               method_73();
            }
         } else {
            method_284(var0, var1, var2);
            if (method_394()) {
               method_72(var0);
               method_393(var0);
               method_73();
            }
         }

         method_230(var0, var1, var2);
         method_140(var0, var1, var2);
      }
   }

   // $VF: renamed from: j (javax.microedition.lcdui.Graphics) void
   private static final void method_393(Graphics var0) {
      Graphics var1 = field_51;
      field_51 = var0;
      method_63(0, 0, 240, 320);
      method_65(16777215);
      int var2 = method_381(true, true);
      String var3 = method_293(5);
      method_331(field_51, 0, 0, field_52, field_53, method_293(0), var2, var2, 3);
      method_372(true, var3, null, true, true);
      method_64();
      field_51 = var1;
   }

   // $VF: renamed from: o () boolean
   public static final boolean method_394() {
      return field_156 == 2;
   }

   // $VF: renamed from: ah () void
   public static final void method_395() {
      method_236();
      method_237();
      if (field_156 == 2) {
         field_156 = 1;
         method_416();
         field_47.method_281();
         method_121();
         method_413(true);
         field_45.method_1653();
      }
   }

   // $VF: renamed from: e (boolean) void
   public static final void method_396(boolean var0) {
      field_157 = var0;
   }

   // $VF: renamed from: ai () void
   public static final void method_397() {
      method_398(true);
   }

   // $VF: renamed from: f (boolean) void
   public static final void method_398(boolean var0) {
      if (!var0 || !field_158 && !field_157) {
         if (field_156 == 1) {
            field_156 = 2;
            method_236();
            method_237();
            method_120();
            method_413(true);
            method_417();
            field_47.method_282();
            field_45.method_1653();
         }
      }
   }

   // $VF: renamed from: aj () void
   public final void method_399() {
      synchronized (field_48) {
         method_418();
         this.method_283();
         if (field_160) {
            method_79();
            method_396(true);
            method_452();
         }
      }
   }

   // $VF: renamed from: ak () void
   public final void method_400() {
      synchronized (field_48) {
         if (field_156 == 0) {
            field_156 = 2;
            method_58(this);
            method_357();
            this.method_280();
            method_262();
            method_395();
            field_45.method_1654(field_46);
            method_358();
         }
      }
   }

   // $VF: renamed from: n () int
   public static final int method_401() {
      return field_163.field_22;
   }

   // $VF: renamed from: o () int
   public static final int method_402() {
      return method_149(method_401() - field_169, field_170 - field_169);
   }

   // $VF: renamed from: p () int
   public static final int method_403() {
      return field_164;
   }

   // $VF: renamed from: a () e
   public static final GameClock method_404() {
      return field_163;
   }

   // $VF: renamed from: c () java.lang.String
   public static final String method_405() {
      int var0;
      if ((var0 = field_166[0]) == -128) {
         var0 = field_166[5];
      }

      return var0 == -128 ? null : method_134(var0);
   }

   // $VF: renamed from: d () java.lang.String
   public static final String method_406() {
      int var0;
      if ((var0 = field_166[1]) == -128) {
         var0 = field_166[3];
      }

      return var0 == -128 ? null : method_134(var0);
   }

   // $VF: renamed from: k (int) boolean
   public static final boolean method_407(int var0) {
      int var1;
      if ((var1 = field_166[var0]) == -128) {
         return false;
      } else {
         method_425(var1);
         return true;
      }
   }

   // $VF: renamed from: q () int
   public static final int method_408() {
      return field_168;
   }

   // $VF: renamed from: r () int
   public static final int method_409() {
      return field_162[field_164];
   }

   // $VF: renamed from: q (int) void
   public static final void method_410(int var0) {
      field_162[field_164] = var0;
      method_413(false);
   }

   // $VF: renamed from: e (int) java.lang.String
   public static final String method_411(int var0) {
      return method_134(field_167[var0]);
   }

   // $VF: renamed from: w (int) int
   public static final int method_412(int var0) {
      return field_168 <= var0 ? -128 : field_167[var0];
   }

   // $VF: renamed from: g (boolean) void
   public static final void method_413(boolean var0) {
      field_172 = true;
      field_173 = var0 || field_173;
   }

   // $VF: renamed from: bA () boolean
   private static final boolean method_414() {
      return (method_260(0, field_164, 1) & 0xFF) != 0 || field_172 || method_394();
   }

   // $VF: renamed from: p () boolean
   public static final boolean method_415() {
      return field_174 || method_394();
   }

   // $VF: renamed from: al () void
   public static final void method_416() {
      field_163.method_23();
   }

   // $VF: renamed from: am () void
   public static final void method_417() {
      field_163.method_24();
   }

   // $VF: renamed from: an () void
   public static final void method_418() {
      field_163.method_25();
   }

   // $VF: renamed from: a (f) void
   public static final void method_419(RichTextLayout var0) {
      field_175 = var0;
   }

   // $VF: renamed from: m (int, boolean) void
   private static final void method_420(int var0, boolean var1) {
      int var2 = field_164;
      if (!var1) {
         if (field_183[var0] != 0) {
            int var3 = var2;

            while (var3 != var0 && var3 != 0) {
               int var4 = field_183[var3];
               field_183[var3] = 0;
               var3 = var4;
            }
         } else {
            field_183[var0] = var2;
         }
      } else {
         field_183[var2] = 0;
      }

      field_181 = true;
      method_439();
      field_164 = var0;
      method_438();
      field_181 = false;
      method_413(var2 != var0);
   }

   // $VF: renamed from: aj (int) boolean
   private static final boolean method_421(int var0) {
      if (field_166[var0] != -128) {
         method_407(var0);
         method_237();
         return true;
      } else {
         return false;
      }
   }

   // $VF: renamed from: l (int) boolean
   public static final boolean method_422(int var0) {
      if (var0 == 8 && method_421(5)) {
         return true;
      } else {
         return var0 == -8 && method_421(4) ? true : method_425(-var0);
      }
   }

   // $VF: renamed from: r (int) void
   public static final void method_423(int var0) {
      field_165 = var0;
   }

   // $VF: renamed from: q () boolean
   public static final boolean method_424() {
      return field_165 != -1 ? method_425(field_165) : false;
   }

   // $VF: renamed from: m (int) boolean
   public static final boolean method_425(int var0) {
      field_165 = -1;
      if (field_176 > 0) {
         int var1 = field_177;
         switch (field_164) {
            case 23:
            case 28:
            case 54:
            case 61:
            case 101:
               field_177 = method_246(field_177, field_176, true);
            default:
               if (field_177 != var1) {
                  method_413(false);
                  method_346(field_177);
               }
         }
      }

      if (field_175 != null && field_175.method_6() == var0) {
         field_175.method_2();
         method_436();
         return true;
      } else {
         int var3 = field_164;
         int var2;
         if (!method_432((var2 = method_441(var0)) & 0xFF)) {
            return false;
         } else {
            method_426(var2 >> 8 & 0xFF);
            return var3 == field_164 ? method_429(var2 >> 16) : false;
         }
      }
   }

   // $VF: renamed from: bk (int) void
   private static final void method_426(int var0) {
      switch (var0) {
         case 1:
            method_1161();
            return;
         case 2:
            method_1191();
            return;
         case 3:
            method_1169();
            return;
         case 4:
            method_1141();
            return;
         case 5:
            method_1421();
            return;
         case 6:
            method_1422();
            return;
         case 7:
            method_1424();
            return;
         case 8:
            method_1426();
            return;
         case 9:
            method_1646();
            return;
         case 10:
            method_1647();
            return;
         case 11:
            method_1097();
            return;
         case 12:
            method_1098();
            return;
         case 13:
            field_47.method_291();
            return;
         case 14:
            method_296();
            return;
         case 15:
            method_362();
            return;
         case 16:
            method_363();
            return;
         case 17:
            method_1145();
            return;
         case 18:
            method_1180();
            return;
         case 19:
            method_1136();
            return;
         case 20:
            method_1178();
            return;
         case 21:
            method_499();
            return;
         case 22:
            method_500();
            return;
         case 23:
            method_1409();
            return;
         case 24:
            method_1411();
            return;
         case 25:
            method_1644();
            return;
         case 26:
            method_1645();
            return;
         case 27:
            method_1639();
            return;
         case 28:
            method_1640();
            return;
         case 29:
            method_511();
            return;
         case 30:
            method_513();
            return;
         case 31:
            method_512();
            return;
         case 32:
            method_1150();
            return;
         case 33:
            method_1181();
            return;
         case 34:
            method_1140();
            return;
         case 35:
            method_1132();
            return;
         case 36:
            method_1144();
            return;
         case 37:
            method_1198();
            return;
         case 38:
            method_1160();
            return;
         case 39:
            method_1127();
            return;
         case 40:
            method_1190();
            return;
         case 41:
            method_1149();
            return;
         case 42:
            method_1595();
            return;
         case 43:
            method_1615();
            return;
         case 44:
            method_1612();
            return;
         case 45:
            method_1163();
            return;
         case 46:
            method_1137();
            return;
         case 47:
            method_1199();
            return;
         case 48:
            method_1139();
            return;
         case 49:
            method_1388();
            return;
         case 50:
            method_1392();
            return;
         case 51:
            method_1389();
            return;
         case 52:
            method_1390();
            return;
         case 53:
            method_1154();
            return;
         case 54:
            method_386();
            return;
         case 55:
            method_387();
            return;
         case 56:
            method_364();
            return;
         case 57:
            method_1170();
            return;
         case 58:
            method_1171();
            return;
         case 59:
            method_1101();
            return;
         case 60:
            method_1158();
            return;
         case 61:
            method_1174();
            return;
         case 62:
            method_1106();
            return;
         case 63:
            method_1105();
            return;
         case 64:
            method_1108();
            return;
         case 65:
            method_1102();
            return;
         case 66:
            method_1109();
            return;
         case 67:
            method_1182();
            return;
         case 68:
            method_1194();
            return;
         case 69:
            method_1598();
            return;
         case 70:
            method_1168();
            return;
         case 71:
            method_1195();
            return;
         case 72:
            method_1103();
            return;
         case 73:
            method_1104();
            return;
         case 74:
            method_490();
            return;
         case 75:
            method_484();
            return;
         case 76:
            method_486();
            return;
         case 77:
            method_1643();
            return;
         case 78:
            method_1399();
            return;
         case 79:
            method_1118();
            return;
         case 80:
            method_1120();
            return;
         case 81:
            method_1488();
            return;
         case 82:
            method_1489();
            return;
         case 83:
            method_1490();
            return;
         case 84:
            method_1100();
            return;
         case 85:
            method_1628();
            return;
         case 86:
            method_1629();
            return;
         case 87:
            method_1176();
            return;
         case 88:
            method_1133();
            return;
         case 89:
            method_1172();
            return;
         case 90:
            method_1165();
            return;
         case 91:
            method_1167();
            return;
         case 92:
            method_1188();
            return;
         case 93:
            method_1635();
            return;
         case 94:
            method_1431();
            return;
         case 95:
            method_1433();
            return;
         case 96:
            method_1642();
            return;
         case 97:
            method_367();
            return;
         case 98:
            method_368();
            return;
         case 99:
            method_504();
            return;
         case 100:
            method_496();
            return;
         case 101:
            method_1143();
            return;
         case 102:
            method_54();
            return;
         case 103:
            method_1634();
            return;
         case 104:
            method_1630();
            return;
         case 105:
            method_1636();
            return;
         case 106:
            method_1637();
            return;
         case 107:
            method_1638();
            return;
         case 108:
            method_1633();
            return;
         case 109:
            method_1641();
            return;
         case 110:
            method_1649();
            return;
         case 111:
            method_1648();
            return;
         case 112:
            method_1151();
            return;
         case 113:
            method_1333();
      }
   }

   // $VF: renamed from: bl (int) void
   private static final void method_427(int var0) {
      if (var0 != 255) {
         method_353(var0);
      }
   }

   // $VF: renamed from: hr () void
   private static final void method_428() {
      int var0 = field_162[field_164];
      method_425(field_167[var0]);
   }

   // $VF: renamed from: ak (int) boolean
   private static final boolean method_429(int var0) {
      if (var0 == 0) {
         return false;
      } else if (var0 == -3) {
         return true;
      } else {
         if (var0 == -2) {
            method_428();
         } else if (var0 == -1) {
            method_430();
         } else if (var0 == -4) {
            method_420(field_183[field_164], true);
         } else if (var0 >= 115) {
            method_431(var0);
         } else {
            method_420(var0, false);
         }

         return true;
      }
   }

   // $VF: renamed from: hs () void
   private static final void method_430() {
      field_164 = 0;
      method_449();
      method_57();
   }

   // $VF: renamed from: bm (int) void
   private static final void method_431(int var0) {
      int var1 = method_260(2, var0 - 115, 0);

      int var2;
      while (!method_432((var2 = method_260(3, var1, 0)) & 0xFF)) {
         var1++;
      }

      method_426(var2 >> 8 & 0xFF);
      method_429(var2 >>> 16);
   }

   // $VF: renamed from: al (int) boolean
   private static final boolean method_432(int var0) {
      boolean var1 = true;
      switch (var0 & 127) {
         case 1:
            var1 = method_1200();
            break;
         case 2:
            var1 = method_1196();
            break;
         case 3:
            var1 = method_1183();
            break;
         case 4:
            var1 = method_1415();
            break;
         case 5:
            var1 = method_1425();
            break;
         case 6:
            var1 = method_1138();
            break;
         case 7:
            var1 = method_1159();
            break;
         case 8:
            var1 = method_1096();
            break;
         case 9:
            var1 = method_301();
            break;
         case 10:
            var1 = method_1179();
            break;
         case 11:
            var1 = method_1111();
            break;
         case 12:
            var1 = method_497();
            break;
         case 13:
            var1 = method_1402();
            break;
         case 14:
            var1 = method_1410();
            break;
         case 15:
            var1 = method_508();
            break;
         case 16:
            var1 = method_514();
            break;
         case 17:
            var1 = method_1162();
            break;
         case 18:
            var1 = method_1164();
            break;
         case 19:
            var1 = method_1166();
            break;
         case 20:
            var1 = method_1184();
            break;
         case 21:
            var1 = method_1185();
            break;
         case 22:
            var1 = method_1186();
            break;
         case 23:
            var1 = method_1177();
            break;
         case 24:
            var1 = method_1148();
            break;
         case 25:
            var1 = method_1157();
            break;
         case 26:
            var1 = method_1122();
            break;
         case 27:
            var1 = method_1611();
            break;
         case 28:
            var1 = method_1591();
            break;
         case 29:
            var1 = method_1130();
            break;
         case 30:
            var1 = method_1155();
            break;
         case 31:
            var1 = method_1129();
            break;
         case 32:
            var1 = method_1114();
            break;
         case 33:
            var1 = method_1121();
            break;
         case 34:
            var1 = method_1110();
            break;
         case 35:
            var1 = method_1147();
            break;
         case 36:
            var1 = method_1382();
            break;
         case 37:
            var1 = method_1385();
            break;
         case 38:
            var1 = method_1393();
            break;
         case 39:
            var1 = method_1394();
            break;
         case 40:
            var1 = method_382();
            break;
         case 41:
            var1 = method_384();
            break;
         case 42:
            var1 = method_1116();
            break;
         case 43:
            var1 = method_1117();
            break;
         case 44:
            var1 = method_1156();
            break;
         case 45:
            var1 = method_1173();
            break;
         case 46:
            var1 = method_1124();
            break;
         case 47:
            var1 = method_487();
            break;
         case 48:
            var1 = method_489();
            break;
         case 49:
            var1 = method_485();
            break;
         case 50:
            var1 = method_1123();
            break;
         case 51:
            var1 = method_1112();
            break;
         case 52:
            var1 = method_1113();
            break;
         case 53:
            var1 = method_1187();
            break;
         case 54:
            var1 = method_1125();
            break;
         case 55:
            var1 = method_1115();
            break;
         case 56:
            var1 = method_1202();
            break;
         case 57:
            var1 = method_1189();
            break;
         case 58:
            var1 = method_494();
            break;
         case 59:
            var1 = method_1434();
            break;
         case 60:
            var1 = method_1432();
            break;
         case 61:
            var1 = method_495();
      }

      return var0 > 127 ? !var1 : var1;
   }

   // $VF: renamed from: d (javax.microedition.lcdui.Graphics) void
   public static final void method_433(Graphics var0) {
      field_171 = method_401();
      if (method_414()) {
         field_172 = false;
         field_174 = field_173;
         field_173 = false;
         method_72(var0);
         TouchInput.beginFrame(field_164);
         switch (field_164) {
            case 1:
               method_1577();
               break;
            case 2:
               method_1526();
               break;
            case 3:
               method_1527();
               break;
            case 4:
               method_1477();
               break;
            case 5:
               method_1557();
               break;
            case 6:
               method_1558();
               break;
            case 7:
               method_1556();
               break;
            case 8:
               method_1509();
               break;
            case 9:
               method_1468();
               break;
            case 10:
               method_290();
               break;
            case 11:
               method_361();
               break;
            case 12:
               method_1131();
               break;
            case 13:
               method_1570();
               break;
            case 14:
               method_1479();
               break;
            case 15:
               method_1551();
               break;
            case 16:
               method_1552();
               break;
            case 17:
               method_359();
               break;
            case 18:
               method_1575();
               break;
            case 19:
               method_1571();
               break;
            case 20:
               method_1507();
               break;
            case 21:
               method_1520();
               break;
            case 22:
               method_1523();
               break;
            case 23:
               method_1481();
               break;
            case 24:
               method_1569();
               break;
            case 25:
               method_1475();
               break;
            case 26:
               method_1521();
               break;
            case 27:
               method_1494();
               break;
            case 28:
               method_1545();
               break;
            case 29:
               method_1546();
               break;
            case 30:
               method_1472();
               break;
            case 31:
               method_1496();
               break;
            case 32:
               method_1537();
               break;
            case 33:
               method_1544();
               break;
            case 34:
               method_1495();
               break;
            case 35:
               method_1541();
               break;
            case 36:
               method_1542();
               break;
            case 37:
               method_1543();
               break;
            case 38:
               method_1601();
               break;
            case 39:
               method_1603();
               break;
            case 40:
               method_1608();
               break;
            case 41:
               method_1604();
               break;
            case 42:
               method_1605();
               break;
            case 43:
               method_1517();
               break;
            case 44:
               method_1518();
               break;
            case 45:
               field_47.method_1503();
               break;
            case 46:
               field_47.method_1530();
               break;
            case 47:
               method_1572();
               break;
            case 48:
               method_1574();
               break;
            case 49:
               method_1573();
               break;
            case 50:
               method_1501();
               break;
            case 51:
               method_1498();
               break;
            case 52:
               method_1480();
               break;
            case 53:
               method_1504();
               break;
            case 54:
               method_1458();
               break;
            case 55:
               method_1602();
               break;
            case 56:
               method_1533();
               break;
            case 57:
               method_1568();
               break;
            case 58:
               method_1553();
               break;
            case 59:
               method_1554();
               break;
            case 60:
               method_1459();
               break;
            case 61:
               method_1487();
               break;
            case 62:
               method_369();
               break;
            case 63:
               method_360();
               break;
            case 64:
               field_47.method_385();
               break;
            case 65:
               method_1589();
               break;
            case 66:
               method_1529();
               break;
            case 67:
               method_1516();
               break;
            case 68:
               method_1519();
               break;
            case 69:
               method_1499();
               break;
            case 70:
               method_1464();
               break;
            case 71:
               method_1463();
               break;
            case 72:
               method_1469();
               break;
            case 73:
               method_1563();
               break;
            case 74:
               method_1564();
               break;
            case 75:
               method_1560();
               break;
            case 76:
               method_1561();
               break;
            case 77:
               method_1562();
               break;
            case 78:
               method_1565();
               break;
            case 79:
               method_1566();
               break;
            case 80:
               method_1559();
               break;
            case 81:
               method_1567();
               break;
            case 82:
               method_1483();
               break;
            case 83:
               method_1535();
               break;
            case 84:
               method_1536();
               break;
            case 85:
               method_1466();
               break;
            case 86:
               method_1467();
               break;
            case 87:
               method_1476();
               break;
            case 88:
               method_1576();
               break;
            case 89:
               method_1547();
               break;
            case 90:
               method_1548();
               break;
            case 91:
               field_47.method_1500();
               break;
            case 92:
               field_47.method_1502();
               break;
            case 93:
               field_47.method_1508();
               break;
            case 94:
               method_1492();
               break;
            case 95:
               method_1493();
               break;
            case 96:
               method_1549();
               break;
            case 97:
               method_1550();
               break;
            case 98:
               method_366();
            case 99:
            case 100:
            case 102:
            default:
               break;
            case 101:
               method_1482();
               break;
            case 103:
               method_1491();
               break;
            case 104:
               method_1462();
               break;
            case 105:
               method_1555();
               break;
            case 106:
               method_1465();
               break;
            case 107:
               method_1470();
               break;
            case 108:
               method_1473();
               break;
            case 109:
               method_1474();
               break;
            case 110:
               method_1522();
               break;
            case 111:
               method_1471();
               break;
            case 112:
               method_1525();
               break;
            case 113:
               method_1524();
               break;
            case 114:
               method_1485();
         }

         method_73();
         field_174 = false;
         field_180 = true;
      }
   }

   // $VF: renamed from: ao () void
   public static final void method_434() {
      field_163.method_26();
   }

   // $VF: renamed from: ap () void
   public static final void method_435() {
      if (field_171 >= field_170) {
         method_425(67);
      }

      int var0;
      method_426((var0 = method_260(0, field_164, 0)) & 0xFF);
      if (field_180) {
         if (!field_178) {
            field_178 = true;
            method_426(var0 >>> 24);
         }

         if (!field_179) {
            field_179 = true;
            method_427(method_260(0, field_164, 1) >> 8 & 0xFF);
         }
      }

      if (field_175 != null) {
         field_175.method_11();
         method_436();
      }
   }

   // $VF: renamed from: ht () void
   private static void method_436() {
      if (field_175 != null) {
         int var0 = field_175.method_6();
         if (field_182 != var0) {
            method_445(field_166[0]);
            method_445(field_166[5]);
            if (var0 != -128) {
               field_182 = var0;
               method_444(var0);
            } else {
               field_182 = -128;
               method_437();
            }

            method_413(true);
         }
      }
   }

   // $VF: renamed from: aq () void
   public static final void method_437() {
      if (!field_181) {
         if (!method_446()) {
            return;
         }

         method_449();
         method_443();
         method_413(true);
      }
   }

   // $VF: renamed from: hu () void
   private static final void method_438() {
      field_178 = false;
      field_180 = false;
      field_179 = false;
      method_426(method_260(0, field_164, 0) >> 16 & 0xFF);
      int var0;
      if ((var0 = method_260(0, field_164, 2) & 0xFF) == 1) {
         method_329();
      } else if (var0 == 2) {
         field_176 = method_347();
         field_177 = method_345();
         if (field_177 >= field_176) {
            field_177 = field_176 - 1;
            method_346(field_177);
         }
      }

      method_443();
      method_448();
   }

   // $VF: renamed from: hv () void
   private static final void method_439() {
      int var0 = method_260(0, field_164, 0);
      if (!field_178) {
         method_426(var0 >>> 24);
         field_178 = true;
      }

      method_426(var0 >> 8 & 0xFF);
      if (field_175 != null) {
         RichTextLayout.method_10();
      }

      field_175 = null;
      field_176 = 0;
      field_177 = 0;
      method_449();
      method_240();
   }

   // $VF: renamed from: X (int) int
   private static final int method_440(int var0) {
      int var1 = field_164 | var0 << 16;
      int var2 = method_261(4);

      for (int var3 = 0; var3 < var2; var3++) {
         if (method_260(4, var3, 0) == var1) {
            return var3;
         }
      }

      return -1;
   }

   // $VF: renamed from: Y (int) int
   private static final int method_441(int var0) {
      int var1;
      return (var1 = method_440(var0)) == -1 ? 0 : method_260(4, var1, 1);
   }

   // $VF: renamed from: ar () void
   public static void method_442() {
      method_449();
      byte[] var10000 = field_161[1];
      byte[] var0 = null;
      var10000[0] = 1;
      field_161[2][0] = 24;
      field_161[3][0] = 1;
      ((byte[])(var0 = field_161[4]))[0] = 64;
      ((byte[])var0)[1] = 2;
      ((byte[])var0)[4] = -2;
      ((byte[])var0)[5] = 7; // Main menu: omit item 43 (About, text 51).
      ((byte[])(var0 = field_161[6]))[1] = 1;
      ((byte[])var0)[2] = 8;
      field_161[8][0] = 1;
      ((byte[])(var0 = field_161[9]))[0] = 64;
      ((byte[])var0)[2] = 3;
      ((byte[])var0)[3] = -128;
      ((byte[])var0)[4] = 1;
      ((byte[])var0)[5] = -124;
      ((byte[])var0)[6] = 1;
      field_161[10][7] = 3;
      ((byte[])(var0 = field_161[12]))[0] = 64;
      ((byte[])var0)[1] = -128;
      field_161[13][0] = 1;
      ((byte[])(var0 = field_161[14]))[0] = -64;
      ((byte[])var0)[2] = 2;
      ((byte[])var0)[3] = -128;
      ((byte[])var0)[4] = 1;
      ((byte[])var0)[5] = 96;
      field_161[18][0] = 68;
      field_161[19][0] = 1;
      field_161[20][0] = 1;
      field_161[21][0] = 1;
      field_161[22][0] = 1;
      field_161[23][0] = -64;
      ((byte[])(var0 = field_161[27]))[1] = 16;
      ((byte[])var0)[2] = -64;
      ((byte[])var0)[3] = 57;
      field_161[28][0] = 68;
      field_161[29][0] = 1;
      ((byte[])(var0 = field_161[31]))[0] = 4;
      ((byte[])var0)[2] = 32;
      field_161[32][0] = 24;
      field_161[33][0] = 1;
      ((byte[])(var0 = field_161[34]))[0] = -64;
      ((byte[])var0)[6] = 112;
      field_161[35][0] = 1;
      field_161[36][0] = 24;
      field_161[37][0] = 1;
      field_161[38][0] = -128;
      field_161[39][0] = 1;
      field_161[41][0] = 1;
      field_161[42][0] = 1;
      field_161[43][0] = 1;
      field_161[44][0] = 1;
      field_161[45][0] = 1;
      ((byte[])(var0 = field_161[46]))[1] = -128;
      ((byte[])var0)[2] = 16;
      field_161[47][0] = 24;
      field_161[48][0] = 1;
      field_161[49][0] = 68;
      ((byte[])(var0 = field_161[50]))[0] = 64;
      ((byte[])var0)[1] = -128;
      ((byte[])(var0 = field_161[51]))[0] = 4;
      ((byte[])var0)[2] = 32;
      ((byte[])(var0 = field_161[52]))[0] = 64;
      ((byte[])var0)[1] = -128;
      field_161[53][0] = 1;
      field_161[54][0] = -128;
      field_161[55][0] = -128;
      ((byte[])(var0 = field_161[56]))[1] = -128;
      ((byte[])var0)[2] = 16;
      field_161[57][0] = 24;
      field_161[58][0] = 1;
      field_161[59][0] = 24;
      field_161[60][0] = -128;
      field_161[61][0] = -128;
      field_161[64][8] = 1;
      field_161[66][0] = 1;
      field_161[67][0] = 1;
      field_161[68][0] = 1;
      field_161[69][0] = 1;
      field_161[72][0] = 24;
      ((byte[])(var0 = field_161[74]))[1] = 2;
      ((byte[])var0)[2] = 8;
      ((byte[])(var0 = field_161[76]))[0] = -128;
      ((byte[])var0)[2] = 16;
      ((byte[])(var0 = field_161[79]))[1] = -128;
      ((byte[])var0)[2] = 8;
      field_161[82][0] = 24;
      field_161[83][0] = 1;
      field_161[84][0] = 1;
      field_161[89][0] = 24;
      field_161[90][0] = 1;
      ((byte[])(var0 = field_161[91]))[0] = 64;
      ((byte[])var0)[1] = -128;
      field_161[92][0] = 1;
      field_161[93][0] = 24;
      field_161[94][0] = 24;
      field_161[98][7] = 24;
      ((byte[])(var0 = field_161[101]))[0] = -128;
      ((byte[])var0)[2] = 4;
      field_161[103][0] = -128;
      field_161[105][0] = 1;
      field_161[114][0] = -128;
      method_420(17, false);
   }

   // $VF: renamed from: hw () void
   private static final void method_443() {
      boolean var0 = true;

      while (true) {
         byte[] var1 = field_161[field_164];

         for (int var2 = 0; var2 < 9; var2++) {
            byte var3 = var1[var2];
            int var4 = var2 << 3;

            for (int var5 = 0; var5 < 8; var5++) {
               if ((var3 & 1 << var5) != 0) {
                  boolean var6 = method_260(1, var4, 0) == 2;
                  if ((var0 && var6 || !var0 && !var6) && method_432(method_441(var4) & 0xFF)) {
                     method_444(var4);
                  }
               }

               var4++;
            }
         }

         if (!var0) {
            field_182 = -128;
            method_436();
            return;
         }

         int var7;
         if ((var7 = field_162[field_164]) > 0 && var7 > field_168 - 1) {
            field_162[field_164] = field_168 - 1;
         }

         var0 = false;
      }
   }

   // $VF: renamed from: s (int) void
   public static final void method_444(int var0) {
      int var1;
      if ((var1 = method_260(1, var0, 0)) == 2) {
         field_167[field_168++] = var0;
      } else {
         field_166[var1] = var0;
      }
   }

   // $VF: renamed from: t (int) void
   public static final void method_445(int var0) {
      if (var0 != -128) {
         int var1;
         if ((var1 = method_260(1, var0, 0)) == 2) {
            for (int var2 = 0; var2 < field_168; var2++) {
               if (field_167[var2] == var0) {
                  System.arraycopy(field_167, var2 + 1, field_167, var2, field_167.length - (var2 + 1));
                  field_168--;
                  return;
               }
            }
         } else {
            field_166[var1] = -128;
         }
      }
   }

   // $VF: renamed from: bB () boolean
   private static final boolean method_446() {
      byte[] var0 = field_161[field_164];

      for (int var1 = 0; var1 < 9; var1++) {
         byte var2 = var0[var1];
         int var3 = var1 << 3;

         for (int var4 = 0; var4 < 8; var4++) {
            if ((var2 & 1 << var4) != 0) {
               if (method_432(method_441(var3) & 0xFF)) {
                  if (!method_447(var3)) {
                     return true;
                  }
               } else if (method_447(var3)) {
                  return true;
               }
            }

            var3++;
         }
      }

      return false;
   }

   // $VF: renamed from: am (int) boolean
   private static final boolean method_447(int var0) {
      int var1;
      if ((var1 = method_260(1, var0, 0)) == 2) {
         for (int var2 = 0; var2 < field_168; var2++) {
            if (field_167[var2] == var0) {
               return true;
            }
         }
      } else if (field_166[var1] == var0) {
         return true;
      }

      return false;
   }

   // $VF: renamed from: hx () void
   private static final void method_448() {
      field_163.method_26();
      field_169 = method_401();
      if (method_432(method_441(67) & 0xFF)) {
         int var0;
         if ((var0 = method_260(0, field_164, 1) >>> 16) > 0) {
            field_170 = field_169 + var0;
            return;
         }

         field_170 = Integer.MAX_VALUE;
      }
   }

   // $VF: renamed from: hy () void
   private static final void method_449() {
      field_168 = 0;

      for (int var0 = 0; var0 < field_166.length; var0++) {
         field_166[var0] = -128;
      }
   }

   // $VF: renamed from: r () boolean
   public static final boolean method_450() {
      if (method_408() == 0) {
         return false;
      } else {
         int var0;
         int var1 = var0 = method_409();
         switch (field_164) {
            case 4:
            case 9:
            case 14:
            case 34:
               var1 = method_246(method_409(), method_408(), true);
            default:
               if (var1 != var0) {
                  method_410(var1);
                  return true;
               } else {
                  return false;
               }
         }
      }
   }

   // $VF: renamed from: b (java.lang.String) int
   public static int method_451(String var0) {
      method_453(var0);
      return 2;
   }

   // $VF: renamed from: as () void
   public static void method_452() {
      if (field_184 != null) {
         try {
            field_47.platformRequest(field_184);
            return;
         } catch (Exception var0) {
         var0.printStackTrace();
         }
      }
   }

   // $VF: renamed from: i (java.lang.String) void
   private static void method_453(String var0) {
      field_184 = var0;
      method_57();
   }

   // $VF: renamed from: b (int, int, int, int) int
   public static int method_454(int var0, int var1, int var2, int var3) {
      if (var0 > var1) {
         return 4096;
      } else {
         int var4 = (var0 << 12) / var1;
         int var5 = (var2 << 12) / var1;
         int var6 = (var1 - var3 << 12) / var1;
         int var7;
         int var8 = (var7 = method_267(8192, var6 - var5 + 4096)) >> 1;
         if (var4 < var5) {
            int var10000 = method_267(var8, var5);
            boolean var14 = false;
            return method_266(method_266(var10000, var4), var4);
         } else if (var4 > var6) {
            int var13 = 4096 - var6;
            int var10 = method_267(var7, var13);
            int var11;
            return method_266(method_266(var11 = method_267(-var8, var13), var4), var4) + method_266(var10, var4) + var11 + 4096;
         } else {
            int var9 = method_266(var5, var8);
            return method_266(var7, var4) - var9;
         }
      }
   }

   // $VF: renamed from: u (int) void
   public static final void method_455(int var0) {
      field_185 = var0;
   }

   // $VF: renamed from: s () int
   public static final int method_456() {
      field_185 = field_185 + 138805 ^ 913476322;
      return field_185 * 612124363 + 11 & 2147483647;
   }

   // $VF: renamed from: at () void
   public static final void method_457() {
      field_185 = field_185 + 138805 ^ 913476322;
   }

   // $VF: renamed from: au () void
   public static void method_458() {
      method_1206();
   }

   // $VF: renamed from: e (java.lang.String) java.lang.String
   public static final String method_459(String var0) {
      field_186.setLength(0);
      field_186.append(var0);
      int var1 = field_186.length();
      boolean var2 = false;

      for (int var3 = 0; var3 < var1; var3++) {
         if (field_186.charAt(var3) == 173) {
            field_186.delete(var3, var3 + 1);
            var1--;
            var2 = true;
         }
      }

      return var2 ? field_186.toString() : var0;
   }

   // $VF: renamed from: a (java.lang.StringBuffer, int, int, java.lang.String) void
   public static final void method_460(StringBuffer var0, int var1, int var2, String var3) {
      if (var2 > 1) {
         String var4 = method_462(227, method_463(var1), method_463(var2), null, null, null, null, null, null);
         var0.setLength(0);
         var0.append("{h}");
         var0.append(var4);
         var0.append(" ");
         if (var3 != null) {
            var0.append(var3);
            var0.append('|');
            var0.append('|');
         }
      }
   }

   // $VF: renamed from: d (java.lang.String) void
   public static final void method_461(String var0) {
      field_186.setLength(0);
      if (var0 != null) {
         field_186.append(var0);
      }
   }

   // $VF: renamed from: a (int, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String) java.lang.String
   public static final String method_462(int var0, String var1, String var2, String var3, String var4, String var5, String var6, String var7, String var8) {
      field_186.setLength(0);
      field_186.append(method_133(var0));
      if (var1 != null) {
         method_153(field_186, 0, var1);
      }

      if (var2 != null) {
         method_153(field_186, 1, var2);
      }

      if (var3 != null) {
         method_153(field_186, 2, var3);
      }

      if (var4 != null) {
         method_153(field_186, 3, var4);
      }

      if (var5 != null) {
         method_153(field_186, 4, var5);
      }

      if (var6 != null) {
         method_153(field_186, 5, var6);
      }

      if (var7 != null) {
         method_153(field_186, 6, var7);
      }

      if (var8 != null) {
         method_153(field_186, 7, var8);
      }

      return field_186.toString();
   }

   // $VF: renamed from: f (int) java.lang.String
   public static final String method_463(int var0) {
      field_187.setLength(0);
      field_187.append(var0);
      return field_187.toString();
   }

   // $VF: renamed from: g (int) java.lang.String
   public static final String method_464(int var0) {
      field_187.setLength(0);
      if (var0 >= 0) {
         field_187.append("+");
      }

      field_187.append(var0);
      return field_187.toString();
   }

   // $VF: renamed from: a (boolean) int
   public static int method_465(boolean var0) {
      if (method_467(var0)) {
         return 1;
      } else if (method_466(var0)) {
         return 4;
      } else if (method_468(var0)) {
         return 8;
      } else {
         return method_469(var0) ? 2 : 0;
      }
   }

   // $VF: renamed from: a (boolean) boolean
   public static boolean method_466(boolean var0) {
      if (!method_233(6) && !method_232(56)) {
         if (var0) {
         }

         return false;
      } else {
         return true;
      }
   }

   // $VF: renamed from: b (boolean) boolean
   public static boolean method_467(boolean var0) {
      if (!method_233(1) && !method_232(50)) {
         if (var0) {
         }

         return false;
      } else {
         return true;
      }
   }

   // $VF: renamed from: c (boolean) boolean
   public static boolean method_468(boolean var0) {
      if (!method_233(2) && !method_232(52)) {
         if (var0) {
         }

         return false;
      } else {
         return true;
      }
   }

   // $VF: renamed from: d (boolean) boolean
   public static boolean method_469(boolean var0) {
      if (!method_233(5) && !method_232(54)) {
         if (var0) {
         }

         return false;
      } else {
         return true;
      }
   }

   // $VF: renamed from: s () boolean
   public static boolean method_470() {
      return method_233(8) || method_232(53);
   }

   // $VF: renamed from: av () void
   public static void method_471() {
      method_234(8);
      method_235(53);
   }

   // $VF: renamed from: t () int
   public static int method_472() {
      return method_465(false);
   }

   // $VF: renamed from: n (int) boolean
   public static boolean method_473(int var0) {
      return method_247(var0) == 8 || var0 == 53;
   }

   // $VF: renamed from: aw () void
   public static void method_474() {
      if (field_194 < 30 || field_194 > 44 || method_401() - field_195 > field_192[field_194 - 30]) {
         method_477();
      }
   }

   // $VF: renamed from: ax () void
   public static final void method_475() {
      method_478(29);
   }

   // $VF: renamed from: ay () void
   public static final void method_476() {
      if (field_194 >= 0) {
         method_478(field_194);
      } else {
         method_477();
      }
   }

   // $VF: renamed from: az () void
   public static final void method_477() {
      boolean var0 = field_349 > 0 && field_348 / field_349 < 50;
      method_455((int)System.currentTimeMillis());
      if (method_456() % 100 < 20) {
         int var1 = var0 ? field_190 : field_189;
         field_196 = (field_196 + 1) % var1;
      }

      int var3 = field_188;
      int var2 = (var0 ? 36 : 30) + field_196 * field_188 + method_456() % var3;
      method_478(field_193[var2 - 30]);
   }

   // $VF: renamed from: v (int) void
   public static final void method_478(int var0) {
      if (var0 != field_194) {
         method_77(0);
         field_194 = var0;
         field_195 = method_401();
         method_76(var0, 100, 0);
      }
   }

   // $VF: renamed from: a (int, int, int, boolean) void
   public static final void method_479(int var0, int var1, int var2, boolean var3) {
      if (!var3 || method_403() == 27) {
         if (var1 == -1 || field_309[var1] == field_416) {
            field_197 = field_155;
            field_198 = var0;
            method_78(var0, var2);
         }
      }
   }

   // $VF: renamed from: aA () void
   public static final void method_480() {
      method_77(1000);
      field_194 = -1;
   }

   // $VF: renamed from: aB () void
   public static final void method_481() {
      if (!method_1651("/demo-mode.txt")) {
         method_55();
      } else {
         field_199 = "TRUE".equals(method_1652("DemoModeEnabled"));
         if (field_199) {
            String var1 = method_286();
            method_461("MenuItem-");
            field_186.append(var1);
            field_200 = method_1652(field_186.toString());
            method_461("Url-");
            field_186.append(var1);
            field_201 = method_1652(field_186.toString());
         }
      }
   }

   // $VF: renamed from: e () java.lang.String
   public static String method_482() {
      return field_200;
   }

   // $VF: renamed from: f () java.lang.String
   public static final String method_483() {
      return method_488() ? method_1401() : null;
   }

   // $VF: renamed from: aC () void
   public static void method_484() {
      field_202 = method_1386(4, field_201, null, method_133(6), method_133(70), method_133(71));
   }

   // $VF: renamed from: t () boolean
   public static boolean method_485() {
      return method_1387(field_202);
   }

   // $VF: renamed from: aD () void
   public static void method_486() {
      field_202 = -1;
   }

   // $VF: renamed from: u () boolean
   public static boolean method_487() {
      return method_488();
   }

   // $VF: renamed from: v () boolean
   public static final boolean method_488() {
      return field_199;
   }

   // $VF: renamed from: w () boolean
   public static boolean method_489() {
      return method_488() ? method_1400() : false;
   }

   // $VF: renamed from: aE () void
   public static void method_490() {
      method_581();
   }

   // $VF: renamed from: g () java.lang.String
   public static String method_491() {
      return method_133(68);
   }

   // $VF: renamed from: h () java.lang.String
   public static String method_492() {
      return method_133(69);
   }

   // $VF: renamed from: i () java.lang.String
   public static String method_493() {
      return method_133(67);
   }

   // $VF: renamed from: x () boolean
   public static boolean method_494() {
      return field_203;
   }

   // $VF: renamed from: y () boolean
   public static boolean method_495() {
      int var0 = method_409();
      return method_403() != 14 && !method_497() ? false : var0 == 0 || var0 == 1;
   }

   // $VF: renamed from: aF () void
   public static void method_496() {
      int var0;
      if ((var0 = method_412(method_409())) == 31) {
         method_499();
      } else if (var0 == 30) {
         method_498();
      } else {
         if (var0 == 32) {
            method_500();
         }
      }
   }

   // $VF: renamed from: z () boolean
   public static boolean method_497() {
      return true;
   }

   // $VF: renamed from: aG () void
   public static void method_498() {
      field_203 = true;
      method_90(!method_91());
      method_413(true);
   }

   // $VF: renamed from: aH () void
   public static void method_499() {
      field_203 = true;
      method_88(!method_92());
      method_413(true);
   }

   // $VF: renamed from: aI () void
   public static void method_500() {
      field_203 = true;
      method_89(!method_94());
      method_413(true);
   }

   // $VF: renamed from: o (int) boolean
   public static boolean method_501(int var0) {
      int var1;
      if ((var1 = method_412(var0)) == 31 || var1 == 32) {
         if (var1 == 31) {
            if (method_81() > 0) {
               return true;
            }

            return false;
         }

         if (var1 == 32) {
            if (method_82() > 0) {
               return true;
            }

            return false;
         }
      }

      return false;
   }

   // $VF: renamed from: p (int) boolean
   public static boolean method_502(int var0) {
      int var1;
      if ((var1 = method_412(var0)) == 31 || var1 == 32) {
         if (var1 == 31) {
            if (method_81() < 4) {
               return true;
            }

            return false;
         }

         if (var1 == 32) {
            if (method_82() < 4) {
               return true;
            }

            return false;
         }
      }

      return false;
   }

   // $VF: renamed from: d (int, int) void
   public static final void method_503(int var0, int var1) {
      if (var1 == 31 || var1 == 32) {
         if (var1 == 31) {
            int var3;
            if ((var3 = method_81() + var0) >= 5) {
               var3 = 0;
            }

            if (var3 < 0) {
               var3 = 4;
            }

            method_83(var3);
         } else if (var1 == 32) {
            int var4;
            if ((var4 = method_82() + var0) >= 5) {
               var4 = 0;
            }

            if (var4 < 0) {
               var4 = 4;
            }

            method_84(var4);
         }

         field_203 = true;
         method_423(79);
         method_236();
         method_413(false);
      }
   }

   // $VF: renamed from: aJ () void
   public static void method_504() {
      if (method_1288()) {
         method_1299();
      }

      int var0;
      if ((var0 = method_160(method_231())) != 0) {
         method_503(var0, method_412(method_409()));
      }
   }

   // $VF: renamed from: e (byte[], int) int
   public static final int method_505(byte[] var0, int var1) {
      if (method_488()) {
         return var1;
      } else {
         var1 = method_259(var0, var1, 100075);
         var1 = method_259(var0, var1, field_461);
         field_231 = field_232;
         var1 = method_259(var0, var1, field_231);
         int var2 = 4;

         while (--var2 >= 0) {
            var1 = method_257(var0, var1, method_583(var2));
            var1 = method_257(var0, var1, method_585(var2));
            var1 = method_259(var0, var1, field_433[var2]);
            var1 = method_259(var0, var1, field_434[var2]);
         }

         var1 = method_258(var0, var1, field_462);
         var1 = method_257(var0, var1, field_463);
         var1 = method_257(var0, var1, field_489);
         var1 = method_544(var0, var1);
         var1 = method_1593(var0, var1);
         var1 = method_258(var0, var1, (byte)method_81());
         var1 = method_258(var0, var1, (byte)method_82());
         field_203 = false;
         return var1;
      }
   }

   // $VF: renamed from: f (byte[], int) int
   public static final int method_506(byte[] var0, int var1) {
      if (method_488()) {
         method_507();
         return var1;
      } else {
         int var2 = method_254(var0, var1);
         var1 += 4;
         if (var2 != 100075) {
            method_507();
            return var1;
         } else {
            field_461 = method_254(var0, var1);
            var1 += 4;
            field_231 = method_254(var0, var1);
            var1 += 4;
            int var3 = 4;

            while (--var3 >= 0) {
               boolean var4 = method_251(var0, var1);
               boolean var5 = method_251(var0, ++var1);
               var1++;
               method_582(var3, var4);
               method_584(var3, var5);
               field_433[var3] = method_254(var0, var1);
               var1 += 4;
               field_434[var3] = method_254(var0, var1);
               var1 += 4;
            }

            field_462 = method_252(var0, var1);
            field_463 = method_251(var0, ++var1);
            field_489 = method_251(var0, ++var1);
            var1 = method_545(var0, ++var1);
            var1 = method_1594(var0, var1);
            boolean var19 = method_91();
            byte var20 = method_252(var0, var1);
            var1++;
            method_83(var20);
            var20 = method_252(var0, var1);
            var1++;
            method_84(var20);
            method_90(var19);
            return var1;
         }
      }
   }

   // $VF: renamed from: aK () void
   public static final void method_507() {
      method_1013();
      method_581();
      method_590();
      method_1006();
      method_1024();
      method_562();
      method_1592();
      field_489 = false;
   }

   // $VF: renamed from: A () boolean
   public static boolean method_508() {
      return method_288() > 1;
   }

   // $VF: renamed from: u () int
   public static int method_509() {
      return method_288();
   }

   // $VF: renamed from: h (int) java.lang.String
   public static String method_510(int var0) {
      return method_295()[var0];
   }

   // $VF: renamed from: aL () void
   public static void method_511() {
      method_1630();
      method_167();
   }

   // $VF: renamed from: aM () void
   public static void method_512() {
      method_475();
   }

   // $VF: renamed from: aN () void
   public static void method_513() {
      method_346(method_287());
   }

   // $VF: renamed from: B () boolean
   public static boolean method_514() {
      return method_345() != method_287();
   }

   // $VF: renamed from: aO () void
   public static final void method_515() {
      field_204 = new long[256];
      field_205 = new long[256];
   }

   // $VF: renamed from: a (int, int, int, boolean) int
   public static final int method_516(int var0, int var1, int var2, boolean var3) {
      if (field_204 == null) {
         method_515();
      }

      field_206 = 0;
      field_207 = 0;
      byte var4 = field_306[var0];
      byte var5 = field_307[var0];
      int var6 = field_302[var0];
      int var7 = field_303[var0];
      field_210 = var4;
      field_211 = var5;
      method_1209(var4, var5);
      method_1216(field_600, field_601);
      int var8 = field_600;
      int var9 = field_601;
      int var10 = method_158(var6 - var8, var7 - var9);
      field_208 = var4 + method_160(var10);
      field_209 = var5 + method_161(var10);
      method_519(-1, var4, var5, var4, var5, var1, var2);

      int var11;
      while ((var11 = method_521(field_204, field_206)) != -1) {
         int var12 = method_523(field_204, var11);
         int var13 = method_524(field_204, var11);
         int var14;
         if ((var14 = method_520(var11)) == -1) {
            int var16 = field_207 - 1;
            if (method_517(var0, method_523(field_205, var16), method_524(field_205, var16))) {
               return 2;
            }

            return 0;
         }

         if (method_525(field_205, var11) > 256) {
            if (method_517(var0, var12, var13)) {
               return 2;
            }

            return 0;
         }

         if (var12 == var1 && var13 == var2) {
            if (method_517(var0, var12, var13)) {
               return 1;
            }

            return 0;
         }

         boolean var15;
         if (var15 = method_518(var0, var14, var12, var13, var12, var13 - 1, var1, var2, var3)) {
            var15 = method_518(var0, var14, var12, var13, var12 + 1, var13, var1, var2, var3);
         }

         if (var15) {
            var15 = method_518(var0, var14, var12, var13, var12, var13 + 1, var1, var2, var3);
         }

         if (var15) {
            var15 = method_518(var0, var14, var12, var13, var12 - 1, var13, var1, var2, var3);
         }

         if (!var15) {
            method_517(var0, var12, var13);
            return 2;
         }
      }

      return 0;
   }

   // $VF: renamed from: d (int, int, int) boolean
   private static final boolean method_517(int var0, int var1, int var2) {
      method_637(var0);
      byte var3 = field_306[var0];
      byte var4 = field_307[var0];
      int var5 = -1;

      while (var1 != var3 || var2 != var4) {
         int var6;
         if ((var6 = method_522(field_205, field_207, var1, var2)) < 0) {
            return false;
         }

         int var7 = method_528(field_205, var6);
         if (var5 < 0 || var7 != var5) {
            method_638(var0, (byte)var1, (byte)var2);
         }

         var5 = var7;
         var1 += method_160(var7);
         var2 += method_161(var7);
      }

      return true;
   }

   // $VF: renamed from: a (int, int, int, int, int, int, int, int, boolean) boolean
   private static final boolean method_518(int var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7, boolean var8) {
      if (method_522(field_205, field_207, var4, var5) != -1) {
         return true;
      } else {
         if (!method_648(field_309[var0], var4, var5, var0, var8)) {
            int var9;
            if ((var9 = method_522(field_204, field_206, var4, var5)) == -1) {
               boolean var10000 = method_519(var1, var2, var3, var4, var5, var6, var7);
               boolean var10 = false;
               if (!var10000) {
                  return false;
               }
            } else {
               int var18 = method_526(field_204, var9);
               int var11;
               if ((var11 = method_526(field_205, var1) + 1) < var18) {
                  long var12 = method_527(field_204, var9);
                  long var14 = method_158(var2 - var4, var3 - var5);
                  long var16 = var11 + var12;
                  field_204[var9] = (long)var4 << 36 | (long)var5 << 28 | var16 << 20 | var11 << 12 | var12 << 4 | var14;
               }
            }
         }

         return true;
      }
   }

   // $VF: renamed from: a (int, int, int, int, int, int, int) boolean
   private static final boolean method_519(int var0, int var1, int var2, int var3, int var4, int var5, int var6) {
      if (field_206 == 256) {
         return false;
      } else {
         int var7;
         if (var1 == field_210 && var2 == field_211 && var3 == field_208 && var4 == field_209) {
            var7 = 1;
         } else {
            var7 = 4;
         }

         int var8 = var0 < 0 ? 0 : method_528(field_205, var0);
         long var9;
         if ((var9 = method_158(var1 - var3, var2 - var4)) != var8) {
            var7++;
         }

         long var11 = var0 == -1 ? 0 : method_526(field_205, var0) + var7;
         int var17;
         int var18;
         long var13 = ((var17 = var3 - var5) < 0 ? -var17 : var17) + ((var18 = var4 - var6) < 0 ? -var18 : var18);
         long var15 = var11 + var13;
         field_204[field_206] = (long)var3 << 36 | (long)var4 << 28 | var15 << 20 | var11 << 12 | var13 << 4 | var9;
         field_206++;
         return true;
      }
   }

   // $VF: renamed from: Z (int) int
   private static final int method_520(int var0) {
      if (field_207 == 256) {
         return -1;
      } else {
         long var1 = field_204[var0];
         if (field_206 > var0 + 1) {
            method_565(field_204, var0 + 1, field_206 - var0 - 1);
         }

         field_206--;
         field_205[field_207] = var1;
         field_207++;
         return field_207 - 1;
      }
   }

   // $VF: renamed from: a (long[], int) int
   private static final int method_521(long[] var0, int var1) {
      int var2 = Integer.MAX_VALUE;
      int var3 = -1;

      for (int var4 = var1 - 1; var4 >= 0; var4--) {
         int var5;
         if ((var5 = method_525(var0, var4)) < var2) {
            var2 = var5;
            var3 = var4;
         }
      }

      return var3;
   }

   // $VF: renamed from: a (long[], int, int, int) int
   private static final int method_522(long[] var0, int var1, int var2, int var3) {
      for (int var4 = var1 - 1; var4 >= 0; var4--) {
         if (method_523(var0, var4) == var2 && method_524(var0, var4) == var3) {
            return var4;
         }
      }

      return -1;
   }

   // $VF: renamed from: b (long[], int) int
   private static final int method_523(long[] var0, int var1) {
      return (int)((17523466567680L & var0[var1]) >> 36);
   }

   // $VF: renamed from: c (long[], int) int
   private static final int method_524(long[] var0, int var1) {
      return (int)((68451041280L & var0[var1]) >> 28);
   }

   // $VF: renamed from: d (long[], int) int
   private static final int method_525(long[] var0, int var1) {
      return (int)((267386880L & var0[var1]) >> 20);
   }

   // $VF: renamed from: e (long[], int) int
   private static final int method_526(long[] var0, int var1) {
      return (int)((1044480L & var0[var1]) >> 12);
   }

   // $VF: renamed from: f (long[], int) int
   private static final int method_527(long[] var0, int var1) {
      return (int)((4080L & var0[var1]) >> 4);
   }

   // $VF: renamed from: g (long[], int) int
   private static final int method_528(long[] var0, int var1) {
      return (int)(15L & var0[var1]);
   }

   // $VF: renamed from: q (int) boolean
   public static final boolean method_529(int var0) {
      return var0 == 43;
   }

   // $VF: renamed from: r (int) boolean
   public static final boolean method_530(int var0) {
      return var0 == 45;
   }

   // $VF: renamed from: w (int) void
   public static final void method_531(int var0) {
      method_731(var0, true, false);
      field_474 = var0;
      field_475 = var0;
      field_476 = true;
      method_423(72);
   }

   // $VF: renamed from: h (boolean) void
   public static final void method_532(boolean var0) {
      field_720 = 67108863;
      method_552(Integer.MAX_VALUE);
      field_212 = -1;
      field_214 = -1;
      field_215 = -1;
      if (!var0) {
         field_217 = -1;
         field_216 = -1;
      }
   }

   // $VF: renamed from: C () boolean
   public static final boolean method_533() {
      int var0 = 4;

      while (--var0 >= 0) {
         if (method_763(field_358, var0) >= 0) {
            return false;
         }
      }

      return true;
   }

   // $VF: renamed from: D () boolean
   public static final boolean method_534() {
      int var0 = 4;

      while (--var0 >= 0) {
         byte var1;
         if ((var1 = method_763(field_358, var0)) >= 0 && !method_555(field_329[var1])) {
            return true;
         }
      }

      return false;
   }

   // $VF: renamed from: aP () void
   public static final void method_535() {
      if (field_223 > 0 && field_225 < 0) {
         int var0 = field_213 - field_223 + 1;

         for (int var1 = 1; field_225 < 0 && var1 <= 4; var1++) {
            for (int var2 = 0; field_225 < 0 && var2 <= 6; var2++) {
               int var3 = method_553(var2, var1);
               if (field_218[var3] == var0) {
                  field_226 = (byte)var1;
                  field_225 = (byte)var2;
               }
            }
         }
      }

      int var10 = method_1276(field_52, 0, 400);
      long var11 = method_1373(true, false, method_133(214), method_563(field_225, field_226), false, (byte)2, false, false, true, var10, var10, false, false);
      method_62(6192724378386649L, var10, 0);
      Graphics var12 = field_51;
      int var4 = method_68(var11);
      int var5 = method_69(var11);
      int var6 = method_70(var11);
      int var7 = method_71(var11);
      boolean var8;
      if (var8 = field_220 >= 0) {
         var12.translate(var4, var5);
      } else {
         method_63(var4, var5, var6, var7);
      }

      if (field_220 >= 0) {
         method_951(var6, var7);
      } else if (field_221 >= 0) {
         method_952(var6, var7);
      } else if (field_222 >= 0) {
         method_542(var12, var6);
      } else if (field_223 >= 0) {
         method_854(var12, var6, var7, false);
      } else if (field_228 >= 0 || field_227 >= 0) {
         boolean var9 = field_228 >= 0;
         method_855(var12, var6, var7, var9, var9 ? field_228 : field_227);
      }

      if (var8) {
         var12.translate(-var4, -var5);
      } else {
         method_64();
      }

      method_64();
      method_1278(true);
      method_413(true);
   }

   // $VF: renamed from: E () boolean
   public static final boolean method_536() {
      return field_223 > 1;
   }

   // $VF: renamed from: aQ () void
   public static final void method_537() {
      field_223--;
   }

   // $VF: renamed from: aR () void
   public static final void method_538() {
      if (field_224 >= 0) {
         method_667(field_224);
      }
   }

   // $VF: renamed from: aS () void
   public static final void method_539() {
      field_224 = -1;
      field_225 = -1;
      field_226 = -1;
      field_619 = method_401();
   }

   // $VF: renamed from: F () boolean
   public static final boolean method_540() {
      return field_220 >= 0;
   }

   // $VF: renamed from: aT () void
   public static void method_541() {
      field_479 = field_220;
      method_1100();
   }

   // $VF: renamed from: d (javax.microedition.lcdui.Graphics, int) void
   private static final void method_542(Graphics var0, int var1) {
      if (field_224 < 0) {
         field_224 = (byte)method_673(0 + field_222, 2);
      }

      byte var2 = field_224;
      int var3 = field_299[var2];
      int var4 = var1 >> 1;
      int var5 = method_1506(12);
      method_1242(var0, var2, var3, var4, var5, false, false, true);
   }

   // $VF: renamed from: G () boolean
   public static final boolean method_543() {
      return field_220 >= 0 || field_221 >= 0 || field_222 >= 0 || field_223 >= 0 || field_228 >= 0 || field_227 >= 0;
   }

   // $VF: renamed from: g (byte[], int) int
   public static final int method_544(byte[] var0, int var1) {
      var1 = method_258(var0, var1, field_212);
      var1 = method_258(var0, var1, field_213);
      var1 = method_258(var0, var1, field_214);
      var1 = method_258(var0, var1, field_215);
      int var2 = 4;

      while (--var2 >= 0) {
         var1 = method_258(var0, var1, field_478[var2]);
      }

      var1 = method_259(var0, var1, field_216);
      return method_259(var0, var1, field_217);
   }

   // $VF: renamed from: h (byte[], int) int
   public static final int method_545(byte[] var0, int var1) {
      field_212 = method_252(var0, var1);
      method_552(method_252(var0, ++var1));
      field_214 = method_252(var0, ++var1);
      field_215 = method_252(var0, ++var1);
      var1++;

      for (int var2 = 4; --var2 >= 0; var1++) {
         field_478[var2] = method_252(var0, var1);
      }

      field_216 = method_254(var0, var1);
      var1 += 4;
      field_217 = method_254(var0, var1);
      return var1 + 4;
   }

   // $VF: renamed from: s (int) boolean
   public static final boolean method_546(int var0) {
      return var0 == 1;
   }

   // $VF: renamed from: t (int) boolean
   public static boolean method_547(int var0) {
      return (field_216 & 1 << var0) != 0;
   }

   // $VF: renamed from: u (int) boolean
   public static boolean method_548(int var0) {
      return (field_217 & 1 << var0) != 0;
   }

   // $VF: renamed from: x (int) void
   public static void method_549(int var0) {
      field_216 |= 1 << var0;
   }

   // $VF: renamed from: y (int) void
   public static void method_550(int var0) {
      field_217 |= 1 << var0;
   }

   // $VF: renamed from: aU () void
   public static final void method_551() {
      field_220 = -1;
      field_221 = -1;
      field_222 = -1;
      field_223 = -1;
      field_224 = -1;
      field_227 = -1;
      field_228 = -1;
      boolean var0 = false;
      int var1;
      if (field_479 < 3 && !method_560(var1 = field_479 + 1) && field_445 >= field_662[var1]) {
         method_559(var1);
         field_220 = (byte)var1;
         var0 = true;
      }

      for (int var3 = 0; var3 < 4; var3++) {
         if (!var0 && !method_557(var3) && field_479 >= field_664[var3] && field_445 >= field_663[var3]) {
            method_556(var3);
            if (var3 == 1) {
               method_552(method_148(field_213, field_677));
            } else if (var3 == 2) {
               method_552(method_148(field_213, field_678));
            } else if (var3 == 3) {
               method_552(method_148(field_213, field_679));
            }

            field_221 = (byte)var3;
            var0 = true;
            break;
         }
      }

      for (int var4 = 0; var4 < 3; var4++) {
         if (!var0 && !method_555(var4) && field_479 >= field_666[var4] && field_445 >= field_665[var4]) {
            method_554(var4);
            field_222 = (byte)var4;
            var0 = true;
            break;
         }
      }

      if (!var0 && field_213 < field_219) {
         var1 = field_479;
         byte var2 = method_1050(field_479);
         if (field_459 >= var2 * 150 / 100) {
            field_223 = (byte)method_552(field_213 + 2);
            var0 = true;
         } else if (field_459 >= var2) {
            field_223 = (byte)method_552(field_213 + 1);
            var0 = true;
         }

         if (var0 && field_478[var1] < 9) {
            field_478[var1]++;
         }
      }

      if (!var0 && field_213 == field_219) {
         var1 = field_479;
         byte var8 = method_1050(field_479);
         if (field_459 >= var8 && (var0 = method_859()) && field_478[var1] < 9) {
            field_478[var1]++;
         }
      }

      if (!var0 && field_213 < field_219) {
         var1 = field_479;
         byte var9 = method_1050(field_479);
         method_1052(var1, (byte)method_148(1, var9 * 80 / 100));
      }
   }

   // $VF: renamed from: x (int) int
   public static final int method_552(int var0) {
      int var1 = field_213;
      field_213 = method_150(var0, 0, field_219);
      return field_213 - var1;
   }

   // $VF: renamed from: l (int, int) int
   public static final int method_553(int var0, int var1) {
      return var0 + (var1 - 1) * 10;
   }

   // $VF: renamed from: z (int) void
   public static final void method_554(int var0) {
      field_215 = (byte)(field_215 | 1 << var0);
   }

   // $VF: renamed from: v (int) boolean
   public static final boolean method_555(int var0) {
      return (field_215 & 1 << var0) != 0;
   }

   // $VF: renamed from: A (int) void
   public static final void method_556(int var0) {
      field_214 = (byte)(field_214 | 1 << var0);
   }

   // $VF: renamed from: w (int) boolean
   public static final boolean method_557(int var0) {
      return (field_214 & 1 << var0) != 0;
   }

   // $VF: renamed from: a (byte, int) boolean
   public static final boolean method_558(byte var0, int var1) {
      return field_218[method_553(var1, var0)] > field_213;
   }

   // $VF: renamed from: B (int) void
   public static final void method_559(int var0) {
      field_212 = (byte)(field_212 | 1 << var0);
   }

   // $VF: renamed from: x (int) boolean
   public static final boolean method_560(int var0) {
      return (field_212 & 1 << var0) != 0;
   }

   // $VF: renamed from: H () boolean
   public static final boolean method_561() {
      return !method_560(field_479);
   }

   // $VF: renamed from: aV () void
   public static void method_562() {
      field_212 = 1;
      field_213 = 0;
      field_214 = 1;
      field_215 = 1;
      int var0 = 4;

      while (--var0 >= 0) {
         field_478[var0] = 0;
      }

      field_216 = 3;
      field_217 = 5;
   }

   // $VF: renamed from: a (int, int) java.lang.String
   public static final String method_563(int var0, int var1) {
      return method_133(
         field_220 >= 0
            ? 289 + field_220
            : (
               field_221 >= 0
                  ? 228 + field_221
                  : (field_222 >= 0 ? 296 + field_222 : (field_228 >= 0 ? 393 + field_228 : (field_227 >= 0 ? 402 + field_227 : 353 + method_553(var0, var1))))
            )
      );
   }

   // $VF: renamed from: aW () void
   public static final void method_564() {
      field_492 = (field_492 + 1) % 66;
      field_220 = -1;
      field_221 = -1;
      field_222 = -1;
      field_225 = -1;
      field_226 = -1;
      field_223 = -1;
      field_228 = -1;
      field_227 = -1;
      switch (field_492) {
         case 0:
            field_220 = 0;
            break;
         case 1:
            field_220 = 1;
            break;
         case 2:
            field_220 = 2;
            break;
         case 3:
            field_220 = 3;
            break;
         case 4:
            field_221 = 2;
            break;
         case 5:
            field_221 = 1;
            break;
         case 6:
            field_221 = 2;
            break;
         case 7:
            field_221 = 3;
            break;
         case 8:
            field_222 = 0;
            break;
         case 9:
            field_222 = 1;
            break;
         case 10:
            field_222 = 2;
            break;
         case 11:
         case 12:
         case 13:
         case 14:
         case 15:
         case 16:
         case 17:
         case 18:
         case 19:
         case 20:
            field_225 = (byte)(0 + field_492 - 11);
            field_226 = 1;
            field_223 = 1;
            break;
         case 21:
         case 22:
         case 23:
         case 24:
         case 25:
         case 26:
         case 27:
         case 28:
         case 29:
         case 30:
            field_225 = (byte)(0 + field_492 - 21);
            field_226 = 2;
            field_223 = 1;
            break;
         case 31:
         case 32:
         case 33:
         case 34:
         case 35:
         case 36:
         case 37:
         case 38:
         case 39:
         case 40:
            field_225 = (byte)(0 + field_492 - 31);
            field_226 = 3;
            field_223 = 1;
            break;
         case 41:
         case 42:
         case 43:
         case 44:
         case 45:
         case 46:
         case 47:
         case 48:
         case 49:
         case 50:
            field_225 = (byte)(0 + field_492 - 41);
            field_226 = 4;
            field_223 = 1;
      }

      if (field_492 >= 51 && field_492 <= 60) {
         field_228 = (byte)(field_492 - 51);
      } else {
         if (field_492 >= 60 && field_492 <= 66) {
            field_227 = (byte)(field_492 - 60);
         }
      }
   }

   // $VF: renamed from: a (long[], int, int) void
   public static final void method_565(long[] var0, int var1, int var2) {
      int var3 = var1 + var2;

      for (int var4 = var1; var4 < var3; var4++) {
         var0[var4 - 1] = var0[var4];
      }
   }

   // $VF: renamed from: a (byte[], int, int) void
   public static final void method_566(byte[] var0, int var1, int var2) {
      int var3 = var1 + var2 + 1;

      while (--var3 > 0) {
         var0[var3] = var0[var3 - 1];
      }
   }

   // $VF: renamed from: m (int, int) int
   public static final int method_567(int var0, int var1) {
      for (int var2 = 0; var2 <= var1; var2++) {
         if ((var0 & 1 << var2) == 0) {
            return var2;
         }
      }

      return -1;
   }

   // $VF: renamed from: y (int) int
   public static final int method_568(int var0) {
      for (int var1 = 0; var1 < 32; var1++) {
         if ((var0 & 1 << var1) != 0) {
            return var1;
         }
      }

      return -1;
   }

   // $VF: renamed from: a (int[], int, int) boolean
   public static final boolean method_569(int[] var0, int var1, int var2) {
      return (var0[var1] & var2) != 0;
   }

   // $VF: renamed from: a (int[], int, int, boolean, boolean, int[], int) void
   public static final void method_570(int[] var0, int var1, int var2, boolean var3, boolean var4, int[] var5, int var6) {
      if (var4 && (var0[var1] & var2) != 0 != var3) {
         var5[var1] = var6;
      }

      if (var3) {
         var0[var1] |= var2;
      } else {
         var0[var1] &= ~var2;
      }
   }

   // $VF: renamed from: a (byte[], int, byte) void
   public static final void method_571(byte[] var0, int var1, byte var2) {
      int var3 = var1;

      while (--var3 >= 0) {
         var0[var3] = var2;
      }
   }

   // $VF: renamed from: c (int, int, int, int) int
   public static final int method_572(int var0, int var1, int var2, int var3) {
      int var4 = method_260(var0, var1, var2);
      int var6 = method_260(var0, var1, var3) - var4;
      return var4 + (var6 == 0 ? 0 : method_152(var6));
   }

   // $VF: renamed from: a (byte[], byte[], int[], int, int) void
   public static final void method_573(byte[] var0, byte[] var1, int[] var2, int var3, int var4) {
      boolean var5 = false;
      boolean var6 = false;
      int var7 = 1000000;

      for (int var8 = 0; var8 < var3; var8++) {
         byte var9 = var0[var8];
         byte var10 = (byte)(var4 / var7 % 10);
         if (var9 > 0) {
            var5 = true;
         }

         if (var10 > 0) {
            var6 = true;
         }

         if (var9 == var10 && (var9 != 0 || var10 != 0 || var5 == var6)) {
            var2[var8] = -1;
         } else {
            var2[var8] = var3 - var8 << 1;
         }

         var1[var8] = var9;
         var0[var8] = var10;
         var7 /= 10;
      }
   }

   // $VF: renamed from: d (int, int, int) int
   public static final int method_574(int var0, int var1, int var2) {
      return var0 + method_151(var1 + 128, var2);
   }

   // $VF: renamed from: e (int, int, int) int
   public static final int method_575(int var0, int var1, int var2) {
      return var0 + method_151(var1, var2);
   }

   // $VF: renamed from: b (int, int, int, int) long
   public static final long method_576(int var0, int var1, int var2, int var3) {
      int var4 = var0 - var1;
      int var5 = var2 - var3;
      return var4 * var4 + var5 * var5;
   }

   // $VF: renamed from: d (int, int, int, int) int
   public static final int method_577(int var0, int var1, int var2, int var3) {
      var2 = method_149(var2, var3);
      int var4;
      int var6;
      int var5 = (var6 = var4 = var1 - var0) < 0 ? -var6 : var6;
      return var0 + method_147(var4) * (method_151(384 + var2 * 256 / var3, var5) + var5) / 2;
   }

   // $VF: renamed from: e (int, int, int, int) int
   public static final int method_578(int var0, int var1, int var2, int var3) {
      var2 = method_149(var2, var3);
      int var4;
      int var6;
      int var5 = (var6 = var4 = var1 - var0) < 0 ? -var6 : var6;
      return var0 + method_147(var4) * (method_151(384 + var2 * 128 / var3, var5) + var5);
   }

   // $VF: renamed from: f (int, int, int, int) int
   public static final int method_579(int var0, int var1, int var2, int var3) {
      var2 = method_149(var2, var3);
      int var4 = var1 - var0;
      return var0 + method_151(var2 * 128 / var3, var4 < 0 ? -var4 : var4) * method_147(var4);
   }

   // $VF: renamed from: aX () void
   public static final void method_580() {
      method_581();
      method_590();
      method_1006();
      method_1024();
      method_562();
      method_589();
   }

   // $VF: renamed from: aY () void
   public static final void method_581() {
      field_229 = 0;
      field_230 = 0;
   }

   // $VF: renamed from: a (int, boolean) void
   public static final void method_582(int var0, boolean var1) {
      if (!method_488()) {
         if (var1) {
            field_229 |= 1 << var0;
            return;
         }

         field_229 &= ~(1 << var0);
      }
   }

   // $VF: renamed from: y (int) boolean
   public static final boolean method_583(int var0) {
      return !method_488() && (field_229 & 1 << var0) != 0;
   }

   // $VF: renamed from: b (int, boolean) void
   public static final void method_584(int var0, boolean var1) {
      if (!method_488()) {
         if (var1) {
            field_230 |= 1 << var0;
            return;
         }

         field_230 &= ~(1 << var0);
      }
   }

   // $VF: renamed from: z (int) boolean
   public static final boolean method_585(int var0) {
      return method_583(var0) && (field_230 & 1 << var0) != 0;
   }

   // $VF: renamed from: i (byte[], int) int
   public static final int method_586(byte[] var0, int var1) {
      if (method_488()) {
         return var1;
      } else {
         var1 = method_259(var0, var1, 100075);
         var1 = method_259(var0, var1, field_669);
         var1 = method_259(var0, var1, field_670);
         var1 = method_259(var0, var1, field_671);
         var1 = method_259(var0, var1, field_465);
         var1 = method_258(var0, var1, field_466);
         var1 = method_259(var0, var1, field_467);
         var1 = method_258(var0, var1, field_422);
         var1 = method_258(var0, var1, field_423);
         var1 = method_258(var0, var1, field_424);
         var1 = method_258(var0, var1, field_425);
         var1 = method_259(var0, var1, field_435);
         var1 = method_258(var0, var1, field_426);
         var1 = method_259(var0, var1, field_436);
         var1 = method_258(var0, var1, field_427);
         var1 = method_259(var0, var1, field_428);
         var1 = method_259(var0, var1, field_437);
         var1 = method_259(var0, var1, field_438);
         var1 = method_259(var0, var1, field_439);
         var1 = method_259(var0, var1, field_440);
         var1 = method_259(var0, var1, field_441);
         var1 = method_259(var0, var1, field_442);
         var1 = method_259(var0, var1, field_443);
         var1 = method_259(var0, var1, field_444);
         var1 = method_259(var0, var1, field_359);
         var1 = method_258(var0, var1, field_360);
         var1 = method_258(var0, var1, field_362);
         var1 = method_258(var0, var1, field_363);
         var1 = method_258(var0, var1, field_364);
         var1 = method_259(var0, var1, field_368);
         var1 = method_259(var0, var1, field_369);
         int var2 = field_406;

         while (--var2 >= 0) {
            int var3 = 81;

            while (--var3 >= 0) {
               var1 = method_258(var0, var1, field_298[var2][var3]);
            }

            var3 = 10;

            while (--var3 >= 0) {
               var1 = method_258(var0, var1, field_396[var2][var3]);
               var1 = method_258(var0, var1, field_397[var2][var3]);
               var1 = method_258(var0, var1, field_398[var2][var3]);
               var1 = method_258(var0, var1, field_399[var2][var3]);
               var1 = method_258(var0, var1, field_400[var2][var3]);
               var1 = method_259(var0, var1, field_401[var2][var3]);
               var1 = method_259(var0, var1, field_402[var2][var3]);
               var1 = method_259(var0, var1, field_403[var2][var3]);
            }

            var1 = method_258(var0, var1, field_409[var2]);
            var1 = method_258(var0, var1, field_410[var2]);
            var1 = method_258(var0, var1, field_412[var2]);
            var1 = method_258(var0, var1, field_413[var2]);
            var1 = method_258(var0, var1, field_418[var2]);
         }

         var1 = method_258(var0, var1, field_414);
         var1 = method_258(var0, var1, field_415);
         var1 = method_258(var0, var1, field_416);
         var1 = method_259(var0, var1, field_417);
         var2 = field_284;

         while (--var2 >= 0) {
            var1 = method_259(var0, var1, field_299[var2]);
            var1 = method_258(var0, var1, field_300[var2]);
            var1 = method_258(var0, var1, field_301[var2]);
            var1 = method_259(var0, var1, field_302[var2]);
            var1 = method_259(var0, var1, field_303[var2]);
            var1 = method_259(var0, var1, field_304[var2]);
            var1 = method_259(var0, var1, field_305[var2]);
            var1 = method_258(var0, var1, field_306[var2]);
            var1 = method_258(var0, var1, field_307[var2]);
            var1 = method_258(var0, var1, field_308[var2]);
            var1 = method_258(var0, var1, field_309[var2]);
            if (var2 <= field_290) {
               var1 = method_259(var0, var1, field_310[var2]);
               var1 = method_259(var0, var1, field_311[var2]);
               var1 = method_259(var0, var1, field_312[var2]);
               var1 = method_259(var0, var1, field_313[var2]);
               var1 = method_258(var0, var1, field_314[var2]);
               var1 = method_258(var0, var1, field_315[var2]);
               var1 = method_258(var0, var1, field_316[var2]);
               var1 = method_259(var0, var1, field_317[var2]);
               var1 = method_259(var0, var1, field_318[var2]);
               var1 = method_259(var0, var1, field_319[var2]);
               var1 = method_259(var0, var1, field_320[var2]);
               var1 = method_259(var0, var1, field_321[var2]);
               var1 = method_258(var0, var1, field_322[var2]);
               int var95 = 16;

               while (--var95 >= 0) {
                  var1 = method_258(var0, var1, field_323[var2][var95]);
                  var1 = method_258(var0, var1, field_324[var2][var95]);
               }

               var1 = method_259(var0, var1, field_325[var2]);
               var1 = method_259(var0, var1, field_326[var2]);
               var1 = method_259(var0, var1, field_327[var2]);
               var1 = method_258(var0, var1, field_328[var2]);
            }

            if (var2 <= field_288) {
               var1 = method_258(var0, var1, field_329[var2]);
               var1 = method_258(var0, var1, field_330[var2]);
               var1 = method_258(var0, var1, method_735(field_331, var2));
               var1 = method_258(var0, var1, method_735(field_332, var2));
               var1 = method_258(var0, var1, method_735(field_333, var2));
               var1 = method_258(var0, var1, field_334[var2]);
               var1 = method_258(var0, var1, field_335[var2]);
               var1 = method_258(var0, var1, field_336[var2]);
               var1 = method_258(var0, var1, field_337[var2]);
               var1 = method_258(var0, var1, field_338[var2]);
               var1 = method_258(var0, var1, field_339[var2]);
               var1 = method_258(var0, var1, field_340[var2]);
               var1 = method_258(var0, var1, field_341[var2]);
               var1 = method_258(var0, var1, field_342[var2]);
               var1 = method_259(var0, var1, field_343[var2]);
               var1 = method_258(var0, var1, field_344[var2]);
               var1 = method_258(var0, var1, field_345[var2]);
            }
         }

         return var1;
      }
   }

   // $VF: renamed from: j (byte[], int) int
   public static final int method_587(byte[] var0, int var1) {
      if (method_488()) {
         method_588();
         return var1;
      } else {
         int var2 = method_254(var0, var1);
         var1 += 4;
         if (var2 != 100075) {
            method_588();
            return var1;
         } else {
            field_669 = method_254(var0, var1);
            var1 += 4;
            field_670 = method_254(var0, var1);
            var1 += 4;
            field_671 = method_254(var0, var1);
            var1 += 4;
            field_465 = method_254(var0, var1);
            var1 += 4;
            field_466 = method_252(var0, var1);
            field_467 = method_254(var0, ++var1);
            var1 += 4;
            field_422 = method_252(var0, var1);
            field_423 = method_252(var0, ++var1);
            field_424 = method_252(var0, ++var1);
            field_425 = method_252(var0, ++var1);
            field_435 = method_254(var0, ++var1);
            var1 += 4;
            field_426 = method_252(var0, var1);
            field_436 = method_254(var0, ++var1);
            var1 += 4;
            field_427 = method_252(var0, var1);
            field_428 = method_254(var0, ++var1);
            var1 += 4;
            field_437 = method_254(var0, var1);
            var1 += 4;
            field_438 = method_254(var0, var1);
            var1 += 4;
            field_439 = method_254(var0, var1);
            var1 += 4;
            field_440 = method_254(var0, var1);
            var1 += 4;
            field_441 = method_254(var0, var1);
            var1 += 4;
            field_442 = method_254(var0, var1);
            var1 += 4;
            field_443 = method_254(var0, var1);
            var1 += 4;
            field_444 = method_254(var0, var1);
            var1 += 4;
            field_359 = method_254(var0, var1);
            var1 += 4;
            field_360 = method_252(var0, var1);
            field_362 = method_252(var0, ++var1);
            field_363 = method_252(var0, ++var1);
            field_364 = method_252(var0, ++var1);
            field_368 = method_254(var0, ++var1);
            var1 += 4;
            field_369 = method_254(var0, var1);
            var1 += 4;

            for (int var3 = field_406; --var3 >= 0; var1++) {
               for (int var4 = 81; --var4 >= 0; var1++) {
                  field_298[var3][var4] = method_252(var0, var1);
               }

               int var95 = 10;

               while (--var95 >= 0) {
                  field_396[var3][var95] = method_252(var0, var1);
                  field_397[var3][var95] = method_252(var0, ++var1);
                  field_398[var3][var95] = method_252(var0, ++var1);
                  field_399[var3][var95] = method_252(var0, ++var1);
                  field_400[var3][var95] = method_252(var0, ++var1);
                  field_401[var3][var95] = method_254(var0, ++var1);
                  var1 += 4;
                  field_402[var3][var95] = method_254(var0, var1);
                  var1 += 4;
                  field_403[var3][var95] = method_254(var0, var1);
                  var1 += 4;
               }

               field_409[var3] = method_252(var0, var1);
               field_410[var3] = method_252(var0, ++var1);
               field_411[var3] = method_937(var3);
               field_412[var3] = method_252(var0, var1);
               field_413[var3] = method_252(var0, ++var1);
               field_418[var3] = method_252(var0, ++var1);
               var1++;
            }

            field_414 = method_252(var0, var1);
            field_415 = method_252(var0, ++var1);
            field_416 = method_252(var0, ++var1);
            field_417 = method_254(var0, ++var1);
            var1 += 4;
            int var94 = field_284;

            while (--var94 >= 0) {
               field_299[var94] = method_254(var0, var1);
               int var51 = var1 + 4;
               field_300[var94] = method_252(var0, var51);
               field_301[var94] = method_252(var0, ++var51);
               field_302[var94] = method_254(var0, ++var51);
               int var54 = var51 + 4;
               field_303[var94] = method_254(var0, var54);
               int var55 = var54 + 4;
               field_304[var94] = method_254(var0, var55);
               int var56 = var55 + 4;
               field_305[var94] = method_254(var0, var56);
               var1 = var56 + 4;
               field_306[var94] = method_252(var0, var1);
               field_307[var94] = method_252(var0, ++var1);
               field_308[var94] = method_252(var0, ++var1);
               method_972(var94, method_252(var0, ++var1));
               var1++;
               if (var94 <= field_290) {
                  field_310[var94] = method_254(var0, var1);
                  var1 += 4;
                  field_311[var94] = method_254(var0, var1);
                  var1 += 4;
                  field_312[var94] = method_254(var0, var1);
                  var1 += 4;
                  field_313[var94] = method_254(var0, var1);
                  var1 += 4;
                  field_314[var94] = method_252(var0, var1);
                  field_315[var94] = method_252(var0, ++var1);
                  method_712(var94, method_252(var0, ++var1));
                  field_317[var94] = method_254(var0, ++var1);
                  var1 += 4;
                  field_318[var94] = method_254(var0, var1);
                  var1 += 4;
                  field_319[var94] = method_254(var0, var1);
                  var1 += 4;
                  field_320[var94] = method_254(var0, var1);
                  var1 += 4;
                  field_321[var94] = method_254(var0, var1);
                  var1 += 4;
                  field_322[var94] = method_252(var0, var1);
                  var1++;

                  for (int var96 = 16; --var96 >= 0; var1++) {
                     field_323[var94][var96] = method_252(var0, var1);
                     field_324[var94][var96] = method_252(var0, ++var1);
                  }

                  field_325[var94] = method_254(var0, var1);
                  int var75 = var1 + 4;
                  field_326[var94] = method_254(var0, var75);
                  int var76 = var75 + 4;
                  field_327[var94] = method_254(var0, var76);
                  var1 = var76 + 4;
                  field_328[var94] = method_252(var0, var1);
                  var1++;
               }

               if (var94 <= field_288) {
                  field_329[var94] = method_252(var0, var1);
                  field_330[var94] = method_252(var0, ++var1);
                  method_736(field_331, var94, method_252(var0, ++var1));
                  method_736(field_332, var94, method_252(var0, ++var1));
                  method_736(field_333, var94, method_252(var0, ++var1));
                  field_334[var94] = method_252(var0, ++var1);
                  field_335[var94] = method_252(var0, ++var1);
                  field_336[var94] = method_252(var0, ++var1);
                  field_337[var94] = method_252(var0, ++var1);
                  field_338[var94] = method_252(var0, ++var1);
                  field_339[var94] = method_252(var0, ++var1);
                  field_340[var94] = method_252(var0, ++var1);
                  field_341[var94] = method_252(var0, ++var1);
                  field_342[var94] = method_252(var0, ++var1);
                  field_343[var94] = method_254(var0, ++var1);
                  var1 += 4;
                  field_344[var94] = method_252(var0, var1);
                  field_345[var94] = method_252(var0, ++var1);
                  var1++;
               }
            }

            return var1;
         }
      }
   }

   // $VF: renamed from: aZ () void
   public static final void method_588() {
      method_589();
      method_584(field_479, false);
   }

   // $VF: renamed from: ba () void
   public static final void method_589() {
      field_465 = 0;
      field_466 = 0;
      field_467 = 0;
      field_422 = 0;
      field_423 = 0;
      field_424 = 0;
      field_425 = 0;
      field_435 = 0;
      field_426 = 0;
      field_436 = 0;
      field_427 = 0;
      field_428 = 0;
      field_437 = 0;
      field_438 = 0;
      field_439 = 0;
      field_440 = 0;
      field_441 = 0;
      field_442 = 0;
      field_443 = 0;
      field_444 = 0;
      method_772();
      field_368 = 0;
      field_369 = 0;
      int var0 = field_406;

      while (--var0 >= 0) {
         method_640(var0);
      }

      method_884();
      method_989();
      method_666();
   }

   // $VF: renamed from: bb () void
   public static final void method_590() {
      field_231 = 512;
      if (method_403() != 107) {
         field_232 = 512;
      }
   }

   // $VF: renamed from: ag () int
   private static int method_591() {
      return method_401() - field_236;
   }

   // $VF: renamed from: b (int, int, int) void
   public static final void method_592(int var0, int var1, int var2) {
      field_234 = var0;
      field_235 = var1;
      field_233 = var2;
      field_236 = method_401();
      field_237 = 0;
   }

   // $VF: renamed from: bc () void
   public static void method_593() {
      int var0 = -(field_430 - 50) * 200 / 50;
      method_592(field_232, method_150(field_232 + var0, 0, 1024), 6000);
      field_232 = field_235;
   }

   // $VF: renamed from: f (int, int, int) int
   public static final int method_594(int var0, int var1, int var2) {
      return var0 * (255 - var2) + var1 * var2 >> 8;
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, boolean) void
   public static final void method_595(Graphics var0, boolean var1) {
      int var2 = 0;
      int var3 = 0;
      int var4 = 0;
      int var5 = 0;
      int var6 = 0;
      int var7 = 0;
      int var8 = 0;
      int var9 = field_232;
      int var10 = method_591();
      if (var9 < 128) {
         var2 = 5490943;
         var3 = 9095677;
      } else if (var9 < 256) {
         var2 = method_325(5490943, 12874515, var9 - 128 << 1);
         var3 = method_325(9095677, 11314738, var9 - 128 << 1);
      } else if (var9 < 384) {
         var2 = 12874515;
         var3 = 11314738;
      } else if (var9 < 512) {
         var2 = method_325(12874515, 335401, var9 - 384 << 1);
         var3 = method_325(11314738, 867375, var9 - 384 << 1);
      } else if (var9 < 768) {
         var2 = method_325(335401, 923684, var9 - 512);
         var3 = method_325(867375, 400167, var9 - 512);
      } else {
         var2 = 923684;
         var3 = 400167;
         int var11 = var9 - 768 >> 1;
         int var10000 = (var10 >> 9) * 11003781;
         boolean var13 = false;
         method_455(var10000);
         int var24;
         var10000 = (var24 = method_151(method_456() >> 3 & 0xFF, 512)) < 0 ? -var24 : var24;
         boolean var14 = false;
         if (var10000 < var11) {
            var6 = var10 >> 1 & 127;
            int var15 = (field_155 & 1) == 0 ? var6 >> 1 : var6;
            var2 = method_325(var2, 2320265, var15 << 1);
            var3 = method_325(var3, 1189944, var15 << 1);
            var7 = method_456() >> 3 & 0xFF;
            var8 = method_456() >> 3 & 0xFF;
         }
      }

      method_1283(var0, var2, var3, 0, 0, field_52, field_53, 12);
      if (var9 > 384 && var9 < 768) {
         int var45;
         if (var9 > 704) {
            var45 = method_150(255 - (var9 - 704 << 2), 0, 255);
         } else if (var9 < 512) {
            var45 = method_150(var9 - 384 << 1, 0, 255);
         } else {
            var45 = 255;
         }

         method_455(212577482);
         int var52 = field_52 * field_53 / 700;
         int var16 = field_53 * 5 >> 3;

         for (int var17 = 0; var17 < var52; var17++) {
            int var30 = method_456() % field_52;
            int var12;
            int var18 = method_266(method_268(var12 = method_456() % var16, field_53), 1044480) >> 12;
            int var38 = method_325(var2, var3, var18);
            int var19 = var12 < var16 - 64 ? var45 : method_594(var45, 0, method_150(var12 - (var16 - 64) << 2, 0, 255));
            int var20 = (var17 & 3) != 0 ? 8947800 : 1203572;
            int var21 = (var17 & 3) != 0 ? 1203572 : 8528496;
            if ((var17 & 1) == 0) {
               var19 >>= 1;
            }

            int var22 = var17 + (var10 >> 4);
            if ((var17 & 3) == 0) {
               var22 <<= 1;
            }

            int var74;
            int var23 = method_325(var38, method_325(var20, var21, (var74 = method_151(var22, 255)) < 0 ? -var74 : var74), var19);
            method_313(var0, method_325(var23, var38, 192));
            method_315(var0, var30 - 1, var12, 3, 1);
            method_315(var0, var30, var12 - 1, 1, 3);
            method_313(var0, var23);
            method_315(var0, var30, var12, 1, 1);
         }

         if (var9 <= 600 && var9 > 450) {
            boolean var58 = (field_155 & 1) == 0 && method_152(150) < 1;
            int var60 = field_243 > 0 ? var10 - field_243 : -1;
            if (var58 && (var60 < 0 || var60 > 2000) && !field_244) {
               field_240 = (field_52 >> 3) + method_152(field_52 >> 1);
               field_241 = 0;
               field_242 = 20 + method_152(40);
               field_244 = true;
               field_243 = var10;
               var60 = 0;
            }

            if (field_244) {
               int var62;
               int var64 = method_594((var62 = field_53 > field_52 ? 24 : 18) * 2, var62 >> 1, method_150(var60, 0, 255));
               int var65 = method_151(field_242, var64);
               int var75 = field_242;
               int var67 = method_151(var75 + 128, var64);
               int var69 = method_594(192, 0, method_150(var60 / 3, 0, 255));
               method_279(var0, (var69 >> 1 << 24) + 13153375);
               method_312(var0, field_240 - (var65 >> 1), field_241 - (var67 >> 1), field_240 - (var65 << 1), field_241 - (var67 << 1));
               method_312(var0, field_240 - 1, field_241, field_240 - (var65 >> 1) - 1, field_241 - (var67 >> 1));
               method_312(var0, field_240 + 1, field_241, field_240 - (var65 >> 1) + 1, field_241 - (var67 >> 1));
               method_279(var0, (var69 << 24) + 16777135);
               method_312(var0, field_240, field_241, field_240 - (var65 >> 1), field_241 - (var67 >> 1));
               method_317(var0, field_240 - 1, field_241 - 1, 2, 2);
               method_316(var0, field_240 - 1, field_241 - 1, 2, 2);
               var69 = method_594(192, 0, method_150(var60 >> 1, 0, 255));
               method_279(var0, (var69 << 24) + 16748719);
               method_315(var0, field_240 - 1, field_241, 1, 1);
               method_315(var0, field_240 + 1, field_241, 1, 1);
               method_315(var0, field_240, field_241 - 1, 1, 1);
               method_315(var0, field_240, field_241 + 1, 1, 1);
               var69 = method_594(255, 0, method_150(var60 >> 1, 0, 255));
               method_279(var0, (var69 << 24) + 16777135);
               method_315(var0, field_240, field_241, 1, 1);
               field_240 += var65;
               field_241 += var67;
               if (field_241 > field_53 + 24) {
                  field_244 = false;
               }
            }
         }
      }

      int var31 = 0;
      if (var9 < 512) {
         int var72;
         int var32 = 48 + method_151((var72 = var9 >> 2) + 128, 111) - 111;
         method_177(var0, 167, field_52 * 1 / 3 - (var9 * 24 >> 8), var32);
         method_177(var0, 166, field_52 * 2 / 3 + (var9 * 24 >> 8), var32);
         var31 = method_325(16777215, 16739328, var9 >> 1);
         var4 = (field_52 >> 1) - 18 + (var9 * 24 >> 8);
         var5 = field_53 - 24 - method_151(128 - (var9 >> 2), field_53 - 48);
         method_313(var0, var31);
         method_317(var0, var4, var5, 24, 24);
         int var39 = 64 + (512 - var9 >> 2) >> 1;
         method_279(var0, 16777215 | var39 << 24);
         method_317(var0, var4 - 6, var5 - 6, 36, 36);
         method_316(var0, var4 - 6, var5 - 6, 36, 36);
         method_316(var0, var4, var5, 24, 24);
      }

      if (var9 > 384) {
         int var33 = var9 > 640 ? 48 : -59 + method_151(var9 - 384 >> 1, 107);
         int var40 = (var9 - 512) * 24 >> 7;
         method_200(var0, 168, field_52 * 2 / 3 + var40, var33, 0);
      }

      method_200(var0, 164, 0, field_53, 0);
      method_200(var0, 164, field_52 - 120, field_53, 1);
      if (var9 < 512) {
         method_597(method_151(128 - (var9 >> 2), 96) - 48, 96 + (var9 * 24 >> 7), 5, 10892520);
         method_597(field_52 - method_151(128 - (var9 >> 2), 96) + 24, 120 + (var9 * 24 >> 7), 3, 11700170);
      } else if (var9 > 640) {
         int var34 = 0;
         if (205 > field_53 / 3 << 1) {
            var34 = (field_53 / 3 << 1) - 205;
         }

         int var41 = var9 > 896 ? var34 : var34 - 205 + method_151(var9 - 640 >> 1, 205);
         int var46 = var9 > 896 ? 215 : 0 + method_151(var9 - 640 >> 1, 215);
         method_200(var0, 170, var46 - 107 - 2, var41, 0);
         method_200(var0, 170, field_52 + 107 - var46 + 2, var34, 1);
      }

      int var35 = field_237 > 0 ? var10 - field_237 : -1;
      int var42;
      if ((var42 = var7 * field_52 - 96 >> 9) > (field_52 >> 1) - 48) {
         var42 += 96;
      }

      int var47 = field_53 / 2 - (var8 * field_53 >> 10);
      if (var6 > 32) {
         method_313(var0, 16777215);
         method_279(var0, 16777215 | var6 << 24);
         int var73;
         if (((var73 = method_456() & 1) < 0 ? -var73 : var73) == 0 && (var35 > 500 || var35 < 0)) {
            field_237 = var10;
            field_238 = 255;
            method_596(var0, var42, var47, method_456() % 48 - 24, field_53 - var47 - 24, 3, false);
            var35 = 0;
            field_239 = true;
         }
      }

      if (var35 < 250 && var35 > 0 && var9 > 768 && field_239) {
         field_238 = method_594(32, 160, 250 - var35);
         method_596(var0, var42, var47, method_456() % 48 - 24, field_53 - var47 - 24, 3, false);
      }

      method_200(var0, 165, 0, field_53, 0);
      method_200(var0, 165, field_52 - 120, field_53, 1);
      method_177(var0, 169, field_52 >> 1, field_53);
      if (var9 < 512) {
         var35 = var31 | 512 - var9 >> 2 >> 1 << 24;
         method_279(var0, var35);
         var4 = var4 + 12 - (field_52 >> 1);
         var5 = var5 + 12 - (field_53 >> 1);
         var42 = method_151((var9 * 2 / 3 >> 1) + 64, 48);
         var47 = (field_52 >> 1) - (var4 >> 1);
         int var53 = (field_53 >> 1) - (var5 >> 1);
         method_317(var0, var47 - (var42 >> 1), var53 - (var42 >> 1), var42, var42);
         method_316(var0, var47 - (var42 >> 1), var53 - (var42 >> 1), var42, var42);
         var47 = (field_52 >> 1) + (var4 >> 1);
         var53 = (field_53 >> 1) + (var5 >> 1);
         method_317(var0, var47 - (var42 >> 2), var53 - (var42 >> 2), var42 >> 1, var42 >> 1);
         method_316(var0, var47 - (var42 >> 2), var53 - (var42 >> 2), var42 >> 1, var42 >> 1);
         var47 = (field_52 >> 1) - (var4 << 1);
         var53 = (field_53 >> 1) - (var5 << 1);
         method_317(var0, var47 - (var42 >> 2), var53 - (var42 >> 2), var42 >> 1, var42 >> 1);
         method_316(var0, var47 - (var42 >> 2), var53 - (var42 >> 2), var42 >> 1, var42 >> 1);
      }

      if (var9 > 600) {
         method_455(15049851);
         var42 = method_148(field_52, field_53) + 96;
         var47 = 80 * (var9 - 600) >> 9;

         for (int var56 = 0; var56 < var47; var56++) {
            int var57;
            int var59 = (((var57 = var10 / ((method_456() & 1) + 2) + (method_456() >> 3)) & 0xFF) * var42 >> 8) - 48;
            int var61 = ((method_456() >> 3) + (var57 >> 8) * var56 * 20) % var42 - (var42 >> 1);
            int var63 = var59 + var61;
            int var66 = var59 + 48 + var61 + (method_456() >> 2) % 10;
            int var68 = var59 + 48 + (method_456() >> 2) % 10;
            method_279(var0, 544187545);
            method_312(var0, var63, var59, var63 + var66 >> 1, var59 + var68 >> 1);
            method_279(var0, 1081058457);
            method_312(var0, var63 + var66 >> 1, var59 + var68 >> 1, var66, var68);
         }
      }

      if (var1 && ((var35 = var9 > 780 ? 21 : (var9 > 680 ? 16 : (var9 > 310 ? 13 : 3))) != field_198 || field_197 < 0 || field_155 - field_197 > 127)) {
         method_479(var35, -1, 100, false);
      }

      method_413(true);
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int, int, int, int, boolean) void
   public static final void method_596(Graphics var0, int var1, int var2, int var3, int var4, int var5, boolean var6) {
      int var7 = var1;
      int var8 = var2;
      int var9 = -1;
      method_313(var0, 16777215);
      byte var10 = 6;
      int var11 = (var4 < 0 ? -var4 : var4) / 6;
      if (var4 < 0) {
         var10 = -6;
      }

      int var12 = var3 / var11;
      int var13 = var11 / (var5 + 1);
      int var14 = 0;
      boolean var15 = false;
      int var16 = 0;

      for (int var17 = 0; var17 < var11; var17++) {
         var14 = (method_456() >> 3) % 12 - 6;
         if (var5 > 0 && var17 - var9 > var13) {
            int var18 = method_456() % 24 + 12;
            if ((method_456() >> 4 & 0xFF) > 128) {
               var18 = -var18;
            }

            method_596(var0, var7, var8, method_456() % 24, var18, 0, !var6);
            var9 = var17;
         }

         if (var14 > 0 && var16 > 12) {
            var14 -= 24;
         }

         if (var14 < 0 && var16 < -12) {
            var14 += 24;
         }

         var16 += var14;
         var14 += var12;
         int var19;
         int var23;
         if (var6) {
            var23 = var7 + var10;
            var19 = var8 + var14;
         } else {
            var23 = var7 + var14;
            var19 = var8 + var10;
         }

         method_279(var0, (field_238 << 24) + 1203572);
         method_312(var0, var7 - 1, var8, var23 - 1, var19);
         method_312(var0, var7 + 1, var8, var23 + 1, var19);
         method_279(var0, (field_238 << 24) + 16777215);
         method_312(var0, var7, var8, var23, var19);
         var7 = var23;
         var8 = var19;
      }
   }

   // $VF: renamed from: b (int, int, int, int) void
   public static final void method_597(int var0, int var1, int var2, int var3) {
      Graphics var4 = field_51;
      method_455(var3);
      int var5;
      int var6 = ((var5 = method_591()) >> 8) % 5;

      for (int var7 = var2; var7 > 0; var7--) {
         int var10 = method_456() & 0xFF;
         int var8 = var0 + method_151(var10 + (var5 >> 4), 24);
         int var9 = var1 + (method_151((method_456() & 0xFF) + (var5 >> 2), 6) - var7 * 24 / var2);
         method_200(var4, 171, var8, var9, var6 + var7);
      }
   }

   // $VF: renamed from: bd () void
   public static final void method_598() {
      int var0;
      if ((var0 = method_994(field_409[field_416])) >= 0) {
         field_246 = method_1435(var0, field_245);
      }
   }

   // $VF: renamed from: C (int) void
   public static final void method_599(int var0) {
      field_258 = var0;
   }

   // $VF: renamed from: v () int
   public static final int method_600() {
      return field_258 - (field_252 >= field_285 && field_252 <= field_289 ? 54 : 0);
   }

   // $VF: renamed from: I () boolean
   public static final boolean method_601() {
      return field_251 >= 0;
   }

   // $VF: renamed from: a (int, long[]) void
   public static final void method_602(int var0, long[] var1) {
      int var2 = 4;

      while (--var2 >= 0) {
         method_603(var2, var0, var1);
      }
   }

   // $VF: renamed from: a (int, int, long[]) void
   public static final void method_603(int var0, int var1, long[] var2) {
      int var3;
      int var4 = (var3 = var0 * 128 - (var1 >> 1)) + var1;
      int var5 = method_574(0, var3, 65536);
      int var6 = method_575(0, var3, 65536);
      int var7 = method_574(0, var4, 65536);
      int var8 = method_575(0, var4, 65536);
      long var9 = (long)var5 << 32 | var6 & 4294967295L;
      long var11 = (long)var7 << 32 | var8 & 4294967295L;
      var2[var0 * 2] = var9;
      var2[var0 * 2 + 1] = var11;
   }

   // $VF: renamed from: a (byte) boolean
   public static final boolean method_604(byte var0) {
      return var0 == 0 || var0 == 2 || var0 == 5 || var0 == 6 || var0 == 7 || var0 == 3 || var0 == 4 || var0 == 8;
   }

   // $VF: renamed from: be () void
   public static final void method_605() {
      if (field_416 == field_408) {
         method_606();
      } else {
         method_607();
      }
   }

   // $VF: renamed from: bf () void
   public static final void method_606() {
      int var0 = field_406 - 3;

      while (var0 >= 0 && field_410[var0] < 0) {
         var0--;
      }

      if (var0 < 0 || field_410[var0] < 0 || var0 == field_408) {
         var0 = field_407;
      }

      byte var1;
      method_619(field_410[var0], var1 = field_410[var0]);
   }

   // $VF: renamed from: bg () void
   public static final void method_607() {
      int var0;
      if ((var0 = method_976(field_416)) >= 0) {
         method_619(-1, var0);
      }
   }

   // $VF: renamed from: bh () void
   public static final void method_608() {
      method_602(field_247, field_249);
      method_602(field_248, field_250);
   }

   // $VF: renamed from: a (int, int, int, int, int, int) void
   public static final void method_609(int var0, int var1, int var2, int var3, int var4, int var5) {
      field_251 = var0;
      field_252 = var2;
      field_253 = (byte)var3;
      field_259 = (byte)var4;
      field_260 = (byte)var5;
      field_254 = (byte)var1;
   }

   // $VF: renamed from: e (int, int) void
   public static final void method_610(int var0, int var1) {
      field_255 = var0;
      field_256 = var1;
      method_1215(field_255, field_256);
      field_257 = field_600;
      method_599(field_601);
      method_611();
   }

   // $VF: renamed from: bi () void
   public static final void method_611() {
      method_612(field_257, method_600());
      method_1216(field_600, field_601);
      field_263 = field_600;
      field_264 = field_601;
   }

   // $VF: renamed from: f (int, int) void
   public static final void method_612(int var0, int var1) {
      int var2;
      int var3 = method_148(var2 = method_149(field_609 - field_598 >> 1, -((field_609 >> 1) - (field_598 >> 1)) + 1), (field_609 >> 1) - (field_598 >> 1) - 1);
      field_600 = method_150(var0, var2, var3);
      int var4;
      int var5 = method_148(
         var4 = method_149(field_610 - field_599 >> 1, -(field_610 * 32 / 100 - (field_599 >> 1)) + 1), field_610 * 45 / 100 - (field_599 >> 1) - 1
      );
      field_601 = method_150(var1, var4, var5);
   }

   // $VF: renamed from: D (int) void
   public static final void method_613(int var0) {
      int var5 = field_257;
      int var6 = method_600();
      long var1 = (long)var5 << 32 | var6 & 4294967295L;
      int var3 = (method_159(var0) + 7) % 4;
      boolean var4;
      if (!(var4 = method_614(var1, var3, field_249, method_160(var0), method_161(var0)))) {
         var4 = method_614(var1, var3, field_250, method_160(var0), method_161(var0));
      }

      if (var4) {
         field_276 = true;
         method_236();
         method_237();
      }
   }

   // $VF: renamed from: a (long, int, long[], int, int) boolean
   public static final boolean method_614(long var0, int var2, long[] var3, int var4, int var5) {
      long var6 = var3[var2 * 2];
      long var8 = var3[var2 * 2 + 1];
      field_269 = false;
      field_270 = -1;
      field_271 = 2147483647L;
      field_272 = Integer.MAX_VALUE;
      field_273 = Integer.MAX_VALUE;
      byte var10 = field_416;
      boolean var11 = field_268 && field_364 == -1;
      if (var10 == field_408) {
         for (int var12 = field_287; var12 <= field_291; var12++) {
            if (!method_615(var10, var11, var12)) {
               int var13 = field_304[var12];
               int var14 = field_305[var12];
               method_617(true, var0, var4, var5, var6, var8, var12, var13, var14);
            }
         }
      } else {
         boolean var10000 = field_267 && field_364 == -1;
         boolean var17 = false;
         if (var10000 || var11) {
            int var18 = field_283;

            while (--var18 >= 0) {
               if (!method_616(var10, var18)) {
                  int var20 = field_304[var18];
                  int var15 = field_305[var18] - 54;
                  method_617(true, var0, var4, var5, var6, var8, var18, var20, var15);
               }
            }
         }

         int var19 = 10;

         while (--var19 >= 0) {
            if (field_396[var10][var19] != -1 && method_888(var10, var19, 1)) {
               int var21 = field_401[var10][var19];
               int var16 = field_402[var10][var19];
               method_617(false, var0, var4, var5, var6, var8, var19, var21, var16);
            }
         }
      }

      if (field_270 != -1) {
         if (field_269) {
            method_619(field_251, field_270);
         } else {
            method_618(field_270);
         }

         return true;
      } else {
         return false;
      }
   }

   // $VF: renamed from: a (byte, boolean, int) boolean
   private static boolean method_615(byte var0, boolean var1, int var2) {
      return field_299[var2] < 0 || field_309[var2] != var0 || var1 && var2 != field_251 || field_300[var2] >= 7 && field_300[var2] <= 10;
   }

   // $VF: renamed from: b (byte, int) boolean
   public static final boolean method_616(byte var0, int var1) {
      return field_299[var1] < 0
         || method_683(var1, 1024)
         || field_309[var1] != var0
         || field_268 && var1 != field_251
         || field_274 == 2 && method_654(var1)
         || field_274 == 2 && method_1056(var0) && var1 < field_286
         || field_274 == 1 && var1 != field_251 && field_251 < field_286;
   }

   // $VF: renamed from: a (boolean, long, int, int, long, long, int, int, int) void
   private static void method_617(boolean var0, long var1, int var3, int var4, long var5, long var7, int var9, int var10, int var11) {
      long var12 = (long)var10 << 32 | var11 & 4294967295L;
      if (method_163(var5, var1, var12, 1) && !method_163(var7, var1, var12, 1)) {
         int var15 = method_600();
         long var16 = method_576(var10, field_257, var11, var15);
         int var20;
         int var18 = (var20 = var4 * (var10 - field_257)) < 0 ? -var20 : var20;
         int var19 = (var20 = var3 * (var11 - var15)) < 0 ? -var20 : var20;
         if (var16 + var18 + var19 < field_271 + field_272 + field_273) {
            field_269 = var0;
            field_270 = var9;
            field_271 = var16;
            field_272 = var18;
            field_273 = var19;
         }
      }
   }

   // $VF: renamed from: E (int) void
   public static final void method_618(int var0) {
      byte var1 = field_416;
      method_1216(field_401[var1][var0], field_402[var1][var0]);
      method_610(field_600, field_601);
      byte var2 = field_254;
      field_254 = (byte)var0;
      method_609(field_251, var0, -1, field_396[var1][var0], field_397[var1][var0], field_398[var1][var0]);
      if (field_254 != var2) {
         method_830();
      }
   }

   // $VF: renamed from: g (int, int) void
   public static final void method_619(int var0, int var1) {
      method_610(field_302[var1], field_303[var1]);
      byte var2 = -1;
      byte var3 = -1;
      byte var4;
      if ((var4 = field_300[var1]) >= 7 && var4 <= 16) {
         int var5 = field_406;

         while (--var5 >= 0) {
            if (field_410[var5] == var1) {
               var2 = field_412[var5];
               var3 = field_413[var5];
               break;
            }
         }
      } else {
         var2 = field_306[var1];
         var3 = field_307[var1];
      }

      method_609(var0, -1, var1, 7, var2, var3);
   }

   // $VF: renamed from: bj () void
   public static int touchCameraRoom = -1;

   public static final void method_620() {
      if (touchCameraRoom == field_416 && method_403() == 27) return;
      touchCameraRoom = -1;
      if (field_416 == field_408) {
         method_621((field_261 * 60 + field_263 * 40) / 100, (field_262 * 60 + field_264 * 40) / 100);
      } else {
         method_621((field_261 * 80 + field_263 * 20) / 100, (field_262 * 80 + field_264 * 20) / 100);
      }
   }

   // $VF: renamed from: h (int, int) void
   public static final void method_621(int var0, int var1) {
      field_261 = var0;
      field_262 = var1;
      method_1215(var0, var1);
      field_265 = field_600;
      field_266 = field_601;
   }

   // $VF: renamed from: bk () void
   public static final void method_622() {
      field_274 = 0;
      method_891();
   }

   // $VF: renamed from: bl () void
   public static final void method_623() {
      int var0;
      if (field_490 < 0 && field_465 - field_275 > 2 && (var0 = method_465(false)) != 0) {
         method_613(var0);
         field_275 = field_465;
         method_1299();
      }

      if (field_364 == -1) {
         if (!method_470()) {
            return;
         }

         method_624();
         method_471();
         method_1299();
      }
   }

   // $VF: renamed from: hz () void
   private static final void method_624() {
      if (field_274 == 0) {
         if (field_253 == 7 && field_416 != field_408) {
            field_251 = field_252;
            if (field_251 >= 0) {
               method_628();
            }
         }
      } else if (field_274 == 2) {
         method_626();
      } else {
         if (field_274 == 1) {
            method_625();
         }
      }
   }

   // $VF: renamed from: hA () void
   private static void method_625() {
      byte var0 = field_253;
      if (field_253 == 7) {
         if (field_251 == field_252) {
            method_627();
            return;
         }
      } else {
         if (var0 == 0) {
            method_955();
            int var7 = field_401[field_416][0];
            int var8 = field_402[field_416][0];
            method_1216(var7, var8);
            method_1064(field_600, field_601, true, true);
            return;
         }

         boolean var1 = false;
         int var2 = field_251;
         if (method_629(field_251)) {
            return;
         }

         byte var3 = method_921(var0);
         byte var4 = field_259;
         byte var5 = field_260;
         byte var6 = 0;
         if (method_724(var2, var4, var5, var3)) {
            method_627();
            field_308[var2] = field_254;
            var6 = field_254;
            var1 = true;
         } else if (var0 == 2 || var0 == 3 || var0 == 4) {
            method_627();
            field_345[var2] = field_254;
            var6 = field_254;
            method_661(var2);
            var1 = true;
         }

         if (var1) {
            if (field_314[var2] != 3) {
               method_682(var2, 512, false, false);
            }

            field_464 = true;
            method_479(2, -1, 100, true);
            if (var6 >= 0) {
               method_1216(field_401[field_416][var6], field_402[field_416][var6]);
               method_1064(field_600, field_601, method_604(var0), true);
            }
         }
      }
   }

   // $VF: renamed from: hB () void
   private static void method_626() {
      int var0 = field_251;
      if (field_252 >= 0) {
         if (field_252 == var0) {
            method_627();
         } else if (!method_616(field_309[var0], var0)) {
            method_713(var0, field_252);
            method_627();
            int var1 = field_304[field_252];
            int var2 = field_305[field_252] - 64;
            method_1216(var1, var2);
            method_1064(field_600, field_601, false, true);
         }
      } else if (field_254 == 9) {
         method_627();
         method_1216(field_401[field_416][9], field_402[field_416][9]);
         method_1064(field_600, field_601, true, true);
         method_423(78);
      }

      method_479(2, -1, 100, true);
   }

   // $VF: renamed from: bm () void
   public static final void method_627() {
      method_891();
      field_274 = 0;
      field_251 = -1;
   }

   // $VF: renamed from: bn () void
   public static final void method_628() {
      if (field_251 >= field_286) {
         field_274 = 2;
      } else {
         field_274 = 1;
      }

      method_886();
   }

   // $VF: renamed from: A (int) boolean
   public static final boolean method_629(int var0) {
      return field_314[var0] == 10 || field_364 >= 0 && var0 == field_360 || field_364 >= 2 || method_1056(field_416) && var0 < field_286;
   }

   // $VF: renamed from: J () boolean
   public static final boolean method_630() {
      return field_466 >= 2 && method_1020(4);
   }

   // $VF: renamed from: K () boolean
   public static final boolean method_631() {
      return field_466 == 0 || field_466 >= 2;
   }

   // $VF: renamed from: z (int) int
   public static final int method_632(int var0) {
      return (var0 - 2) % 9;
   }

   // $VF: renamed from: B (int) boolean
   public static boolean method_633(int var0) {
      switch (var0) {
         case 0:
            if (field_422 != 0 && field_423 != 0) {
               return false;
            }

            return true;
         case 1:
            if (field_425 >= 2) {
               return true;
            }

            return false;
         case 2:
            if (field_445 - field_443 > 999) {
               return true;
            }

            return false;
         case 3:
            if (field_424 > 0) {
               return true;
            }

            return false;
         case 4:
            if (field_423 > 0) {
               return true;
            }

            return false;
         case 5:
            if (field_425 == 0) {
               return true;
            }

            return false;
         case 6:
            if (field_439 == 0) {
               return true;
            }

            return false;
         case 7:
            if (field_423 > 0 && field_424 >= 2) {
               return true;
            }

            return false;
         case 8:
            if (field_427 == 0) {
               return true;
            }

            return false;
         default:
            return false;
      }
   }

   // $VF: renamed from: C (int) boolean
   public static final boolean method_634(int var0) {
      return var0 == 91;
   }

   // $VF: renamed from: F (int) void
   public static final void method_635(int var0) {
      method_1209(field_306[var0], field_307[var0]);
      method_650(var0, field_600, field_601);
   }

   // $VF: renamed from: a (int, byte, byte) boolean
   public static final boolean method_636(int var0, byte var1, byte var2) {
      byte var3;
      return (var3 = field_309[var0]) >= 0
         && method_645(var3, var1, var2) < 0
         && !method_657(var3, var1, var2, var0)
         && (method_516(var0, var1, var2, false) == 1 || method_516(var0, var1, var2, true) == 1);
   }

   // $VF: renamed from: G (int) void
   public static final void method_637(int var0) {
      int var1 = 16;

      while (--var1 >= 0) {
         field_323[var0][var1] = -128;
         field_324[var0][var1] = -128;
      }

      field_322[var0] = 0;
   }

   // $VF: renamed from: a (int, byte, byte) void
   public static final void method_638(int var0, byte var1, byte var2) {
      byte var3 = field_322[var0];
      field_323[var0][var3] = var1;
      field_324[var0][var3] = var2;
      field_322[var0]++;
   }

   // $VF: renamed from: b (int, byte, byte) void
   public static final void method_639(int var0, byte var1, byte var2) {
      byte var3;
      if ((var3 = field_322[var0]) > 0) {
         int var4 = method_149(var3, 15);
         method_566(field_323[var0], 0, var4);
         method_566(field_324[var0], 0, var4);
      }

      field_323[var0][0] = var1;
      field_324[var0][0] = var2;
      field_322[var0]++;
   }

   // $VF: renamed from: H (int) void
   public static final void method_640(int var0) {
      method_571(field_298[var0], 81, (byte)-1);
   }

   // $VF: renamed from: b (int, int) boolean
   public static final boolean method_641(int var0, int var1) {
      return var0 < 0 || var1 < 0 || var0 > 8 || var1 > 8;
   }

   // $VF: renamed from: c (int, int) boolean
   public static final boolean method_642(int var0, int var1) {
      return var0 < 0 || var1 < 0 || var0 > 8 || var1 > 8;
   }

   // $VF: renamed from: a (int, int, byte, byte) void
   public static final void method_643(int var0, int var1, byte var2, byte var3) {
      field_298[var0][var3 * 9 + var2] = (byte)var1;
   }

   // $VF: renamed from: a (byte, int, int) void
   public static final void method_644(byte var0, int var1, int var2) {
      field_298[var0][var2 * 9 + var1] = -1;
   }

   // $VF: renamed from: a (byte, int, int) byte
   public static final byte method_645(byte var0, int var1, int var2) {
      return var0 >= 0 && !method_642(var1, var2) ? field_298[var0][var2 * 9 + var1] : -1;
   }

   // $VF: renamed from: n (int, int) int
   public static final int method_646(int var0, int var1) {
      int var2 = field_284;

      while (--var2 >= 0) {
         if (field_299[var2] >= 0 && field_306[var2] == var0 && field_307[var2] == var1) {
            return var2;
         }
      }

      return -1;
   }

   // $VF: renamed from: a (byte, int, int, boolean, boolean) void
   public static final void method_647(byte var0, int var1, int var2, boolean var3, boolean var4) {
      if (!method_642(var1, var2)) {
         if (var3) {
            method_643(var0, var4 ? 126 : 127, (byte)var1, (byte)var2);
            return;
         }

         byte var5;
         if ((var5 = method_645(var0, var1, var2)) == 127 || var5 == 126) {
            method_644(var0, var1, var2);
         }
      }
   }

   // $VF: renamed from: a (byte, int, int, int, boolean) boolean
   public static final boolean method_648(byte var0, int var1, int var2, int var3, boolean var4) {
      byte var5 = method_645(var0, var1, var2);
      return (var4 ? var5 >= 0 && var5 != 126 : var5 >= 0) || method_641(var1, var2) || method_657(var0, var1, var2, var3);
   }

   // $VF: renamed from: c (int, int, int) void
   public static final void method_649(int var0, int var1, int var2) {
      method_1215(var1, var2);
      int var3 = field_600;
      int var4 = field_601;
      method_652(var0, var1, var2, var3, var4);
   }

   // $VF: renamed from: d (int, int, int) void
   public static final void method_650(int var0, int var1, int var2) {
      method_1216(var1, var2);
      int var3 = field_600;
      int var4 = field_601;
      method_652(var0, var3, var4, var1, var2);
   }

   // $VF: renamed from: b (byte, int, int) void
   public static final void method_651(byte var0, int var1, int var2) {
      method_1209(var1, var2);
      method_650(var0, field_600, field_601);
   }

   // $VF: renamed from: d (int, int, int, int, int) void
   private static void method_652(int var0, int var1, int var2, int var3, int var4) {
      method_653(var0, var3, var4);
      field_302[var0] = var1;
      field_303[var0] = var2;
      field_304[var0] = var3;
      field_305[var0] = var4;
      if (field_252 == var0) {
         method_610(var1, var2);
      }
   }

   // $VF: renamed from: p (int, int, int) void
   private static final void method_653(int var0, int var1, int var2) {
      method_1214(var1, var2);
      byte var3 = (byte)field_600;
      byte var4 = (byte)field_601;
      if (var3 >= 0 && var4 >= 0 && var3 < 9 && var4 < 9) {
         byte var5 = field_306[var0];
         byte var6 = field_307[var0];
         field_306[var0] = var3;
         field_307[var0] = var4;
         if (var0 < field_287) {
            byte var7;
            if (method_645(var7 = field_309[var0], var5, var6) == var0) {
               method_644(var7, var5, var6);
            }

            if (method_645(var7, var3, var4) < 0) {
               method_643(var7, var0, var3, var4);
            }
         }
      }
   }

   // $VF: renamed from: D (int) boolean
   public static boolean method_654(int var0) {
      return field_302[var0] < 0 || field_303[var0] < 0;
   }

   // $VF: renamed from: I (int) void
   public static final void method_655(int var0) {
      field_322[var0]--;
      byte var1;
      if ((var1 = field_322[var0]) < 0) {
         method_637(var0);
         method_716(var0, field_316[var0], true);
      } else {
         byte var2 = field_323[var0][var1];
         byte var3 = field_324[var0][var1];
         method_656(var0, var2, var3);
      }
   }

   // $VF: renamed from: q (int, int, int) void
   private static void method_656(int var0, int var1, int var2) {
      method_1209(var1, var2);
      method_1216(field_600, field_601);
      int var3 = field_302[var0];
      int var4 = field_303[var0];
      int var5 = field_600;
      int var6 = field_601;
      int var7 = var5 - var3;
      int var8 = var6 - var4;
      int var9 = method_162((long)var7 << 32 | var8 & 4294967295L);
      int var10 = field_279 * 60 / 60;
      if (var0 < field_286) {
         byte var10000 = method_735(field_332, var0);
         boolean var11 = false;
         if (var10000 > 95) {
            var10 = 50 * var10 / 100;
         }
      }

      field_310[var0] = method_151(var9 + 128, var10);
      field_311[var0] = method_151(var9, var10);
      field_320[var0] = var5;
      field_321[var0] = var6;
      method_716(var0, (byte)1, true);
      method_479(48, var0, 40, true);
   }

   // $VF: renamed from: a (int, int, int, int) boolean
   public static final boolean method_657(int var0, int var1, int var2, int var3) {
      int var4 = field_283;

      while (--var4 >= 0) {
         if (field_309[var4] == var0 && var4 != var3 && field_299[var4] >= 0 && method_658(var4, var1, var2)) {
            return true;
         }
      }

      return false;
   }

   // $VF: renamed from: a (int, int, int) boolean
   public static final boolean method_658(int var0, int var1, int var2) {
      byte var3;
      return (var3 = field_323[var0][0]) > -128 && var3 == var1 && field_324[var0][0] == var2;
   }

   // $VF: renamed from: J (int) void
   public static final void method_659(int var0) {
      int var1 = field_310[var0];
      int var2 = field_311[var0];
      if (method_1056(field_309[var0]) || method_683(var0, 1024)) {
         var1 = var1 * 120 / 100;
         var2 = var2 * 120 / 100;
      }

      int var3 = field_302[var0];
      int var4 = field_303[var0];
      int var5 = var3 + var1;
      int var6 = var4 + var2;
      method_1215(var5, var6);
      int var7 = field_600;
      int var8 = field_601;
      method_1214(var7, var8);
      boolean var9 = field_600 == field_306[var0] && field_601 == field_307[var0];
      byte var10 = -1;
      if (!var9) {
         var9 = (var10 = method_645(field_309[var0], field_600, field_601)) < 0 || var10 == var0 || var10 == 126 || var10 == field_328[var0];
      }

      if (var9) {
         method_649(var0, var5, var6);
      } else {
         if (field_278 < 0 || field_465 - field_278 > 20) {
            field_278 = field_465;
            method_737(field_331, var0, 1000);
            method_737(field_331, var10, 1000);
            if (var0 < field_280 && field_309[var0] == field_416) {
               method_1073(field_302[var0], field_303[var0], method_735(field_331, var0));
            }
         }

         byte var11 = field_323[var0][0];
         byte var12 = field_324[var0][0];
         if (var11 > -128 && var12 > -128) {
            if (method_636(var0, var11, var12)) {
               method_635(var0);
               method_655(var0);
               return;
            }

            if (var0 >= field_286 && var0 <= field_289) {
               method_716(var0, (byte)30, true);
            }
         }
      }
   }

   // $VF: renamed from: a (int, int, int, int, int) void
   public static final void method_660(int var0, int var1, int var2, int var3, int var4) {
      method_637(var0);
      method_638(var0, (byte)var3, (byte)var4);
      method_638(var0, (byte)var1, (byte)var2);
      method_655(var0);
   }

   // $VF: renamed from: K (int) void
   public static final void method_661(int var0) {
      byte var1 = field_309[var0];
      byte var2 = field_345[var0];
      byte var3 = field_397[var1][var2];
      byte var4 = field_398[var1][var2];
      byte var6 = method_921(field_396[var1][var2]);
      if (method_724(var0, var3, var4, var6)) {
         field_308[var0] = var2;
      } else {
         method_737(field_331, var0, 250);
         method_887(var0, var3, var4, 1, 6, 1, 6, true, true);
         byte var7 = (byte)field_600;
         byte var8 = (byte)field_601;
         if (var7 >= 0 && var8 >= 0) {
            method_724(var0, var7, var8, (byte)25);
         }
      }
   }

   // $VF: renamed from: a (int, int, byte) boolean
   public static final boolean method_662(int var0, int var1, byte var2) {
      byte var3 = field_309[var0];
      byte var4 = field_397[var3][var1];
      byte var5 = field_398[var3][var1];
      if (method_663(var0, var4, var5, var2)) {
         field_308[var0] = (byte)var1;
         return true;
      } else {
         return false;
      }
   }

   // $VF: renamed from: a (int, int, int, byte) boolean
   public static final boolean method_663(int var0, int var1, int var2, byte var3) {
      if (method_636(var0, (byte)var1, (byte)var2)) {
         if (method_654(var0)) {
            byte var4;
            int var5 = (var4 = field_308[var0]) - 1;
            byte var6 = field_309[var0];
            method_725(var0, (byte)var5, field_397[var6][var4], field_398[var6][var4], false);
         }

         method_712(var0, var3);
         method_655(var0);
         return true;
      } else {
         return false;
      }
   }

   // $VF: renamed from: a (int, boolean, int) boolean
   public static final boolean method_664(int var0, boolean var1, int var2) {
      byte var3 = field_306[var0];
      byte var4 = field_307[var0];
      int var5 = method_665(field_309[var0], 40, var3, var4, var1);
      int var6 = field_600;
      int var7 = field_601;
      if (var5 < 40 && method_636(var0, (byte)var6, (byte)var7)) {
         method_712(var0, (byte)(var2 >= 0 ? (byte)var2 : (var1 ? 30 : 5)));
         method_655(var0);
         return true;
      } else {
         return false;
      }
   }

   // $VF: renamed from: a (byte, int, int, int, boolean) int
   public static final int method_665(byte var0, int var1, int var2, int var3, boolean var4) {
      int var5 = 0;

      int var6;
      int var7;
      do {
         method_717(var2, var3);
         var6 = field_600;
         var7 = field_601;
         var5++;
      } while (var5 < var1 && (var4 && !method_782(var0, true, var6, var7) || method_645(var0, var6, var7) >= 0 || method_657(var0, var6, var7, -1)));

      return var5;
   }

   // $VF: renamed from: bo () void
   public static final void method_666() {
      for (int var0 = field_284; --var0 >= 0; field_301[var0] = (byte)var0) {
         method_667(var0);
      }
   }

   // $VF: renamed from: L (int) void
   public static final void method_667(int var0) {
      if (field_252 == var0 || field_251 == var0) {
         method_609(-1, -1, -1, -1, -1, -1);
         method_627();
      }

      field_299[var0] = -1;
      field_300[var0] = -1;
      field_302[var0] = 0;
      field_303[var0] = 0;
      field_304[var0] = 0;
      field_305[var0] = 0;
      byte var1 = field_306[var0];
      byte var2 = field_307[var0];
      byte var3;
      if ((var3 = field_309[var0]) >= 0 && method_645(var3, var1, var2) == var0) {
         method_644(var3, var1, var2);
      }

      field_307[var0] = 0;
      field_306[var0] = 0;
      field_308[var0] = -1;
      method_972(var0, (byte)-1);
      if (var0 < field_286) {
         method_669(var0);
      }

      if (var0 < field_287) {
         method_668(var0);
      }
   }

   // $VF: renamed from: bn (int) void
   private static void method_668(int var0) {
      if (method_683(var0, 1024)) {
         field_363 = method_148(0, field_363 - 1);
         if (field_363 > 0) {
            method_791(var0);
         }
      }

      if (field_251 == var0) {
         field_251 = -1;
      }

      method_740(var0);
      field_310[var0] = 0;
      field_311[var0] = 0;
      field_312[var0] = 0;
      field_313[var0] = 0;
      field_314[var0] = 5;
      field_315[var0] = 5;
      method_712(var0, (byte)(var0 >= field_286 ? 30 : 5));
      field_317[var0] = 0;
      field_318[var0] = 0;
      field_319[var0] = 0;
      field_320[var0] = 0;
      field_321[var0] = 0;
      method_748(var0);
      method_637(var0);
      field_327[var0] = -1;
   }

   // $VF: renamed from: bo (int) void
   private static void method_669(int var0) {
      field_329[var0] = -1;
      field_330[var0] = -1;
      method_736(field_331, var0, 0);
      method_736(field_332, var0, 0);
      method_736(field_333, var0, 0);
      field_334[var0] = 0;
      field_335[var0] = 0;
      field_336[var0] = 0;
      field_337[var0] = 0;
      field_338[var0] = 0;
      field_339[var0] = 0;
      field_340[var0] = 0;
      field_341[var0] = 0;
      field_342[var0] = -1;
   }

   // $VF: renamed from: a (byte, int, int, byte, byte, byte, byte, byte, byte, byte) int
   public static final int method_670(byte var0, int var1, int var2, byte var3, byte var4, byte var5, byte var6, byte var7, byte var8, byte var9) {
      return method_675(var0, (byte)0, field_285, field_288, var1, var2, var3, var4, var5, var6, var7, var8, var9, 0);
   }

   // $VF: renamed from: a (byte, int, int) int
   public static final int method_671(byte var0, int var1, int var2) {
      int var3;
      if ((
            var3 = method_675(
               var0, (byte)1, field_286, field_289, var1, var2, (byte)-128, (byte)-128, (byte)-128, (byte)-128, (byte)-128, (byte)-128, (byte)-128, 0
            )
         )
         >= 0) {
         method_716(var3, (byte)30, true);
      }

      return var3;
   }

   // $VF: renamed from: a (byte, byte, int, int, int) int
   public static final int method_672(byte var0, byte var1, int var2, int var3, int var4) {
      return method_675(var0, var1, field_287, field_291, var2, var3, (byte)-128, (byte)-128, (byte)-128, (byte)-128, (byte)-128, (byte)-128, (byte)-128, var4);
   }

   // $VF: renamed from: o (int, int) int
   public static final int method_673(int var0, int var1) {
      int var2 = 1 + method_152(5);
      int var3 = 1 + method_152(5);
      int var4 = var1 != -1 ? var1 : method_572(13, var0, 0, 1);
      int var5 = method_572(13, var0, 5, 6);
      int var6 = method_572(13, var0, 7, 8);
      int var7 = method_572(13, var0, 9, 10);
      int var8 = method_572(13, var0, 11, 12);
      int var9 = method_572(13, var0, 13, 14);
      return method_670(method_674(), var2, var3, (byte)var0, (byte)var6, (byte)var7, (byte)var5, (byte)var4, (byte)var8, (byte)var9);
   }

   // $VF: renamed from: a () byte
   public static final byte method_674() {
      byte var0 = -1;
      if (field_479 == 0) {
         var0 = field_407;
      } else {
         int var1 = method_993(0);
         int var2 = field_406;

         while (--var2 >= 0) {
            if (field_409[var2] == var1) {
               var0 = (byte)var2;
               break;
            }
         }
      }

      return var0;
   }

   // $VF: renamed from: a (byte, byte, int, int, int, int, byte, byte, byte, byte, byte, byte, byte, int) int
   private static final int method_675(
      byte var0, byte var1, int var2, int var3, int var4, int var5, byte var6, byte var7, byte var8, byte var9, byte var10, byte var11, byte var12, int var13
   ) {
      int var14;
      if ((var14 = method_680(var2, var3)) < 0) {
         return -1;
      } else {
         method_667(var14);
         if (var13 == 0) {
            method_1209(var4, var5);
         } else if (var13 == 1) {
            method_1210(var4, var5);
         } else if (var13 == 3) {
            method_1213(var4, var5);
         } else if (var13 == 4) {
            method_1212(var4, var5);
         }

         int var15 = field_600;
         int var16 = field_601;
         method_676(var1, var0, var14, var15, var16, var6, var7, var8, var9, var10, var11, var12);
         return var14;
      }
   }

   // $VF: renamed from: a (byte, byte, int, int, int, byte, byte, byte, byte, byte, byte, byte) void
   private static final void method_676(
      byte var0, byte var1, int var2, int var3, int var4, byte var5, byte var6, byte var7, byte var8, byte var9, byte var10, byte var11
   ) {
      field_300[var2] = var0;
      method_972(var2, var1);
      int var12 = method_152(Integer.MAX_VALUE);
      if (var2 < field_286 && method_152(100) < 85) {
         var12 &= -65536;
         int var13 = method_677(true);
         int var14 = method_677(false);
         var12 |= var13 | var14 << 8;
      }

      field_299[var2] = var12;
      method_650(var2, var3, var4);
      field_308[var2] = -1;
      if (var2 < field_286) {
         method_678(var2, var5, var6, var7, var8, var9, var10, var11);
      }

      if (var2 < field_287) {
         method_682(var2, 1, true, false);
         method_682(var2, 2, false, false);
      }
   }

   // $VF: renamed from: d (boolean) int
   private static final int method_677(boolean var0) {
      int var1 = method_152(Integer.MAX_VALUE);

      for (int var2 = 0; var2 <= 14; var2++) {
         int var3 = (var2 + var1) % 14;
         boolean var4 = false;
         int var5 = field_280;

         while (--var5 >= 0) {
            int var6;
            if ((var6 = field_299[var5]) >= 0) {
               int var7 = var6 & 0xFF;
               int var8 = (var6 & 0xFF00) >> 8;
               if (var0 && var7 == var3 || !var0 && var8 == var3) {
                  var4 = true;
               }
            }
         }

         if (!var4) {
            return var3;
         }
      }

      return method_152(255);
   }

   // $VF: renamed from: a (int, byte, byte, byte, byte, byte, byte, byte) void
   private static final void method_678(int var0, byte var1, byte var2, byte var3, byte var4, byte var5, byte var6, byte var7) {
      field_329[var0] = var1;
      field_330[var0] = -1;
      method_736(field_331, var0, var2);
      method_736(field_332, var0, var3);
      method_736(field_333, var0, var4);
      field_334[var0] = var5;
      field_340[var0] = var6;
      field_341[var0] = var7;
      field_342[var0] = -1;
      field_343[var0] = -1;
      field_344[var0] = -1;
      field_345[var0] = -1;
      method_682(var0, 256, method_152(2) == 0, false);
   }

   // $VF: renamed from: a (int, byte) void
   public static final void method_679(int var0, byte var1) {
      byte var2 = (byte)method_572(12, var1, 0, 1);
      byte var3 = (byte)method_572(12, var1, 2, 3);
      byte var4 = (byte)method_572(12, var1, 4, 5);
      byte var5 = (byte)method_572(12, var1, 6, 7);
      byte var6 = (byte)method_572(12, var1, 8, 9);
      field_330[var0] = var1;
      field_335[var0] = var2;
      field_336[var0] = var3;
      field_337[var0] = var4;
      field_338[var0] = var5;
      field_339[var0] = var6;
   }

   // $VF: renamed from: p (int, int) int
   public static final int method_680(int var0, int var1) {
      for (int var2 = var0; var2 <= var1; var2++) {
         if (field_299[var2] < 0) {
            return var2;
         }
      }

      return -1;
   }

   // $VF: renamed from: bp () void
   public static final void method_681() {
      boolean var0 = false;

      do {
         var0 = true;
         int var1 = field_284;

         while (--var1 > 0) {
            byte var2 = field_301[var1];
            byte var3 = field_301[var1 - 1];
            int var4 = field_305[var2];
            int var5 = field_305[var3];
            if (var4 > var5) {
               field_301[var1] = var3;
               field_301[var1 - 1] = var2;
               var0 = false;
            }
         }
      } while (!var0);
   }

   // $VF: renamed from: a (int, int, boolean, boolean) void
   public static final void method_682(int var0, int var1, boolean var2, boolean var3) {
      method_570(field_312, var0, var1, var2, var3, field_313, field_465);
   }

   // $VF: renamed from: d (int, int) boolean
   public static final boolean method_683(int var0, int var1) {
      return method_569(field_312, var0, var1);
   }

   // $VF: renamed from: bq () void
   public static final void method_684() {
      field_349 = 0;
      field_348 = 0;
      field_347 = false;
      int var0 = field_417;
      field_420 = field_419;
      field_419 = field_417;
      field_469 = field_470;
      field_470 = field_417;
      int var1 = 0;
      int var2 = 0;
      int var3 = field_283;

      while (--var3 >= 0) {
         if (field_299[var3] >= 0) {
            byte var4 = field_309[var3];
            if (var3 < field_280) {
               if ((var1 & 1 << var4) != 0) {
                  var2 |= 1 << var4;
               } else {
                  var1 |= 1 << var4;
               }

               field_349++;
               byte var5;
               if ((var5 = method_735(field_331, var3)) == 100 && (field_155 & 127) == 40) {
                  method_479(1, var3, 100, true);
               }

               field_348 += var5;
               if (var5 < 100) {
                  var0 &= ~(1 << var4);
               }

               if (var5 < 100 || !method_683(var3, 8)) {
                  method_978(var4, false);
                  method_1055(var4, false);
               }
            } else if (var3 < field_283 && field_418[var4] > 0) {
               method_1055(var4, false);
            }

            if (var3 < field_283) {
               method_685(var3);
            }
         }
      }

      field_470 &= var2;
      field_419 &= var2;
      if (!method_1017(330)) {
         int var7 = method_568(var3 = var0 & var2);
         method_1019(330, false, var3 > 0, false, -1, -1, var7 >= 0 && var7 < field_406 ? var7 : -1, false, true);
      }
   }

   // $VF: renamed from: M (int) void
   public static final void method_685(int var0) {
      int var1 = field_304[var0];
      int var2 = field_305[var0];
      byte var3 = field_309[var0];
      byte var4 = -1;
      if (method_683(var0, 512)) {
         field_347 = true;
         var4 = field_292;
      }

      if (var4 < 0 && var0 < field_286 && method_1056(var3)) {
         var4 = field_292;
      }

      byte var5 = field_314[var0];
      int var6 = field_155 - field_317[var0];
      if (var4 < 0 && var0 < field_286) {
         if (method_735(field_331, var0) == 100) {
            var4 = field_293;
         } else if (method_735(field_332, var0) == 100) {
            var4 = field_294;
         }
      }

      boolean var7 = var0 < field_286;
      if (var5 == 0) {
         method_687(var0);
      } else if (var5 == 1) {
         method_688(var0);
      } else if (var5 == 2) {
         method_689(var0);
      } else if (var5 == 3) {
         method_696(var0);
      } else if (var7) {
         if (var5 == 5) {
            method_686(var0);
         } else if (var5 == 6) {
            if (var3 == field_416 && var6 % 32 == 0) {
               method_1067(field_302[var0], field_303[var0], method_735(field_331, var0));
            }

            method_690(var0);
         } else if (var5 == 7) {
            method_691(var0);
            if (var3 == field_416 && var6 % 32 == 0) {
               method_1066(field_302[var0], field_303[var0], method_735(field_331, var0));
            }

            if (var4 == -1) {
               var4 = field_295;
            }
         } else if (var5 == 8) {
            method_692(var0);
            if (var4 == -1) {
               var4 = field_295;
            }
         } else if (var5 == 9) {
            if (var3 == field_416 && var6 % 48 == 0) {
               method_1068(field_302[var0], field_303[var0]);
            }

            method_693(var0);
            if (var4 == -1) {
               var4 = field_295;
            }
         } else if (var5 == 10) {
            method_708(var0);
            if (var4 < 0) {
               var4 = field_292;
            }
         } else if (var5 == 11) {
            method_694(var0);
         } else if (var5 == 12) {
            method_705(var0);
         } else if (var5 == 13) {
            method_706(var0);
         } else if (var5 == 14) {
            if (method_741(var0, 1, (byte)6)) {
               method_726(var0, (byte)(field_308[var0] - 1), field_306[var0], field_307[var0], true);
               method_1208(true);
            }
         } else if (var5 == 15) {
            method_741(var0, 2, (byte)18);
         } else if (var5 == 16) {
            method_741(var0, 2, (byte)19);
         } else if (var5 == 17) {
            method_741(var0, 2, (byte)14);
         } else if (var5 == 18) {
            method_741(var0, 4, (byte)12);
         } else if (var5 == 19) {
            method_741(var0, 4, (byte)0);
         } else if (var5 == 20) {
            method_860(var0);
         } else if (var5 == 21) {
            method_695(var0);
         } else if (var5 == 22) {
            method_877(var0);
         } else if (var5 == 23) {
            method_790(var0);
         } else if (var5 == 24) {
            method_704(var0);
         } else if (var5 == 25) {
            method_697(var0);
         } else if (var5 == 26) {
            method_698(var0);
         } else if (var5 == 27) {
            method_699(var0);
         } else if (var5 == 28) {
            method_700(var0);
         } else if (var5 == 29) {
            method_702(var0);
         }
      } else if (var5 == 30) {
         method_707(var0);
      } else if (var5 == 31) {
         method_709(var0);
      } else if (var5 == 32) {
         method_741(var0, 100, (byte)30);
      } else if (var5 == 33) {
         method_783(var0);
      } else if (var5 == 34) {
         method_784(var0);
      } else if (var5 == 35) {
         method_789(var0);
      } else if (var5 == 36) {
         method_787(var0);
      } else if (var5 == 37) {
         method_788(var0);
      } else if (var5 == 38) {
         method_785(var0);
      } else if (var5 == 39) {
         method_786(var0);
      } else if (var5 == 40) {
         method_701(var0);
      }

      if (var0 < field_287) {
         int var8 = field_304[var0] - var1;
         int var9 = field_305[var0] - var2;
         boolean var10 = var8 != 0 || var9 != 0;
         method_682(var0, 2, var10, false);
         if (var10 && var5 != 2 && (var8 < 0 ? -var8 : var8) > 0) {
            method_721(var0, var8 < 0, true);
         }
      }

      if (var0 < field_286) {
         if (var4 == -1) {
            var4 = field_296;
         }

         method_957(var3, var4);
      }
   }

   // $VF: renamed from: N (int) void
   public static final void method_686(int var0) {
      if (!method_878(var0)) {
         if (field_274 != 1 || field_252 != var0) {
            boolean var1 = false;
            int var2 = field_306[var0];
            byte var3 = field_307[var0];
            byte var4 = field_309[var0];
            if (var2 == field_397[var4][0] && var3 == field_398[var4][0]) {
               var1 = true;
            }

            if (var1 || var0 < field_286 && method_735(field_332, var0) < 100) {
               GameClock.field_28.setSeed(var0 + System.currentTimeMillis());
               var2 = method_152(128 + 128 * (100 - method_735(field_331, var0)) / 100);
               if (field_364 == -1 && (var1 || var2 == 0)) {
                  method_664(var0, false, -1);
                  return;
               }

               if (var2 < 8) {
                  method_722(var0, !method_683(var0, 256), false);
               }
            }
         }
      }
   }

   // $VF: renamed from: O (int) void
   public static final void method_687(int var0) {
      method_655(var0);
   }

   // $VF: renamed from: P (int) void
   public static final void method_688(int var0) {
      if (method_270(field_302[var0], field_303[var0], field_320[var0], field_321[var0], field_279 << 1)) {
         field_315[var0] = 0;
         field_318[var0] = field_302[var0];
         field_319[var0] = field_303[var0];
         method_716(var0, (byte)2, true);
      } else {
         method_659(var0);
      }
   }

   // $VF: renamed from: Q (int) void
   public static final void method_689(int var0) {
      int var1;
      if ((var1 = field_465 - field_317[var0]) > 4) {
         method_649(var0, field_320[var0], field_321[var0]);
         method_716(var0, field_315[var0], true);
      } else {
         int var2 = method_579(field_318[var0], field_320[var0], var1, 4);
         int var3 = method_579(field_319[var0], field_321[var0], var1, 4);
         method_649(var0, var2, var3);
      }
   }

   // $VF: renamed from: R (int) void
   public static final void method_690(int var0) {
      int var1 = field_465 - field_317[var0];
      if (field_363 == 0 && (method_1056(field_309[var0]) || var1 > field_670 || method_735(field_332, var0) == 0 && var1 > 20)) {
         method_718(var0);
      }

      if ((field_465 & 63) == 0) {
         method_479(18, var0, 100, true);
      }
   }

   // $VF: renamed from: S (int) void
   public static final void method_691(int var0) {
      if (!method_878(var0)) {
         method_738(var0, true);
         method_744(var0, true, true);
         if ((field_465 & 127) == 0) {
            method_479(27 + method_152(2), var0, 100, true);
         }
      }
   }

   // $VF: renamed from: T (int) void
   public static final void method_692(int var0) {
      if (!method_878(var0)) {
         if (method_683(var0, 32768)) {
            method_738(var0, false);
         } else if (method_683(var0, 65536)) {
            method_738(var0, false);
         }

         method_744(var0, false, true);
      }
   }

   // $VF: renamed from: U (int) void
   public static final void method_693(int var0) {
      if (!method_878(var0)) {
         method_738(var0, true);
         method_744(var0, false, true);
         if ((field_465 & 127) == 0) {
            method_479(10 + method_152(2), var0, 100, true);
         }
      }
   }

   // $VF: renamed from: V (int) void
   public static final void method_694(int var0) {
      method_739(var0, (byte)17);
   }

   // $VF: renamed from: W (int) void
   public static final void method_695(int var0) {
      method_739(var0, (byte)20);
   }

   // $VF: renamed from: X (int) void
   public static final void method_696(int var0) {
      method_1064(field_302[var0], field_303[var0], true, false);
      boolean var1 = false;
      if (var0 < field_280 && field_344[var0] < 0) {
         method_682(var0, 512, true, false);
      }

      if (method_683(var0, 512)) {
         var1 = method_1061(var0);
      }

      if (var0 < field_280 && field_344[var0] >= 0) {
         byte var2 = field_309[var0];
         byte var3 = field_306[var0];
         byte var4 = field_307[var0];
         if (method_645(var2, var3, var4) == var0) {
            method_644(var2, var3, var4);
         }

         method_972(var0, field_344[var0]);
         field_344[var0] = -1;
         if (field_252 == var0 || field_251 == var0) {
            field_251 = -1;
            method_618(0);
         }

         method_651((byte)var0, 6, 7);
         if (!method_664(var0, false, -1)) {
            method_716(var0, (byte)5, true);
         }

         method_1299();
      } else {
         if (!var1) {
            method_667(var0);
         }
      }
   }

   // $VF: renamed from: Y (int) void
   public static final void method_697(int var0) {
      if (field_465 - field_317[var0] == 0 || field_465 % (25 + 25 * (100 - method_735(field_331, var0)) / 100) == 0) {
         method_661(var0);
      }
   }

   // $VF: renamed from: Z (int) void
   public static final void method_698(int var0) {
      if (!method_711(var0, false, field_344[var0])) {
         byte var1 = field_309[var0];
         byte var2 = field_397[var1][0];
         byte var3 = field_398[var1][0];
         method_887(var0, var2, var3, 1, 6, 1, 6, true, true);
         byte var4 = (byte)field_600;
         byte var5 = (byte)field_601;
         if (var4 >= 0 && var5 >= 0) {
            method_724(var0, var4, var5, (byte)26);
         }
      }
   }

   // $VF: renamed from: aa (int) void
   public static final void method_699(int var0) {
      if (!method_878(var0)) {
         int var1;
         if ((var1 = field_465 - field_317[var0]) == 1) {
            method_1450(var0);
         }

         method_738(var0, true);
         if (var1 > 30) {
            method_716(var0, (byte)5, true);
         }
      }
   }

   // $VF: renamed from: ab (int) void
   public static final void method_700(int var0) {
      if (field_328[var0] < 0) {
         method_716(var0, (byte)5, true);
      }

      method_703(var0);
   }

   // $VF: renamed from: ac (int) void
   public static final void method_701(int var0) {
      byte var1 = field_328[var0];
      method_703(var0);
      int var2;
      if ((var2 = field_465 - field_317[var0]) == 21 && var1 >= 0) {
         int var3 = (field_304[var1] * 60 + field_304[var0] * 40) / 100;
         int var4 = field_305[var1] - 47;
         method_1216(var3, var4);
         method_1071(field_600, field_601);
         method_479(24, var0, 100, true);
      }

      if (var1 >= 0 && var2 == 22 && field_314[var1] != 29) {
         method_716(var1, (byte)29, true);
      }

      if (var2 > 55) {
         method_716(var0, (byte)30, true);
         if (var1 >= 0) {
            method_682(var1, 512, false, false);
            method_737(field_331, var1, -1000);
            method_737(field_332, var1, 1000);
            method_737(field_333, var1, 1000);
            method_664(var1, false, 5);
            method_740(var0);
         }
      }
   }

   // $VF: renamed from: ad (int) void
   public static final void method_702(int var0) {
      if (field_328[var0] == -1) {
         method_716(var0, (byte)5, true);
      } else {
         method_703(var0);
      }
   }

   // $VF: renamed from: bp (int) void
   private static void method_703(int var0) {
      byte var1;
      if ((var1 = field_328[var0]) >= 0) {
         boolean var2 = field_304[var1] < field_304[var0];
         method_721(var0, var2, true);
      }
   }

   // $VF: renamed from: ae (int) void
   public static final void method_704(int var0) {
      if (field_465 % (var0 + 1) == 0) {
         byte var1 = field_309[var0];
         int var2 = 10;

         while (--var2 >= 0) {
            if (field_396[var1][var2] == 1 && method_888(var1, var2, 1) && method_662(var0, var2, (byte)11)) {
               return;
            }
         }
      }
   }

   // $VF: renamed from: af (int) void
   public static final void method_705(int var0) {
      byte var1 = field_306[var0];
      byte var2 = field_307[var0];
      method_712(var0, (byte)13);
      if ((byte)(field_308[var0] - 1) < 2) {
         method_660(var0, var1 - 2, var2, var1, var2);
      } else {
         method_660(var0, var1, var2 - 2, var1, var2);
      }
   }

   // $VF: renamed from: ag (int) void
   public static final void method_706(int var0) {
      method_664(var0, false, -1);
   }

   // $VF: renamed from: ah (int) void
   public static final void method_707(int var0) {
      if (field_363 == 0 && field_364 == -1) {
         GameClock.field_28.setSeed(var0 + System.currentTimeMillis());
         if (field_465 - field_317[var0] < 2) {
            method_742(var0, true);
         }

         if (method_742(var0, true) > 10 && method_152(128) == 0) {
            method_664(var0, true, -1);
         }
      }
   }

   // $VF: renamed from: bq (int) void
   private static final void method_708(int var0) {
      field_347 = true;
      boolean var1 = method_683(var0, 16);
      method_722(var0, !var1, false);
      byte var2 = field_306[var0];
      byte var3 = field_307[var0];
      if (field_465 % 10 == 0) {
         for (int var4 = field_289; var4 >= field_286; var4--) {
            if (field_299[var4] >= 0 && field_309[var4] == field_309[var0]) {
               byte var5 = field_306[var4];
               byte var6 = field_307[var4];
               int var11;
               int var7 = (var11 = var5 - var2) < 0 ? -var11 : var11;
               int var8 = (var11 = var6 - var3) < 0 ? -var11 : var11;
               if (var7 <= 1 && var8 <= 1) {
                  boolean var9 = method_683(var0, 128);
                  int var10 = field_304[var4] - field_304[var0];
                  if (var9 && var10 <= 0 || !var9 && var10 >= 0) {
                     method_716(var0, (byte)5, false);
                     return;
                  }
               } else if (field_314[var4] == 30 && field_364 == -1) {
                  method_716(var4, (byte)31, false);
               }
            }
         }
      }

      if (field_465 - field_317[var0] > 40 && method_743(var0, var1, var2, var3) < 0) {
         method_716(var0, (byte)5, false);
      }

      if (var1) {
         method_1211(var2, var3);
      } else {
         method_1212(var2, var3);
      }

      int var12 = field_600;
      method_1209(var2, var3);
      var12 = var12 + field_600 >> 1;
      int var14;
      int var15;
      if (((var15 = (var14 = field_304[var0]) - var12) < 0 ? -var15 : var15) > 6) {
         method_650(var0, (var14 * 80 + var12 * 20) / 100, field_305[var0]);
      } else {
         method_682(var0, 2, false, false);
      }

      method_721(var0, !var1, false);
   }

   // $VF: renamed from: br (int) void
   private static final void method_709(int var0) {
      int var1 = field_280;

      while (--var1 >= 0) {
         if (field_299[var1] >= 0 && field_314[var1] == 10 && method_683(var1, 16)) {
            int var2 = field_306[var1];
            int var3 = field_307[var1] - 1;
            method_887(var0, var2, var3, 0, 8, 0, 8, true, true);
            var2 = field_600;
            var3 = field_601;
            if (method_636(var0, (byte)var2, (byte)var3)) {
               method_712(var0, (byte)32);
               method_655(var0);
               return;
            }
         }
      }

      method_716(var0, (byte)30, true);
   }

   // $VF: renamed from: c (int, boolean) void
   public static final void method_710(int var0, boolean var1) {
      if (field_344[var0] < 0) {
         if ((var1 || field_465 % (var0 + 1) == 0) && !method_711(var0, true, (byte)-1)) {
            method_716(var0, (byte)5, true);
         }
      }
   }

   // $VF: renamed from: a (int, boolean, byte) boolean
   public static final boolean method_711(int var0, boolean var1, byte var2) {
      byte var3 = field_309[var0];
      byte var4 = field_397[var3][0];
      byte var5 = field_398[var3][0];
      if (method_636(var0, var4, var5)) {
         if (method_654(var0)) {
            byte var6;
            int var7 = (var6 = field_308[var0]) - 1;
            method_725(var0, (byte)var7, field_397[var3][var6], field_398[var3][var6], false);
            boolean var8 = false;
            if (field_314[var0] == 6) {
               var8 = true;
               method_726(var0, (byte)var7, field_306[var0], field_307[var0], false);
               method_1208(true);
            }

            method_716(var0, (byte)(var8 ? 16 : 0), true);
         }

         if (field_323[var0][1] == var4) {
            field_323[var0][0] = var4;
            field_324[var0][0] = (byte)(var5 + 2);
         } else {
            method_639(var0, var4, (byte)(var5 + 2));
         }

         method_712(var0, (byte)3);
         if (var0 < field_280 && var2 >= 0) {
            field_344[var0] = var2;
         }

         if (var1) {
            method_682(var0, 512, true, false);
            if (!method_1017(343)) {
               method_1019(343, method_1056(var3), true, true, var0, 218, field_309[var0], false, true);
            }
         }

         method_655(var0);
         return true;
      } else {
         return false;
      }
   }

   // $VF: renamed from: b (int, byte) void
   public static final void method_712(int var0, byte var1) {
      field_316[var0] = var1;
   }

   // $VF: renamed from: i (int, int) void
   public static final void method_713(int var0, int var1) {
      byte var2 = field_306[var1];
      byte var3 = field_307[var1];
      method_887(var0, var2, var3, var2 - 1, var2 - 1, var3, var3, true, true);
      if (field_600 < 0) {
         method_887(var0, var2, var3, var2, var2, var3 - 1, var3 - 1, true, true);
         if (field_600 < 0) {
            method_887(var0, var2, var3, var2 + 1, var2 + 1, var3, var3, true, true);
            if (field_600 < 0) {
               method_887(var0, var2, var3, var2, var2, var3 + 1, var3 + 1, true, true);
            }
         }
      }

      if (field_600 >= 0) {
         method_740(var0);
         field_328[var0] = (byte)var1;
         field_328[var1] = (byte)var0;
         method_716(var1, (byte)28, true);
         method_724(var0, (byte)field_600, (byte)field_601, (byte)40);
      }
   }

   // $VF: renamed from: j (int, int) void
   public static final void method_714(int var0, int var1) {
      if (field_465 - field_317[var0] > var1) {
         method_664(var0, false, -1);
      }
   }

   // $VF: renamed from: a (int, int, boolean) boolean
   public static final boolean method_715(int var0, int var1, boolean var2) {
      int var3;
      int var4;
      label46: {
         if (field_304[var0] < field_304[var1]) {
            if (!var2) {
               var3 = var1;
               var4 = var0;
               break label46;
            }
         } else if (var2) {
            var3 = var1;
            var4 = var0;
            break label46;
         }

         var3 = var0;
         var4 = var1;
      }

      byte var5 = field_306[var4];
      byte var6 = field_307[var4];
      byte var7 = field_306[var3];
      byte var8 = field_307[var3];
      boolean var9 = false;
      int var10 = var2 ? var5 - 1 : var5 + 1;
      int var11 = var2 ? var6 + 1 : var6 - 1;
      if (var7 == var10 && var8 == var11) {
         method_716(var3, (byte)10, true);
         var9 = true;
      } else if (method_636(var3, (byte)var10, (byte)var11)) {
         method_712(var3, (byte)10);
         method_655(var3);
         var9 = true;
      }

      if (var9) {
         method_716(var4, (byte)10, true);
         method_682(var4, 16, !var2, false);
         method_682(var3, 16, var2, false);
      }

      return var9;
   }

   // $VF: renamed from: a (int, byte, boolean) void
   public static final void method_716(int var0, byte var1, boolean var2) {
      byte var3 = field_309[var0];
      byte var4 = field_314[var0];
      if (var1 == 10) {
         if (!method_1056(var3)) {
            for (int var5 = field_289; var5 >= field_286; var5--) {
               if (field_299[var5] >= 0 && field_309[var5] == var3) {
                  byte var6 = field_306[var5];
                  byte var7 = field_307[var5];
                  int var8 = field_306[var0];
                  byte var9 = field_307[var0];
                  int var10;
                  if (((var10 = var8 - var6) < 0 ? -var10 : var10) <= 1 && ((var8 = var9 - var7) < 0 ? -var8 : var8) <= 1) {
                     return;
                  }
               }
            }

            if (!method_1017(327)) {
               method_1019(327, false, field_416 != field_408, true, var0, -1, field_309[var0], false, true);
            }
         }

         field_422 = 1;
      } else if (var1 == 6) {
         method_746(var0, false);
      } else if (var1 == 8) {
         byte var11 = field_308[var0];
         method_682(var0, 32768, false, false);
         method_682(var0, 65536, false, false);
         boolean var12;
         if (!(var12 = var11 >= 0 && (method_823(var3, var11, 24) || method_823(var3, var11, 25) || method_823(var3, var11, 26))) && field_346 == 1) {
            field_346 = (byte)((field_346 + 1) % 3);
         }

         boolean var13;
         if (!(var13 = var11 >= 0 && method_823(var3, var11, 23)) && field_346 == 0) {
            field_346 = (byte)((field_346 + 1) % 3);
         }

         if (field_346 == 1 && var12) {
            method_682(var0, 32768, true, false);
         } else if (field_346 == 0 && var13) {
            method_682(var0, 65536, true, false);
            method_750(field_299[var0] % 101);
         }

         field_346 = (byte)((field_346 + 1) % 3);
      }

      if (var4 == 6 && var1 != 6) {
         method_746(var0, true);
      }

      field_314[var0] = var1;
      if (var2) {
         field_317[var0] = field_465;
      }

      if (var0 == field_252 && (var1 == 8 || var1 == 7 || var1 == 9 || var4 == 8 || var4 == 7 || var4 == 9)) {
         method_1299();
      }
   }

   // $VF: renamed from: k (int, int) void
   public static final void method_717(int var0, int var1) {
      byte var2 = 0;
      byte var3 = 0;
      var2 = (byte)(1 + (var0 + 1 + method_152(4)) % 5);
      var3 = (byte)(1 + (var1 + 1 + method_152(4)) % 5);
      field_600 = method_150(var2, 1, 5);
      field_601 = method_150(var3, 1, 5);
   }

   // $VF: renamed from: ai (int) void
   public static final void method_718(int var0) {
      method_716(var0, (byte)15, true);
      method_726(var0, (byte)(field_308[var0] - 1), field_306[var0], field_307[var0], false);
      method_1208(true);
   }

   // $VF: renamed from: A (int) int
   public static final int method_719(int var0) {
      return method_683(var0, 128) ? 1 : 0;
   }

   // $VF: renamed from: B (int) int
   public static final int method_720(int var0) {
      return method_683(var0, 256) ? 1 : 0;
   }

   // $VF: renamed from: a (int, boolean, boolean) void
   public static final void method_721(int var0, boolean var1, boolean var2) {
      method_682(var0, 128, var1, false);
      method_722(var0, var1, var2);
   }

   // $VF: renamed from: b (int, boolean, boolean) void
   public static final void method_722(int var0, boolean var1, boolean var2) {
      int var3 = field_465;
      if (var2 || var3 - field_327[var0] > 15) {
         method_682(var0, 256, var1, false);
         field_327[var0] = var3;
      }
   }

   // $VF: renamed from: E (int) boolean
   public static final boolean method_723(int var0) {
      int var1 = field_280;

      while (--var1 >= 0) {
         if (field_299[var1] >= 0 && field_309[var1] == field_416 && field_314[var1] == 6 && var0 == field_308[var1] - 1) {
            return true;
         }
      }

      return false;
   }

   // $VF: renamed from: a (int, byte, byte, byte) boolean
   public static final boolean method_724(int var0, byte var1, byte var2, byte var3) {
      if (method_636(var0, var1, var2)) {
         boolean var4 = false;
         if (method_654(var0)) {
            byte var6 = (byte)(field_308[var0] - 1);
            method_725(var0, var6, field_306[var0], field_307[var0], false);
            if (field_314[var0] == 6) {
               var4 = true;
               method_726(var0, var6, field_306[var0], field_307[var0], false);
               method_1208(true);
            }
         }

         method_712(var0, var3);
         method_716(var0, (byte)(var4 ? 16 : 0), true);
         return true;
      } else {
         return false;
      }
   }

   // $VF: renamed from: a (int, byte, int, int, boolean) void
   public static final void method_725(int var0, byte var1, int var2, int var3, boolean var4) {
      boolean var5 = var1 < 2;
      if (var4) {
         if (var5) {
            method_639((byte)var0, (byte)(var2 - 2), (byte)var3);
         } else {
            method_639((byte)var0, (byte)var2, (byte)(var3 - 2));
         }
      } else {
         method_638((byte)var0, field_306[var0], field_307[var0]);
      }
   }

   // $VF: renamed from: b (int, byte, int, int, boolean) void
   public static final void method_726(int var0, byte var1, int var2, int var3, boolean var4) {
      boolean var5 = var1 < 2;
      if (var4) {
         if (var5) {
            method_651((byte)var0, (byte)(var2 - 2), (byte)(var3 - 1));
         } else {
            method_651((byte)var0, (byte)(var2 - 1), (byte)(var3 - 2));
         }
      } else if (var5) {
         method_651((byte)var0, (byte)(var2 - 2), (byte)var3);
      } else {
         method_651((byte)var0, (byte)var2, (byte)(var3 - 2));
      }
   }

   // $VF: renamed from: aj (int) void
   public static final void method_727(int var0) {
      if (var0 <= field_280 - 1) {
         int var1;
         if ((var1 = field_299[var0]) >= 0) {
            byte var2 = method_735(field_331, var0);
            byte var3 = method_735(field_332, var0);
            byte var4 = method_735(field_333, var0);
            if (!method_1017(323)) {
               method_1019(323, false, var2 == 100 && field_416 != field_408, true, var0, 219, field_309[var0], false, true);
            }

            if (!method_1017(325)) {
               method_1019(325, false, var3 == 100 && field_416 != field_408, true, var0, 220, field_309[var0], false, true);
            }

            if (method_729(var0, var4, var2)) {
               return;
            }

            byte var5;
            if (method_1056(var5 = field_309[var0])) {
               method_736(field_332, var0, method_149(10, method_735(field_332, var0)));
            }

            if (field_364 >= 3 && method_779(var0)) {
               method_737(field_331, var0, -300);
            }

            byte var6 = field_314[var0];
            if (field_364 == -1) {
               boolean var7 = method_730(var0, var2, var4, var6);
               method_728(var0, var2, var3, var7);
            }

            method_780(var0);
            if (var6 >= 6 && var6 <= 10) {
               byte var13;
               if ((var13 = field_308[var0]) >= 0) {
                  byte var8 = field_339[var0];
                  byte var9 = field_338[var0];
                  byte var10 = field_337[var0];
                  method_824(var5, var13);
                  int var11 = method_148(0, field_600);
                  int var12 = method_148(0, field_601);
                  if (var6 == 7) {
                     method_1453(var0, var11, var12, var2, var3, var8);
                  } else if (var6 == 8) {
                     method_1452(var0, var11, var12, var8, var10);
                  } else if (var6 == 6) {
                     method_1448(var0, var11, var12, var3);
                  } else if (var6 == 9) {
                     method_1449(var0, var11, var12, var9);
                  }
               } else if (var6 == 10) {
                  method_1451(var0);
               }
            }

            method_749(var0, var1, var2, var3);
         }
      }
   }

   // $VF: renamed from: b (int, int, int, boolean) void
   public static final void method_728(int var0, int var1, int var2, boolean var3) {
      byte var4;
      if (var2 < 100 && field_314[var0] != 6 && (var4 = field_340[var0]) > 0 && var1 > 90) {
         int var5 = 0;
         int var6 = 4000 * var1 / 100;
         byte var7 = field_306[var0];
         byte var8 = field_307[var0];
         int var9 = method_148(0, var7 - 2);
         int var10 = method_149(8, var7 + 2);
         int var11 = method_148(0, var8 - 2);
         int var12 = method_149(8, var8 + 2);
         byte var13 = field_309[var0];

         for (int var14 = var9; var14 <= var10; var14++) {
            for (int var15 = var11; var15 <= var12; var15++) {
               byte var16;
               if ((var16 = method_645(var13, var14, var15)) != var0 && var16 >= 0 && var16 < field_286 && method_735(field_332, var16) < 100) {
                  byte var17 = field_341[var16];
                  int var22;
                  int var23;
                  int var18 = method_148(1, ((var22 = var14 - var7) < 0 ? -var22 : var22) + ((var23 = var15 - var8) < 0 ? -var23 : var23));
                  int var19 = var6 * method_148(0, var4 - var17) / 100 / var18;
                  method_737(field_331, var16, var19);
                  var5 += var19;
                  if (var19 > 1) {
                     if (method_152(4) == 0) {
                        method_747(var16, 135, method_152(1), true, true);
                     } else {
                        method_747(var16, 134, method_152(3), true, true);
                     }

                     if (!method_1017(335)) {
                        method_1019(335, false, field_416 != field_408, true, var0, 222, field_309[var0], false, true);
                     }
                  }

                  byte var20 = field_314[var16];
                  if (var3
                     && (var20 == 5 || var20 == 7 || var20 == 8 || var20 == 9 || var20 == 25)
                     && ((var22 = var7 - var14) < 0 ? -var22 : var22) <= 1
                     && ((var22 = var8 - var15) < 0 ? -var22 : var22) <= 1) {
                     boolean var21;
                     if (!(var21 = method_715(var0, var16, true))) {
                        method_715(var16, var0, false);
                     }

                     if (var21) {
                        var3 = false;
                     }
                  }
               }
            }
         }

         if (var5 > 1) {
            method_747(var0, 133, 0, true, false);
         }
      }
   }

   // $VF: renamed from: e (int, int, int) boolean
   private static final boolean method_729(int var0, int var1, int var2) {
      if (var1 == 0 && var2 == 0) {
         method_531(var0);
         return true;
      } else {
         return false;
      }
   }

   // $VF: renamed from: b (int, int, int, byte) boolean
   private static boolean method_730(int var0, int var1, int var2, byte var3) {
      if (var1 == 100) {
         if (!method_683(var0, 8)) {
            method_682(var0, 8, true, true);
            if (field_416 == field_309[var0]) {
               method_479(0, -1, 100, true);
            }
         }
      } else {
         method_682(var0, 8, false, false);
      }

      int var4 = method_1454();
      boolean var5 = false;
      if (method_683(var0, 8)) {
         var5 = true;
      }

      if (!var5 && var2 >= 60) {
         int var6 = 100 * (var2 - 60) / 40;
         int var7 = 100 * (var4 - 33) / 67;
         var5 = var6 > var7;
      }

      byte var10 = field_336[var0];
      byte var11 = field_335[var0];
      if (!var5 && var11 >= 60 && var11 > var10) {
         var5 = true;
      }

      if (!var5) {
         return false;
      } else {
         boolean var8 = false;
         if ((var3 == 5 || var3 == 25) && field_465 - field_313[var0] > 30) {
            int var9 = method_152(100);
            if (var10 > var11) {
               if (var9 < var10) {
                  var8 = true;
               }
            } else if (var9 < var11 && var4 < var11) {
               method_710(var0, true);
            }
         }

         return var8;
      }
   }

   // $VF: renamed from: c (int, boolean, boolean) void
   public static final void method_731(int var0, boolean var1, boolean var2) {
      if (var1) {
         method_1064(field_302[var0], field_303[var0], true, false);
      }

      byte var3 = field_329[var0];
      int var4 = var1 ? method_260(13, var3, 4) : method_260(13, var3, 3);
      if (var1) {
         field_722[var3]++;
         if (field_425 == 0) {
            field_723++;
         }
      }

      if (var2) {
         method_667(var0);
      }

      if (var1) {
         field_425++;
         field_435 += var4;
         field_460 = var4;
         method_1009(1, var4);
      } else {
         field_426++;
         field_436 += var4;
      }
   }

   // $VF: renamed from: br () void
   public static final void method_732() {
      method_1008(-2500);
      method_1009(1, 2500);
   }

   // $VF: renamed from: bs () void
   public static final void method_733() {
      int var0 = field_280;

      while (--var0 >= 0) {
         if (field_299[var0] >= 0) {
            field_334[var0]--;
            if (field_334[var0] == 0) {
               method_731(var0, false, false);
               method_682(var0, 131072, true, false);
            }
         }
      }
   }

   // $VF: renamed from: bt () void
   public static final void method_734() {
      int var0 = field_280;

      while (--var0 >= 0) {
         if (field_299[var0] >= 0 && method_683(var0, 131072)) {
            method_667(var0);
         }
      }
   }

   // $VF: renamed from: a (int[], int) byte
   public static final byte method_735(int[] var0, int var1) {
      return (byte)(var0[var1] / 100);
   }

   // $VF: renamed from: a (int[], int, int) void
   public static final void method_736(int[] var0, int var1, int var2) {
      var0[var1] = var2 * 100;
   }

   // $VF: renamed from: b (int[], int, int) void
   public static final void method_737(int[] var0, int var1, int var2) {
      if (var1 >= 0 && var1 < field_280) {
         if (field_466 < 2 && var2 > 0 && var0 == field_331) {
            var2 >>= 1;
         }

         int var4 = method_150(var0[var1] + var2, 0, 10000);
         var0[var1] = var4;
         if (!method_1017(326)) {
            method_1019(326, false, var0 == field_333 && var2 < 0, true, var1, 221, field_309[var1], true, false);
         }

         if (!method_1017(347)) {
            method_1019(347, false, var0 == field_333 && var4 == 0 && method_735(field_331, var1) > 0, true, var1, 221, field_309[var1], true, false);
         }

         if (!method_1017(348)) {
            method_1019(348, false, var0 == field_333 && var2 > 0, true, var1, 221, field_309[var1], false, true);
         }
      }
   }

   // $VF: renamed from: d (int, boolean) void
   public static final void method_738(int var0, boolean var1) {
      byte var2;
      if ((var2 = field_308[var0]) >= 0) {
         byte var3 = field_309[var0];
         boolean var4 = field_401[var3][var2] < field_304[var0];
         method_721(var0, var4, var1);
      }
   }

   // $VF: renamed from: c (int, byte) void
   public static final void method_739(int var0, byte var1) {
      method_740(var0);
      byte var2 = (byte)(field_308[var0] - 1);
      field_342[var0] = var2;
      byte var3 = field_306[var0];
      byte var4 = field_307[var0];
      method_725(var0, var2, var3, var4, true);
      method_712(var0, var1);
      method_655(var0);
   }

   // $VF: renamed from: ak (int) void
   public static final void method_740(int var0) {
      byte var1;
      if ((var1 = field_328[var0]) >= 0) {
         field_328[var1] = -1;
      }

      field_328[var0] = -1;
   }

   // $VF: renamed from: b (int, int, byte) boolean
   public static final boolean method_741(int var0, int var1, byte var2) {
      if (field_465 - field_317[var0] >= var1) {
         method_716(var0, var2, true);
         return true;
      } else {
         return false;
      }
   }

   // $VF: renamed from: a (int, boolean) int
   public static final int method_742(int var0, boolean var1) {
      boolean var2 = field_304[var0] > 0;
      method_721(var0, var2, var1);
      return field_465 - field_317[var0];
   }

   // $VF: renamed from: a (int, boolean, byte, byte) int
   public static final int method_743(int var0, boolean var1, byte var2, byte var3) {
      int var4 = var2 + (var1 ? 1 : -1);
      int var5 = var3 + (var1 ? -1 : 1);
      byte var6;
      return (var6 = method_645(field_309[var0], var4, var5)) >= 0
            && var6 <= field_288
            && field_314[var6] == 10
            && method_683(var6, 128) != method_683(var0, 128)
         ? var6
         : -1;
   }

   // $VF: renamed from: d (int, boolean, boolean) void
   public static final void method_744(int var0, boolean var1, boolean var2) {
      if ((var2 && method_735(field_332, var0) == 100 || var1 && method_735(field_331, var0) == 100) && field_465 - field_317[var0] > 3) {
         method_664(var0, false, 5);
      } else {
         method_714(var0, field_670);
      }
   }

   // $VF: renamed from: bu () void
   public static final void method_745() {
      int var0 = field_283;

      while (--var0 >= 0) {
         if (field_299[var0] >= 0) {
            method_682(var0, 2048, false, false);
         }
      }
   }

   // $VF: renamed from: e (int, boolean) void
   public static final void method_746(int var0, boolean var1) {
      byte var2;
      boolean var3 = method_823(var2 = field_309[var0], 1 + field_342[var0], 4);
      boolean var4 = method_823(var2, 1 + field_342[var0], 5);
      method_682(var0, 8192, var3, false);
      method_682(var0, 16384, var4, false);
      if (var3 || var4) {
         method_682(var0, 4096, var1, false);
         field_343[var0] = field_465;
         if (field_416 == var2) {
            method_479(6, var0, 100, true);
         }
      }
   }

   // $VF: renamed from: a (int, int, int, boolean, boolean) void
   public static final void method_747(int var0, int var1, int var2, boolean var3, boolean var4) {
      if (var3 || field_326[var0] < 0) {
         field_326[var0] = field_465 + (var4 ? 10 : 0);
         field_325[var0] = var1 << 16 | var2;
         field_350 = var0;
      }
   }

   // $VF: renamed from: al (int) void
   public static final void method_748(int var0) {
      field_325[var0] = -1;
      field_326[var0] = -1;
   }

   // $VF: renamed from: b (int, int, byte, byte) void
   public static final void method_749(int var0, int var1, byte var2, byte var3) {
      if (var3 == 100) {
         method_747(var0, 131, 0, false, false);
      } else if (var0 != field_350 && method_152(20) == 0) {
         method_747(var0, 136, var1 % 6, false, false);
      } else {
         if (method_152(5) == 0) {
            if (var2 >= 50) {
               method_747(var0, 132, (var2 - 50) * 2 / 50, false, false);
               return;
            }

            if (var2 < 10) {
               method_747(var0, 130, method_152(4), false, false);
            }
         }
      }
   }

   // $VF: renamed from: am (int) void
   public static final void method_750(int var0) {
      field_351 = 60 + 40 * var0 / 100;
      field_352 = 0;
   }

   // $VF: renamed from: e (int, int, int) void
   public static final void method_751(int var0, int var1, int var2) {
      int var3;
      if ((var3 = var1 & 0xFF) < 6 || var3 >= 24 && var3 <= 29 || var3 >= 60 && var3 <= 77 || var3 >= 84 && var3 <= 89 || var3 >= 120 && var3 <= 155) {
         int var4 = var3 < 6 ? 5 : (var3 < 60 ? 3 : (var3 >= 84 && var3 < 100 ? 5 : 0));
         int var5;
         if ((var5 = var3 % 6) == 0) {
            method_479(20, var0, 100, true);
         }

         if (var5 < 2) {
            field_604 = var4;
         } else if (var5 == 2) {
            field_604 = var4 + 1;
            method_754(var3 < 120 ? 40 : 5);
         } else if (var5 < 5) {
            field_604 = var4 + 2;
         } else {
            field_604 = 3;
         }

         if (var5 >= 1 && var5 <= 3) {
            int var6 = var2 == 0 ? 2 : -2;
            field_606 += var6;
            field_602 += 2;
            field_605 = var3 < 64 ? 2 : 0;
         }
      } else {
         field_604 = 3;
      }
   }

   // $VF: renamed from: d (javax.microedition.lcdui.Graphics, int, int, int) void
   public static final void method_752(Graphics var0, int var1, int var2, int var3) {
      int var4 = var3 == 1 ? -1 : 1;
      int var5;
      field_354 = var5 = field_465 << 4;
      int var6 = 40 * field_352 / 100;
      int var7 = 8 * field_352 / 100;
      int var8 = (method_151(384 + var5 % 512, var6) + var6 >> 1) * var4;
      int var9 = -(method_151(128 + (var5 << 1) % 512, var7) - var7) >> 1;
      int var10 = var1 + var4 * 40 * 50 / 100;
      int var11 = var2 - 64;
      int var12 = var10 + var8;
      int var13 = var11 + var9;
      method_313(var0, 15397588);
      method_312(var0, var12, var13, var10, var11 - field_599);
      method_200(var0, 10, var12, var13, 3);
      method_753();
   }

   // $VF: renamed from: hC () void
   private static final void method_753() {
      if (field_353 > 0) {
         field_352 = method_149(field_351, field_352 + 7);
         field_353 = method_148(0, field_353 - 7);
      } else {
         field_352 = method_148(0, field_352 - 1);
      }
   }

   // $VF: renamed from: bs (int) void
   private static final void method_754(int var0) {
      int var1 = field_354 % 512;
      if (field_352 < 50 || var1 > 384 || var1 < 128) {
         field_353 = method_149(50, field_353 + var0);
      }
   }

   // $VF: renamed from: bv () void
   public static final void method_755() {
      method_762();
      field_358 = 0;
   }

   // $VF: renamed from: bw () void
   public static final void method_756() {
      method_1118();
      method_1009(1, method_1010());
   }

   // $VF: renamed from: bx () void
   public static final void method_757() {
      method_758(method_1048(3, field_358));
   }

   // $VF: renamed from: an (int) void
   public static final void method_758(int var0) {
      if (var0 != 0) {
         field_358 += var0;
         int var1 = 4;

         while (--var1 >= 0) {
            byte var2;
            if ((var2 = method_763(field_358, var1)) >= 0) {
               method_682(var2, 128, (field_358 & 1) == 0, false);
            }
         }

         method_1009(1, method_1010());
      }
   }

   // $VF: renamed from: by () void
   public static final void method_759() {
      if (field_432 > 0 && field_426 > 0) {
         method_760(method_1048(field_432 > 0 ? 2 : 1, field_358));
      }
   }

   // $VF: renamed from: ao (int) void
   public static final void method_760(int var0) {
      if (var0 != 0) {
         field_358 += var0;
         int var1 = 4;

         while (--var1 >= 0) {
            byte var2;
            if ((var2 = method_763(field_358, var1)) >= 0) {
               method_682(var2, 128, (field_358 & 1) == 0, false);
            }
         }

         method_413(true);
      }
   }

   // $VF: renamed from: bz () void
   public static final void method_761() {
      field_358 = -1;
      method_764(-1);
   }

   // $VF: renamed from: bA () void
   public static final void method_762() {
      GameClock.field_28.setSeed(System.currentTimeMillis());
      method_767(method_769());
      int var1 = method_770();
      if (field_479 == 0 && field_466 == 0) {
         boolean var9 = method_1014();
         int var10 = 3;

         while (--var10 >= 0) {
            method_679(method_768(-1, 0 + var10, 0, var9 ? 1 : 2), (byte)4);
            method_679(method_768(-1, 0 + var10, 0 + var10, var9 ? 1 : 2), (byte)4);
         }
      } else {
         if (!method_555(1)) {
            method_768(-1, 0, 0, 1);
            method_768(-1, 0, 0, 1);
            method_768(-1, 0, 0, 1);
         }

         if (var1 == 0) {
            int var2 = 3;

            while (--var2 >= 0) {
               method_768(-1, var2, 0 + var2, 1);
            }
         }

         if (method_555(1) && method_555(2)) {
            method_768(-1, 1, 1 + method_152(2), -1);
            method_768(-1, 2, 1 + method_152(2), -1);
         }

         int var7 = 4;

         while (--var7 >= 0) {
            method_768(-1, 0, 0, -1);
            method_768(-1, 1, 1, -1);
            method_768(-1, 2, 2, -1);
         }

         var7 = 3;

         while (--var7 >= 0) {
            method_765();
            int var3 = 4;

            while (--var3 >= 0) {
               byte var4;
               if ((var4 = method_763(var7, var3)) != -1 && var4 != -2) {
                  if (field_329[var4] == 2) {
                     int var6 = method_766(field_357);
                     method_679(var4, (byte)var6);
                     field_357[var6]++;
                     field_356[var6]++;
                  } else {
                     int var11 = method_766(field_356);
                     method_679(var4, (byte)var11);
                     field_356[var11]++;
                  }
               }
            }
         }
      }
   }

   // $VF: renamed from: a (int, int) byte
   public static final byte method_763(int var0, int var1) {
      return field_355[var0 * 4 + var1];
   }

   // $VF: renamed from: ap (int) void
   public static final void method_764(int var0) {
      int var1 = 0;
      int var2 = 12;

      while (--var2 >= 0) {
         byte var3;
         if ((var3 = field_355[var2]) != -1 && var3 != -2) {
            if (var2 / 4 == var0) {
               method_682(var3, 1, false, false);
               method_651(var3, 6, 7 - var1);
               method_664(var3, false, -1);
               var1++;
            } else {
               method_667(var3);
            }
         }
      }

      if (field_358 >= 0) {
         method_1008(var2 = method_1010());
         field_437 += var2;
      }
   }

   // $VF: renamed from: bB () void
   public static final void method_765() {
      method_571(field_356, 5, (byte)0);
      method_571(field_357, 5, (byte)0);
      int var0 = field_280;

      while (--var0 >= 0) {
         byte var1 = field_330[var0];
         if (field_299[var0] >= 0 && var1 >= 0 && !method_683(var0, 1)) {
            byte var2 = field_329[var0];
            field_356[var1]++;
            if (var2 == 2) {
               field_357[var1]++;
            }
         }
      }
   }

   // $VF: renamed from: a (byte[]) int
   public static final int method_766(byte[] var0) {
      int var1 = 0;
      int var2 = Integer.MAX_VALUE;
      int var3 = 5;

      while (--var3 >= 0) {
         byte var4;
         if ((var4 = var0[var3]) < var2) {
            var1 = var3;
            var2 = var4;
         }
      }

      return var1;
   }

   // $VF: renamed from: aq (int) void
   public static final void method_767(int var0) {
      for (int var1 = 0; var1 < 3; var1++) {
         for (int var2 = 0; var2 < 4; var2++) {
            field_355[var1 * 4 + var2] = (byte)(var2 < var0 ? -1 : -2);
         }
      }
   }

   // $VF: renamed from: g (int, int, int, int) int
   public static final int method_768(int var0, int var1, int var2, int var3) {
      int var4;
      if ((var4 = method_771(var1)) >= 0) {
         int var5 = var0 == -1 ? method_673(var2, var3) : var0;
         field_355[var4] = (byte)var5;
         return var5;
      } else {
         return -1;
      }
   }

   // $VF: renamed from: w () int
   public static final int method_769() {
      int var0 = 0;
      int var1 = field_280;

      while (--var1 >= 0) {
         if (field_299[var1] >= 0) {
            var0++;
         }
      }

      byte var4 = 0;
      int var2 = field_406;

      while (--var2 >= 0) {
         byte var3;
         if ((var3 = field_409[var2]) >= 0 && method_994(var3) == 0) {
            var4 += 4;
         }
      }

      return var4 - var0;
   }

   // $VF: renamed from: x () int
   public static final int method_770() {
      int var0 = 0;
      int var1 = field_280;

      while (--var1 >= 0) {
         if (field_299[var1] >= 0 && field_334[var1] == 1) {
            var0++;
         }
      }

      return var0;
   }

   // $VF: renamed from: C (int) int
   public static final int method_771(int var0) {
      int var1;
      int var2 = (var1 = var0 * 4) + 4 - 1;

      for (int var3 = var1; var3 <= var2; var3++) {
         if (field_355[var3] == -1) {
            return var3;
         }
      }

      return -1;
   }

   // $VF: renamed from: bC () void
   public static final void method_772() {
      field_359 = -1;
      field_360 = -1;
      field_362 = 0;
      field_363 = 0;
      field_364 = -1;

      for (int var0 = field_286; var0 <= field_289; var0++) {
         if (field_299[var0] >= 0 && method_683(var0, 1024)) {
            method_667(var0);
         }
      }
   }

   // $VF: renamed from: bD () void
   public static final void method_773() {
      if (field_364 == -1) {
         method_1168();
         method_794();
         field_427++;
         field_428++;
         method_1008(-2000);
      }
   }

   // $VF: renamed from: L () boolean
   public static final boolean method_774() {
      boolean var0;
      if (!(var0 = field_445 >= 2000)) {
         field_481 = 256;
         field_482 = method_462(field_481, method_463(2000), null, null, null, null, null, null, null);
      }

      return var0;
   }

   // $VF: renamed from: bE () void
   public static final void method_775() {
      int var0;
      int var1 = (var0 = method_994(field_409[field_416])) == 0 ? 500 : 100;
      int var2 = field_360;
      int var3 = field_465 - field_359;
      switch (field_364) {
         case -1:
            return;
         case 0:
            if (method_777()) {
               method_794();
               method_745();
            }

            return;
         case 1:
            if (method_776(var2)) {
               method_78(23, 100);
               method_794();
            }

            return;
         case 2:
            method_738(var2, true);
            if (method_793(10)) {
               method_745();
               method_1596(method_1056(field_309[field_360]), 17, true);
            }

            return;
         case 3:
            if (method_796() || var3 > var1) {
               method_794();
            }

            return;
         case 4:
            if (method_793(20)) {
               field_362 = method_148(1, method_149(var0 == 0 ? 4 : 2, method_996(field_309[var2])));
               field_363 = 0;
               method_795();
               method_78(22, 100);
            }

            return;
         case 5:
            if (field_465 % 22 == 0) {
               if (method_994(field_300[field_410[field_309[var2]]]) == 0) {
                  boolean var9 = false;
                  boolean var10000;
                  if (var3 > var1) {
                     var10000 = true;
                  } else {
                     int var10 = 0;
                     int var6 = 0;
                     int var7 = field_280;

                     while (--var7 >= 0) {
                        if (field_299[var7] >= 0 && field_309[var7] == field_309[var2]) {
                           if (field_314[var7] == 6) {
                              var10++;
                           } else {
                              var6++;
                           }
                        }
                     }

                     var10000 = (var7 = var10 + var6) >= field_363 && var10 == field_363 || var7 < field_363 && var6 == 0;
                  }

                  if (var10000) {
                     method_800(var2);
                     method_794();
                  }

                  return;
               }

               if (method_792(field_309[var2], (byte)39, false, true, true) || method_793(var1)) {
                  method_800(var2);
               }
            }

            return;
         case 6:
            if (field_465 % 33 == 0 && (method_792(field_309[var2], (byte)37, false, true, true) || method_793(var1))) {
               method_791(-1);
            }

            return;
         case 7:
            if (field_465 % 66 == 0) {
               if (var3 > var1 << 1) {
                  for (int var4 = field_286; var4 <= field_289; var4++) {
                     if (field_299[var4] >= 0 && method_683(var4, 1024)) {
                        method_667(var4);
                     }
                  }
               } else if (var3 > var1) {
                  method_791(-1);
               }

               boolean var8 = true;

               for (int var5 = field_286; var5 <= field_289; var5++) {
                  if (field_299[var5] >= 0 && field_309[var5] == field_309[var2] && method_683(var5, 1024)) {
                     var8 = false;
                     break;
                  }
               }

               if (var8) {
                  if (field_360 >= 0) {
                     method_664(field_360, true, 30);
                  }

                  field_364 = -1;
                  method_1299();
               }
            }

            return;
         case 8:
         case 9:
         case 10:
         case 11:
         case 12:
         case 13:
      }
   }

   // $VF: renamed from: F (int) boolean
   public static final boolean method_776(int var0) {
      if (field_465 % 33 == 0) {
         byte var1 = field_309[field_360];
         byte var2 = field_397[var1][9];
         byte var3 = field_398[var1][9];
         if (field_306[var0] == var2 && field_307[var0] == var3 && field_314[var0] == 30) {
            return true;
         }
      }

      return false;
   }

   // $VF: renamed from: M () boolean
   public static final boolean method_777() {
      int var0 = -1;

      for (int var1 = field_286; var1 <= field_289; var1++) {
         if (field_299[var1] >= 0 && field_309[var1] == field_416) {
            var0 = var1;
            break;
         }
      }

      field_360 = var0;
      return method_778();
   }

   // $VF: renamed from: N () boolean
   public static final boolean method_778() {
      if (field_360 >= 0) {
         if (method_662(field_360, 9, (byte)30)) {
            return true;
         }

         method_664(field_360, true, 30);
      }

      return false;
   }

   // $VF: renamed from: G (int) boolean
   public static final boolean method_779(int var0) {
      return field_360 >= 0 && field_309[field_360] == field_309[var0];
   }

   // $VF: renamed from: ar (int) void
   public static final void method_780(int var0) {
      byte var1;
      if (method_979(var1 = field_309[var0])) {
         if (field_364 > -1 || method_1057()) {
            return;
         }

         byte var2 = field_329[var0];
         field_418[var1] = (byte)method_150(field_418[var1] - field_661[var2], 0, 100);
      }
   }

   // $VF: renamed from: as (int) void
   public static final void method_781(int var0) {
      if (!method_979(var0)) {
         field_418[var0] = (byte)method_150(field_418[var0] + 4, 0, 100);
      }
   }

   // $VF: renamed from: a (int, boolean, int, int) boolean
   public static final boolean method_782(int var0, boolean var1, int var2, int var3) {
      if (!var1 && var2 == 0 && var3 == 0) {
         return false;
      } else {
         int var4 = 10;

         while (--var4 >= 0) {
            byte var5;
            if ((var5 = field_396[var0][var4]) != -1) {
               byte var6 = field_397[var0][var4];
               byte var7 = field_398[var0][var4];
               if (var5 != 1 && var5 != 4 && var5 != 2 && var5 != 3) {
                  int var8;
                  if (var5 == 0 && ((var8 = var2 - var6) < 0 ? -var8 : var8) < 2 && ((var0 = var3 - var7) < 0 ? -var0 : var0) < 2) {
                     return false;
                  }
               } else if (var2 == var6 && var3 == var7) {
                  return false;
               }
            }
         }

         return true;
      }
   }

   // $VF: renamed from: at (int) void
   public static final void method_783(int var0) {
      byte var1 = field_309[var0];
      byte var2 = field_397[var1][0];
      byte var3 = field_398[var1][0];
      if (!method_657(var1, var2, var3, var0) && method_645(var1, var2, var3) < 0) {
         method_637(var0);
         method_638(var0, var2, var3);
         method_712(var0, (byte)34);
         method_655(var0);
      }
   }

   // $VF: renamed from: au (int) void
   public static final void method_784(int var0) {
      if (!method_683(var0, 4)) {
         method_682(var0, 4, true, false);
         method_795();
      }

      method_664(var0, false, 38);
   }

   // $VF: renamed from: av (int) void
   public static final void method_785(int var0) {
      method_798((byte)var0);
   }

   // $VF: renamed from: aw (int) void
   public static final void method_786(int var0) {
      if (field_465 - field_317[var0] > 700) {
         method_801(var0);
      }
   }

   // $VF: renamed from: ax (int) void
   public static final void method_787(int var0) {
      method_801(var0);
   }

   // $VF: renamed from: ay (int) void
   public static final void method_788(int var0) {
      method_721(var0, true, true);
   }

   // $VF: renamed from: az (int) void
   public static final void method_789(int var0) {
      if (method_683(var0, 2048)) {
         byte var10;
         if ((var10 = field_328[var0]) >= 0) {
            int var2 = field_304[var10];
            int var3 = field_305[var10];
            int var4 = field_304[var0];
            int var5 = field_305[var0];
            int var6 = (var2 * 10 + var4 * 90) / 100;
            int var7 = (var3 * 10 + var5 * 90) / 100;
            method_1214(var6, var7);
            int var8 = field_600;
            int var9 = field_601;
            if (method_782(field_309[var0], false, var8, var9)) {
               method_650(var0, var6, var7);
            }
         } else {
            method_801(var0);
         }
      } else {
         byte var1 = field_328[var0];
         if (method_994(field_300[field_410[field_309[var0]]]) == 0) {
            method_716(var1, (byte)24, true);
         } else {
            method_740(var1);
            method_737(field_331, var1, -10000);
            method_716(var1, (byte)5, true);
            method_716(var0, (byte)39, true);
         }

         method_682(var0, 2048, true, false);
         method_682(var1, 2048, true, false);
      }
   }

   // $VF: renamed from: aA (int) void
   public static final void method_790(int var0) {
      if (method_152(128) < 16) {
         method_722(var0, !method_683(var0, 256), false);
      }
   }

   // $VF: renamed from: aB (int) void
   public static final void method_791(int var0) {
      method_455((int)System.currentTimeMillis());
      int var1 = method_456() % 10;
      int var2 = field_289 - field_286 + 1;

      for (int var3 = 0; var3 < var2; var3++) {
         int var4;
         if ((var4 = field_286 + (var3 + var1) % var2) != var0 && field_299[var4] >= 0 && method_683(var4, 1024) && method_711(var4, false, (byte)-1)) {
            return;
         }
      }
   }

   // $VF: renamed from: a (int, byte, boolean, boolean, boolean) boolean
   private static boolean method_792(int var0, byte var1, boolean var2, boolean var3, boolean var4) {
      boolean var5 = true;
      int var6 = field_283;

      while (--var6 >= 0) {
         if (field_299[var6] >= 0
            && field_309[var6] == var0
            && (!var2 || var6 < field_280)
            && (!var3 || var6 >= field_286)
            && (!var4 || method_683(var6, 1024))
            && field_314[var6] != var1) {
            var5 = false;
            break;
         }
      }

      if (var5) {
         method_794();
         return true;
      } else {
         return false;
      }
   }

   // $VF: renamed from: an (int) boolean
   private static final boolean method_793(int var0) {
      if (field_465 - field_359 >= var0) {
         method_794();
         return true;
      } else {
         return false;
      }
   }

   // $VF: renamed from: hD () void
   private static final void method_794() {
      field_364++;
      field_359 = field_465;
   }

   // $VF: renamed from: hE () void
   private static final void method_795() {
      if (field_362 > 0) {
         field_362--;
         byte var0 = field_309[field_360];
         byte var1 = field_397[var0][0];
         byte var2 = field_398[var0][0];
         int var3;
         if ((var3 = method_671(var0, var1, var2 + 1)) >= 0) {
            field_363++;
            method_682(var3, 1024, true, false);
            method_716(var3, (byte)33, true);
         }
      }
   }

   // $VF: renamed from: O () boolean
   public static final boolean method_796() {
      boolean var0 = true;
      int var1 = field_280;

      while (--var1 >= 0) {
         if (field_299[var1] >= 0 && field_309[var1] == field_309[field_360]) {
            var0 = method_797(var0, var1);
         }
      }

      return var0;
   }

   // $VF: renamed from: a (boolean, int) boolean
   public static boolean method_797(boolean var0, int var1) {
      method_682(var1, 512, false, false);
      byte var2 = field_314[var1];
      byte var3 = field_306[var1];
      byte var4 = field_307[var1];
      if (var3 > 0 && var3 < 7 && var4 > 0 && var4 < 7 && var2 == 5) {
         field_328[var1] = -1;
      } else {
         var0 = false;
         if (method_654(var1)) {
            if (var2 == 20) {
               method_716(var1, (byte)12, true);
            } else if (var2 == 6) {
               method_718(var1);
            }
         } else if (!method_683(var1, 2048) && method_664(var1, false, 5)) {
            method_737(field_331, var1, -500);
            method_682(var1, 2048, true, false);
         }
      }

      return var0;
   }

   // $VF: renamed from: c (byte) boolean
   private static final boolean method_798(byte var0) {
      byte var1 = field_309[var0];
      if (field_328[var0] < 0) {
         int var2 = field_280;

         while (--var2 >= 0) {
            if (field_299[var2] >= 0 && field_309[var2] == var1 && field_328[var2] < 0 && field_314[var2] == 5) {
               byte var3 = field_306[var2];
               byte var4 = field_307[var2];
               boolean var5;
               if (!(var5 = method_799(var0, (byte)var2, var3 + 1, var4))
                  && !(var5 = method_799(var0, (byte)var2, var3 - 1, var4))
                  && !(var5 = method_799(var0, (byte)var2, var3, var4 + 1))) {
                  var5 = method_799(var0, (byte)var2, var3, var4 - 1);
               }

               if (var5) {
                  return true;
               }
            }
         }

         return false;
      } else {
         return true;
      }
   }

   // $VF: renamed from: a (byte, byte, int, int) boolean
   private static final boolean method_799(byte var0, byte var1, int var2, int var3) {
      if (var2 > 0 && var3 > 0 && method_636(var0, (byte)var2, (byte)var3)) {
         method_740(var0);
         field_328[var1] = var0;
         field_328[var0] = var1;
         method_716(var1, (byte)23, true);
         method_712(var0, (byte)35);
         method_655(var0);
         return true;
      } else {
         return false;
      }
   }

   // $VF: renamed from: bt (int) void
   private static final void method_800(int var0) {
      for (int var1 = field_286; var1 <= field_289; var1++) {
         if (field_299[var1] >= 0 && field_309[var1] == field_309[var0] && method_683(var1, 1024)) {
            method_801(var1);
         }
      }
   }

   // $VF: renamed from: bu (int) void
   private static final void method_801(int var0) {
      if (field_314[var0] != 37) {
         byte var1 = field_309[var0];
         byte var2 = field_397[var1][0];
         byte var3 = field_398[var1][0];

         for (int var4 = 0; var4 <= field_363; var4++) {
            if (method_636(var0, (byte)(var2 - 1), (byte)(var3 - var4 - 1))) {
               method_712(var0, (byte)37);
               method_655(var0);
               return;
            }
         }

         method_664(var0, false, 36);
      }
   }

   // $VF: renamed from: H (int) boolean
   public static final boolean method_802(int var0) {
      return var0 == 60;
   }

   // $VF: renamed from: I (int) boolean
   public static final boolean method_803(int var0) {
      return var0 == 18;
   }

   // $VF: renamed from: q (int, int) int
   public static final int method_804(int var0, int var1) {
      int var2 = 0;
      int var3 = 10;

      while (--var3 >= 0) {
         byte var4;
         if ((var4 = field_396[var0][var3]) >= 1 && var4 <= 4) {
            byte var5 = field_365[var4 - 1 << 1];
            byte var6 = field_365[(var4 - 1 << 1) + 1];
            method_824(var0, var3);
            int var7 = method_148(0, field_600);
            int var8 = method_148(0, field_601);
            if (var5 == var1) {
               var2 += var7;
            }

            if (var6 == var1) {
               var2 += var8;
            }
         }
      }

      return var2;
   }

   // $VF: renamed from: a (byte, int) void
   public static final void method_805(byte var0, int var1) {
      field_370[var0] = (short)var1;
   }

   // $VF: renamed from: a (int) short
   public static final short method_806(int var0) {
      return field_370[var0];
   }

   // $VF: renamed from: a (byte, byte, int, int) void
   public static final void method_807(byte var0, byte var1, int var2, int var3) {
      method_811(var0, var1, var2, -1, -1, -1, -1, var3);
   }

   // $VF: renamed from: a (byte, byte, int, int, int) void
   public static final void method_808(byte var0, byte var1, int var2, int var3, int var4) {
      method_811(var0, var1, var2, var3, -1, -1, -1, var4);
   }

   // $VF: renamed from: a (byte, byte, int, int, int, int) void
   public static final void method_809(byte var0, byte var1, int var2, int var3, int var4, int var5) {
      method_811(var0, var1, var2, var3, var4, -1, -1, var5);
   }

   // $VF: renamed from: a (byte, byte, int, int, int, int, int) void
   public static final void method_810(byte var0, byte var1, int var2, int var3, int var4, int var5, int var6) {
      method_811(var0, var1, var2, var3, var4, var5, -1, var6);
   }

   // $VF: renamed from: a (byte, byte, int, int, int, int, int, int) void
   public static final void method_811(byte var0, byte var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      int var8 = method_812(var0, var1);
      field_371[var8 + 4] = (byte)var2;
      field_371[var8 + 3] = (byte)var3;
      field_371[var8 + 2] = (byte)var4;
      field_371[var8 + 1] = (byte)var5;
      field_371[var8] = (byte)var6;
      field_218[method_553(var1, var0)] = (byte)var7;
      if (var7 > field_219) {
         field_219 = var7;
      }
   }

   // $VF: renamed from: a (byte, int) int
   public static final int method_812(byte var0, int var1) {
      return (var0 - 1) * 10 * 5 + var1 * 5;
   }

   // $VF: renamed from: r (int, int) int
   public static final int method_813(int var0, int var1) {
      method_824(var0, var1);
      int var2 = field_600;
      int var3 = field_601;
      if (var2 < 0) {
         return -128;
      } else if (var3 == 0) {
         return var2;
      } else if (var2 == 0) {
         return 3 + var3;
      } else {
         return var3 == 1 ? 6 + var2 : 9;
      }
   }

   // $VF: renamed from: c (byte, int) boolean
   public static final boolean method_814(byte var0, int var1) {
      if (var1 >= 1 && var1 <= 8) {
         byte var2 = field_399[var0][var1];
         return method_844(field_396[var0][var1]) ? var2 > 0 : var2 != -128;
      } else {
         return false;
      }
   }

   // $VF: renamed from: l (int, int) void
   public static final void method_815(int var0, int var1) {
      int var2 = method_1012();
      field_399[var0][var1] = -128;
      if (var0 == field_416) {
         method_825();
      }

      if (field_479 == 0 && !method_1609(18)) {
         boolean var3 = false;

         for (int var4 = 1; var4 <= 8; var4++) {
            byte var5;
            if ((var5 = field_396[var0][var4]) >= 0) {
               byte var6 = field_399[var0][var4];
               boolean var7;
               if ((var7 = method_844(var5)) && var6 > 0 || !var7 && var6 >= 0) {
                  var3 = true;
                  break;
               }
            }
         }

         method_1596(!var3, 18, true);
      }

      int var8 = method_1012();
      field_442 = field_442 + method_148(0, var2 - var8);
   }

   // $VF: renamed from: c (int, int, int, int) void
   public static final void method_816(int var0, int var1, int var2, int var3) {
      field_483 = var1;
      field_484 = -1;

      for (int var4 = var3; var4 < 10; var4++) {
         if (method_818(var0, var1, var2, var3, var4)) {
            field_484 = var4;
            return;
         }
      }

      if (var1 < 4) {
         boolean var5 = method_820(var0, var1);
         if (method_819(var0, var1) || var5) {
            field_483 = var1 + 1;
            method_919(var2);
            int var7;
            field_484 = (var7 = field_600 + field_601) == 0 ? 0 : (var7 == 1 ? 1 : 2);
         }
      }
   }

   // $VF: renamed from: d (int, int, int, int) void
   public static final void method_817(int var0, int var1, int var2, int var3) {
      field_483 = var1;
      field_484 = -1;

      for (int var4 = var3; var4 >= 0; var4--) {
         if (method_818(var0, var1, var2, var3, var4)) {
            field_484 = var4;
            return;
         }
      }

      if (var1 > 2) {
         boolean var5 = method_820(var0, var1);
         boolean var6;
         if ((var6 = method_819(var0, var1)) || var5) {
            field_483 = var1 - 1;
            field_484 = 7;
            if (var6) {
               field_484 = 7;
               return;
            }

            if (var5) {
               field_484 = 4;
            }
         }
      }
   }

   // $VF: renamed from: b (int, int, int, int, int) boolean
   public static final boolean method_818(int var0, int var1, int var2, int var3, int var4) {
      boolean var5 = method_820(var0, var1);
      boolean var6 = method_819(var0, var1);
      method_919(var4);
      int var7 = field_600;
      int var8 = field_601;
      return var4 != var3 && method_821(var2, var4) && (!var6 || var7 + var8 < 3) && (!var5 || var7 + var8 <= 1);
   }

   // $VF: renamed from: o (int, int) boolean
   private static boolean method_819(int var0, int var1) {
      return !method_820(var0, var1) && var0 == 0 && var1 != 1;
   }

   // $VF: renamed from: p (int, int) boolean
   private static boolean method_820(int var0, int var1) {
      return field_479 > 1 && var0 == 0 && var1 != 1;
   }

   // $VF: renamed from: e (int, int) boolean
   public static final boolean method_821(int var0, int var1) {
      method_919(var0);
      int var2 = field_600;
      int var3 = field_601;
      method_919(var1);
      int var4 = field_600;
      int var5 = field_601;
      return var2 + var3 <= var4 + var5;
   }

   // $VF: renamed from: f (int, int, int) void
   public static final void method_822(int var0, int var1, int var2) {
      method_919(var2);
      field_399[var0][var1] = (byte)(field_600 << 4 | field_601);
      method_1208(true);
      method_825();
      field_369 = field_368;
      field_368 = field_466;
      int var3;
      method_1596((var3 = method_994(field_409[var0])) == 0 && method_804(var0, 1) == 12, 5, true);
      method_1596(var3 == 0 && method_804(var0, 0) == 12, 6, true);
      method_1596(var3 == 1 && method_804(var0, 3) == 12, 7, true);
      method_1596(var3 == 2 && method_804(var0, 4) >= 9, 8, true);
      method_1596(var3 == 3 && method_804(var0, 2) == 12, 9, true);
      byte var5;
      if (field_416 >= 0 && var0 == field_416 && field_254 >= 0 && ((var5 = field_396[field_416][field_254]) == 2 || var5 == 3 || var5 == 4)) {
         int var4 = field_288;

         while (--var4 >= field_285) {
            if (field_299[var4] >= 0 && field_308[var4] == field_254) {
               method_664(var4, false, 5);
            }
         }
      }
   }

   // $VF: renamed from: b (int, int, int) boolean
   public static final boolean method_823(int var0, int var1, int var2) {
      return method_829(method_812(field_396[var0][var1], method_813(var0, var1)), var2);
   }

   // $VF: renamed from: m (int, int) void
   public static final void method_824(int var0, int var1) {
      if (method_844(field_396[var0][var1])) {
         field_600 = -128;
         field_601 = -128;
      } else {
         byte var3;
         if ((var3 = field_399[var0][var1]) < 0) {
            field_600 = -128;
            field_601 = -128;
         } else {
            field_600 = (var3 & 240) >> 4;
            field_601 = var3 & 15;
         }
      }
   }

   // $VF: renamed from: bF () void
   public static final void method_825() {
      byte var0 = field_416;
      field_391 = 0;
      field_392 = 0;

      for (int var1 = 1; var1 <= 4; var1++) {
         method_824(var0, var1);
         int var2 = method_148(0, field_600);
         int var3 = method_148(0, field_601);
         field_391 += var2;
         field_392 += var3;
      }

      field_245 = method_1220();
      method_598();
      method_827();
   }

   // $VF: renamed from: P () boolean
   public static final boolean method_826() {
      boolean var0 = false;
      int var1 = field_406;

      while (--var1 >= 0 && !var0) {
         if (field_409[var1] >= 0) {
            int var2 = 10;

            while (--var2 >= 0 && !var0) {
               if (field_396[var1][var2] >= 0) {
                  method_824(var1, var2);
                  if (field_600 > 0 || field_601 > 0) {
                     var0 = true;
                  }
               }
            }
         }
      }

      return var0;
   }

   // $VF: renamed from: bG () void
   public static final void method_827() {
      int var0 = 2236979;
      int[] var1 = field_503;
      int[] var2 = field_504;
      int var3;
      if ((var3 = method_994(field_409[field_416])) == 1) {
         var1 = field_506;
         var2 = field_506;
      } else if (var3 == 2) {
         var1 = field_505;
         var2 = field_505;
      } else if (var3 == 3) {
         var1 = field_507;
         var2 = field_507;
      }

      var3 = method_828(field_391, var1, true);
      int var4 = method_828(field_392, var2, true);
      int var5 = method_828(field_391, var1, false);
      int var6 = method_828(field_392, var2, false);
      if (field_391 + field_392 == 0 || field_392 == 0) {
         field_389 = var3;
         field_390 = var5;
      } else if (field_391 == 0) {
         field_389 = var4;
         field_390 = var6;
      } else {
         int var7 = method_1292(var4, var3);
         int var8 = method_1292(var6, var5);
         int var9 = method_1292(var3, var4);
         int var10 = method_1292(var5, var6);
         field_389 = method_325(var7, var9, 128);
         field_390 = method_325(var8, var10, 128);
      }

      field_387 = method_325(field_389, var0, 34);
      field_388 = method_325(field_390, var0, 34);
   }

   // $VF: renamed from: a (int, int[], boolean) int
   private static int method_828(int var0, int[] var1, boolean var2) {
      int var3 = (var0 >> 1) + (var2 ? 0 : 7);
      return (var0 & 1) == 0 ? var1[var3] : method_325(var1[var3], var1[var3 + 1], 128);
   }

   // $VF: renamed from: f (int, int) boolean
   public static final boolean method_829(int var0, int var1) {
      if (var0 < 0) {
         return false;
      } else {
         boolean var2 = false;
         int var3 = 5;

         while (--var3 >= 0) {
            byte var4;
            if (var0 + var3 < field_366 && (var4 = field_371[var0 + var3]) >= 0 && var4 == var1) {
               var2 = true;
               break;
            }
         }

         return var2;
      }
   }

   // $VF: renamed from: bH () void
   public static final void method_830() {
      byte var0 = field_416;
      byte var1 = field_254;
      byte var2;
      if ((var2 = field_396[var0][var1]) >= 1 && var2 <= 4) {
         int var3 = method_813(var0, var1);
         method_831(field_396[var0][var1], var3);
      }
   }

   // $VF: renamed from: n (int, int) void
   public static final void method_831(int var0, int var1) {
      System.arraycopy(field_385, 0, field_384, 0, 3);
      int var2 = (var0 - 1) * 2;
      byte var3 = field_365[var2];
      byte var4 = field_365[var2 + 1];
      method_919(var1);
      int var5 = field_600;
      int var6 = field_601;
      int var7 = 0;

      for (int var8 = var5; --var8 >= 0; var7++) {
         method_834(var7, var3);
      }

      for (int var9 = var6; --var9 >= 0; var7++) {
         method_834(var7, var4);
      }

      for (int var10 = 3 - var5 - var6; --var10 >= 0; var7++) {
         method_834(var7, -1);
      }
   }

   // $VF: renamed from: a (int, int, boolean) void
   public static final void method_832(int var0, int var1, boolean var2) {
      field_483 = 0;
      field_484 = var0 - var1;
      if (var0 <= 3) {
         field_483 = 162;
         field_484 = var0;
         if (var2) {
            field_484 += 4;
            return;
         }
      } else {
         if (var0 == 4) {
            field_483 = 163;
            return;
         }

         if (var0 == 5) {
            field_483 = 163;
            field_484 = 1;
            return;
         }

         if (var0 == 6) {
            field_483 = 50;
            return;
         }

         if (var0 == 7) {
            field_483 = 51;
            return;
         }

         if (var0 == 8) {
            field_483 = 52;
            return;
         }

         if (var0 == 9) {
            field_483 = 160;
            return;
         }

         if (var0 == 10) {
            field_483 = 161;
            field_484 = var2 ? 1 : 0;
            return;
         }

         if (var0 < 20) {
            field_483 = 157;
            field_484 = var0 - var1;
            return;
         }

         if (var0 < 27) {
            field_483 = 158;
            field_484 = var0 - var1;
            if (var2) {
               field_484 += 7;
               return;
            }
         } else {
            field_483 = 159;
         }
      }
   }

   // $VF: renamed from: D (int) int
   public static final int method_833(int var0) {
      if (var0 < 11) {
         return 0;
      } else if (var0 < 20) {
         return 11;
      } else {
         return var0 < 27 ? 20 : 27;
      }
   }

   // $VF: renamed from: N (int, int) void
   private static void method_834(int var0, int var1) {
      if (field_385[var0] != var1) {
         field_385[var0] = (byte)var1;
         field_386[var0] = field_155;
      }
   }

   // $VF: renamed from: y () int
   public static final int method_835() {
      short var0 = -1;
      int var1 = 0;
      byte var2;
      if (method_844(var2 = field_396[field_416][field_372])) {
         boolean var3;
         if ((!(var3 = var2 == 9) || method_547(field_382)) && (var3 || method_548(field_382))) {
            if (field_382 == field_399[field_416][field_372]) {
               var0 = 257;
            } else {
               int var4 = method_851(field_416, field_372, field_373, field_374, field_376);
               if (field_445 < var4) {
                  var0 = 256;
                  var1 = var4;
               }
            }
         } else {
            var0 = 258;
         }
      } else if (field_373 == var2 && field_376 == field_374) {
         var0 = 257;
      } else {
         int var5 = method_851(field_416, field_372, field_373, field_374, field_376);
         if (method_558(field_373, field_376)) {
            var0 = 258;
         } else if (field_445 < var5) {
            var0 = 256;
            var1 = var5;
         }
      }

      if (var0 == 256) {
         field_482 = method_462(256, method_463(var1), null, null, null, null, null, null, null);
      } else {
         field_482 = method_133(var0);
      }

      return var0;
   }

   // $VF: renamed from: bI () void
   public static final void method_836() {
      field_393 = true;
      method_1488();
      byte var0 = field_416;
      byte var1 = field_254;
      field_372 = field_254;
      field_373 = field_396[var0][var1];
      if (method_844(field_373)) {
         field_382 = field_399[var0][var1];
         if (field_382 < 0) {
            field_382 = 1;
         }

         field_376 = field_382;
         int var6 = method_842() + 1;
         if (method_837()) {
            var6--;
         }

         field_381 = var6;
         method_839(field_382 - (method_837() ? 1 : 0));
         method_850();
         field_481 = method_835();
      } else {
         int var2;
         field_374 = var2 = method_813(var0, var1);
         field_376 = var2 < 0 ? 0 : var2;
         field_375 = field_376;
         field_481 = method_835();
         method_831(field_373, field_376);
         method_850();
         int var3 = method_994(field_409[var0]);
         byte var4 = field_373;
         byte var5 = field_373;
         method_846(var3, var4, var5, var2);
         field_381 = method_847(var2, method_819(var3, var4), method_820(var3, var4));
         method_838(method_848(var3, var4, var2, var2));
      }
   }

   // $VF: renamed from: Q () boolean
   public static final boolean method_837() {
      return field_399[field_416][field_372] != 0;
   }

   // $VF: renamed from: aC (int) void
   public static final void method_838(int var0) {
      field_382 = var0;
      method_839(var0);
   }

   // $VF: renamed from: bv (int) void
   private static void method_839(int var0) {
      field_186.setLength(0);
      field_186.append(method_463(var0 + 1));
      field_186.append("/");
      field_186.append(method_463(field_381));
      field_383 = field_186.toString();
   }

   // $VF: renamed from: bJ () void
   public static final void method_840() {
      int var1;
      if ((var1 = method_160(method_231())) != 0) {
         boolean var2 = false;
         if (method_844(field_373)) {
            int var3 = method_843();
            int var4 = method_842();
            var2 = var1 < 0 && field_382 > var3 || var1 > 0 && field_382 < var4;
         } else {
            var2 = var1 < 0 && field_377 >= 0 || var1 > 0 && field_378 >= 0;
         }

         if (var2) {
            field_486 = var1;
            method_236();
            method_237();
            method_841(var1);
            method_1049();
         }
      }

      if (field_393 && !method_844(field_373)) {
         field_393 = false;
         method_1016();
      }
   }

   // $VF: renamed from: aD (int) void
   public static final void method_841(int var0) {
      if (var0 != 0) {
         byte var1 = field_416;
         int var2 = field_376;
         if (method_844(field_373)) {
            int var6 = field_382;
            int var7 = method_843();
            int var5 = method_842();
            field_382 = method_150(field_382 + var0, var7, var5);
            field_376 = field_382;
            if (field_382 != var6) {
               method_839(field_382 - (method_837() ? 1 : 0));
               method_850();
               field_481 = method_835();
               if (field_382 == var7 || field_382 == var5) {
                  method_413(true);
               }
            }

            return;
         }

         int var3;
         if ((var3 = var0 > 0 ? field_378 : field_377) >= 0) {
            field_373 = (byte)(var0 > 0 ? field_380 : field_379);
            field_375 = var2;
            field_376 = var3;
            method_831(field_373, field_376);
            method_850();
            field_481 = method_835();
            method_838(field_382 + var0);
         }

         byte var4 = field_396[var1][field_372];
         method_846(method_994(field_409[var1]), field_373, var4, field_374);
      }
   }

   // $VF: renamed from: z () int
   public static final int method_842() {
      return field_373 == 8 ? 8 : 5;
   }

   // $VF: renamed from: A () int
   public static final int method_843() {
      return field_399[field_416][field_372] == 0 ? 0 : 1;
   }

   // $VF: renamed from: b (byte) boolean
   public static final boolean method_844(byte var0) {
      return var0 == 8 || var0 == 9;
   }

   // $VF: renamed from: b (int, byte, byte) boolean
   public static final boolean method_845(int var0, byte var1, byte var2) {
      method_824(var0, field_372);
      int var3 = method_148(0, field_600);
      int var4 = method_148(0, field_601);
      int var5 = var3 + var4;
      int var6 = var2 - 1 << 1;
      boolean var7 = field_365[var6] == var1;
      boolean var8 = field_365[var6 + 1] == var1;
      if (var7) {
         return var3 < 1 && var5 <= 1 && !method_558(var2, 1) || var3 < 2 && var5 <= 2 && !method_558(var2, 2) || var3 < 3 && var5 <= 3 && !method_558(var2, 3);
      } else {
         return !var8
            ? false
            : var4 < 1 && var5 <= 1 && !method_558(var2, 4) || var4 < 2 && var5 <= 2 && !method_558(var2, 5) || var4 < 3 && var5 <= 3 && !method_558(var2, 6);
      }
   }

   // $VF: renamed from: e (int, int, int, int) void
   public static final void method_846(int var0, int var1, int var2, int var3) {
      method_816(var0, var1, var3, field_376);
      field_380 = field_483;
      field_378 = field_484;
      method_817(var0, var1, var3, field_376);
      field_379 = field_483;
      field_377 = field_484;
      if (field_378 < 0 || field_377 < 0) {
         method_413(true);
      }
   }

   // $VF: renamed from: a (int, boolean, boolean) int
   public static final int method_847(int var0, boolean var1, boolean var2) {
      method_919(var0);
      int var3 = field_600 + field_601;
      int var4 = 0;
      int var5 = 4;

      while (--var5 >= 0) {
         if (var5 >= var3 && (!var1 || var5 < 3) && (!var2 || var5 < 2)) {
            var4 += var5 + 1;
         }
      }

      return !var1 && !var2 ? var4 : var4 * 3;
   }

   // $VF: renamed from: h (int, int, int, int) int
   public static final int method_848(int var0, int var1, int var2, int var3) {
      int var4 = 0;

      while (true) {
         method_817(var0, var1, var2, var3);
         if (field_484 == -1) {
            return var4;
         }

         var4++;
         var1 = field_483;
         var3 = field_484;
      }
   }

   // $VF: renamed from: bK () void
   public static final void method_849() {
      method_1489();
      int var0;
      method_1008(-(var0 = method_851(field_416, field_372, field_373, field_374, field_376)));
      field_440 += var0;
      if (method_844(field_373)) {
         field_399[field_416][field_372] = (byte)field_382;
         method_1208(true);
      } else {
         if (field_372 == 5 || field_372 == 6) {
            byte var1 = field_396[field_416][field_372];
            if (field_373 != var1 || field_374 < 0) {
               byte var2 = field_416;
               if (field_372 == 5) {
                  method_902(var2, var1, false);
                  method_902(var2, field_373, true);
               } else {
                  method_903(var2, var1, false);
                  method_903(var2, field_373, true);
               }
            }
         }

         method_822(field_416, field_372, field_376);
         int var3 = field_401[field_416][field_372];
         int var4 = field_402[field_416][field_372];
         method_1216(var3, var4);
         method_1072(field_600, field_601);
         method_479(5, -1, 100, false);
      }
   }

   // $VF: renamed from: bL () void
   public static final void method_850() {
      method_573(field_449, field_450, field_451, 7, method_851(field_416, field_372, field_373, field_374, method_844(field_373) ? field_382 : field_376));
   }

   // $VF: renamed from: a (byte, int, byte, int, int) int
   public static final int method_851(byte var0, int var1, byte var2, int var3, int var4) {
      if (method_844(var2)) {
         byte var12 = var3 < 0 ? -1 : field_399[var0][var1];
         short var13 = 0;
         if (var12 >= 0) {
            var13 = method_806(method_852(var2, var12));
         }

         return method_806(method_852(var2, (byte)var4)) - var13 * 33 / 100;
      } else {
         byte var5 = field_396[var0][var1];
         int var6 = 0;
         int var7 = var3 < 0 ? -1 : method_812(var5, var3);
         int var8 = method_812(var2, var4);
         int var9 = 5;

         while (--var9 >= 0) {
            byte var10;
            if (var8 + var9 < field_366 && (var10 = field_371[var8 + var9]) >= 0 && (var5 != var2 || !method_829(var7, var10))) {
               short var11 = method_806(var10);
               var6 += var11;
            }
         }

         if (var7 >= 0) {
            var9 = 5;

            while (--var9 >= 0) {
               byte var15;
               if ((var15 = field_371[var7 + var9]) >= 0 && (var5 != var2 || !method_829(var8, var15))) {
                  short var16 = method_806(var15);
                  var6 -= var16 * 33 / 100;
               }
            }
         }

         return method_148(0, var6);
      }
   }

   // $VF: renamed from: a (byte, byte) int
   public static final int method_852(byte var0, byte var1) {
      return method_853(var0) + var1;
   }

   // $VF: renamed from: a (byte) byte
   public static final byte method_853(byte var0) {
      return (byte)(var0 == 9 ? 44 : 35);
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int, boolean) void
   public static final void method_854(Graphics var0, int var1, int var2, boolean var3) {
      int var4 = (var1 >> 1) + (var3 ? 9 : 0);
      int var5 = (var2 >> 1) + (var3 ? 12 : 0);
      int var6 = method_812(field_226, field_225);
      int var7 = method_812(field_226, 0);
      method_863(var0, var4, var5, false, false, field_225, var6, var7, false);
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int, boolean, byte) void
   public static final void method_855(Graphics var0, int var1, int var2, boolean var3, byte var4) {
      int var5 = var3 ? 138 + var4 : 147 + var4;
      int var6 = var3 ? 35 + var4 : 44 + var4;
      method_856(var0, var1, var2, var5, var6);
   }

   // $VF: renamed from: p (javax.microedition.lcdui.Graphics, int, int, int, int) void
   private static final void method_856(Graphics var0, int var1, int var2, int var3, int var4) {
      int var5 = field_367[var4 << 2];
      int var6 = field_367[(var4 << 2) + 1];
      int var7 = var1 >> 1;
      method_1528(var0, var3, 0, var7, var5, var6, var2, true);
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, boolean, boolean, int, boolean, boolean, int, int, int, boolean, boolean) void
   public static final void method_857(
      Graphics var0, boolean var1, boolean var2, int var3, boolean var4, boolean var5, int var6, int var7, int var8, boolean var9, boolean var10
   ) {
      int var11 = method_833(var6);
      method_832(var6, var11, var2);
      int var12 = field_483;
      int var13 = field_484;
      method_1270(var1, var12, var2);
      var7 += field_600;
      var8 += field_601;
      if (!var1) {
         int var14 = var6 < 11 ? 162 : var12;
         var7 -= method_181(var14) >> 1;
         var8 -= method_182(var14) >> 1;
      }

      if (!var1 && var12 != 159 && var12 != 157) {
         int var28 = var6 << 2;
         int var15 = field_367[var28];
         int var16 = field_367[var28 + 1];
         int var17 = field_367[var28 + 2];
         int var18 = field_367[var28 + 3];
         method_1298(var12, var17, var18, var15, var16, 0, field_52 - 1, 0, field_53 - 1, false);
         int var19 = 0;
         int var20 = 0;
         int var21 = var18 - var17;
         int var22 = var16 - var15;
         int var23 = method_149(field_52 * 60 / 100, 120);
         int var24 = method_149(field_53 * 60 / 100, 120);
         byte var25 = 3;
         if (var6 == 20) {
            var25 = 32;
         } else if (var6 != 21 && var6 != 22) {
            if (var6 == 23) {
               var25 = 4;
            } else if (var6 >= 24 && var6 <= 26) {
               var25 = 20;
            } else if (var6 < 0 || var6 > 3) {
               if (var6 >= 4 && var6 <= 5) {
                  var25 = 40;
               } else if (var6 >= 6 && var6 <= 8) {
                  var25 = 32;
               } else if (var6 == 9) {
                  var25 = 20;
               } else if (var6 == 10) {
                  var25 = 36;
               }
            }
         }

         if ((var25 & 4) != 0) {
            var19 = -method_148(0, (var23 >> 1) - (var21 >> 1));
         } else if ((var25 & 8) != 0) {
            var19 = method_148(0, (var23 >> 1) - (var21 >> 1));
         }

         if ((var25 & 16) != 0) {
            var20 = -method_148(0, (var24 >> 1) - (var22 >> 1));
         } else if ((var25 & 32) != 0) {
            var20 = method_148(0, (var24 >> 1) - (var22 >> 1));
         }

         var7 = field_600 + var19;
         var8 = field_601 + var20;
      }

      if (var10) {
         if (method_1293()) {
            var7 += 17;
         } else {
            var8 -= 4;
         }
      }

      int var29 = var7;
      int var30 = var8;
      method_920(var6);
      if (!var9) {
         var29 = var7 + field_600;
         var30 = var8 + field_601;
      }

      int var31 = method_579(var29, var7, var3, 400);
      int var32 = method_579(var30, var8, var3, 400);
      if (var4 && var5 && var3 > 400 && var3 < 500) {
         var32 += method_147(field_601);
         method_413(true);
      }

      method_200(var0, var12, var31, var32, var13);
      if (var3 <= 400) {
         method_413(true);
      }
   }

   // $VF: renamed from: i (javax.microedition.lcdui.Graphics, int, int, int) void
   private static void method_858(Graphics var0, int var1, int var2, int var3) {
      method_455(var1 + var2);
      int var4 = var3;

      while (--var4 >= 0) {
         int var5 = var1 - 24 + method_456() % 48;
         int var6 = var2 - 6 + method_456() % 12;
         method_200(var0, 156, var5, var6, method_456() % 15);
      }
   }

   // $VF: renamed from: R () boolean
   public static boolean method_859() {
      int var0 = method_567(field_216, 5);
      int var1 = method_567(field_217, 8);
      if (var0 < 0 && var1 < 0) {
         return false;
      } else if (var0 == -1 || var1 != -1 && var0 >= var1) {
         if (var1 == -1 || var0 != -1 && var1 > var0) {
            return false;
         } else {
            method_550(var1);
            field_228 = (byte)var1;
            return true;
         }
      } else {
         method_549(var0);
         field_227 = (byte)var0;
         return true;
      }
   }

   // $VF: renamed from: aE (int) void
   public static final void method_860(int var0) {
      int var1 = field_465 - field_317[var0];
      byte var2 = field_308[var0];
      method_824(field_309[var0], var2);
      int var3 = method_148(0, field_600);
      int var4 = method_148(0, field_601);
      if (var1 > 200 + 400 * (var3 + var4) / 3) {
         byte var5;
         if ((var5 = field_309[var0]) == field_416) {
            int var6 = method_683(var0, 128) ? -1 : 1;
            int var7 = field_304[var0] + var6 * 40 * 60 / 100;
            int var8 = field_305[var0] - 20;
            method_1216(var7, var8);
            method_1072(field_600, field_601);
            method_479(4, var0, 100, true);
         }

         method_898(var5, var2, false);
         method_815(var5, var2);
         method_1208(true);
         method_716(var0, (byte)22, true);
      }

      method_738(var0, true);
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int, boolean, boolean, int, byte, int, int, int, int, int, boolean) void
   public static final void method_861(
      Graphics var0, int var1, int var2, boolean var3, boolean var4, int var5, byte var6, int var7, int var8, int var9, int var10, int var11, boolean var12
   ) {
      RemasterArt.beginFixture(var0, var5, var6);
      try {
         drawOriginalFixture(var0,var1,var2,var3,var4,var5,var6,var7,var8,var9,var10,var11,var12);
      } finally {
         var0.remaster("fixtureEnd", new int[0]);
      }
   }

   private static void drawOriginalFixture(
      Graphics var0, int var1, int var2, boolean var3, boolean var4, int var5, byte var6, int var7, int var8, int var9, int var10, int var11, boolean var12
   ) {
      if (var4 && !method_814(field_416, var5)) {
         method_858(var0, var1 + var9, var2 + var10, var11);
      } else {
         method_862(var0, var1, var2, var3, var4, var6, var7, var8, var12);
      }
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int, boolean, boolean, byte, int, int, boolean) void
   public static final void method_862(Graphics var0, int var1, int var2, boolean var3, boolean var4, byte var5, int var6, int var7, boolean var8) {
      int var9 = method_812(var5, var6);
      int var10 = var7 < 0 ? -1 : method_812(var5, var7);
      method_863(var0, var1, var2, var3, var4, var6, var9, var10, var8);
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int, boolean, boolean, int, int, int, boolean) void
   public static final void method_863(Graphics var0, int var1, int var2, boolean var3, boolean var4, int var5, int var6, int var7, boolean var8) {
      int var9 = method_401() - field_619;
      boolean var10 = false;
      if (var7 >= 0) {
         int var11 = 5;

         while (--var11 >= 0) {
            byte var12;
            if ((var12 = field_371[var6 + var11]) >= 0 && !method_829(var7, var12)) {
               var10 = true;
               break;
            }
         }
      }

      int var19 = 5;

      while (--var19 >= 0) {
         byte var13;
         if ((var13 = field_371[var6 + var19]) >= 0 && (!var4 || var13 < 4 || var13 > 9)) {
            boolean var16;
            label54: {
               var16 = false;
               if (var7 >= 0) {
                  int var17 = 5;

                  byte var18;
                  do {
                     if (--var17 < 0) {
                        break label54;
                     }
                  } while ((var18 = field_371[var7 + var17]) < 0 || var18 != var13);
               }

               var16 = true;
            }

            method_857(var0, var4, var3, var9, true, var10, var13, var1, var2, var16, var8);
         }
      }
   }

   // $VF: renamed from: hF () void
   private static void method_864() {
      boolean var0;
      int var1 = (var0 = method_1293()) && field_373 == 1 ? field_53 * 10 / 100 : 0;
      int var2 = (field_52 >> 1) + 0;
      int var3 = (field_53 >> 1) + var1;
      method_861(field_51, var2, var3, false, false, field_372, field_373, field_376, field_375, 0, 0, 0, true);
      method_866(var2 + (var0 ? 8 : 0), var3);
      int var4;
      int var5;
      if (var0) {
         var4 = 17;
         var5 = field_53 - 51 >> 1;
      } else {
         var4 = (field_52 >> 1) - 51;
         var5 = method_149(field_53 * 80 / 100, field_53 - 34);
      }

      for (int var6 = 0; var6 < 3; var6++) {
         byte var7 = field_385[var6];
         if (!var0) {
            int var8 = field_386[var6] + 15;
            int var9;
            if ((var9 = field_155 - var8) < 0) {
               var7 = field_384[var6];
               method_865(var4, var5, var7);
               method_413(true);
            } else if (var9 < 2) {
               method_200(field_51, 154, var4, var5, 1 + (var7 < 0 ? 3 - var9 : var9) % 2);
               method_413(true);
            } else {
               method_865(var4, var5, var7);
            }
         } else if (var7 >= 0) {
            method_200(field_51, var0 ? 155 : 153, var4, var5, var7);
         } else {
            method_200(field_51, var0 ? 155 : 153, var4, var5, 5);
         }

         if (var0) {
            var5 += 18;
         } else {
            var4 += 34;
         }
      }

      method_867();
   }

   // $VF: renamed from: r (int, int, int) void
   private static void method_865(int var0, int var1, int var2) {
      if (var2 >= 0) {
         method_200(field_51, 153, var0, var1, var2);
      } else {
         method_200(field_51, 154, var0, var1, 0);
      }
   }

   // $VF: renamed from: o (int, int) void
   public static final void method_866(int var0, int var1) {
      String var2 = null;
      if (field_481 == 258) {
         var2 = method_133(215);
      } else if (field_481 == 257) {
         var2 = method_133(216);
      }

      if (var2 != null) {
         method_205(0, field_51, var2, var0, var1, 3);
      }
   }

   // $VF: renamed from: hG () void
   private static void method_867() {
      int var0 = method_211(1);
      if (method_1293()) {
         method_205(1, field_51, field_383, 61, field_53 - (var0 >> 1) + 0, 33);
      } else {
         method_205(1, field_51, field_383, (field_52 >> 1) + 0, (var0 << 1) + 0, 17);
      }
   }

   // $VF: renamed from: a (boolean, boolean, boolean, boolean, boolean) void
   public static final void method_868(boolean var0, boolean var1, boolean var2, boolean var3, boolean var4) {
      if (!method_1025()) {
         method_813(field_416, field_372);
         boolean var5;
         boolean var6;
         boolean var7;
         if (var7 = method_844(field_373)) {
            int var8 = method_843();
            int var9 = method_842();
            var5 = field_382 > var8;
            var6 = field_382 < var9;
         } else {
            var5 = field_377 >= 0;
            var6 = field_378 >= 0;
         }

         String var12;
         if (var7) {
            var12 = method_133(394 + method_852(field_373, (byte)field_382) - 36);
         } else {
            int var13 = (field_373 - 1) * 10 + field_376;
            var12 = method_133(353 + var13);
         }

         int var14 = var2 ? method_1275() : 0;
         long var10 = method_1373(var1, true, method_133(226), var12, true, (byte)1, var5, var6, var0, var14, field_716 ? var14 : 0, var3, !field_716);
         method_62(6192724378386649L, var14, 0);
         method_63(method_68(var10), method_69(var10), method_70(var10), method_71(var10));
         if (var7) {
            method_855(field_51, field_52, field_53, field_373 == 8, (byte)field_382);
            method_866(field_52 >> 1, field_53 >> 1);
            method_867();
            if (field_481 == 258) {
            }
         } else {
            method_864();
         }

         method_64();
         method_64();
      }
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, boolean, boolean, int, int, int, int, int) void
   public static final void method_869(Graphics var0, boolean var1, boolean var2, int var3, int var4, int var5, int var6, int var7) {
      int var8 = field_401[var3][var4];
      int var9 = field_402[var3][var4];
      if (field_396[var3][var4] == 2) {
         var8 -= field_394 * (var1 ? -1 : 1);
         var9 -= field_395;
      }

      method_861(var0, var8, var9, var1, var2, var4, field_396[field_416][var4], method_813(var3, var4), -1, var5, var6, var7, false);
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int, boolean, boolean, int, int, int, int, int) void
   public static final void method_870(Graphics var0, int var1, int var2, boolean var3, boolean var4, int var5, int var6, int var7, int var8, int var9) {
      method_861(var0, var1, var2, var3, var4, var6, field_396[field_416][var6], method_813(var5, var6), -1, var7, var8, var9, false);
   }

   // $VF: renamed from: c (javax.microedition.lcdui.Graphics, int) void
   public static final void method_871(Graphics var0, int var1) {
      method_869(var0, false, true, var1, 1, 0, 92, 10);
      method_869(var0, false, true, var1, 2, 0, 92, 10);
      method_869(var0, true, true, var1, 3, 0, 92, 10);
      method_869(var0, true, true, var1, 4, 0, 92, 10);
   }

   // $VF: renamed from: e (javax.microedition.lcdui.Graphics, int, int) void
   public static final void method_872(Graphics var0, int var1, int var2) {
      int var3 = field_401[var1][var2] - field_394;
      int var4 = field_402[var1][var2] - field_395;
      method_870(var0, var3, var4, false, true, field_416, 5, 12, 0, 10);
   }

   // $VF: renamed from: f (javax.microedition.lcdui.Graphics, int, int) void
   public static final void method_873(Graphics var0, int var1, int var2) {
      int var3 = field_401[var1][var2] + field_394;
      int var4 = field_402[var1][var2] - field_395;
      method_870(var0, var3, var4, true, true, field_416, 6, 0, 92, 10);
   }

   // $VF: renamed from: e (javax.microedition.lcdui.Graphics, int, int, int) void
   public static final void method_874(Graphics var0, int var1, int var2, int var3) {
      byte var4 = field_309[var1];
      method_870(var0, var2, var3, false, true, var4, field_308[var1], 0, 0, 5);
   }

   // $VF: renamed from: f (javax.microedition.lcdui.Graphics, int, int, int) void
   public static final void method_875(Graphics var0, int var1, int var2, int var3) {
      byte var4 = field_309[var1];
      method_870(var0, var2, var3, false, true, var4, field_308[var1], 0, 0, 5);
   }

   // $VF: renamed from: s (int, int) int
   public static final int method_876(int var0, int var1) {
      int var2 = 10;

      while (--var2 >= 0) {
         byte var3;
         if ((var3 = field_396[var1][var2]) >= 0 && method_814((byte)var1, var2)) {
            int var4 = method_813(var1, var2);
            if (method_844(var3)) {
               var4 = field_399[var1][var2];
            }

            int var5 = method_851((byte)var1, var2, var3, -128, var4);
            var0 += var5;
         }
      }

      return var0;
   }

   // $VF: renamed from: aF (int) void
   public static final void method_877(int var0) {
      if (field_465 % (var0 + 1) == 0 && !method_879(var0)) {
         method_710(var0, false);
      }
   }

   // $VF: renamed from: J (int) boolean
   public static final boolean method_878(int var0) {
      if ((field_364 == -1 || !method_779(var0)) && field_418[field_309[var0]] == 0) {
         if (!method_879(var0)) {
            method_710(var0, false);
         }

         field_423 = 1;
         return true;
      } else {
         return false;
      }
   }

   // $VF: renamed from: K (int) boolean
   public static final boolean method_879(int var0) {
      byte var1 = field_309[var0];
      int var2 = 10;

      while (--var2 >= 0) {
         if (field_396[var1][var2] != -1 && method_814(field_416, var2)) {
            byte var4 = field_397[var1][var2];
            byte var5 = field_398[var1][var2];
            int var7 = field_396[var1][var2] == 1 ? 21 : 20;
            if (method_645(var1, var4, var5) == var0) {
               method_716(var0, (byte)var7, true);
               field_308[var0] = (byte)var2;
               return true;
            }

            if (method_662(var0, var2, (byte)var7)) {
               return true;
            }
         }
      }

      return false;
   }

   // $VF: renamed from: g (int, int) boolean
   public static final boolean method_880(int var0, int var1) {
      return !method_1017(var0) ? method_1019(var0, false, method_845(field_416, (byte)var1, field_373), false, -1, -1, -1, false, false) : false;
   }

   // $VF: renamed from: g (javax.microedition.lcdui.Graphics, int, int) void
   public static final void method_881(Graphics var0, int var1, int var2) {
      int var3 = field_401[var1][var2];
      int var4 = field_402[var1][var2];
      byte var5;
      if ((var5 = field_399[var1][var2]) == -128) {
         method_858(var0, var3 + 14, var4 + field_549 * 90 / 100, 4);
      } else {
         if (var5 > 0) {
            boolean var6 = var3 > 0;
            int var7 = 147 + var5;
            method_1270(true, var7, var6);
            method_200(var0, var7, var3 + field_600, var4 + field_601, var6 ? 1 : 0);
         }
      }
   }

   // $VF: renamed from: g (javax.microedition.lcdui.Graphics, int, int, int) void
   public static final void method_882(Graphics var0, int var1, int var2, int var3) {
      byte var4 = field_416;
      byte var5 = field_308[var1];
      byte var6;
      if ((var6 = field_399[var4][var5]) == -128) {
         method_858(var0, var2, var3, 2);
      } else {
         boolean var7 = var2 > 0;
         int var8 = 138 + var6;
         method_1270(true, var8, var7);
         method_200(var0, var8, var2 + field_600, var3 + field_601, var7 ? 1 : 0);
      }
   }

   // $VF: renamed from: e (java.lang.String) void
   public static final void method_883(String var0) {
      method_868(true, true, false, true, false);
      method_1379(var0);
   }

   // $VF: renamed from: bM () void
   public static final void method_884() {
      int var0 = field_406;

      while (--var0 >= 0) {
         method_885(var0);
      }
   }

   // $VF: renamed from: aG (int) void
   public static final void method_885(int var0) {
      int var1 = 10;

      while (--var1 >= 0) {
         field_396[var0][var1] = -1;
         field_397[var0][var1] = 0;
         field_398[var0][var1] = 0;
         field_399[var0][var1] = 0;
         field_400[var0][var1] = 0;
         field_401[var0][var1] = 0;
         field_402[var0][var1] = 0;
         field_403[var0][var1] = 0;
      }
   }

   // $VF: renamed from: bN () void
   public static final void method_886() {
      if (field_274 == 2) {
         method_892(field_251);
      } else if (field_274 == 1) {
         method_893(field_251);
      } else {
         method_891();
      }
   }

   // $VF: renamed from: a (int, int, int, int, int, int, int, boolean, boolean) void
   public static final void method_887(int var0, int var1, int var2, int var3, int var4, int var5, int var6, boolean var7, boolean var8) {
      var3 = method_150(var3, 0, 8);
      var4 = method_150(var4, 0, 8);
      var5 = method_150(var5, 0, 8);
      var6 = method_150(var6, 0, 8);
      field_600 = -128;
      field_601 = -128;
      byte var9 = field_309[var0];

      for (int var10 = 0; var10 < 4; var10++) {
         for (int var11 = var1 - var10; var11 <= var1 + var10; var11++) {
            for (int var12 = var2 + var10; var12 >= var2 - var10; var12--) {
               if (var11 >= var3
                  && var11 <= var4
                  && var12 >= var5
                  && var12 <= var6
                  && !method_648(var9, var11, var12, var0, false)
                  && (!var7 || method_516(var0, var11, var12, false) == 1)) {
                  boolean var13 = true;
                  if (!var8) {
                     int var14 = 10;

                     while (--var14 >= 0) {
                        if (field_396[var9][var14] >= 0 && field_397[var9][var14] == var11 && field_398[var9][var14] == var12) {
                           var13 = false;
                           break;
                        }
                     }
                  }

                  if (var13) {
                     field_600 = var11;
                     field_601 = var12;
                     return;
                  }
               }
            }
         }
      }
   }

   // $VF: renamed from: c (int, int, int) boolean
   public static final boolean method_888(int var0, int var1, int var2) {
      return method_569(field_403[var0], var1, var2);
   }

   // $VF: renamed from: c (int, int, int, boolean) void
   public static final void method_889(int var0, int var1, int var2, boolean var3) {
      method_570(field_403[var0], var1, var2, var3, false, null, 0);
   }

   // $VF: renamed from: b (byte, int) void
   public static final void method_890(byte var0, int var1) {
      int var2 = 10;

      while (--var2 >= 0) {
         field_396[var0][var2] = -1;
      }

      method_914(var0);
      method_915(var0);
      if (field_479 == 0 || var0 != field_407) {
         method_899(var0, var1);
         method_901(var0, var1);
      }
   }

   // $VF: renamed from: bO () void
   public static final void method_891() {
      method_894(field_416);
      method_916(true);
      method_900(true, true);
      method_913(true, true);
      if (field_364 >= 2) {
         field_267 = false;
         field_268 = false;
      } else {
         field_267 = true;
         field_268 = false;
      }
   }

   // $VF: renamed from: aH (int) void
   public static final void method_892(int var0) {
      if (var0 >= 0) {
         method_894(field_309[var0]);
         if (field_364 >= 2) {
            field_267 = false;
            field_268 = false;
         } else {
            field_267 = true;
            field_268 = false;
            if (field_364 == -1) {
               method_917();
            }
         }
      }
   }

   // $VF: renamed from: aI (int) void
   public static final void method_893(int var0) {
      if (var0 >= 0) {
         byte var1 = method_735(field_332, var0);
         method_894(field_309[var0]);
         if (field_364 >= 2) {
            field_267 = false;
            field_268 = false;
            method_900(false, false);
         } else {
            if (method_1201() > 1) {
               method_916(false);
            }

            method_900(false, false);
            if (var1 < 100) {
               method_913(false, false);
            }

            field_267 = false;
            field_268 = true;
         }
      }
   }

   // $VF: renamed from: aJ (int) void
   public static final void method_894(int var0) {
      int var1 = 10;

      while (--var1 >= 0) {
         method_889(var0, var1, 1, false);
      }
   }

   // $VF: renamed from: f (int, boolean, boolean) void
   private static final void method_895(int var0, boolean var1, boolean var2) {
      byte var3 = field_416;
      byte var4 = field_396[var3][var0];
      byte var5 = field_397[var3][var0];
      byte var6 = field_398[var3][var0];
      int var7 = field_251;
      if (var1 || var7 < 0 || field_308[var7] != var0 || field_306[var7] != var5 || field_307[var7] != var6) {
         if (var1 || var7 < 0 || !method_658(var7, var5, var6)) {
            if (var4 != 1 && (!var1 || var4 < 2 || var4 > 4) || !method_657(var3, var5, var6, -1) && method_645(var3, var5, var6) < 0) {
               if (var2 || field_399[var3][var0] != -128) {
                  if (!var1 && method_844((byte)var4)) {
                     byte var8 = field_399[var3][var0];
                     if (!method_896(method_852((byte)var4, var8))) {
                        return;
                     }
                  }

                  method_889(var3, var0, 1, true);
               }
            }
         }
      }
   }

   // $VF: renamed from: ao (int) boolean
   private static final boolean method_896(int var0) {
      return var0 == 36 || var0 == 41 || var0 == 47;
   }

   // $VF: renamed from: a (int, int, byte, int, int, byte, byte, boolean) void
   private static final void method_897(int var0, int var1, byte var2, int var3, int var4, byte var5, byte var6, boolean var7) {
      field_396[var0][var1] = var2;
      field_401[var0][var1] = var3;
      field_402[var0][var1] = var4;
      field_397[var0][var1] = var5;
      field_398[var0][var1] = var6;
      field_403[var0][var1] = 0;
      field_400[var0][var1] = -1;
      method_898(var0, var1, true);
      method_889(var0, var1, 2, var7);
   }

   // $VF: renamed from: b (int, int, boolean) void
   public static final void method_898(int var0, int var1, boolean var2) {
      field_399[var0][var1] = 0;
      byte var3;
      if (var2 && (var3 = field_400[var0][var1]) >= 0) {
         method_667(var3);
      }
   }

   // $VF: renamed from: p (int, int) void
   public static final void method_899(int var0, int var1) {
      byte var2;
      if ((var2 = (byte)(1 + var1 - 0)) == 1) {
         method_897(var0, 1, var2, field_537 - field_527 * 5 / 100, field_538 + field_549 * 60 / 100, (byte)0, (byte)4, true);
         method_897(var0, 2, var2, field_539 - field_527 * 5 / 100, field_540 + field_549 * 60 / 100, (byte)0, (byte)1, true);
         method_897(var0, 3, var2, field_541 + field_527 * 5 / 100, field_542 + field_549 * 60 / 100, (byte)1, (byte)0, true);
         method_897(var0, 4, var2, field_543 + field_527 * 5 / 100, field_544 + field_549 * 60 / 100, (byte)4, (byte)0, true);
      } else if (var2 == 2) {
         method_905((byte)var0, (byte)1, (byte)6, (byte)1, true, true);
         method_905((byte)var0, (byte)1, (byte)3, (byte)2, true, true);
         method_905((byte)var0, (byte)3, (byte)1, (byte)3, false, true);
         method_905((byte)var0, (byte)6, (byte)1, (byte)4, false, true);
      } else if (var2 == 3) {
         method_904((byte)var0, (byte)0, (byte)4, (byte)3, true);
         method_904((byte)var0, (byte)6, (byte)0, (byte)2, true);
         method_904((byte)var0, (byte)6, (byte)4, (byte)4, true);
      } else {
         if (var2 == 4) {
            method_906((byte)var0, 2, 1, (byte)1, true);
            method_906((byte)var0, 2, 4, (byte)2, true);
            method_906((byte)var0, 6, 1, (byte)3, true);
            method_906((byte)var0, 6, 4, (byte)4, true);
         }
      }
   }

   // $VF: renamed from: a (boolean, boolean) void
   public static final void method_900(boolean var0, boolean var1) {
      method_895(1, var0, var1);
      method_895(2, var0, var1);
      method_895(3, var0, var1);
      method_895(4, var0, var1);
   }

   // $VF: renamed from: c (byte, int) void
   public static final void method_901(byte var0, int var1) {
      if (var1 == 0) {
         method_902(var0, (byte)2, true);
         method_903(var0, 3, true);
      } else if (var1 == 1) {
         method_907(var0, 0, 0, (byte)5);
         method_908(var0, 2, 0, (byte)6);
         method_907(var0, 7, 4, (byte)7);
         method_907(var0, 7, 6, (byte)8);
      } else if (var1 == 2) {
         method_908(var0, 0, 1, (byte)5);
         method_907(var0, 3, 0, (byte)6);
      } else {
         if (var1 == 3) {
            method_907(var0, 0, 0, (byte)5);
            method_907(var0, 0, 2, (byte)6);
            method_907(var0, 0, 7, (byte)7);
            method_907(var0, 7, 0, (byte)8);
         }
      }
   }

   // $VF: renamed from: a (byte, byte, boolean) void
   public static final void method_902(byte var0, byte var1, boolean var2) {
      if (var1 == 2) {
         method_905(var0, (byte)1, (byte)6, (byte)5, true, var2);
      } else if (var1 == 3) {
         method_904(var0, (byte)1, (byte)6, (byte)5, var2);
      } else {
         if (var1 == 4) {
            method_906(var0, 1, 6, (byte)5, var2);
         }
      }
   }

   // $VF: renamed from: a (byte, int, boolean) void
   public static final void method_903(byte var0, int var1, boolean var2) {
      if (var1 == 2) {
         boolean var7 = false;
         method_905(var0, (byte)6, (byte)1, (byte)6, false, var2);
      } else if (var1 == 3) {
         boolean var6 = false;
         method_904(var0, (byte)6, (byte)1, (byte)6, var2);
      } else if (var1 == 4) {
         boolean var5 = false;
         method_906(var0, 6, 1, (byte)6, var2);
      } else {
         if (var1 == 9) {
            byte var3 = 0;
            int var4;
            if ((var4 = method_994(field_409[var0])) == 1) {
               var3 = 1;
            } else if (var4 == 2) {
               var3 = 6;
            } else if (var4 == 3) {
               var3 = 7;
            }

            method_908(var0, 0, var3, (byte)6);
         }
      }
   }

   // $VF: renamed from: a (byte, byte, byte, byte, boolean) void
   private static void method_904(byte var0, byte var1, byte var2, byte var3, boolean var4) {
      if (var4) {
         method_1209(var1, var2);
         int var5 = field_600;
         int var6 = field_601;
         var5 += field_525 * 15 / 100;
         var6 += -(field_526 * 22 / 100);
         method_897(var0, var3, (byte)3, var5, var6, var1, var2, true);
         var1 = (byte)(var1 + 2);
         int var7 = method_672(var0, (byte)2, var1, ++var2, 1);
         field_400[var0][var3] = (byte)var7;
         field_308[var7] = var3;
      } else {
         method_909(field_372);
         var1 = (byte)(var1 + 2);
         var2++;
      }

      method_910(var0, var1, var2, var4);
   }

   // $VF: renamed from: a (byte, byte, byte, byte, boolean, boolean) void
   private static void method_905(byte var0, byte var1, byte var2, byte var3, boolean var4, boolean var5) {
      method_911(var4, var0, var1, var2, var5);
      if (var5) {
         if (var4) {
            method_1212(var1 - 1, var2);
         } else {
            method_1211(var1, var2 - 1);
         }

         int var6 = field_600 + field_394 * (var4 ? 1 : -1);
         int var7 = field_601 + field_395;
         method_897(var0, var3, (byte)2, var6, var7, var1, var2, false);
      }
   }

   // $VF: renamed from: a (byte, int, int, byte, boolean) void
   private static void method_906(byte var0, int var1, int var2, byte var3, boolean var4) {
      if (var4) {
         method_1209(var1, var2);
         int var5 = field_600 - field_525 * 30 / 100;
         int var6 = field_601 - (field_526 >> 3);
         method_897(var0, var3, (byte)4, var5, var6, (byte)var1, (byte)var2, false);
         int var7 = method_672(var0, (byte)3, var1, ++var2, 0);
         field_400[var0][var3] = (byte)var7;
         field_308[var7] = var3;
      } else {
         method_909(field_372);
         var2++;
      }

      method_912(var0, var1, var2, var4);
   }

   // $VF: renamed from: a (byte, int, int, byte) void
   private static void method_907(byte var0, int var1, int var2, byte var3) {
      method_1209(var1, var2);
      int var4 = field_600;
      int var5 = field_601;
      byte var6 = (byte)var1;
      byte var7 = (byte)(var2 + 1);
      if (method_648(var0, var6, var7, -1, false)) {
         var6 = (byte)(var1 + 1);
         var7 = (byte)var2;
      }

      method_897(var0, var3, (byte)8, var4, var5, var6, var7, false);
      int var8 = method_672(var0, (byte)20, var1, var2, 0);
      field_400[var0][var3] = (byte)var8;
      field_308[var8] = var3;
      method_647(var0, var1, var2, true, false);
   }

   // $VF: renamed from: b (byte, int, int, byte) void
   private static void method_908(byte var0, int var1, int var2, byte var3) {
      method_1209(var1, var2);
      int var4 = field_600;
      int var5 = field_601 - field_549;
      method_897(var0, var3, (byte)9, var4, var5, (byte)var1, (byte)var2, false);
   }

   // $VF: renamed from: aK (int) void
   public static final void method_909(int var0) {
      byte var1;
      if ((var1 = field_400[field_416][var0]) >= 0) {
         method_667(var1);
      }
   }

   // $VF: renamed from: a (byte, byte, byte, boolean) void
   public static final void method_910(byte var0, byte var1, byte var2, boolean var3) {
      method_647(var0, var1 - 1, var2 + 1, var3, false);
      method_647(var0, var1 - 1, var2, var3, false);
      method_647(var0, var1 - 1, var2 - 1, var3, false);
      method_647(var0, var1 - 1, var2 - 2, var3, true);
      method_647(var0, var1, var2 - 1, var3, true);
   }

   // $VF: renamed from: a (boolean, byte, byte, byte, boolean) void
   public static final void method_911(boolean var0, byte var1, byte var2, byte var3, boolean var4) {
      if (var0) {
         method_647(var1, var2 - 1, var3, var4, false);
         method_647(var1, var2 - 1, var3 + 1, var4, false);
      } else {
         method_647(var1, var2, var3 - 1, var4, false);
         method_647(var1, var2 + 1, var3 - 1, var4, false);
      }
   }

   // $VF: renamed from: a (byte, int, int, boolean) void
   public static final void method_912(byte var0, int var1, int var2, boolean var3) {
      method_647(var0, var1, var2, var3, false);
      method_647(var0, var1 - 1, var2, var3, false);
      method_647(var0, var1 + 1, var2, var3, false);
      method_647(var0, var1 + 1, var2 - 1, var3, true);
   }

   // $VF: renamed from: b (boolean, boolean) void
   public static final void method_913(boolean var0, boolean var1) {
      method_895(5, var0, var1);
      method_895(6, var0, var1);
      method_895(7, var0, var1);
      method_895(8, var0, var1);
   }

   // $VF: renamed from: a (byte) void
   public static final void method_914(byte var0) {
      method_1209(6, 8);
      method_897(var0, 0, (byte)0, field_600, field_601, (byte)6, (byte)7, false);
   }

   // $VF: renamed from: b (byte) void
   public static final void method_915(byte var0) {
      method_1209(3, 8);
      method_897(var0, 9, (byte)5, field_600, field_601 - 30, (byte)4, (byte)8, false);
      method_672(var0, (byte)6, 3, 8, 0);
      method_647(var0, 3, 8, true, false);
   }

   // $VF: renamed from: i (boolean) void
   public static final void method_916(boolean var0) {
      if (field_479 > 0) {
         method_895(0, var0, true);
      }
   }

   // $VF: renamed from: bP () void
   public static final void method_917() {
      method_895(9, false, true);
   }

   // $VF: renamed from: g (int, int, int) void
   public static final void method_918(int var0, int var1, int var2) {
      byte var3;
      int var4;
      field_604 = 15 + var0 % 3;
      var3 = 3;
      var4 = 0;
      byte var5;
      byte var6;
      label40:
      if ((var5 = field_309[var1]) == field_416 && (var6 = field_308[var1]) >= 0) {
         int var10000 = method_813(var5, var6);
         boolean var7 = false;
         switch (var10000) {
            case 0:
            case 1:
            default:
               break label40;
            case 2:
               var3 = 2;
               break label40;
            case 3:
               var3 = 1;
               break label40;
            case 4:
               var10000 = 1;
               break;
            case 5:
               var10000 = 2;
               break;
            case 6:
               var10000 = 3;
               break;
            case 7:
               var10000 = method_152(2);
               break;
            case 8:
               var4 = method_152(100) < 33 ? 1 : 0;
               break label40;
            case 9:
               var10000 = method_152(100) < 33 ? 0 : 2;
         }

         var4 = var10000;
      }

      if (var2 % (var3 * 20) == 0) {
         var6 = field_306[var1];
         byte var9 = field_307[var1];
         if (method_683(var1, 128)) {
            method_1212(var6, var9);
         } else {
            method_1211(var6, var9);
         }

         method_1216(field_600, field_601 - 6);
         method_1065(field_600, field_601, var4);
      }
   }

   // $VF: renamed from: aL (int) void
   public static final void method_919(int var0) {
      byte var1 = 0;
      byte var2 = 0;
      switch (var0) {
         case 1:
            var1 = 1;
            break;
         case 2:
            var1 = 2;
            break;
         case 3:
            var1 = 3;
            break;
         case 4:
            var2 = 1;
            break;
         case 5:
            var2 = 2;
            break;
         case 6:
            var2 = 3;
            break;
         case 7:
            var1 = 1;
            var2 = 1;
            break;
         case 8:
            var1 = 2;
            var2 = 1;
            break;
         case 9:
            var1 = 1;
            var2 = 2;
      }

      field_600 = var1;
      field_601 = var2;
   }

   // $VF: renamed from: aM (int) void
   public static final void method_920(int var0) {
      switch (var0) {
         case 0:
         case 1:
         case 2:
         case 3:
         case 13:
         case 16:
         case 17:
         case 21:
         case 22:
         case 26:
         case 29:
            field_600 = -field_52;
            field_601 = -field_53;
            return;
         case 4:
         case 5:
         case 9:
         case 15:
         case 25:
         case 30:
         case 33:
            field_600 = field_52;
            field_601 = -field_53;
            return;
         case 6:
         case 7:
         case 8:
         case 19:
         case 23:
         case 32:
            field_600 = -field_52;
            field_601 = field_53;
            return;
         case 10:
         case 11:
         case 12:
         case 14:
         case 18:
         case 20:
         case 24:
         case 27:
         case 28:
         case 31:
         case 34:
            field_600 = field_52;
            field_601 = field_53;
      }
   }

   // $VF: renamed from: b (byte) byte
   public static final byte method_921(byte var0) {
      switch (var0) {
         case 1:
            return 11;
         case 2:
            return 8;
         case 3:
            return 7;
         case 4:
            return 9;
         case 5:
         case 6:
         case 7:
         default:
            return 5;
         case 8:
         case 9:
            return 27;
      }
   }

   // $VF: renamed from: bQ () void
   public static final void method_922() {
      byte var0 = field_259;
      byte var1 = field_260;
      method_992(method_985(var0, var1, -1));
      method_936();
      int var3;
      if ((var3 = method_646(var0, var1)) >= 0) {
         method_1272(var3);
      }

      int var4 = method_994(field_300[var3]);
      method_667(var3);
      int var5;
      method_609(var5 = method_672(field_408, (byte)17, var0, var1, 0), -1, var5, 7, var0, var1);
      method_1299();
      int var6;
      method_1008(var6 = method_933(var4) >> 1);
      field_438 += var6;
      method_479(7, -1, 100, false);
   }

   // $VF: renamed from: bR () void
   public static final void method_923() {
      method_946(method_1048(4, field_712));
   }

   // $VF: renamed from: bS () void
   public static final void method_924() {
      method_475();
      int var0 = 0;
      int var1 = 4;

      while (--var1 >= 0) {
         var0 += field_433[var1];
      }

      method_573(field_446, field_447, field_448, 7, var0);
      method_573(field_449, field_450, field_451, 7, field_433[field_479]);
   }

   // $VF: renamed from: S () boolean
   public static final boolean method_925() {
      return !method_601();
   }

   // $VF: renamed from: T () boolean
   public static final boolean method_926() {
      int var0 = method_935(field_143);
      return !method_601() || var0 != field_416;
   }

   // $VF: renamed from: U () boolean
   public static final boolean method_927() {
      return (byte)method_935(field_143) != field_416;
   }

   // $VF: renamed from: bT () void
   public static final void method_928() {
      method_980((byte)method_935(field_143));
   }

   // $VF: renamed from: bU () void
   public static final void method_929() {
      field_143 = 0;
      int var0 = method_1201();

      while (--var0 >= 0) {
         if (method_935(var0) == field_416) {
            field_143 = var0;
            return;
         }
      }
   }

   // $VF: renamed from: V () boolean
   public static final boolean method_930() {
      return field_479 > 0 && field_251 < 0 && field_416 != field_408 && field_254 == 0 && method_1201() > 1;
   }

   // $VF: renamed from: bV () void
   public static final void method_931() {
      byte var0 = (byte)method_935(field_143);
      int var1 = field_251;
      if (field_251 >= field_285 && var1 <= field_288 && !method_629(var1)) {
         if (!method_711(var1, false, var0)) {
            field_344[var1] = var0;
            method_716(var1, (byte)26, true);
         }

         method_627();
      }
   }

   // $VF: renamed from: bW () void
   public static final void method_932() {
      Graphics var0 = field_51;
      method_1219(field_416 == field_408);
      method_1380(true);
      method_62(6192724378386649L, 0, 0);
      method_1344(true, false);
      method_64();
      method_62(10133451359912117L, 0, 0);
      byte var1 = (byte)method_985(field_259, field_260, -1);
      int var2;
      int var3 = (var2 = field_52 / 5) - 17 >> 1;
      int var4;
      int var5;
      int var6 = var5 = (var4 = field_53 - 17) - 12 - 6;
      int var7 = method_148(1, 1);

      for (int var8 = 0; var8 < 5; var8++) {
         for (byte var9 = 12; var9 < var5; var9 += 12) {
            method_200(var0, 91, var3 + 8, var9, 1);
         }

         method_200(var0, 91, var3 + 8, 0, 0);
         method_200(var0, 91, var3 + 8, var5, 2);
         int var11 = var6 * method_804(var1, var8) / 12;
         int var10 = var3 + 8 - 4;
         if (var11 > 0) {
            method_313(var0, field_508[var8]);
            method_315(var0, var10, var5 + 6 - var11, 6, var11);
            if (var11 == var6) {
               method_315(var0, var10 + var7, var5 + 6 - var11 - var7, 8 - (var7 << 1), 2);
            }

            method_313(var0, field_509[var8]);
            method_315(var0, var10 + 4 + 2, var5 + 6 - var11, 2, var11);
            method_315(var0, var10 + var7, var5 + 6, 8 - (var7 << 1), 2);
         }

         method_200(var0, 155, var3, var4, var8);
         var3 += var2;
      }

      method_64();
      method_1353(method_1539(), 0, true);
      method_1289(field_51);
      method_413(true);
   }

   // $VF: renamed from: E (int) int
   public static final int method_933(int var0) {
      return method_260(10, 0 + var0, 0);
   }

   // $VF: renamed from: B () int
   public static final int method_934() {
      int var0 = field_479;
      int var1 = method_601() ? (var0 == 0 ? 0 : field_414 - 1) : (var0 == 0 ? 0 : field_414);
      if (var0 > 0) {
         var1--;
      }

      return var1;
   }

   // $VF: renamed from: F (int) int
   public static final int method_935(int var0) {
      boolean var1 = !method_601();
      int var2 = field_406;

      while (--var2 >= 0) {
         if (field_410[var2] >= 0 && var2 != field_407 && (var1 || var2 != field_408)) {
            if (var0 == 0) {
               return var2;
            }

            var0--;
         }
      }

      return -1;
   }

   // $VF: renamed from: bX () void
   public static final void method_936() {
      int var0 = field_406;

      while (--var0 >= 0) {
         if (field_409[var0] >= 0) {
            field_411[var0] = method_937(var0);
         }
      }
   }

   // $VF: renamed from: i (int) java.lang.String
   public static final String method_937(int var0) {
      byte var1 = field_409[var0];
      field_186.setLength(0);
      switch (var1) {
         case 7:
         case 8:
         case 9:
         case 10:
            field_186.append(method_133(-1));
            break;
         case 11:
         case 12:
         case 13:
            field_186.append(method_133(228));
            break;
         case 14:
            field_186.append(method_133(229));
            break;
         case 15:
            field_186.append(method_133(230));
            break;
         case 16:
            field_186.append(method_133(231));
         case 17:
         default:
            break;
         case 18:
            field_186.append(method_133(232));
      }

      byte var2;
      if ((var2 = method_981(var0)) > 1) {
         field_186.append(" ");
         field_186.append(method_463(var2));
      }

      return field_186.toString();
   }

   // $VF: renamed from: c (int, int, boolean) void
   public static final void method_938(int var0, int var1, boolean var2) {
      method_61(method_1332(var0, var2));
      method_940(var1);
      method_64();
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int, int, byte) void
   public static final void method_939(Graphics var0, int var1, int var2, int var3, byte var4) {
      if (field_252 == var1) {
         boolean var5 = false;
         method_1203(var2, var3 + 11, field_525 * 120 / 100, 1, method_1241(), -1, 12);
      }

      int var7 = 92 + var4 - 7;
      method_200(var0, var7, var2, var3 + 11, 0);
      if (var4 >= 11 && var4 <= 13 && field_306[var1] == method_1000() && field_307[var1] == method_997()) {
         method_200(var0, 103, var2 - 27, var3 - 7, field_155 >> 1);
      }

      if (var4 >= 11 && var4 <= 16) {
         int var6 = method_985(Integer.MIN_VALUE, Integer.MIN_VALUE, var1);
         method_941(var2 + (field_252 == var1 ? 21 : 0), var3 + (field_252 == var1 ? -12 : -28), var6, true);
         if (field_252 == var1) {
            method_208(2, field_411[var6]);
            field_51.getTranslateX();
            method_205(2, field_51, field_411[var6], var2, var3 - 57, 3);
         }
      }
   }

   // $VF: renamed from: aN (int) void
   public static final void method_940(int var0) {
      int var1;
      if ((var1 = method_935(var0)) >= 0 && var1 != field_408) {
         method_941(14, 12, var1, false);
      }
   }

   // $VF: renamed from: d (int, int, int, boolean) void
   public static final void method_941(int var0, int var1, int var2, boolean var3) {
      Graphics var4 = field_51;
      if (var2 != -1) {
         int var5 = var0 - 9;
         int var6 = var1 - 9;
         byte var7;
         byte var8;
         byte var9;
         byte var10;
         byte var11;
         byte var12;
         byte var13;
         byte var14;
         byte var15;
         if (var3) {
            method_177(var4, 106, var5, var6);
            var7 = 2;
            var8 = 3;
            var9 = 8;
            var10 = 13;
            var11 = 18;
            var12 = 3;
            var13 = 3;
            var14 = 3;
            var15 = 3;
         } else {
            method_177(var4, 90, var5, var6);
            var7 = 4;
            var8 = 4;
            var9 = 11;
            var10 = 4;
            var11 = 11;
            var12 = 4;
            var13 = 4;
            var14 = 11;
            var15 = 11;
         }

         field_485 = method_956(var2, field_292);
         field_483 = method_956(var2, field_293);
         field_484 = method_956(var2, field_294);
         field_600 = method_956(var2, field_295);
         field_601 = method_956(var2, field_296);
         method_944(var4, var5, var6, var7, var8, var12);
         method_944(var4, var5, var6, var7, var9, var13);
         method_944(var4, var5, var6, var7, var10, var14);
         method_944(var4, var5, var6, var7, var11, var15);
         if (field_485 + field_483 + field_484 + field_600 + field_601 > 0) {
            if (var3) {
               method_177(var4, 86, var5 + 19, var6 + 2);
               return;
            }

            method_177(var4, 86, var5 + 10, var6 + 8);
         }
      }
   }

   // $VF: renamed from: q (int, int) void
   public static final void method_942(int var0, int var1) {
      if (var0 == 31) {
         method_946(var1);
      } else {
         if (var0 == 12) {
            method_1046(var1);
         }
      }
   }

   // $VF: renamed from: L (int) boolean
   public static final boolean method_943(int var0) {
      return var0 == 34;
   }

   // $VF: renamed from: e (javax.microedition.lcdui.Graphics, int, int, int, int, int) void
   private static void method_944(Graphics var0, int var1, int var2, int var3, int var4, int var5) {
      int var6;
      if ((var6 = method_945(var0)) >= 0) {
         int var7 = var1 + var4;
         int var8 = var2 + var5;
         method_315(var0, var7, var8, var3, var3);
         if (var3 > 2) {
            int var9 = method_326(var6, 221);
            method_313(var0, var9);
            method_315(var0, var7, var8, 1, 1);
            method_315(var0, var7 + var3 - 1, var8, 1, 1);
            method_315(var0, var7, var8 + var3 - 1, 1, 1);
            method_315(var0, var7 + var3 - 1, var8 + var3 - 1, 1, 1);
         }
      }
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics) int
   private static final int method_945(Graphics var0) {
      int var1 = -1;
      if (field_485 > 0) {
         var1 = (field_155 & 1) == 0 ? 0 : field_404[field_292];
         field_485--;
         method_413(true);
      } else if (field_483 > 0) {
         var1 = field_404[field_293];
         field_483--;
      } else if (field_484 > 0) {
         var1 = field_404[field_294];
         field_484--;
      } else if (field_600 > 0) {
         var1 = field_404[field_295];
         field_600--;
      } else if (field_601 > 0) {
         var1 = field_404[field_296];
         field_601--;
      }

      if (var1 >= 0) {
         method_313(var0, var1);
      }

      return var1;
   }

   // $VF: renamed from: aO (int) void
   public static final void method_946(int var0) {
      if (var0 != 0) {
         field_712 += var0;
         method_573(field_449, field_450, field_451, 7, method_933(field_712));
      }
   }

   // $VF: renamed from: e (javax.microedition.lcdui.Graphics) void
   public static final void method_947(Graphics var0) {
      method_949(var0);
      int var1;
      int var2 = -(var1 = field_479 == 1 ? 182 : (field_479 == 2 ? 228 : 272));
      int var3;
      int var4 = (var3 = -44 + (var1 >> 1)) + (var1 >> 1);
      method_308(var0);
      method_310(var0, 0, -field_599, var1, field_599 << 1);
      method_948(var0, -3, -1, -2, -1, true, 14);
      int var7;
      if ((var7 = var0.getTranslateX()) >= 0) {
         method_310(var0, -var1, -field_599, var1, field_599 << 1);
         method_948(var0, -1, -3, 0, 0, false, 14);
      }

      method_309(var0);
      method_308(var0);
      int var8 = field_479 == 1 ? 603979776 : 1140850688;
      method_279(var0, var8);
      method_277(var0, 0, -44, var2, var3, var2 + 60, var3 + 6);
      method_277(var0, 0, -44, var2 + 60, var3 + 6, 0, -12);
      method_277(var0, 0, -44, var1, var3, var1 - 60, var3 + 6);
      method_277(var0, 0, -44, var1 - 60, var3 + 6, 0, -12);
      method_277(var0, var2, var3, 0, var4, var2 + 12, var3 + 32);
      method_277(var0, 0, var4, var2 + 12, var3 + 32, 12, var4 + 32);
      method_277(var0, 12, var4 + 32, var1, var3, 0, var4);
      method_277(var0, var1 + 12, var3 + 32, 12, var4 + 32, var1, var3);
      method_310(var0, 0, -field_599, var1, field_599 << 1);
      var8 = field_479 == 1 ? 3 : (field_479 == 2 ? 4 : 5);
      method_948(var0, var8, -3, 0, 0, false, 14);
      if (var7 >= 0) {
         method_310(var0, -var1, -field_599, var1, field_599 << 1);
         var8 = field_479 == 1 ? 3 : (field_479 == 2 ? 4 : 5);
         method_948(var0, -3, var8, 0, -1, true, 14);
      }

      method_309(var0);
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int, int, int, boolean, int) void
   public static final void method_948(Graphics var0, int var1, int var2, int var3, int var4, boolean var5, int var6) {
      var3 += var1 * field_516 + var2 * field_518;
      var4 += var1 * field_519 + var2 * field_519;
      var3 += var5 ? 0 : -40;
      var4 -= 20;
      int var7 = 0;
      int var8 = 0;

      for (int var9 = 0; var9 < var6; var9++) {
         int var10 = var8 * field_521 + var7 * field_523;
         int var11 = var8 * field_522 + var7 * field_524;
         int var12 = var10 + var3;
         int var13 = var11 + var4;
         method_200(var0, 102, var12, var13, field_479 + (var5 ? 0 : 4));
         if (var5) {
            var8++;
         } else {
            var7++;
         }
      }
   }

   // $VF: renamed from: k (javax.microedition.lcdui.Graphics) void
   private static final void method_949(Graphics var0) {
      int var1 = 54 + field_479;

      int var2;
      for (int var3 = -(var2 = method_148(1 + field_609 / 90, 1 + field_610 / 54)); var3 < var2; var3++) {
         for (int var4 = -var2; var4 < var2; var4++) {
            int var5 = var3 * field_516 + var4 * field_518;
            int var6 = var3 * field_517 + var4 * field_519;
            method_177(var0, var1, var5, var6);
         }
      }
   }

   // $VF: renamed from: b (boolean) int
   public static final int method_950(boolean var0) {
      int var1 = method_953(true, var0);
      method_1278(true);
      method_413(true);
      return var1;
   }

   // $VF: renamed from: r (int, int) void
   public static final void method_951(int var0, int var1) {
      method_954(92 + field_220, field_220, var0 >> 1, 3, var1);
   }

   // $VF: renamed from: s (int, int) void
   public static final void method_952(int var0, int var1) {
      method_954(99 + field_221 - 1, 6 + field_221, var0 >> 1, 3, var1);
   }

   // $VF: renamed from: b (boolean, boolean) int
   public static final int method_953(boolean var0, boolean var1) {
      int var2 = field_479;
      method_1461(0, 3, field_479);
      int var3 = var0 ? method_1275() : 0;
      long var4 = method_1373(
         true, false, method_133(210), method_133(285 + var2), true, (byte)2, field_713, field_714, true, var3, field_716 ? var3 : 0, var1, false
      );
      method_62(6192724378386649L, var3, 0);
      method_63(method_68(var4), method_69(var4), method_70(var4), method_71(var4));
      int var6 = field_52 >> 1;
      int var7 = field_53 >> 1;
      method_954(92 + var2, var2, var6, 0, field_53);
      if (!method_560(var2)) {
         String var8 = method_133(215);
         method_66(0, var8, 3);
      } else if (method_583(var2)) {
         method_200(field_51, 75, var6 + 32, var7 + 25 + method_151(method_401() * 90 / 100, 2), 3);
      }

      method_64();
      method_64();
      return var3;
   }

   // $VF: renamed from: b (int, int, int, int, int) void
   public static final void method_954(int var0, int var1, int var2, int var3, int var4) {
      int var5 = var4 - var3;
      int var6 = var1 << 1;
      int var7 = field_405[var6];
      int var8;
      int var9 = (var8 = field_405[var6 + 1]) - var7;
      if (var1 > 0 && var1 < 4 && var9 > var5) {
         var6 = 3 + var1 << 1;
         var7 = field_405[var6];
         var8 = field_405[var6 + 1];
         int var10;
         int var11 = method_181(var10 = 96 + (var1 - 1)) * 45 / 100;

         for (int var12 = 2; var12 >= 1; var12--) {
            int var13;
            if ((var13 = var2 - var12 * 62) > var11) {
               method_1528(field_51, var10, 0, var13, var7, var8, var5, true);
            }

            if ((var13 = var2 + var12 * 62) < field_52 - var11) {
               method_1528(field_51, var10, 0, var13, var7, var8, var5, true);
            }
         }

         method_1528(field_51, var10, 0, var2, var7, var8, var5, true);
      } else {
         method_1528(field_51, var0, 0, var2, var7, var8, var5, true);
      }
   }

   // $VF: renamed from: bY () void
   public static final void method_955() {
      method_423(70);
   }

   // $VF: renamed from: t (int, int) int
   public static final int method_956(int var0, int var1) {
      return field_421[var0 * field_297 + var1];
   }

   // $VF: renamed from: t (int, int) void
   public static final void method_957(int var0, int var1) {
      field_421[var0 * field_297 + var1]++;
   }

   // $VF: renamed from: bZ () void
   public static final void method_958() {
      int var0 = field_406 * field_297;

      while (--var0 >= 0) {
         field_421[var0] = 0;
      }
   }

   // $VF: renamed from: C () int
   public static final int method_959() {
      return method_148(0, field_414 - (field_479 == 0 ? 2 : 3));
   }

   // $VF: renamed from: ca () void
   public static final void method_960() {
      method_1489();
      byte var0 = field_259;
      byte var1 = field_260;
      int var2;
      if ((var2 = method_646(var0, var1)) >= 0) {
         method_1272(var2);
         method_667(var2);
      }

      int var3 = method_672(field_408, (byte)method_993(field_712), var0, var1, 0);
      method_988(field_712, var3, -1, var0, var1);
      method_609(var3, -1, var3, 7, var0, var1);
      method_1299();
      int var4;
      method_1008(-(var4 = method_933(field_712)));
      field_440 += var4;
      boolean var5 = false;
      if (!method_1017(346)) {
         var5 = method_1019(346, false, true, false, -1, -1, -1, true, false);
      }

      if (!var5 && !method_1609(4)) {
         boolean var6 = false;
         boolean var7 = false;
         boolean var8 = false;
         int var9 = field_406;

         while (--var9 >= 0) {
            int var10 = method_994(field_409[var9]);
            if (var9 != field_407) {
               if (var10 == 1) {
                  var6 = true;
               } else if (var10 == 3) {
                  var7 = true;
               } else if (var10 == 2) {
                  var8 = true;
               }
            }
         }

         method_1596(var6 && var7 && var8, 4, true);
      }

      method_78(5, 100);
   }

   // $VF: renamed from: cb () void
   public static final void method_961() {
      method_980((byte)method_985(field_259, field_260, -1));
   }

   // $VF: renamed from: W () boolean
   public static final boolean method_962() {
      return method_965() < 0;
   }

   // $VF: renamed from: X () boolean
   public static final boolean method_963() {
      return method_966() < 0;
   }

   // $VF: renamed from: cc () void
   public static final void method_964() {
      field_481 = method_966();
      field_482 = method_133(field_481);
   }

   // $VF: renamed from: D () int
   public static final int method_965() {
      if (!method_557(field_712)) {
         return 261;
      } else {
         return field_445 < method_933(field_712) ? 256 : -1;
      }
   }

   // $VF: renamed from: E () int
   public static final int method_966() {
      if (field_479 == 0) {
         return 240;
      } else {
         int var0 = field_252;
         byte var1;
         if ((var1 = field_300[var0]) >= 11 && var1 <= 13 && method_995(var1) == 1) {
            return 240;
         } else {
            int var2 = method_985(field_259, field_260, -1);
            boolean var3 = false;

            for (int var4 = field_285; var4 < field_288; var4++) {
               if (field_299[var4] >= 0 && field_344[var4] == var2) {
                  var3 = true;
                  break;
               }
            }

            return !method_973(var2) && !var3 ? -1 : 241;
         }
      }
   }

   // $VF: renamed from: Y () boolean
   public static final boolean method_967() {
      return field_416 == field_408 && field_252 >= field_287 && field_300[field_252] == 17;
   }

   // $VF: renamed from: Z () boolean
   public static final boolean method_968() {
      byte var0;
      return field_416 == field_408 && field_252 >= field_287 ? (var0 = field_300[field_252]) >= 11 && var0 <= 16 : false;
   }

   // $VF: renamed from: aa () boolean
   public static final boolean method_969() {
      byte var0;
      return field_416 == field_408 && field_252 >= field_287 ? (var0 = field_300[field_252]) >= 11 && var0 <= 16 : false;
   }

   // $VF: renamed from: ab () boolean
   public static boolean method_970() {
      return field_361;
   }

   // $VF: renamed from: cd () void
   public static final void method_971() {
      method_573(field_449, field_450, field_451, 7, method_933(field_712));
   }

   // $VF: renamed from: d (int, byte) void
   public static final void method_972(int var0, byte var1) {
      byte var2 = field_309[var0];
      field_309[var0] = var1;
      if (var0 < field_280) {
         if (var2 >= 0 && !method_977(var2)) {
            method_974(var2, false);
         }

         if (var1 >= 0) {
            method_974(var1, true);
         }
      }
   }

   // $VF: renamed from: M (int) boolean
   public static final boolean method_973(int var0) {
      return (field_417 & 1 << var0) != 0;
   }

   // $VF: renamed from: f (int, boolean) void
   public static final void method_974(int var0, boolean var1) {
      if (var1) {
         field_417 |= 1 << var0;
      } else {
         field_417 &= ~(1 << var0);
      }
   }

   // $VF: renamed from: G (int) int
   public static final int method_975(int var0) {
      int var1 = field_280;

      while (--var1 >= 0) {
         if (field_299[var1] >= 0 && field_309[var1] == var0) {
            return var1;
         }
      }

      return -1;
   }

   // $VF: renamed from: H (int) int
   public static final int method_976(int var0) {
      for (int var1 = field_286; var1 <= field_289; var1++) {
         if (field_299[var1] >= 0 && field_309[var1] == var0 && !method_683(var1, 1024)) {
            return var1;
         }
      }

      return -1;
   }

   // $VF: renamed from: N (int) boolean
   public static final boolean method_977(int var0) {
      return method_975(var0) >= 0;
   }

   // $VF: renamed from: g (int, boolean) void
   public static final void method_978(int var0, boolean var1) {
      if (var1) {
         field_419 |= 1 << var0;
      } else {
         field_419 &= ~(1 << var0);
      }
   }

   // $VF: renamed from: O (int) boolean
   public static final boolean method_979(int var0) {
      return (field_420 & 1 << var0) != 0;
   }

   // $VF: renamed from: c (byte) void
   public static final void method_980(byte var0) {
      if (field_479 > 0 && field_416 != var0) {
         field_415 = field_416;
         field_416 = var0;
         if (!method_1122()) {
            field_615 = true;
         }

         method_1208(true);
         method_1076();
      }
   }

   // $VF: renamed from: a (int) byte
   public static final byte method_981(int var0) {
      byte var1 = field_409[var0];
      byte var2 = 0;
      int var3 = field_406;

      while (--var3 >= 0) {
         if (field_409[var3] == var1) {
            var2++;
         }

         if (var3 == var0) {
            break;
         }
      }

      return var2;
   }

   // $VF: renamed from: ce () void
   public static final void method_982() {
      method_988(-128, 127, 18, -128, -128);
      if (field_479 == 0) {
         int var4 = method_672(field_408, (byte)(7 + field_479), 2, 2, 0);
         int var5 = method_988(0, var4, -1, 2, 2);
         if (method_1014()) {
            byte var2;
            method_822(var2 = (byte)var5, 1, 1);
            method_822(var2, 2, 1);
            method_822(var2, 3, 3);
            method_822(var2, 4, 6);
            method_822(var2, 5, 7);
            method_822(var2, 6, 2);
         }
      } else {
         int var0 = method_672(field_408, (byte)(7 + field_479), -1, 2, 0);
         method_988(-1, var0, -1, -1, 2);
         var0 = method_672(field_408, (byte)method_993(0), method_1000(), method_997(), 0);
         int var1 = method_988(0, var0, -1, method_1000(), method_997());
         if (field_479 == 3 && field_466 == 0) {
            method_815(var1, 1);
            method_815(var1, 2);
            method_815(var1, 3);
            method_815(var1, 4);
            method_815(var1, 5);
            if (field_479 == 3) {
               method_983(method_1000(), method_998());
               method_983(method_1000(), method_999());
            }
         }

         method_984();
      }
   }

   // $VF: renamed from: O (int, int) void
   private static void method_983(int var0, int var1) {
      int var2 = method_672(field_408, (byte)method_993(0), var0, var1, 0);
      int var3;
      method_815(var3 = method_988(0, var2, -1, var0, var1), 1);
      method_815(var3, 2);
      method_815(var3, 3);
      method_815(var3, 4);
      method_815(var3, 5);
      method_815(var3, 6);
   }

   // $VF: renamed from: cf () void
   public static final void method_984() {
      if (field_479 == 1) {
         method_986(method_1000(), method_997());
         method_986(method_1000(), method_998());
      } else if (field_479 == 2) {
         method_986(method_1000(), method_997());
         method_986(method_1000(), method_998());
         method_986(method_1001(), method_997());
         method_986(method_1001(), method_998());
      } else {
         if (field_479 == 3) {
            method_986(method_1000(), method_997());
            method_986(method_1000(), method_998());
            method_986(method_1000(), method_999());
            method_986(method_1001(), method_997());
            method_986(method_1001(), method_998());
            method_986(method_1001(), method_999());
         }
      }
   }

   // $VF: renamed from: g (int, int, int) int
   public static final int method_985(int var0, int var1, int var2) {
      int var3 = field_406;

      while (--var3 >= 0) {
         if (field_409[var3] >= 0
            && (var0 == Integer.MIN_VALUE || field_412[var3] == var0)
            && (var1 == Integer.MIN_VALUE || field_413[var3] == var1)
            && (var2 < 0 || field_410[var3] == var2)) {
            return var3;
         }
      }

      return -1;
   }

   // $VF: renamed from: A (int, int) int
   private static int method_986(int var0, int var1) {
      return method_985(var0, var1, -1) < 0 ? method_672(field_408, (byte)17, var0, var1, 0) : -1;
   }

   // $VF: renamed from: cg () void
   public static final void method_987() {
      if (field_479 != 0) {
         field_416 = field_408;
         field_415 = field_408;
      } else {
         field_416 = field_407;
         field_415 = field_407;
      }
   }

   // $VF: renamed from: a (int, int, int, int, int) int
   public static final int method_988(int var0, int var1, int var2, int var3, int var4) {
      byte var5;
      if ((var5 = (byte)method_991()) >= 0) {
         byte var6 = var2 >= 0 ? (byte)var2 : field_300[var1];
         field_409[var5] = var6;
         field_410[var5] = (byte)var1;
         field_411[var5] = null;
         field_412[var5] = (byte)var3;
         field_413[var5] = (byte)var4;
         field_418[var5] = 100;
         field_414++;
         method_936();
         boolean var7 = false;
         if (field_479 == 0) {
            if (var6 >= 7 && var6 <= 10) {
               var7 = true;
            }
         } else if (var6 >= 11 && var6 <= 16) {
            var7 = true;
         }

         if (var7) {
            method_890(var5, var0);
            method_671(var5, 0, 0);
         }

         return var5;
      } else {
         return -1;
      }
   }

   // $VF: renamed from: ch () void
   public static final void method_989() {
      int var0 = field_406;

      while (--var0 >= 0) {
         method_990(var0);
      }

      field_414 = 0;
      field_416 = field_479 == 0 ? field_407 : field_408;
      field_415 = field_416;
      field_417 = 0;
   }

   // $VF: renamed from: bw (int) void
   private static void method_990(int var0) {
      field_409[var0] = -1;
      field_410[var0] = -1;
      field_411[var0] = null;
      field_412[var0] = -1;
      field_413[var0] = -1;
      field_418[var0] = -1;
   }

   // $VF: renamed from: F () int
   public static final int method_991() {
      int var0 = field_406;

      while (--var0 >= 0) {
         if (field_410[var0] < 0) {
            return var0;
         }
      }

      return -1;
   }

   // $VF: renamed from: aP (int) void
   public static final void method_992(int var0) {
      method_640(var0);
      method_885(var0);
      int var1 = field_284;

      while (--var1 >= 0) {
         if (field_299[var1] >= 0 && field_309[var1] == var0) {
            method_667(var1);
         }
      }

      method_990(var0);
      field_414--;
   }

   // $VF: renamed from: I (int) int
   public static final int method_993(int var0) {
      return var0 == 0 ? 11 + (field_479 - 1) : 14 + (var0 - 1);
   }

   // $VF: renamed from: J (int) int
   public static final int method_994(int var0) {
      switch (var0) {
         case 7:
         case 8:
         case 9:
         case 10:
            return 0;
         case 11:
         case 12:
         case 13:
            return 0;
         case 14:
            return 1;
         case 15:
            return 2;
         case 16:
            return 3;
         default:
            return -1;
      }
   }

   // $VF: renamed from: K (int) int
   public static final int method_995(int var0) {
      int var1 = 0;

      for (int var2 = 0; var2 < field_406; var2++) {
         if (field_409[var2] == var0) {
            var1++;
         }
      }

      return var1;
   }

   // $VF: renamed from: L (int) int
   public static final int method_996(int var0) {
      int var1 = 0;
      int var2 = field_280;

      while (--var2 >= 0) {
         if (field_299[var2] >= 0 && field_309[var2] == var0) {
            var1++;
         }
      }

      return var1;
   }

   // $VF: renamed from: G () int
   public static int method_997() {
      return 0;
   }

   // $VF: renamed from: H () int
   public static int method_998() {
      int var0 = 3;
      if (field_479 == 2) {
         var0++;
      }

      return var0;
   }

   // $VF: renamed from: I () int
   public static int method_999() {
      return 6;
   }

   // $VF: renamed from: J () int
   public static int method_1000() {
      return field_479 == 2 ? 2 : 3;
   }

   // $VF: renamed from: K () int
   public static int method_1001() {
      return field_479 == 2 ? 5 : 6;
   }

   // $VF: renamed from: ci () void
   public static final void method_1002() {
      method_1003(method_1048(method_1534(), field_429));
   }

   // $VF: renamed from: aQ (int) void
   public static final void method_1003(int var0) {
      if (var0 != 0) {
         field_429 = (byte)(field_429 + var0);
      }
   }

   // $VF: renamed from: u (int, int) int
   public static final int method_1004(int var0, int var1) {
      int var2 = 100 * var1 / var0;
      int var3 = 5;

      while (--var3 >= 0) {
         if (var2 > field_667[var3]) {
            return var3;
         }
      }

      return 0;
   }

   // $VF: renamed from: cj () void
   public static final void method_1005() {
      field_446 = new byte[7];
      field_447 = new byte[7];
      field_448 = new int[7];
      field_449 = new byte[7];
      field_450 = new byte[7];
      field_451 = new int[7];
   }

   // $VF: renamed from: ck () void
   public static final void method_1006() {
      for (int var0 = 4; --var0 >= 0; field_434[var0] = 0) {
         field_433[var0] = 0;
      }

      method_1009(0, 0);
      method_1009(1, 0);
   }

   // $VF: renamed from: L () int
   public static final int method_1007() {
      int var0 = 0;
      int var1 = 4;

      while (--var1 >= 0) {
         var0 += field_434[var1] + field_433[var1];
      }

      return var0;
   }

   // $VF: renamed from: aR (int) void
   public static final void method_1008(int var0) {
      method_1009(0, field_445 + var0);
   }

   // $VF: renamed from: u (int, int) void
   public static final void method_1009(int var0, int var1) {
      var1 = method_150(var1, 0, 9999999);
      if (var0 == 0) {
         field_445 = var1;
         field_433[field_479] = var1;
         method_573(field_446, field_447, field_448, 7, var1);
      } else {
         method_573(field_449, field_450, field_451, 7, var1);
      }
   }

   // $VF: renamed from: M () int
   public static final int method_1010() {
      int var0 = method_1011(field_358);
      if (field_358 == 1) {
         var0 += 200;
      } else if (field_358 == 2) {
         var0 += 400;
      }

      return var0;
   }

   // $VF: renamed from: aa (int) int
   private static int method_1011(int var0) {
      int var1 = 0;
      int var2 = 4;

      while (--var2 >= 0) {
         byte var3;
         if ((var3 = method_763(var0, var2)) >= 0) {
            var1 += method_260(13, field_329[var3], 2);
         }
      }

      return var1;
   }

   // $VF: renamed from: N () int
   public static final int method_1012() {
      int var0 = 0;
      int var1 = field_406;

      while (--var1 >= 0) {
         byte var2;
         byte var3;
         if ((var2 = field_409[var1]) >= 0 && (var3 = (byte)method_994(var2)) >= 0) {
            var0 = method_876(var0 + method_933(var3), var1);
         }
      }

      return var0;
   }

   // $VF: renamed from: cl () void
   public static final void method_1013() {
      field_461 = 0;
      field_462 = 0;
      field_463 = false;
   }

   // $VF: renamed from: ac () boolean
   public static final boolean method_1014() {
      return !method_1187() || method_488();
   }

   // $VF: renamed from: ad () boolean
   public static boolean method_1015() {
      return field_463;
   }

   // $VF: renamed from: ae () boolean
   public static final boolean method_1016() {
      int var0 = 5;

      while (--var0 >= 0) {
         if (method_880(337 + var0, 0 + var0)) {
            return true;
         }
      }

      return false;
   }

   // $VF: renamed from: P (int) boolean
   public static final boolean method_1017(int var0) {
      var0 -= 321;
      return (field_461 & 1 << var0) != 0;
   }

   // $VF: renamed from: h (int, boolean) void
   public static final void method_1018(int var0, boolean var1) {
      var0 -= 321;
      if (var1) {
         field_461 |= 1 << var0;
      } else {
         field_461 &= ~(1 << var0);
      }
   }

   // $VF: renamed from: a (int, boolean, boolean, boolean, int, int, int, boolean, boolean) boolean
   public static final boolean method_1019(int var0, boolean var1, boolean var2, boolean var3, int var4, int var5, int var6, boolean var7, boolean var8) {
      if (field_364 <= -1) {
         if (var1) {
            method_1018(var0, true);
         } else if (var2 && field_471 == -1) {
            method_1018(var0, true);
            field_474 = var4;
            method_1060(var0, var3, var5, var6, var7, var8);
            return true;
         }

         return false;
      } else {
         return false;
      }
   }

   // $VF: renamed from: Q (int) boolean
   public static final boolean method_1020(int var0) {
      boolean var1 = method_1021(var0);
      method_1022(var0);
      return !var1;
   }

   // $VF: renamed from: R (int) boolean
   public static final boolean method_1021(int var0) {
      return (field_462 & var0) != 0;
   }

   // $VF: renamed from: aS (int) void
   public static final void method_1022(int var0) {
      if (!method_488()) {
         field_462 = (byte)(field_462 | var0);
      }
   }

   // $VF: renamed from: cm () void
   public static final void method_1023() {
      field_406 = 8;
      field_280 = 24;
      field_407 = (byte)(field_406 - 2);
      field_408 = (byte)(field_406 - 1);
      field_281 = field_406;
      field_282 = (field_406 - 1) * 6 + field_406 + 1;
      field_283 = field_280 + field_281;
      field_284 = field_283 + field_282;
      field_285 = 0;
      field_286 = field_280;
      field_287 = field_283;
      field_288 = field_286 - 1;
      field_289 = field_287 - 1;
      field_290 = field_289;
      field_291 = field_284 - 1;
      field_409 = new byte[field_406];
      field_410 = new byte[field_406];
      field_411 = new String[field_406];
      field_412 = new byte[field_406];
      field_413 = new byte[field_406];
      field_418 = new byte[field_406];
      field_421 = new byte[field_406 * field_297];
      field_396 = new byte[field_406][10];
      field_397 = new byte[field_406][10];
      field_398 = new byte[field_406][10];
      field_399 = new byte[field_406][10];
      field_400 = new byte[field_406][10];
      field_401 = new int[field_406][10];
      field_402 = new int[field_406][10];
      field_403 = new int[field_406][10];
      field_298 = new byte[field_406][81];
      field_299 = new int[field_284];
      field_300 = new byte[field_284];
      field_301 = new byte[field_284];
      field_302 = new int[field_284];
      field_303 = new int[field_284];
      field_304 = new int[field_284];
      field_305 = new int[field_284];
      field_306 = new byte[field_284];
      field_307 = new byte[field_284];
      field_308 = new byte[field_284];
      field_309 = new byte[field_284];
      field_310 = new int[field_283];
      field_311 = new int[field_283];
      field_312 = new int[field_283];
      field_313 = new int[field_283];
      field_314 = new byte[field_283];
      field_315 = new byte[field_283];
      field_316 = new byte[field_283];
      field_317 = new int[field_283];
      field_318 = new int[field_283];
      field_319 = new int[field_283];
      field_320 = new int[field_283];
      field_321 = new int[field_283];
      field_322 = new byte[field_283];
      field_323 = new byte[field_283][16];
      field_324 = new byte[field_283][16];
      field_325 = new int[field_283];
      field_326 = new int[field_283];
      field_327 = new int[field_283];
      field_328 = new byte[field_283];
      field_329 = new byte[field_280];
      field_330 = new byte[field_280];
      field_331 = new int[field_280];
      field_332 = new int[field_280];
      field_333 = new int[field_280];
      field_334 = new byte[field_280];
      field_335 = new byte[field_280];
      field_336 = new byte[field_280];
      field_337 = new byte[field_280];
      field_338 = new byte[field_280];
      field_339 = new byte[field_280];
      field_340 = new byte[field_280];
      field_341 = new byte[field_280];
      field_342 = new byte[field_280];
      field_343 = new int[field_280];
      field_344 = new byte[field_280];
      field_345 = new byte[field_280];
      method_1005();
      method_1094();
      method_608();
      field_478 = new byte[4];
      field_468 = new int[80];
   }

   // $VF: renamed from: cn () void
   public static final void method_1024() {
      for (int var0 = 0; var0 < 80; var0++) {
         field_468[var0] = method_260(11, 0 + var0, 0) << 1 | 1;
      }
   }

   // $VF: renamed from: af () boolean
   public static final boolean method_1025() {
      return field_487 == field_155;
   }

   // $VF: renamed from: co () void
   public static final void method_1026() {
      field_146 = field_146 + method_1048(method_1128(), field_146);
   }

   // $VF: renamed from: v (int, int) int
   public static final int method_1027(int var0, int var1) {
      return field_468[var0 * 20 + var1] >> 1;
   }

   // $VF: renamed from: M (int) int
   public static final int method_1028(int var0) {
      return method_260(11, 80 + var0, 0);
   }

   // $VF: renamed from: h (int, int) boolean
   public static final boolean method_1029(int var0, int var1) {
      return (field_468[var0 * 20 + var1] & 1) == 0;
   }

   // $VF: renamed from: v (int, int) void
   public static final void method_1030(int var0, int var1) {
      field_727 = -1;
      field_728 = -1;
      boolean var2 = false;
      int var3 = var1 << 1;

      for (int var4 = 19; var4 >= 0; var4--) {
         int var5;
         if ((var5 = var4 == 0 ? var3 + 1 : field_468[var0 * 20 + var4 - 1]) < var3) {
            field_468[var0 * 20 + var4] = var5;
            var2 = true;
         } else if (var2) {
            field_468[var0 * 20 + var4] = var3;
            field_727 = var4 + 1;
            field_728 = var0;
            return;
         }
      }
   }

   // $VF: renamed from: cp () void
   public static final void method_1031() {
      if (field_251 >= 0) {
         method_619(field_251, field_251);
         method_628();
      } else {
         method_627();
      }

      method_1299();
      method_479(26, -1, 100, true);
   }

   // $VF: renamed from: cq () void
   public static final void method_1032() {
      if (field_251 >= 0) {
         method_619(field_251, field_251);
      }

      method_627();
      method_1299();
      method_479(26, -1, 100, true);
   }

   // $VF: renamed from: cr () void
   public static final void method_1033() {
      int var0 = field_252;
      if (field_252 >= 0) {
         method_664(var0, false, 5);
         method_1299();
      }
   }

   // $VF: renamed from: ag () boolean
   public static final boolean method_1034() {
      return !method_1156() && field_416 != field_408 && field_251 >= 0;
   }

   // $VF: renamed from: ah () boolean
   public static final boolean method_1035() {
      int var0 = field_252;
      byte var1;
      return field_251 >= 0 && field_251 != field_252
         ? false
         : var0 >= field_285 && var0 <= field_288 && ((var1 = field_314[var0]) == 7 || var1 == 8 || var1 == 9);
   }

   // $VF: renamed from: cs () void
   public static final void method_1036() {
      method_592(1024, field_231, 4000);
   }

   // $VF: renamed from: ct () void
   public static final void method_1037() {
      field_620 = -1;
   }

   // $VF: renamed from: cu () void
   public static final void method_1038() {
      method_1039();
   }

   // $VF: renamed from: hH () void
   private static final void method_1039() {
      if (field_465 - field_467 >= field_669) {
         if (field_491) {
            field_467 = field_465;
         } else {
            method_1044();
         }
      } else {
         method_623();
         method_620();
         method_958();
         method_684();
         method_727(field_465 % field_671);
         method_775();
         int var0;
         if ((var0 = field_465 & 63) == 8) {
            method_886();
         } else if (var0 == 16) {
            int var1 = field_406;

            while (--var1 >= 0) {
               if (field_409[var1] >= 0) {
                  method_781(var1);
               }
            }
         } else if (var0 == 24 && field_349 == 0) {
            method_1043();
            return;
         }

         field_511.method_26();
         field_465++;
         boolean var10000 = method_1017(350);
         boolean var7 = false;
         if (!var10000) {
            method_1019(350, false, method_402() > 1000, true, method_975(field_416), -1, -1, false, false);
         }

         if (!method_1017(322)) {
            method_1019(322, field_464, method_402() > 15000 && field_416 != field_408, false, -1, -1, -1, false, false);
         }

         if (!method_1017(334) && field_466 >= 1 && field_465 % 37 == 0) {
            method_1019(334, method_826(), method_402() > 3000 && field_416 != field_408, false, -1, -1, -1, false, false);
         }

         if (method_1017(334) && !method_1017(342) && field_416 != field_408 && method_402() > 2000 && field_465 % 37 == 0 && field_466 - field_369 >= 2) {
            method_1060(342, false, -1, -1, false, false);
            method_1018(342, true);
         }

         if (field_466 == 0 && !method_1017(344)) {
            method_1019(344, field_439 > 0, field_465 - field_467 > field_669 >> 1, false, -1, -1, -1, false, false);
         }

         if ((field_465 - field_467) % (field_669 >> 2) == 0) {
            boolean var3 = false;
            int var4 = field_406;

            while (--var4 >= 0) {
               int var5 = 10;

               while (--var5 >= 0) {
                  if (field_396[var4][var5] == 2) {
                     var3 = true;
                  }
               }
            }

            if (!var3) {
               method_1060(345, false, -1, -1, false, false);
            }
         }

         method_474();
         if (field_416 == field_408 && (field_465 & 127) == 0) {
            method_479(8, -1, 100, false);
         }
      }
   }

   // $VF: renamed from: cv () void
   public static final void method_1040() {
      if (!method_1117()) {
         method_958();
         field_419 = 0;
         field_420 = 0;
         method_1455();
         field_467 = field_465;
         field_443 = field_445;
         field_444 = method_1012();
         field_422 = 0;
         field_423 = 0;
         field_424 = 0;
         field_425 = 0;
         field_435 = 0;
         field_426 = 0;
         field_436 = 0;
         field_427 = 0;
         field_437 = 0;
         field_438 = 0;
         field_439 = 0;
         field_440 = 0;
         field_441 = 0;
         field_442 = 0;
         if (field_358 != -1) {
            method_764(field_358);
            field_358 = -1;
         }

         int var0;
         method_1008(-(var0 = field_444 * 15 / 100));
         field_441 += var0;

         for (int var2 = field_286; var2 <= field_289; var2++) {
            if (field_299[var2] >= 0) {
               method_665(field_309[var2], 40, 1, 1, true);
               method_651((byte)var2, field_600, field_601);
               method_716(var2, (byte)30, true);
            }
         }

         var0 = field_406;

         while (--var0 >= 0) {
            field_418[var0] = 100;
         }

         for (int var4 = field_285; var4 <= field_288; var4++) {
            if (field_299[var4] >= 0) {
               method_737(field_331, var4, -1000);
               method_682(var4, 8, false, false);
               method_682(var4, 2048, false, false);
               byte var1;
               if ((var1 = field_314[var4]) >= 20 || var1 <= 22) {
                  method_797(false, var4);
               }
            }
         }

         field_278 = -1;
      }

      field_464 = false;
      method_1018(342, false);
      method_477();
   }

   // $VF: renamed from: cw () void
   public static final void method_1041() {
      field_512 = method_401();
      method_733();
      method_772();
      method_767(4);
      field_432 = 0;
      int var0 = field_280;

      while (--var0 >= 0) {
         if (field_299[var0] >= 0) {
            if (method_683(var0, 131072)) {
               method_768(var0, 0, -1, -1);
            } else {
               method_768(var0, 1, -1, -1);
               field_432++;
            }
         }
      }

      if (field_426 > 0) {
         field_358 = 0;
         method_1009(1, field_436);
      } else if (field_432 > 0) {
         field_358 = 1;
      }

      field_429 = 0;
   }

   // $VF: renamed from: cx () void
   public static final void method_1042() {
      method_767(0);
      method_734();
      method_1008(field_436);
      int var0;
      field_277 = method_633(var0 = method_632(field_466));
      if (field_277) {
         method_1008(field_660[var0]);
         field_721++;
      }

      field_466++;
      if (!method_970()) {
         method_1622();
      }

      int var1;
      field_455 = var1 = method_1012();
      field_434[field_479] = var1;
      field_456 = field_443 + field_444;
      field_457 = field_445 + var1;
      field_458 = field_457 - field_456;
      field_459 = 100 * field_458 / field_456;
      byte var2 = method_1050(field_479);
      field_430 = method_149(field_459 * 100 / var2, 100);
      field_431 = method_1004(var2 * field_456 / 100, field_458);
      if (!method_970()) {
         method_593();
      }

      if (method_1187() && !method_970()) {
         method_551();
      }

      field_452 = field_277 ? field_660[var0] : 0;
      field_453 = field_424 * 2500;
      field_454 = field_427 * 2000;
      if (method_1187()) {
         method_1030(field_479, field_458);
      }
   }

   // $VF: renamed from: cy () void
   public static final void method_1043() {
      if (field_424 > 0 && field_425 > 0) {
         field_480 = 267;
      } else if (field_424 > 0) {
         field_480 = 265;
      } else if (field_425 > 0) {
         field_480 = 266;
      }

      method_423(75);
   }

   // $VF: renamed from: cz () void
   public static final void method_1044() {
      field_480 = 264;
      method_423(75);
   }

   // $VF: renamed from: cA () void
   public static final void method_1045() {
      field_715 = true;
   }

   // $VF: renamed from: aT (int) void
   public static final void method_1046(int var0) {
      if (var0 != 0) {
         field_479 += var0;
         method_573(field_449, field_450, field_451, 7, field_433[field_479]);
      }
   }

   // $VF: renamed from: h (int, int, int) int
   public static final int method_1047(int var0, int var1, int var2) {
      int var4;
      if ((var4 = method_160(method_231())) < 0 && var2 > var0 || var4 > 0 && var2 < var1) {
         field_486 = var4;
         method_236();
         method_237();
         if (var4 < 0 && var2 == var0 + 1 || var4 > 0 && var2 == var1 - 1) {
            method_413(true);
         }

         return var4;
      } else {
         return 0;
      }
   }

   // $VF: renamed from: w (int, int) int
   public static final int method_1048(int var0, int var1) {
      int var2;
      if ((var2 = method_1047(0, var0 - 1, var1)) != 0) {
         method_1049();
      }

      return var2;
   }

   // $VF: renamed from: cB () void
   public static final void method_1049() {
      method_479(17, -1, 100, false);
      field_619 = method_401() + 550;
      field_487 = field_155;
      field_716 = false;
      field_715 = true;
      method_1143();
      method_423(73);
   }

   // $VF: renamed from: b (int) byte
   public static final byte method_1050(int var0) {
      return field_668[method_1051(var0)];
   }

   // $VF: renamed from: N (int) int
   public static final int method_1051(int var0) {
      return var0 * 10 + field_478[var0];
   }

   // $VF: renamed from: e (int, byte) void
   public static final void method_1052(int var0, byte var1) {
      int var2 = method_1051(var0);
      field_668[var2] = var1;
   }

   // $VF: renamed from: j () java.lang.String
   public static final String method_1053() {
      if (!method_1187()) {
         return method_1117() ? method_133(249) : method_133(316);
      } else {
         String var0 = null;
         String var1 = null;
         String var2 = null;
         int var3 = -1;

         for (int var4 = 0; var4 < 4; var4++) {
            int var5 = field_663[var4];
            if (!method_557(var4) && field_479 >= field_664[var4]) {
               var3 = var5;
               break;
            }
         }

         for (int var6 = 0; var6 < 3; var6++) {
            int var7 = field_665[var6];
            if (!method_555(var6) && field_479 >= field_666[var6] && (var3 < 0 || var7 < var3)) {
               var3 = var7;
               break;
            }
         }

         if (var3 >= 0) {
            var0 = method_463(var3);
         }

         if (field_213 < field_219) {
            var1 = method_463(method_1050(field_479));
         }

         if (field_479 < 3 && !method_560(field_479 + 1)) {
            var2 = method_463(field_662[field_479 + 1]);
         }

         field_187.setLength(0);
         field_187.append(method_1117() ? method_133(249) : method_133(250));
         if (var0 != null) {
            field_187.append('|');
            field_187.append('|');
            field_187.append(method_462(251, var0, null, null, null, null, null, null, null));
         }

         if (var1 != null) {
            field_187.append('|');
            field_187.append('|');
            field_187.append(method_462(252, var1, null, null, null, null, null, null, null));
         }

         if (var2 != null) {
            field_187.append('|');
            field_187.append('|');
            field_187.append(method_462(253, var2, null, null, null, null, null, null, null));
         }

         return field_187.toString();
      }
   }

   // $VF: renamed from: k () java.lang.String
   public static final String method_1054() {
      int var0 = field_472;
      if (field_472 >= 0 && var0 != field_416) {
         field_186.setLength(0);
         field_186.append(field_411[var0]);
         field_186.append(":");
         field_186.append('|');
         field_186.append('|');
         field_186.append(method_133(field_471));
         return field_186.toString();
      } else {
         return method_133(field_471);
      }
   }

   // $VF: renamed from: i (int, boolean) void
   public static final void method_1055(int var0, boolean var1) {
      if (var1) {
         field_470 |= 1 << var0;
      } else {
         field_470 &= ~(1 << var0);
      }
   }

   // $VF: renamed from: S (int) boolean
   public static final boolean method_1056(int var0) {
      return (field_469 & 1 << var0) != 0;
   }

   // $VF: renamed from: ai () boolean
   public static final boolean method_1057() {
      return field_470 != 0;
   }

   // $VF: renamed from: aj () boolean
   public static final boolean method_1058() {
      return field_471 >= 0;
   }

   // $VF: renamed from: cC () void
   public static final void method_1059() {
      int var0 = field_471;
      method_1490();
      field_471 = -1;
      field_473 = false;
      field_477 = -1;
      field_474 = -1;
      if (field_475 >= 0) {
         if (field_476) {
            method_1008(field_460);
         }

         method_667(field_475);
         field_475 = -1;
         field_476 = false;
      }

      method_1599();
      if (!method_1017(352)) {
         method_1019(352, false, var0 == 350, true, method_975(field_416), -1, -1, false, false);
      } else {
         if (!method_1017(351)) {
            method_1019(351, false, var0 == 352, true, method_975(field_416), -1, -1, false, false);
         }
      }
   }

   // $VF: renamed from: a (int, boolean, int, int, boolean, boolean) void
   public static final void method_1060(int var0, boolean var1, int var2, int var3, boolean var4, boolean var5) {
      field_471 = var0;
      field_472 = var3;
      field_473 = var1;
      field_477 = var2;
      if (var4) {
         method_479(14, -1, 100, false);
      } else if (var5) {
         method_479(12, -1, 100, false);
      }

      method_423(76);
   }

   // $VF: renamed from: T (int) boolean
   public static final boolean method_1061(int var0) {
      field_424++;
      field_474 = var0;
      field_475 = var0;
      method_732();
      method_423(77);
      return true;
   }

   // $VF: renamed from: cD () void
   public static final void method_1062() {
      String var0;
      field_488 = (var0 = method_156("Enable-Cheats")) != null && "TRUE".equals(var0.trim());
      field_490 = -1;
   }

   // $VF: renamed from: aU (int) void
   public static final void method_1063(int var0) {
      if (field_488) {
         boolean var1 = true;
         int var2 = method_403();
         if (var0 == 37671) {
            if (var2 == 27) {
               method_1044();
            }
         } else if (var0 == 26422) {
            method_532(false);
         } else if (var0 == 17539) {
            boolean var6 = false;
            method_1008(15000);
            field_439 += 15000;
         } else {
            switch (var0) {
               case 119:
                  if (field_490 < 0) {
                     field_490 = field_252;
                  } else {
                     field_490 = -1;
                  }
                  break;
               case 134:
                  method_564();
                  break;
               case 4626:
                  method_1438();
                  method_598();
                  method_1094();
                  method_827();
                  method_1208(true);
                  break;
               case 9284:
                  int var7 = field_280;

                  while (--var7 >= 0) {
                     if (field_299[var7] >= 0) {
                        method_737(field_331, var7, -10000);
                     }
                  }
                  break;
               case 9286:
                  int var5 = field_280;

                  while (--var5 >= 0) {
                     if (field_299[var5] >= 0) {
                        method_737(field_331, var5, 10000);
                     }
                  }
                  break;
               case 12868:
                  method_737(field_331, field_490, -2500);
                  break;
               case 12902:
                  method_737(field_333, field_490, -2500);
                  break;
               case 13096:
                  method_737(field_332, field_490, -2500);
                  break;
               case 14114:
                  method_710(field_490, true);
                  field_490 = -1;
                  method_607();
                  break;
               case 16964:
                  method_737(field_331, field_490, 2500);
                  break;
               case 16998:
                  method_737(field_333, field_490, 2500);
                  break;
               case 17192:
                  method_737(field_332, field_490, 2500);
                  break;
               case 29830:
                  field_492 = -1;
                  method_564();
                  break;
               case 30579:
                  if (field_490 < field_280 && field_490 >= 0) {
                     method_736(field_331, field_490, 0);
                     method_736(field_333, field_490, 0);
                  }
                  break;
               case 30822:
                  method_532(true);
                  break;
               case 33891:
                  int var3 = field_465 - field_467;
                  int var4 = field_669 - var3;
                  field_465 = field_467 + var3 + var4 * 50 / 100;
                  break;
               case 78641:
                  field_493 = !field_493;
                  break;
               case 7566179:
                  field_491 = false;
                  break;
               case 7566182:
                  field_491 = true;
                  break;
               default:
                  var1 = false;
            }
         }

         field_489 |= var1;
      }
   }

   // $VF: renamed from: b (int, int, boolean, boolean) void
   public static final void method_1064(int var0, int var1, boolean var2, boolean var3) {
      method_1074((byte)10, var0, var1, var2 ? 1 : 0, var3 ? 1 : 0);
   }

   // $VF: renamed from: h (int, int, int) void
   public static final void method_1065(int var0, int var1, int var2) {
      if (field_500 < 0 || field_465 - field_500 > 10) {
         field_500 = field_465;
         method_1074((byte)9, var0, var1, var2, 0);
      }
   }

   // $VF: renamed from: i (int, int, int) void
   public static final void method_1066(int var0, int var1, int var2) {
      method_1074((byte)1, var0, var1, var2, 0);
   }

   // $VF: renamed from: j (int, int, int) void
   public static final void method_1067(int var0, int var1, int var2) {
      method_1074((byte)2, var0, var1, var2, 0);
   }

   // $VF: renamed from: w (int, int) void
   public static final void method_1068(int var0, int var1) {
      method_1074((byte)3, var0, var1, 0, 0);
   }

   // $VF: renamed from: x (int, int) void
   public static final void method_1069(int var0, int var1) {
      method_1074((byte)4, var0, var1, 0, 0);
   }

   // $VF: renamed from: y (int, int) void
   public static final void method_1070(int var0, int var1) {
      method_1074((byte)5, var0, var1, 0, 0);
   }

   // $VF: renamed from: z (int, int) void
   public static final void method_1071(int var0, int var1) {
      method_1074((byte)8, var0, var1, 0, 0);
   }

   // $VF: renamed from: A (int, int) void
   public static final void method_1072(int var0, int var1) {
      method_1074((byte)6, var0, var1, 0, 0);
   }

   // $VF: renamed from: k (int, int, int) void
   public static final void method_1073(int var0, int var1, int var2) {
      method_1074((byte)7, var0, var1, var2 * 5 / 100, 0);
   }

   // $VF: renamed from: a (byte, int, int, int, int) int
   public static final int method_1074(byte var0, int var1, int var2, int var3, int var4) {
      int var5 = -1;

      for (int var6 = 0; var6 < 20; var6++) {
         if (field_494[var6] == -1) {
            var5 = var6;
            break;
         }
      }

      if (var5 == -1) {
         return var5;
      } else {
         field_494[var5] = var0;
         field_496[var5] = var1;
         field_497[var5] = var2;
         field_498[var5] = var3;
         field_499[var5] = var4;
         field_495[var5] = method_1099();
         return var5;
      }
   }

   // $VF: renamed from: cE () void
   public static final void method_1075() {
      if (field_494 == null) {
         field_494 = new byte[20];
         field_495 = new int[20];
         field_496 = new int[20];
         field_497 = new int[20];
         field_498 = new int[20];
         field_499 = new int[20];
      }

      method_1076();
      field_500 = -1;
   }

   // $VF: renamed from: cF () void
   public static final void method_1076() {
      if (field_494 != null) {
         for (int var0 = 0; var0 < 20; var0++) {
            field_494[var0] = -1;
         }
      }
   }

   // $VF: renamed from: O (int) int
   public static final int method_1077(int var0) {
      switch (field_494[var0]) {
         case 1:
            return 3000;
         case 2:
            return 3000;
         case 3:
            return 2000;
         case 4:
            return 1000;
         case 5:
            return 600;
         case 6:
            return 800;
         case 7:
            return 800;
         case 8:
            return 1200;
         case 9:
            return 2000;
         case 10:
            return 500;
         default:
            return 1000;
      }
   }

   // $VF: renamed from: aV (int) void
   public static final void method_1078(int var0) {
      field_494[var0] = -1;
   }

   // $VF: renamed from: f (javax.microedition.lcdui.Graphics) void
   public static final void method_1079(Graphics var0) {
      if (field_494 != null) {
         int var1 = method_1099();

         for (int var2 = 0; var2 < 20; var2++) {
            if (field_494[var2] > 0) {
               int var3;
               if ((var3 = (var1 - field_495[var2] << 10) / method_1077(var2)) < 1024) {
                  method_1080(var0, var3, var2);
               } else {
                  method_1078(var2);
               }
            }
         }
      }
   }

   // $VF: renamed from: h (javax.microedition.lcdui.Graphics, int, int) void
   public static final void method_1080(Graphics var0, int var1, int var2) {
      if (!field_493) {
         method_1215(field_496[var2], field_497[var2]);
         switch (field_494[var2]) {
            case 1:
               method_1084(var0, field_600, field_601, var1, field_495[var2], field_498[var2]);
               return;
            case 2:
               method_1085(var0, field_600, field_601, var1, field_495[var2], field_498[var2]);
               return;
            case 3:
               method_1086(var0, field_600, field_601, var1, field_495[var2]);
               return;
            case 4:
               method_1088(var0, field_600, field_601, var1, field_495[var2]);
               return;
            case 5:
               method_1087(var0, field_600, field_601, var1, field_495[var2]);
               return;
            case 6:
               method_1089(var0, field_600, field_601, var1, field_495[var2], 30, 48, 48, 3);
               return;
            case 7:
               method_1093(var0, field_600, field_601, var1, field_495[var2], field_498[var2]);
               return;
            case 8:
               method_1089(var0, field_600, field_601, var1, field_495[var2], 31, 24, 24, 3);
               return;
            case 9:
               method_1091(var0, field_600, field_601, field_498[var2], var1);
               return;
            case 10:
               method_1092(field_600, field_601, var1, field_498[var2] == 1, field_499[var2] == 1);
         }
      }
   }

   // $VF: renamed from: i (javax.microedition.lcdui.Graphics, int, int, int, int) void
   public static final void method_1081(Graphics var0, int var1, int var2, int var3, int var4) {
      method_200(var0, 32 + var3, var1, var2, var4);
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int, int, int, int, int, int) void
   public static final void method_1082(Graphics var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      method_455(var4);

      for (int var8 = 0; var8 < 5; var8++) {
         int var9;
         if ((var9 = var3 - (var8 << 9) / 5) > 0 && var9 < 512) {
            int var10 = var2 - (var9 * 24 >> 7);
            int var11 = var1 + (((method_456() >> 4) % 24 - 12) * var9 >> 9) + (method_151((method_456() >> 3 & 511) + var9, 12) * var9 >> 9);
            if (var6 != -1 && (var8 & 1) == 0) {
               method_1081(var0, var11, var10, var6, var9 >> 4);
               method_457();
            } else {
               var5 -= 50;
               int var12 = var7;
               if ((method_456() >> 3) % 25 < var5) {
                  var12 = 1;
               }

               method_1083(var0, var11, var10, var12);
            }
         } else {
            method_457();
            method_457();
            method_457();
         }
      }
   }

   // $VF: renamed from: j (javax.microedition.lcdui.Graphics, int, int, int) void
   private static final void method_1083(Graphics var0, int var1, int var2, int var3) {
      method_200(var0, 27, var1, var2, var3);
   }

   // $VF: renamed from: b (javax.microedition.lcdui.Graphics, int, int, int, int, int) void
   public static final void method_1084(Graphics var0, int var1, int var2, int var3, int var4, int var5) {
      var1 += 12;
      var2 -= 6;
      method_1082(var0, var1, var2, var3, var4, var5, -1, 0);
   }

   // $VF: renamed from: c (javax.microedition.lcdui.Graphics, int, int, int, int, int) void
   public static final void method_1085(Graphics var0, int var1, int var2, int var3, int var4, int var5) {
      var2 -= 24;
      method_1082(var0, var1, var2, var3, var4, var5, 1, 3);
   }

   // $VF: renamed from: j (javax.microedition.lcdui.Graphics, int, int, int, int) void
   public static final void method_1086(Graphics var0, int var1, int var2, int var3, int var4) {
      method_455(var4);
      var2 -= 48;
      int var5 = var2 - 24 - method_151(var3, 6);
      var2 -= 12;
      method_1083(var0, var1, var5, 4);

      for (int var6 = 0; var6 < 5; var6++) {
         int var7;
         if ((var7 = var3 - (var6 << 8) / 5) > 0 && var7 < 768) {
            int var8 = var2 - var7 * 24 / 768 + method_151(var7 + 128, 12);
            int var10;
            int var9 = var1 + method_151((var10 = var7 + 128) + 128, 12);
            method_1081(var0, var9, var8, 2, var7 * 6 / 768);
         }
      }
   }

   // $VF: renamed from: k (javax.microedition.lcdui.Graphics, int, int, int, int) void
   public static final void method_1087(Graphics var0, int var1, int var2, int var3, int var4) {
      method_455(var4);

      for (int var5 = 0; var5 < 3; var5++) {
         int var6;
         if ((var6 = var3 - (var5 << 8) / 3) > 0 && var6 < 768) {
            int var7 = method_456() >> 3;
            int var8 = var6 * (24 + (method_456() >> 3) % 12) / 768;
            int var9 = var1 + method_151(var7 + 128, var8);
            int var10 = var2 + method_151(var7, var8);
            if ((method_456() >> 3 & 0xFF) < 180) {
               method_200(var0, 29, var9, var10, var6 >> 6);
            } else {
               method_1083(var0, var9, var10, 2);
            }
         } else {
            method_457();
            method_457();
            method_457();
         }
      }

      if (var3 < 550) {
         method_200(var0, 28, var1, var2, var3 / 200);
      }
   }

   // $VF: renamed from: l (javax.microedition.lcdui.Graphics, int, int, int, int) void
   public static final void method_1088(Graphics var0, int var1, int var2, int var3, int var4) {
      method_455(var4);
      var2 -= 60;

      for (int var5 = 0; var5 < 5; var5++) {
         int var6;
         if ((var6 = var3 - (var5 << 8) / 5) > 0 && var6 < 768) {
            int var7 = (method_456() >> 3) % 96 - 48;
            int var8 = var1 + (var7 * (var6 + 128) >> 10);
            int var9 = var2 - method_151(var6 / 3, 24) + (12 * var6 * var6 >> 19);
            method_1081(var0, var8, var9, 0, var6 >> 7);
         } else {
            method_457();
         }
      }
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int, int, int, int, int, int, int) void
   public static final void method_1089(Graphics var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      method_455(var4);
      method_1090(var0, var1, var2, var3, var5, var6, var7, var8);
   }

   // $VF: renamed from: b (javax.microedition.lcdui.Graphics, int, int, int, int, int, int, int) void
   public static final void method_1090(Graphics var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      var1 -= var5 >> 1;
      var2 -= var6 >> 1;
      int var8 = var7;

      while (--var8 >= 0) {
         int var9;
         if ((var9 = var3 - (var8 << 8) / var7) > 0 && var9 < 768) {
            int var10 = var1 + (method_456() >> 3) % var5;
            int var11 = var2 + (method_456() >> 3) % var6;
            method_200(var0, var4, var10, var11, var9 * 7 / 768);
         } else {
            method_457();
            method_457();
         }
      }
   }

   // $VF: renamed from: m (javax.microedition.lcdui.Graphics, int, int, int, int) void
   public static final void method_1091(Graphics var0, int var1, int var2, int var3, int var4) {
      if (var4 < 700) {
         boolean var11 = false;
         method_308(var0);
         method_310(var0, var1 - 13, var2 - 36, 27, 36);
         method_200(var0, 11, var1, var2 + (700 - var4) * 36 / 700, var3);
         method_309(var0);
      } else {
         int var5 = var1 + 96;
         int var6 = var2 + 96;
         var4 -= 700;
         int var7 = method_577(var1, var5, var4, 324);
         int var8 = method_577(var2, var6, var4, 324);
         int var9 = -method_151(var4 * 256 / 324, 24);
         method_200(var0, 11, var7, var8 + var9, var3);
      }
   }

   // $VF: renamed from: b (int, int, int, boolean, boolean) void
   public static final void method_1092(int var0, int var1, int var2, boolean var3, boolean var4) {
      method_1203(var0, var1, var4 ? 48 : 24, var3 ? 1 : 0, var4 ? 6750054 : 16777215, var2, 1024);
   }

   // $VF: renamed from: d (javax.microedition.lcdui.Graphics, int, int, int, int, int) void
   public static final void method_1093(Graphics var0, int var1, int var2, int var3, int var4, int var5) {
      method_455(var4);
      var2 -= 48;
      var1 -= 12;

      for (int var6 = 0; var6 < var5; var6++) {
         int var7;
         if ((var7 = var3 - (var6 << 8) / var5) > 0 && var7 < 768) {
            int var8 = var2 - var7 * 48 / 768;
            int var9 = var1 + ((method_456() >> 3) % 24 - 12) * var7 / 768 + (method_456() >> 3) % 24;
            method_1083(var0, var9, var8, 1);
         } else {
            method_457();
            method_457();
         }
      }
   }

   // $VF: renamed from: cG () void
   public static final void method_1094() {
      field_501 = new int[4];
      field_501[0] = 0;
      field_501[1] = 14273440;
      field_501[2] = 6256756;
      field_501[3] = 5268305;
      field_502 = new int[4];
      field_502[0] = 7435351;
      field_502[1] = 9145715;
      field_502[2] = 11251342;
      field_502[3] = 13290667;
      field_503 = new int[14];
      field_504 = new int[14];
      method_1095(field_503, 7703422, 8291766, 7699889, 6647464, 5792156, 5265549, 4804736, 7703422, 6850724, 6193052, 5402504, 4743543, 4018789, 3425877);
      method_1095(
         field_504, 7703422, 8032853, 9215306, 10594367, 12106045, 13682214, 14663703, 7703422, 6650436, 7701562, 8949297, 11573296, 13674022, 14653975
      );
      field_505 = new int[14];
      field_506 = new int[14];
      field_507 = new int[14];
      method_1095(field_505, 5327446, 6115685, 6969462, 7889031, 8677271, 9399717, 9990832, 7959419, 8353411, 8747659, 9601179, 10520493, 11111608, 11505600);
      method_1095(
         field_506, 8616042, 9403753, 10257512, 11832677, 13802081, 14917983, 15837790, 6048579, 7492677, 8936519, 8936519, 11824458, 12940364, 13990477
      );
      method_1095(field_507, 8094062, 8686446, 9213551, 10201967, 11388015, 12309616, 12771184, 5790532, 6975303, 8160329, 8426067, 9479768, 10335579, 10994526);
      field_508 = new int[5];
      field_508[0] = 12446297;
      field_508[1] = 13981659;
      field_508[2] = 6271971;
      field_508[3] = 16086094;
      field_508[4] = 16774003;
      field_509 = new int[5];
      field_509[0] = 8627766;
      field_509[1] = 9975452;
      field_509[2] = 3898529;
      field_509[3] = 11488046;
      field_509[4] = 13994527;
   }

   // $VF: renamed from: a (int[], int, int, int, int, int, int, int, int, int, int, int, int, int, int) void
   private static void method_1095(
      int[] var0,
      int var1,
      int var2,
      int var3,
      int var4,
      int var5,
      int var6,
      int var7,
      int var8,
      int var9,
      int var10,
      int var11,
      int var12,
      int var13,
      int var14
   ) {
      var0[0] = var1;
      var0[1] = var2;
      var0[2] = var3;
      var0[3] = var4;
      var0[4] = var5;
      var0[5] = var6;
      var0[6] = var7;
      var0[7] = var8;
      var0[8] = var9;
      var0[9] = var10;
      var0[10] = var11;
      var0[11] = var12;
      var0[12] = var13;
      var0[13] = var14;
   }

   // $VF: renamed from: ak () boolean
   public static boolean method_1096() {
      return field_513;
   }

   // $VF: renamed from: cH () void
   public static void method_1097() {
      field_513 = true;
   }

   // $VF: renamed from: cI () void
   public static void method_1098() {
      field_513 = false;
   }

   // $VF: renamed from: O () int
   public static final int method_1099() {
      return field_511.field_22;
   }

   // $VF: renamed from: cJ () void
   public static void method_1100() {
      field_350 = -1;
      field_512 = -1;
      field_358 = -1;
      method_589();
      method_982();
      method_1009(0, field_433[field_479]);
   }

   // $VF: renamed from: cK () void
   public static void method_1101() {
      method_605();
      if (field_254 >= 1 && field_254 <= 8) {
         method_830();
      }

      method_621(field_263, field_264);
      method_1208(true);
      field_275 = field_465;
      if (field_416 != field_408) {
         method_886();
         field_346 = 1;
         method_825();
      }

      method_622();
      method_1075();
   }

   // $VF: renamed from: cL () void
   public static void method_1102() {
      field_511.method_23();
      field_510 = 1;
      method_1488();
      method_236();
      method_237();
   }

   // $VF: renamed from: cM () void
   public static void method_1103() {
      method_1105();
      method_480();
   }

   // $VF: renamed from: cN () void
   public static void method_1104() {
      field_715 = true;
   }

   // $VF: renamed from: cO () void
   public static void method_1105() {
      method_1107(true);
   }

   // $VF: renamed from: cP () void
   public static void method_1106() {
      method_1107(field_477 >= 0);
   }

   // $VF: renamed from: j (boolean) void
   public static final void method_1107(boolean var0) {
      field_511.method_24();
      field_510 = 2;
      field_512 = var0 ? method_401() : -1;
   }

   // $VF: renamed from: cQ () void
   public static void method_1108() {
      field_511.method_23();
      field_510 = 1;
      method_476();
      if (field_254 >= 1 && field_254 <= 8) {
         method_830();
      }

      field_715 = true;
      field_716 = true;
      field_486 = 1;
      method_236();
      method_237();
   }

   // $VF: renamed from: cR () void
   public static void method_1109() {
      field_511.method_25();
      field_510 = 0;
   }

   // The responsive UI shows the complete message, so its action skips legacy pagination.
   public static void modernContinue(boolean left) {
      if (left && field_175 != null) {
         for (int page = 0; page < 512 && field_175.method_6() != -128; page++) field_175.method_2();
         method_436();
      }
      if (left) { if (!method_407(0)) method_407(5); }
      else { if (!method_407(1)) method_407(3); }
   }

   // $VF: renamed from: al () boolean
   public static boolean method_1110() {
      if (field_251 >= 0) {
         return false;
      } else if (field_253 != 7) {
         byte var1 = field_254;
         return field_254 >= 1 && var1 <= 8;
      } else {
         return false;
      }
   }

   // $VF: renamed from: am () boolean
   public static boolean method_1111() {
      return method_1017(321);
   }

   // $VF: renamed from: an () boolean
   public static boolean method_1112() {
      return !method_970() && !method_1017(349) && field_459 < 0;
   }

   // $VF: renamed from: ao () boolean
   public static boolean method_1113() {
      method_477();
      return method_1020(8);
   }

   // $VF: renamed from: ap () boolean
   public static boolean method_1114() {
      return field_479 == 0 && !method_583(field_479);
   }

   // $VF: renamed from: aq () boolean
   public static boolean method_1115() {
      return method_1020(2);
   }

   // $VF: renamed from: ar () boolean
   public static boolean method_1116() {
      return method_583(field_479);
   }

   // $VF: renamed from: as () boolean
   public static boolean method_1117() {
      return method_585(field_479);
   }

   // $VF: renamed from: cS () void
   public static void method_1118() {
      method_1119(field_510 != 0);
   }

   // $VF: renamed from: k (boolean) void
   public static final void method_1119(boolean var0) {
      if (field_510 != 2) {
         field_146 = 0;
         int var1 = method_403();
         if (!var0 && !method_943(var1)) {
            method_475();
         } else {
            method_476();
         }

         method_1143();
      }
   }

   // $VF: renamed from: cT () void
   public static void method_1120() {
      field_146 = 0;
      method_1488();
   }

   // $VF: renamed from: at () boolean
   public static boolean method_1121() {
      return true;
   }

   // $VF: renamed from: au () boolean
   public static boolean method_1122() {
      return false;
   }

   // $VF: renamed from: av () boolean
   public static boolean method_1123() {
      return true;
   }

   // $VF: renamed from: aw () boolean
   public static boolean method_1124() {
      return true;
   }

   // $VF: renamed from: ax () boolean
   public static boolean method_1125() {
      return method_774();
   }

   // $VF: renamed from: j (int) java.lang.String
   public static String method_1126(int var0) {
      int var1;
      return (var1 = method_935(var0)) < 0 ? "" : field_411[var1];
   }

   // $VF: renamed from: cU () void
   public static void method_1127() {
      method_931();
   }

   // $VF: renamed from: P () int
   public static int method_1128() {
      return 5;
   }

   // $VF: renamed from: ay () boolean
   public static boolean method_1129() {
      return field_473;
   }

   // $VF: renamed from: az () boolean
   public static boolean method_1130() {
      return field_432 > 0 || field_426 > 0;
   }

   // $VF: renamed from: cV () void
   public static void method_1131() {
      if (!method_1025()) {
         method_950(false);
      }
   }

   // $VF: renamed from: cW () void
   public static void method_1132() {
      field_481 = method_965();
      if (field_481 == 256) {
         field_482 = method_462(256, method_463(method_933(field_712)), null, null, null, null, null, null, null);
      } else {
         field_482 = method_133(field_481);
      }
   }

   // $VF: renamed from: cX () void
   public static void method_1133() {
      int var0 = method_402();
      field_232 = method_577(field_234, field_235, var0, field_233);
      if (var0 > field_233) {
         method_423(81);
      }
   }

   // $VF: renamed from: k (int) java.lang.String
   public static String method_1134(int var0) {
      return method_133(193 + var0);
   }

   // $VF: renamed from: l () java.lang.String
   public static String method_1135() {
      field_186.setLength(0);
      method_460(field_186, field_146 + 1, method_1128(), method_1460());
      if (field_146 > 0) {
         for (int var0 = 1; var0 <= 20; var0++) {
            boolean var1;
            if (var1 = method_1029(field_146 - 1, var0 - 1)) {
               field_186.append("{h}");
            }

            field_186.append(var0 + ": ");
            field_186.append(method_1027(field_146 - 1, var0 - 1));
            if (var1) {
               field_186.append(" *");
            }

            field_186.append("|");
         }
      } else {
         int var5 = 0;
         int var6 = method_1007();
         boolean var2 = false;

         for (int var3 = 1; var3 <= 20; var3++) {
            int var4 = method_1028(var5);
            if (var6 > var4 && !var2) {
               var2 = true;
               field_186.append("{h}");
               field_186.append(var3 + ": ");
               field_186.append(var6);
               field_186.append(" *");
               field_186.append("|");
            } else {
               field_186.append(var3 + ": ");
               field_186.append(var4);
               field_186.append("|");
               var5++;
            }
         }
      }

      return field_186.toString();
   }

   // $VF: renamed from: cY () void
   public static void method_1136() {
      method_1046(method_1048(4, field_479));
   }

   // $VF: renamed from: cZ () void
   public static void method_1137() {
      method_840();
   }

   // $VF: renamed from: aA () boolean
   public static boolean method_1138() {
      return method_630();
   }

   // $VF: renamed from: da () void
   public static void method_1139() {
      method_849();
   }

   // $VF: renamed from: db () void
   public static void method_1140() {
      method_923();
   }

   // $VF: renamed from: dc () void
   public static void method_1141() {
      method_541();
   }

   // $VF: renamed from: aW (int) void
   public static void method_1142(int var0) {
      method_1063(var0);
   }

   // $VF: renamed from: dd () void
   public static void method_1143() {
      method_1037();
   }

   // $VF: renamed from: de () void
   public static void method_1144() {
      method_964();
   }

   // $VF: renamed from: df () void
   public static void method_1145() {
      method_961();
   }

   // $VF: renamed from: m () java.lang.String
   public static String method_1146() {
      return method_1054();
   }

   // $VF: renamed from: aB () boolean
   public static boolean method_1147() {
      return field_481 < 0;
   }

   // $VF: renamed from: aC () boolean
   public static boolean method_1148() {
      return method_930();
   }

   // $VF: renamed from: dg () void
   public static void method_1149() {
      method_1031();
   }

   // $VF: renamed from: dh () void
   public static void method_1150() {
      method_929();
   }

   // $VF: renamed from: di () void
   public static void method_1151() {
      method_1040();
   }

   // $VF: renamed from: n () java.lang.String
   public static String method_1152() {
      return method_1054();
   }

   // $VF: renamed from: o () java.lang.String
   public static String method_1153() {
      return method_1054();
   }

   // $VF: renamed from: dj () void
   public static void method_1154() {
      method_1026();
   }

   // $VF: renamed from: aD () boolean
   public static boolean method_1155() {
      return method_1058();
   }

   // $VF: renamed from: aE () boolean
   public static boolean method_1156() {
      return method_1035();
   }

   // $VF: renamed from: aF () boolean
   public static boolean method_1157() {
      return method_926();
   }

   // $VF: renamed from: dk () void
   public static void method_1158() {
      method_755();
   }

   // $VF: renamed from: aG () boolean
   public static boolean method_1159() {
      return method_631();
   }

   // $VF: renamed from: dl () void
   public static void method_1160() {
      method_922();
   }

   // $VF: renamed from: dm () void
   public static void method_1161() {
      method_539();
   }

   // $VF: renamed from: aH () boolean
   public static boolean method_1162() {
      return method_967();
   }

   // $VF: renamed from: dn () void
   public static void method_1163() {
      method_759();
   }

   // $VF: renamed from: aI () boolean
   public static boolean method_1164() {
      return method_968();
   }

   // $VF: renamed from: do () void
   public static void method_1165() {
      method_761();
   }

   // $VF: renamed from: aJ () boolean
   public static boolean method_1166() {
      return method_969();
   }

   // $VF: renamed from: dp () void
   public static void method_1167() {
      method_756();
   }

   // $VF: renamed from: dq () void
   public static void method_1168() {
      method_1032();
   }

   // $VF: renamed from: dr () void
   public static void method_1169() {
      method_537();
   }

   // $VF: renamed from: ds () void
   public static void method_1170() {
      method_1041();
   }

   // $VF: renamed from: dt () void
   public static void method_1171() {
      method_1042();
   }

   // $VF: renamed from: du () void
   public static void method_1172() {
      method_773();
   }

   // $VF: renamed from: aK () boolean
   public static boolean method_1173() {
      return method_1034();
   }

   // $VF: renamed from: dv () void
   public static void method_1174() {
      method_1059();
   }

   // $VF: renamed from: Q () int
   public static int method_1175() {
      return 2;
   }

   // $VF: renamed from: dw () void
   public static void method_1176() {
      method_1036();
   }

   // $VF: renamed from: aL () boolean
   public static boolean method_1177() {
      return method_963();
   }

   // $VF: renamed from: dx () void
   public static void method_1178() {
      method_1045();
   }

   // $VF: renamed from: aM () boolean
   public static boolean method_1179() {
      return method_561();
   }

   // $VF: renamed from: dy () void
   public static void method_1180() {
      method_924();
   }

   // $VF: renamed from: dz () void
   public static void method_1181() {
      method_971();
   }

   // $VF: renamed from: dA () void
   public static void method_1182() {
      method_1038();
   }

   // $VF: renamed from: aN () boolean
   public static boolean method_1183() {
      return method_540();
   }

   // $VF: renamed from: aO () boolean
   public static boolean method_1184() {
      return method_962();
   }

   // $VF: renamed from: aP () boolean
   public static boolean method_1185() {
      return method_925();
   }

   // $VF: renamed from: aQ () boolean
   public static boolean method_1186() {
      return method_927();
   }

   // $VF: renamed from: aR () boolean
   public static boolean method_1187() {
      return method_1015();
   }

   // $VF: renamed from: dB () void
   public static void method_1188() {
      method_757();
   }

   // $VF: renamed from: aS () boolean
   public static boolean method_1189() {
      return method_533();
   }

   // $VF: renamed from: dC () void
   public static void method_1190() {
      method_960();
   }

   // $VF: renamed from: dD () void
   public static void method_1191() {
      method_538();
   }

   // $VF: renamed from: p () java.lang.String
   public static String method_1192() {
      method_1018(321, true);
      return method_133(321);
   }

   // $VF: renamed from: q () java.lang.String
   public static String method_1193() {
      return method_133(268);
   }

   // $VF: renamed from: dE () void
   public static void method_1194() {
      method_1002();
   }

   // $VF: renamed from: dF () void
   public static void method_1195() {
      method_1033();
   }

   // $VF: renamed from: aT () boolean
   public static boolean method_1196() {
      return method_543();
   }

   // $VF: renamed from: r () java.lang.String
   public static String method_1197() {
      return method_1053();
   }

   // $VF: renamed from: dG () void
   public static void method_1198() {
      method_928();
   }

   // $VF: renamed from: dH () void
   public static void method_1199() {
      method_836();
   }

   // $VF: renamed from: aU () boolean
   public static boolean method_1200() {
      return method_536();
   }

   // $VF: renamed from: R () int
   public static int method_1201() {
      return method_934();
   }

   // $VF: renamed from: aV () boolean
   public static boolean method_1202() {
      return method_534();
   }

   // $VF: renamed from: a (int, int, int, int, int, int, int) void
   public static final void method_1203(int var0, int var1, int var2, int var3, int var4, int var5, int var6) {
      if (!field_612) {
         Graphics var7 = field_51;
         int var8 = var5 >= 0 ? var5 % var6 : field_465 % var6;
         int var9 = 255 * (var6 - var8) / var6 << 24;
         method_279(var7, 0 | var9);
         method_279(var7, var4 | var9);
         int var10;
         int var11 = (var10 = method_151(var8 * 128 / var6, var2)) >> var3;
         int var12 = var0 - var10 / 2;
         int var13 = var1 - var11 / 2;
         method_318(var7, var12, var13, var10, var11, 0, 360);
         method_318(var7, var12 - 1, var13, var10, var11, 0, 360);
         method_318(var7, var12 + 1, var13, var10, var11, 0, 360);
         method_318(var7, var12, var13 - 1, var10, var11, 0, 360);
         method_318(var7, var12, var13 + 1, var10, var11, 0, 360);
      }
   }

   // $VF: renamed from: dI () void
   public static final void method_1204() {
      field_598 = 240;
      field_599 = 320;
   }

   // $VF: renamed from: dJ () void
   public static final void method_1205() {
      field_607 = null;
      field_608 = null;
   }

   // $VF: renamed from: dK () void
   public static final void method_1206() {
      int var0 = method_148(field_598, field_553 * 2);
      int var1 = method_148(field_599, field_554 * 5);
      int var2 = field_609;
      int var3 = field_610;
      field_609 = var0;
      field_610 = var1;
      if (field_607 != null && (field_609 != var2 || field_610 != var3)) {
         method_1205();
      }
   }

   // $VF: renamed from: dL () void
   public static final void method_1207() {
      if (field_607 == null) {
         field_607 = Image.createImage(field_609, field_610);
         field_608 = field_607.getGraphics();
         method_1208(true);
      }
   }

   // $VF: renamed from: l (boolean) void
   public static final void method_1208(boolean var0) {
      field_611 = var0;
   }

   // $VF: renamed from: B (int, int) void
   public static final void method_1209(int var0, int var1) {
      field_600 = (var0 * field_564 >> 1) - (var1 * field_564 >> 1);
      field_601 = (var0 * field_565 >> 1) + (var1 * field_565 >> 1) + (field_565 >> 1);
   }

   // $VF: renamed from: C (int, int) void
   public static final void method_1210(int var0, int var1) {
      field_600 = (var0 * field_564 >> 1) - (var1 * field_564 >> 1);
      field_601 = (var0 * field_565 >> 1) + (var1 * field_565 >> 1);
   }

   // $VF: renamed from: D (int, int) void
   public static final void method_1211(int var0, int var1) {
      field_600 = (var0 * field_564 >> 1) - (var1 * field_564 >> 1) + (field_564 >> 1);
      field_601 = (var0 * field_565 >> 1) + (var1 * field_565 >> 1) + (field_565 >> 1);
   }

   // $VF: renamed from: E (int, int) void
   public static final void method_1212(int var0, int var1) {
      field_600 = (var0 * field_564 >> 1) - (var1 * field_564 >> 1) - (field_564 >> 1);
      field_601 = (var0 * field_565 >> 1) + (var1 * field_565 >> 1) + (field_565 >> 1);
   }

   // $VF: renamed from: F (int, int) void
   public static final void method_1213(int var0, int var1) {
      field_600 = (var0 * field_564 >> 1) - (var1 * field_564 >> 1);
      field_601 = (var0 * field_565 >> 1) + (var1 * field_565 >> 1) + field_565;
   }

   // $VF: renamed from: G (int, int) void
   public static final void method_1214(int var0, int var1) {
      int var2 = 1024 * var0 / field_564;
      int var3 = 1024 * var1 / field_565;
      field_600 = (var2 + var3) / 1024;
      field_601 = (var3 - var2) / 1024;
   }

   // $VF: renamed from: H (int, int) void
   public static final void method_1215(int var0, int var1) {
      field_600 = method_1218(var0 * 2 / 2 - var1 * 2 / 2);
      field_601 = method_1218(var0 * 1 / 2 + var1 * 1 / 2);
   }

   // $VF: renamed from: I (int, int) void
   public static final void method_1216(int var0, int var1) {
      var0 = method_1217(var0);
      var1 = method_1217(var1);
      field_600 = (2 * var1 + 1 * var0) / 2;
      field_601 = (2 * var1 - 1 * var0) / 2;
   }

   // $VF: renamed from: P (int) int
   public static final int method_1217(int var0) {
      return var0 << 12;
   }

   // $VF: renamed from: Q (int) int
   public static final int method_1218(int var0) {
      return var0 >> 12;
   }

   // $VF: renamed from: m (boolean) void
   public static final void method_1219(boolean var0) {
      boolean var2 = method_403() == 27;
      field_612 = false;
      if (field_607 == null) {
         method_1207();
         method_605();
      }

      Graphics var3 = field_51;
      Graphics var4 = field_608;
      int var5 = field_609;
      int var6 = field_610;
      method_313(var3, 2238248);
      method_315(var3, 0, 0, field_52, field_53);
      int var7 = field_251;
      int var8 = (field_598 >> 1) - field_265 - method_148(0, field_598 - var5 >> 1);
      int var9 = (field_599 >> 1) - field_266 - method_148(0, field_599 - var6 >> 1);
      var3.translate(var8, var9);
      if (field_611) {
         method_313(var4, 2238248);
         method_315(var4, 0, 0, var5, var6);
         var4.translate((var5 >> 1) + 0, (var6 >> 1) + 0);
         method_1231(var4, var0);
         var4.translate(-(var5 >> 1) - 0, -(var6 >> 1) - 0);
         field_611 = false;
      }

      var3.drawImage(field_607, -(var5 >> 1), -(var6 >> 1), 20);
      var3.translate(0, 0);
      if (var2 && field_416 != field_408) {
         for (int var12 = 0; var12 < 10; var12++) {
            if (field_396[field_416][var12] != -1 && method_888(field_416, var12, 1)) {
               TouchInput.addFixture(var12, field_401[field_416][var12] + var3.getTranslateX(), field_402[field_416][var12] + var3.getTranslateY());
            }
         }
      }
      method_1237(var3, var0);
      int var10;
      if ((var10 = method_994(field_409[field_416])) >= 0) {
         method_1439(var3, var10, field_245, 1);
      }

      byte var11 = field_253;
      if (field_253 != 7) {
         method_1221(var11);
      }

      if (field_416 != field_408 && var2) {
         method_1269(field_51);
      }

      if (field_276 && field_251 >= 0 && field_251 < field_287 && field_252 != field_251) {
         method_1229(var3, var7);
      }

      method_1268();
      method_1079(var3);
      var3.translate(0, 0);
      var3.translate(-var8, -var9);
      if (field_416 != field_408) {
         method_1222(var3, var7 >= 0 ? var7 : field_252, field_253);
      }

      method_1226(var3);
   }

   // $VF: renamed from: S () int
   public static final int method_1220() {
      int var0 = field_391 + field_392;
      if (field_391 >= 9) {
         return 3;
      } else if (field_392 >= 9) {
         return 4;
      } else if (var0 >= 9) {
         return 2;
      } else {
         return var0 >= 6 ? 1 : 0;
      }
   }

   // $VF: renamed from: d (byte) void
   private static void method_1221(byte var0) {
      method_1203(field_257, method_600(), field_525 >> 1, method_604(var0) ? 1 : 0, method_1241(), -1, 12);
   }

   // $VF: renamed from: i (javax.microedition.lcdui.Graphics, int, int) void
   public static final void method_1222(Graphics var0, int var1, int var2) {
      if (var1 >= 0 && var1 <= field_289) {
         int var3 = field_598 - 93 - field_577;
         int var4 = field_578;
         if (field_510 == 2 && field_512 >= 0) {
            int var5;
            if ((var5 = method_401() - field_512) >= 500) {
               return;
            }

            var4 += method_578(0, -96, var5, 500);
         }

         method_1223(var0, var1, var2, var3, var4, -1, -1, -1, -1);
      }
   }

   // $VF: renamed from: b (javax.microedition.lcdui.Graphics, int, int, int, int, int, int, int, int) void
   public static final void method_1223(Graphics var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      if (var1 >= field_286 && var1 <= field_289
            && var0.remaster("guard-panel", new int[]{var1, field_299[var1], var3, var4})) return;
      method_177(var0, 83, var3, var4);
      int var13 = var3 + 96 - 20;
      int var14 = var4 + 57;
      int var9 = var3 + field_579;
      int var10 = var4 + field_580;
      int var11 = var4 + field_581;
      int var12 = var4 + field_582;
      if (var1 >= field_285 && var1 <= field_289) {
         boolean var10000 = var1 >= field_286;
         boolean var15 = false;
         if (var10000) {
            method_1224(var3, var4);
         }

         method_1242(var0, var1, field_299[var1], var13, var14, false, true, true);
      }

      if (var1 >= 0) {
         if (var1 >= field_285 && var1 <= field_288) {
            var14 = var6 >= 0 ? var6 : method_735(field_331, var1);
            method_1230(var0, var14, 16743174, 255, var9, var10, field_583, field_584);
            int var25 = var7 >= 0 ? var7 : method_735(field_332, var1);
            method_1230(var0, var25, 12583167, 255, var9, var11, field_583, field_584);
            int var16 = var8 >= 0 ? var8 : method_735(field_333, var1);
            method_1230(var0, var16, 57087, 255, var9, var12, field_583, field_584);
         }

         if (var5 >= 0) {
            var14 = var5 == 0 ? field_580 : (var5 == 1 ? field_581 : field_582);
            method_177(var0, 77, var9 + field_583 + method_151(method_401(), 3), var4 + var14 + 1 - method_151(method_401(), 3) - 2);
            method_413(false);
            return;
         }
      } else {
         method_1224(var3, var4);
         if (var2 == 1 || var2 == 4 || var2 == 2 || var2 == 3) {
            var14 = field_585;
            int var26 = field_586;
            int var27 = field_587;
            int var17 = field_588;
            int var18 = var3 + var14;
            int var19 = var4 + var26;
            var18 += var27 - 51 >> 1;
            var19 += var17 - 17 >> 1;

            for (int var20 = 0; var20 < 3; var20++) {
               byte var21 = field_385[var20];
               method_200(var0, 155, var18 + var20 * 17, var19, var21 >= 0 ? var21 : 5);
            }

            method_1225(var0, var2, var3, var4);
         }
      }
   }

   // $VF: renamed from: P (int, int) void
   private static void method_1224(int var0, int var1) {
      Graphics var2 = field_51;
      int var3 = field_585;
      int var4 = field_586;
      int var5 = field_587;
      int var6 = field_588;
      int var7 = var0 + var3;
      int var8 = var1 + var4;
      method_313(var2, 1910573);
      method_315(var2, var7, var8, var5, var6 >> 1);
      method_313(var2, 1646369);
      method_315(var2, var7, var8 + (var6 >> 1), var5, var6 >> 1);
   }

   // $VF: renamed from: k (javax.microedition.lcdui.Graphics, int, int, int) void
   private static void method_1225(Graphics var0, int var1, int var2, int var3) {
      method_308(var0);
      int var6 = var2 + 62;
      int var7 = var3 + 4;
      method_310(var0, var6, var7, 27, 26);
      if (var1 == 1) {
         int var4 = var2 + 44;
         int var5 = var3 - 36;
         method_200(var0, 162, var4, var5, 1);
         var4 = var2 + 52;
         var5 = var3 - 56;
         method_200(var0, 163, var4, var5, 0);
      } else if (var1 == 2) {
         int var9 = var2 + 18;
         int var16 = var3 - 129;
         method_200(var0, 158, var9, var16, 0);
         var9 = var2 + 93 - 18;
         var16 = var3 + 34 - 8;
         method_200(var0, 8, var9, var16, 4);
      } else if (var1 == 3) {
         int var11 = var2 + 17;
         int var18 = var3 - 1;
         method_200(var0, 157, var11, var18, 0);
         var11 = var2 + 21;
         var18 = var3 - 5;
         method_200(var0, 157, var11, var18, 6);
      } else if (var1 == 4) {
         int var13 = var2 + 36;
         int var20 = var3 - 14;
         method_200(var0, 159, var13, var20, 0);
         var13 = var2 + 30;
         var20 = var3 - 25;
         method_200(var0, 159, var13, var20, 2);
      }

      method_309(var0);
   }

   // $VF: renamed from: l (javax.microedition.lcdui.Graphics) void
   private static void method_1226(Graphics var0) {
      int var1 = 0;
      if (field_510 == 2 && field_512 >= 0) {
         int var2;
         if ((var2 = method_401() - field_512) >= 500) {
            return;
         }

         var1 = method_578(0, -96, var2, 500);
      }

      int var14 = field_577;
      int var3 = field_578 + var1;
      int elapsed = field_465 - field_467;
      int[] hud = new int[29];
      hud[0]=var14; hud[1]=var3; hud[2]=field_445;
      hud[3]=field_349==0?192:(100*field_349-field_348)*192/100/field_349;
      hud[4]=elapsed; hud[5]=field_669;
      hud[6]=method_1057()?2:(field_347?1:(elapsed>95*field_669/100?3:0));
      hud[7]=field_465;
      for(int digit=0;digit<7;digit++){
         hud[8+digit]=field_446[digit]; hud[15+digit]=field_447[digit]; hud[22+digit]=field_448[digit];
      }
      if(var0.remaster("status-hud",hud)){
         // Preserve the original digit countdown and redraw requests without painting old sprites.
         for(int digit=0;digit<7;digit++){
            int phase=field_448[digit];
            if(phase!=-1){
               field_448[digit]--;
               if(phase<4)method_413(false);
            }
         }
         if(hud[6]==3 && (field_155&63)==20)method_479(25,-1,100,true);
         return;
      }
      method_177(var0, 81, var14, var3);
      method_1228(var0, var14 + field_589, var3 + field_590, field_446, field_448, field_447);
      int var4 = field_465 - field_467;
      if (method_1057()) {
         method_1227(var0, var14, var3, 2);
      } else if (field_347) {
         method_1227(var0, var14, var3, 1);
      } else if (var4 > 95 * field_669 / 100) {
         method_1227(var0, var14, var3, 3);
         if ((field_155 & 63) == 20) {
            method_479(25, -1, 100, true);
         }
      } else {
         int var5 = var14 + field_591;
         int var6 = var3 + field_592;
         int var7 = field_593;
         int var8 = field_349 == 0 ? 192 : (100 * field_349 - field_348) * 192 / 100 / field_349;
         int var9 = 288 + var8;
         int var10 = var5 + method_151(var9 + 128, var7);
         int var11 = var6 + method_151(var9, var7);
         method_313(var0, 0);
         method_312(var0, var5 + 1, var6, var10 + 1, var11);
         method_312(var0, var5 - 1, var6, var10 - 1, var11);
         method_312(var0, var5, var6 + 1, var10, var11 + 1);
         method_312(var0, var5, var6 - 1, var10, var11 - 1);
         method_313(var0, 16711680);
         method_312(var0, var5, var6, var10, var11);
      }

      int var15 = var14 + field_594;
      int var16 = var3 + field_595;
      int var17 = method_149(field_596, var4 * field_596 / field_669);
      method_177(var0, 84, var15 + var17, var16);
   }

   // $VF: renamed from: l (javax.microedition.lcdui.Graphics, int, int, int) void
   private static void method_1227(Graphics var0, int var1, int var2, int var3) {
      method_200(var0, 82, var1, var2, 0);
      if ((field_465 >> 1 & 1) == 0) {
         method_200(var0, 82, var1, var2, var3);
      }
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int, byte[], int[], byte[]) void
   public static final void method_1228(Graphics var0, int var1, int var2, byte[] var3, int[] var4, byte[] var5) {
      boolean var6 = false;
      boolean var7 = false;

      for (int var8 = 0; var8 < 7; var8++) {
         int var9 = var1 + var8 * 8;
         byte var10;
         if ((var10 = var3[var8]) > 0) {
            var7 = true;
         }

         int var11 = var4[var8];
         byte var12;
         if ((var12 = var5[var8]) > 0) {
            var6 = true;
         }

         byte var13 = var11 == -1 ? var10 : var12;
         int var14;
         if (var11 == -1) {
            var14 = var7 ? var13 : 10;
            method_200(var0, 87, var9, var2, var14);
         } else {
            var14 = var11 < 4 ? 11 + (var11 & 1) : (var6 ? var13 : 10);
            method_200(var0, 87, var9, var2, var14);
            var4[var8]--;
         }

         if (var14 == 11 || var14 == 12) {
            method_413(false);
         }
      }
   }

   // $VF: renamed from: e (javax.microedition.lcdui.Graphics, int) void
   private static void method_1229(Graphics var0, int var1) {
      int var2 = field_302[var1];
      int var3 = field_303[var1];
      int var4 = field_255;
      int var5 = field_256;
      int var6 = 2 * field_525 / 90;
      int var7 = (var4 - var2) / 84;
      int var8 = (var5 - var3) / 84;
      int var9 = method_629(var1) ? 16733525 : 15663103;
      int var10 = 50 * field_525 / 90;
      int var11 = field_314[var1] == 6 ? 22 : 51;
      int var12 = var1 >= field_286 && field_252 >= 0 ? 51 : 0;

      for (int var13 = 78 + field_465 % 6; var13 >= 0; var13 -= 6) {
         int var14 = var2 + var13 * var7 - var6 / 2;
         int var15 = var3 + var13 * var8 - var6 / 2;
         method_1215(var14, var15);
         int var16 = field_600;
         int var17 = field_601 - method_151(var13 * 256 / 84, var10) - (84 - var13) * var11 / 84 - var13 * var12 / 84;
         method_313(var0, 3355443);
         method_315(var0, var16 - 1, var17 - 1, var6 + 2, var6 + 2);
         method_313(var0, var9);
         method_315(var0, var16, var17, var6, var6);
      }
   }

   // $VF: renamed from: d (javax.microedition.lcdui.Graphics, int, int, int, int, int, int, int) void
   private static void method_1230(Graphics var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      int var8 = var1 * var6 / 100;
      if (var1 > 0 && var8 == 0) {
         var8 = 1;
      }

      int var9 = method_325(var2, 16777215, 119);
      boolean var10;
      if (var10 = method_1271(var0, var4, var5, var8, var7, var3 << 24 | var2)) {
         method_1271(var0, var4, var5, var8, 1, var3 << 24 | var9);
      }

      if (!var10) {
         method_313(var0, var2);
         method_315(var0, var4, var5, var8, var7);
         method_313(var0, var9);
         method_315(var0, var4, var5, var8, 1);
      }
   }

   // $VF: renamed from: c (javax.microedition.lcdui.Graphics, boolean) void
   private static void method_1231(Graphics var0, boolean var1) {
      if (var1) {
         method_947(var0);
      } else {
         int var2 = field_561 - field_559;
         int var3 = field_562 - field_560;
         byte var4 = field_416;
         int var5;
         if ((var5 = method_994(field_300[field_410[var4]])) == 0) {
            method_1234(var0, 0, 0, 1, 3421504, 0, 0, field_559, field_560, 0, 0);
            method_1234(var0, 0, 0, 2, 4409420, 0, 0, field_559, field_560, 0, 0);
            method_1234(var0, 0, 0, 0, 3421504, var2, var3, field_561, field_562, var2, var3);
            method_1234(var0, 0, 0, 3, 4409420, field_559 - field_561, var3, field_561, field_562, -var2, var3);
         }

         method_1263(var0, 0, 0);
         if (!var1 && !field_612) {
            method_1233(var0, method_981(field_416));
         }

         if (var5 == 0 && !field_612) {
            method_1235(var0, 0, 0, 0, 0, 1);
            method_1235(var0, 0, 0, 0, 0, 2);
            method_1235(var0, 0, 0, var2, var3, 0);
            method_1235(var0, 0, 0, field_559 - field_561, var3, 3);
         }

         method_1260(var0, 0, 0, var5, field_387, field_388, field_552, field_551, field_568, field_570, field_569, field_571, true);
         method_1260(var0, 0, 0, var5, field_389, field_390, field_552, field_551, field_572, field_574, field_573, field_575, false);
         method_1232(var0);
         method_1209(6, 8);
         method_177(var0, 60, field_600 - 13, field_601 - 21);
         method_1439(var0, method_994(field_409[field_416]), field_245, 0);
         if (var5 == 1) {
            method_871(var0, var4);
         }

         if (var5 == 0) {
            int var6 = 4;

            while (--var6 >= 0) {
               method_1266(var0, var6, false);
               if (method_823(var4, 1 + var6, 9)) {
                  boolean var7 = var6 < 2;
                  int var8 = field_401[var4][1 + var6];
                  int var9 = field_402[var4][1 + var6] - 22;
                  method_200(var0, 160, var8 - 20, var9 - 63 - field_549 * 55 / 100, var7 ? 0 : 11);
               }
            }
         }

         boolean var10 = false;
         byte var11;
         if ((var11 = field_396[var4][5]) == 2) {
            method_872(var0, var4, 5);
         } else if (var11 == 9) {
            method_881(var0, var4, 5);
         }

         if ((var11 = field_396[var4][6]) == 2) {
            method_873(var0, var4, 6);
         } else {
            if (var11 == 9) {
               method_881(var0, var4, 6);
            }
         }
      }
   }

   // $VF: renamed from: m (javax.microedition.lcdui.Graphics) void
   private static final void method_1232(Graphics var0) {
      int var1 = field_553 / field_532 + 3;
      int var2 = field_554 * 2 - field_531 + field_520;
      int var3 = var1;

      while (--var3 >= 0) {
         method_200(var0, 61, 0 + var3 * field_532, var2 - var3 * field_531, (var3 & 1) << 1);
      }

      var2 = field_554 * 2 - field_531 + field_520;
      var3 = var1;

      while (--var3 >= 0) {
         method_200(var0, 61, -75 - var3 * field_532, var2 - var3 * field_531, 1 + ((var3 & 1) << 1));
      }

      int var4 = -field_536 - field_552;
      int var5 = -field_533;
      int var6 = var4 - field_535;

      for (int var7 = 0; var7 < 6; var7++) {
         int var8 = 2;

         while (--var8 >= 0) {
            method_200(
               var0,
               61,
               -field_553 - 75 + 2 - var8 * field_532,
               (field_554 >> 1) - var7 * (71 - field_534) - 4 - field_520 - var8 * field_531,
               1 + ((var7 & 1) << 1)
            );
         }
      }

      for (int var11 = 0; var11 < 6; var11++) {
         int var12 = 2;

         while (--var12 >= 0) {
            method_200(
               var0, 61, field_553 + var12 * field_532, (field_554 >> 1) - var11 * (71 - field_534) - 4 - field_520 - var12 * field_531, (var11 & 1) << 1
            );
         }
      }

      method_1257(var0, var5, var6, 4, false);
      method_1257(var0, -75, var4, 4, true);
      method_1257(var0, -75 + field_533, var4 - field_536, 4, true);
      method_1257(var0, var5 + field_533, var4 - (71 - field_534) - 1, 4, false);
   }

   // $VF: renamed from: f (javax.microedition.lcdui.Graphics, int) void
   private static void method_1233(Graphics var0, int var1) {
      if (field_597 == null) {
         field_597 = new int[18];
         field_597[0] = 0;
         field_597[1] = -1;
         field_597[2] = -1;
         field_597[3] = 0;
         field_597[4] = 0;
         field_597[5] = -1;
         field_597[6] = 0;
         field_597[7] = 0;
         field_597[8] = 0;
         field_597[9] = 0;
         field_597[10] = 1;
         field_597[11] = -1;
         field_597[12] = 1;
         field_597[13] = -1;
         field_597[14] = -1;
         field_597[15] = 1;
         field_597[16] = 0;
         field_597[17] = -1;
      }

      int var2 = 2 * field_516 + 2 * field_518;
      int var3 = 2 * field_517 + 2 * field_519;
      int var4 = var1 - 1;
      int var5 = 0;
      int var6 = 0;
      byte var7 = 0;
      byte var8 = 0;
      switch (var1) {
         case 1:
            var7 = 36;
            var8 = 25;
            break;
         case 2:
            var7 = 46;
            var8 = 31;
            break;
         case 3:
            var7 = 61;
            var8 = 37;
            break;
         case 4:
            var7 = 59;
            var8 = 35;
            break;
         case 5:
            var7 = 50;
            var8 = 29;
            break;
         case 6:
            var7 = 64;
            var8 = 34;
      }

      for (int var9 = 0; var9 < 3; var9++) {
         int var10;
         if ((var10 = field_597[var4 * 3 + var9]) >= 0) {
            method_200(var0, 58, var2 + var5 - (var7 >> 1), var3 + var6 - (var8 >> 1), var10);
            var5 += var10 == 0 ? 13 : 23;
            var6 += var10 == 0 ? 7 : 12;
         }
      }
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int, int, int, int, int, int, int, int, int) void
   private static void method_1234(Graphics var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10) {
      int var11 = 1 + var3;
      boolean var12 = var3 < 2;
      if (!field_612) {
         method_1258(var0, var1, var2, var4, var5, var6, var12);
      }

      byte var13 = field_416;
      int var14 = method_823(field_416, var11, 8) ? 52 : (method_823(var13, var11, 7) ? 51 : 50);
      method_1259(var0, var1, var2, var14, var7, var8, var12);
      method_1236(var0, var9, var10, var3, var12, var11);
   }

   // $VF: renamed from: f (javax.microedition.lcdui.Graphics, int, int, int, int, int) void
   private static void method_1235(Graphics var0, int var1, int var2, int var3, int var4, int var5) {
      boolean var6 = var5 < 2;
      int var7 = var1 + var3;
      int var8 = var2 + var4;
      int var11 = var7 + (var6 ? -field_527 : field_527);
      int var12 = var8 + field_528;
      method_313(var0, 3751490);
      method_312(var0, var7, var8, var11, var12);
      method_313(var0, 5133395);
      method_312(var0, var7, var8 - 1, var11, var12 - 1);
      method_313(var0, 55267664);
      method_312(var0, var7, var8 - 2, var11, var12 - 2);
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int, int, boolean, int) void
   private static void method_1236(Graphics var0, int var1, int var2, int var3, boolean var4, int var5) {
      int var6 = var1 - 80 * (var4 ? 1 : 0);
      int var7 = var2 - 70;
      int var8 = 7 * (var4 ? -1 : 1);
      var6 += var8;
      var7 -= 3;
      int var9 = 0;
      method_870(var0, var6, var7, !var4, true, field_416, var5, 45, 60, 13);
      if (method_723(var3)) {
         method_200(var0, 24, var6, var7, var4 ? 0 : 1);
      }

      if (!field_612) {
         method_279(var0, 855638016);
         var7 = var2 - field_549;
         var8 = var1 - field_527 * (var4 ? 1 : -1);
         var9 = var7 - field_528;
         method_277(var0, var1, var7, var8, var9, var1 - field_527 * (var4 ? 1 : -1), var2);
      }
   }

   // $VF: renamed from: d (javax.microedition.lcdui.Graphics, boolean) void
   private static final void method_1237(Graphics var0, boolean var1) {
      method_681();
      int var2 = field_284;

      while (--var2 >= 0) {
         byte var3 = field_301[var2];
         int var4;
         if ((var4 = field_299[var3]) >= 0 && field_309[var3] == field_416) {
            int var5 = field_304[var3];
            int var6 = field_305[var3];
            if (method_403() == 27 && (var3 >= field_287 || !var1)) {
               TouchInput.addEntity(var3, var5 + var0.getTranslateX(), var6 + var0.getTranslateY(), var3 < field_287);
            }
            if (var3 < field_286) {
               if (!var1) {
                  method_1238(var0, var3, var4, var5, var6);
                  if (field_274 == 2 && !method_616(field_416, var3) && field_328[var3] < 0) {
                     method_200(var0, 78, var5, var6 - 68, method_1099());
                  }
               }
            } else if (var3 < field_287) {
               if (!var1) {
                  method_1238(var0, var3, var4, var5, var6);
               }
            } else {
               method_1240(var0, var3, var5, var6);
            }
         }
      }
   }

   // $VF: renamed from: q (javax.microedition.lcdui.Graphics, int, int, int, int) void
   private static void method_1238(Graphics var0, int var1, int var2, int var3, int var4) {
      if (var1 < field_286 && method_654(var1)) {
         byte var5 = field_342[var1];
         boolean var6 = field_314[var1] == 6;
         boolean var7 = var5 < 2;
         method_308(var0);
         int var8 = var5 < 2 ? var5 : (var5 == 2 ? 1 : 0);
         int var9 = 3;

         while (--var9 >= 0) {
            int var10 = field_545[var8 * 3 + var9];
            int var11 = field_546[var8 * 3 + var9];
            if (!var7) {
               var10 = -var10 - field_547 + 1;
            }

            method_310(var0, var10, var11, field_547, field_548);
            if (field_251 == var1 || field_252 == var1) {
               method_1239(var3, var4 + (var6 ? -20 : 0));
            }

            if (!var6) {
               method_1242(var0, var1, var2, var3, var4, true, false, true);
            }

            int var12;
            if ((var12 = field_343[var1]) >= 0) {
               boolean var13;
               int var14;
               if ((var14 = method_577((var13 = method_683(var1, 4096)) ? 0 : 100, var13 ? 100 : 0, field_465 - var12 << 2, 100)) > 100 && var13) {
                  field_343[var1] = -1;
               } else {
                  method_1265(var0, var5, var7, var14, var1);
               }
            }
         }

         method_309(var0);
         method_1266(var0, var5, true);
      } else {
         if (method_683(var1, 512)) {
            if ((field_465 >> 1 & 1) == 0) {
               method_200(var0, 82, var3 - 18, var4 - 102, 1);
            }
         } else {
            method_1256(var0, var1, var3, var4);
         }

         if (field_251 == var1 || field_252 == var1) {
            method_1239(var3, var4);
         }

         method_1242(var0, var1, var2, var3, var4, true, false, true);
      }

      if (var1 < field_286) {
         method_1254(var0, var1, var3, var4, method_735(field_331, var1), 30, 16743174);
      } else {
         byte var15;
         if (method_979(var15 = field_309[var1])) {
            method_1254(var0, var1, var3, var4, field_418[var15], 0, 65280);
         }
      }
   }

   // $VF: renamed from: Q (int, int) void
   private static void method_1239(int var0, int var1) {
      method_1203(var0, var1, field_525 >> 1, 1, method_1241(), -1, 12);
   }

   // $VF: renamed from: m (javax.microedition.lcdui.Graphics, int, int, int) void
   private static void method_1240(Graphics var0, int var1, int var2, int var3) {
      byte var4;
      if ((var4 = field_300[var1]) == 2) {
         method_874(var0, var1, var2, var3);
      } else if (var4 == 3) {
         method_875(var0, var1, var2, var3);
      } else if (var4 == 6) {
         boolean var7 = field_364 >= 2;
         method_200(var0, 62, var2, var3, 0);
         if (var7 && (field_465 & 1) == 0) {
            method_200(var0, 62, var2, var3, 1);
            method_1277(var0, var2, var3 - 26, 16764108, -1);
         }
      } else if (var4 >= 7 && var4 <= 16) {
         boolean var6 = false;
         method_939(var0, var1, var2, var3 + -8, var4);
      } else if (var4 != 17) {
         if (var4 == 20) {
            method_882(var0, var1, var2, var3);
         }
      } else {
         boolean var5 = false;
         if (field_251 == var1 || field_252 == var1) {
            method_1203(var2, var3 + 1, field_525 >> 1, 1, method_1241(), -1, 12);
         }

         method_177(var0, 63, var2, var3 + 1 + 10);
      }
   }

   // $VF: renamed from: T () int
   public static final int method_1241() {
      if (field_416 == field_408) {
         return field_479 <= 1 ? 16777215 : 12311787;
      } else {
         return field_251 >= 0 && method_629(field_251) ? 16733525 : 12311787;
      }
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int, int, int, boolean, boolean, boolean) void
   public static final void method_1242(Graphics var0, int var1, int var2, int var3, int var4, boolean var5, boolean var6, boolean var7) {
      boolean modern = RemasterArt.beginActor(var0, var1, var2, var3, var4, var5, var6);
      try {
         drawOriginalActor(var0, var1, var2, var3, var4, var5, var6, var7);
      } finally {
         if (modern) RemasterArt.endActor(var0);
      }
   }

   private static void drawOriginalActor(Graphics var0, int var1, int var2, int var3, int var4, boolean var5, boolean var6, boolean var7) {
      byte var8;
      if ((var8 = field_314[var1]) != 33) {
         int var9 = 0;
         boolean var10 = var1 < field_286;
         byte var11 = 0;
         if (!var10) {
            if (method_683(var1, 1024)) {
               var9 = 4;
               var11 = 23;
            } else {
               var9 = 3;
               var11 = 23;
            }
         } else {
            var9 = 0 + field_329[var1];
            var11 = 22;
         }

         field_603 = var3;
         byte var12 = var10 ? method_735(field_331, var1) : 0;
         byte var13 = var10 ? method_735(field_332, var1) : 0;
         byte var14 = var10 ? method_735(field_333, var1) : 0;
         int var15 = field_465 - field_317[var1];
         if (!var5 || var8 != 14 && var8 != 15 && var8 != 16) {
            int var36 = var15 - 2 & 63;
            if (var8 == 8 && var13 == 100 && var36 == 0) {
               field_317[var1] = field_465;
            }

            boolean var37 = method_683(var1, 1024);
            boolean var18 = method_683(var1, 2);
            int var19 = method_719(var1);
            int var20 = method_720(var1);
            int var21 = var2 & 0xFF;
            int var22 = (var2 & 0xFF00) >> 8;
            int var23 = (var2 & 0xFF0000) >> 16;
            int var24 = var37 ? ((field_428 & 7) == 0 ? 19 : 17) : (var10 ? (var21 % 3 == 0 ? -1 : var21 % 15) : 15);
            int var25 = var37 ? 16 : (var10 ? var22 % 15 : 15 + var22 % 3);
            int var26 = var10 ? var23 : 1;
            int var27 = field_465 >> (var13 > 95 ? 2 : (method_1057() ? 0 : 1));
            field_605 = var18 ? field_576[var27 % 4] : 1;
            field_606 = 0;
            field_602 = var4 + 1;
            boolean var29 = false;
            boolean var30 = false;
            if (var1 < field_280) {
               byte var31 = field_308[var1];
               byte var32 = field_309[var1];
               var29 = var31 >= 0 && method_888(var32, var31, 2);
            }

            if (var24 == 19) {
               field_604 = 30 + (var27 & 1);
               if ((field_155 & 127) == 30) {
                  method_479(9, var1, 100, true);
               }
            } else if (method_683(var1, 1024)) {
               field_604 = 32;
            } else if (var18) {
               field_604 = 9 + field_576[var27 % 4];
            } else {
               int var38 = field_465 - field_317[var1];
               if (var8 == 7) {
                  method_918(var27, var1, var38);
               } else if (var8 == 8) {
                  method_1246(var1, var15, var13, var19, var5);
               } else if (var8 == 9) {
                  var30 = method_1247(var1, var15);
               } else if (var8 == 10) {
                  method_1248(var1, var19, var15);
               } else if (var8 == 40) {
                  method_1243(var1);
               } else if (var8 == 29) {
                  field_604 = 10;
                  if (var38 > 10) {
                     field_606 = method_151(var38 + field_299[var1] << 5, 2);
                  }
               } else if (var8 == 20) {
                  method_1250(var1, var15, var29);
               } else if (var8 == 27) {
                  method_1251(var15);
               } else if (var8 == 30) {
                  if (var1 == field_360 && field_364 == 2) {
                     field_604 = 7;
                  } else if ((field_465 + var2) % 200 < 50) {
                     field_604 = 24 + var27 % 3;
                  } else {
                     field_604 = 10;
                  }
               } else if (var8 == 5 && var10 && var12 == 0 && var13 == 0 && var14 < 50 && var38 > 10) {
                  field_604 = 30 + (var27 & 1);
                  field_602 += var27 & 1;
                  int var40;
                  field_605 = (var40 = var27 % 64) < 16 ? 0 : (var40 < 32 ? 1 : 2);
                  if ((field_155 & 127) == 16) {
                     method_479(9, var1, 100, true);
                  }
               } else {
                  field_604 = 10;
               }
            }

            if (var24 == 17) {
               method_455(field_299[var1]);
               if (method_456() % 100 < 5) {
                  var24 = 18;
                  field_604 = 24 + var27 % 3;
               }
            }

            int var28 = (field_604 << 1) + var19;
            int var39 = (field_605 << 1) + var19;
            if (!var6) {
               method_177(var0, 26, field_603, var4);
               method_200(var0, var11, field_603, var4, var39);
               method_200(var0, 13, field_603, var4, (var9 << 1) + var19);
            }

            int var41;
            if (!var5 && !var6 && var1 >= field_285 && var1 <= field_288 && var7 && !method_546(var41 = method_403()) && !method_529(var41)) {
               method_1244(var0, var1, var3, var4 + 0);
            }

            if (field_605 == 0) {
               field_602--;
            } else if (field_605 == 2) {
               field_602++;
            } else if (var30) {
               field_602 += var15 >> 1 & 1;
            }

            var41 = field_603 + field_606;
            if (var24 != 19) {
               method_200(var0, 12, var41, field_602, (var26 << 1) + var20);
            }

            if (var28 != 16 && var28 != 17) {
               method_200(var0, 14, var41, field_602, (var25 << 1) + var20);
            }

            if (var24 >= 0) {
               if (var24 == 19) {
                  method_200(var0, 16, var41, field_602, var20);
                  if ((field_428 & 63) == 0) {
                     method_200(var0, 19, var41, field_602, 32 + var20);
                  } else if ((field_428 & 31) == 0) {
                     method_200(var0, 18, var41, field_602 - 6, var20);
                  }
               } else if (var24 == 17) {
                  method_200(var0, 15, var41, field_602, var20);
               } else if (var24 == 18) {
                  method_200(var0, 17, var41, field_602, var20);
               } else if (var24 == 15) {
                  method_200(var0, 18, var41, field_602, var20);
               } else {
                  method_200(var0, 19, var41, field_602, (var24 << 1) + var20);
               }
            }

            if (var30) {
               method_200(var0, 19, var41, field_602, 32 + var20);
            }

            if (!var6) {
               if (field_604 == 32) {
                  method_200(var0, 20, field_603, var4, var20);
               } else {
                  method_200(var0, 21, field_603, var4, var28);
               }
            }

            if (var5) {
               if (var8 == 8 && var13 < 100) {
                  method_1252(var1, var0, field_603, var4, var36, var19, (100 - field_337[var1]) * 15 / 100 * (100 - var13) / 100);
                  return;
               }
            } else {
               method_455((int)System.currentTimeMillis() + var1);
               if (method_456() % 10000 < 50) {
                  boolean var33 = method_683(var1, 256);
                  method_682(var1, 256, !var33, false);
               }

               if (method_456() % 10000 < 2) {
                  boolean var43 = method_683(var1, 128);
                  method_682(var1, 128, !var43, false);
                  method_682(var1, 256, !var43, false);
               }
            }
         } else {
            byte var10000 = field_308[var1];
            boolean var16 = false;
            byte var17 = (byte)(var10000 - 1);
            method_200(var0, 25, field_603, var4, var17 < 2 ? 0 : 1);
         }
      }
   }

   // $VF: renamed from: bx (int) void
   private static void method_1243(int var0) {
      field_604 = 10;
      int var1;
      if ((var1 = field_465 - field_317[var0]) < 3) {
         field_604 = 9;
      } else if (var1 < 6) {
         field_604 = 21;
      } else if (var1 < 9) {
         field_604 = 28;
      } else if (var1 < 12) {
         field_604 = 29;
      } else if (var1 < 15) {
         field_604 = 28;
      } else if (var1 < 18) {
         field_604 = 21;
      } else if (var1 < 21) {
         field_604 = 6;
      } else if (var1 < 24) {
         field_604 = 22;
      } else if (var1 < 27) {
         field_604 = 21;
      } else {
         if (var1 < 30) {
            field_604 = 9;
         }
      }
   }

   // $VF: renamed from: n (javax.microedition.lcdui.Graphics, int, int, int) void
   private static void method_1244(Graphics var0, int var1, int var2, int var3) {
      byte var4;
      if ((var4 = field_334[var1]) > 0) {
         method_313(var0, 1185304);
         boolean var6;
         int var7;
         int var8 = method_211(var7 = (var6 = method_1294()) ? 1 : 2);
         int var9;
         int var10 = var9 = var6 ? var8 * 130 / 100 : var8 * 150 / 100;
         int var11 = var3 - (var6 ? 64 : 66);
         int var12 = var2 - (var10 >> 1);
         int var13 = var11 - var9 * 45 / 100;
         method_1245(var0, var10, var9, var12, var13);
         method_205(var7, var0, method_463(var4), var2, var11, 3);
      }
   }

   // $VF: renamed from: n (javax.microedition.lcdui.Graphics, int, int, int, int) void
   public static final void method_1245(Graphics var0, int var1, int var2, int var3, int var4) {
      method_315(var0, var3 + 1, var4 - 1, var1 - 2, var2 + 2);
      method_315(var0, var3 - 1, var4 + 1, var1 + 2, var2 - 2);
      method_315(var0, var3, var4, 1, 1);
      method_315(var0, var3 + var1 - 1, var4, 1, 1);
      method_315(var0, var3, var4 + var2 - 1, 1, 1);
      method_315(var0, var3 + var1 - 1, var4 + var2 - 1, 1, 1);
   }

   // $VF: renamed from: a (int, int, int, int, boolean) void
   public static final void method_1246(int var0, int var1, int var2, int var3, boolean var4) {
      if (var2 == 100) {
         field_604 = 10;
      } else if (method_683(var0, 32768)) {
         int var8;
         if ((var8 = var1 & 63) == 4) {
            method_479(19, var0, 100, true);
         }

         if (!var4) {
            field_604 = 10;
         } else if (var8 < 7) {
            field_604 = 12 + var8 / 3;
         } else if (var8 < 9) {
            field_604 = 13;
         } else if (var8 < 37) {
            field_604 = 10;
         } else {
            field_604 = 12;
         }
      } else if (method_683(var0, 65536)) {
         method_751(var0, var1, var3);
      } else {
         boolean var5 = method_683(var0, 128);
         boolean var6 = method_683(var0, 256);
         method_722(var0, !var5, false);
         if (var5 == var6) {
            field_604 = 10;
            if (field_317[var0] - field_465 > 50) {
               method_682(var0, 128, true, true);
               method_682(var0, 256, false, true);
            }
         } else {
            int var7;
            label87: {
               if ((var7 = var1 & 127) < 46) {
                  if ((var7 %= 9) >= 2) {
                     if (var7 == 2) {
                        field_604 = 19;
                        break label87;
                     }

                     if (var7 < 7) {
                        field_604 = 20;
                        break label87;
                     }

                     if (var7 == 7) {
                        field_604 = 19;
                        break label87;
                     }

                     if (var7 != 8) {
                        break label87;
                     }
                  }
               } else if (var7 < 90 && (var7 -= 46) >= 2) {
                  if (var7 < 4) {
                     field_604 = 19;
                  } else if (var7 < 28) {
                     field_604 = 20;
                  } else if (var7 == 28) {
                     field_604 = 19;
                  } else {
                     field_604 = 18;
                  }
                  break label87;
               }

               field_604 = 18;
            }

            if (var7 == 7 && field_309[var0] == field_416) {
               method_1069(field_302[var0], field_303[var0]);
            }
         }
      }
   }

   // $VF: renamed from: i (int, int) boolean
   public static final boolean method_1247(int var0, int var1) {
      int var2 = -1;
      byte var3 = field_308[var0];
      byte var4 = field_309[var0];
      if (var3 >= 0 && method_823(var4, var3, 33)) {
         var2 = 28 + (var1 >> 4) % 2;
      }

      if (var2 < 0) {
         var2 = 27;
      }

      field_604 = var2;
      return var3 >= 0 && method_823(var4, var3, 32);
   }

   // $VF: renamed from: s (int, int, int) void
   private static final void method_1248(int var0, int var1, int var2) {
      int var3 = var1 == 0 ? 1 : -1;
      if (!method_1249(var0, var3)) {
         int var4;
         int var5;
         if ((var4 = (var2 >> 1) + field_299[var0] & 31) == 4
            && method_152(100) < 60
            && (var5 = method_743(var0, method_683(var0, 16), field_306[var0], field_307[var0])) >= 0) {
            method_682(var5, 32, true, false);
            method_479(15, var0, 100, true);
         }

         if (var4 < 4) {
            field_604 = var4;
            field_603 += var3 * (var4 << 1);
            field_605 = (byte)(var4 < 2 ? 2 : 0);
            return;
         }

         if (var4 >= 10 && var4 <= 12) {
            field_604 = (var5 = var4 - 10) + 3;
            field_603 += var3 * (var5 << 1);
            field_605 = (byte)(var5 < 2 ? 2 : 0);
            return;
         }

         if (var4 >= 24 && var4 <= 26) {
            field_604 = (var5 = var4 - 24) + 5;
            field_603 += var3 * (var5 << 1);
            field_605 = (byte)(var5 < 2 ? 2 : 0);
            return;
         }

         field_606 += var3;
         field_602++;
         field_604 = 3;
      }
   }

   // $VF: renamed from: j (int, int) boolean
   public static final boolean method_1249(int var0, int var1) {
      boolean var2 = method_683(var0, 32);
      boolean var3 = method_683(var0, 64);
      if (!var2 && !var3) {
         return false;
      } else {
         if (var2) {
            method_682(var0, 32, false, false);
            method_682(var0, 64, true, false);
            method_455((int)System.currentTimeMillis());
            int var4 = field_304[var0] + var1 * 40 * (20 + method_456() % 30) / 100;
            int var5 = field_305[var0] - 68 * (30 + method_456() % 30) / 100;
            method_1216(var4, var5);
            method_1070(field_600, field_601);
         } else if (var3) {
            method_682(var0, 64, false, false);
         }

         field_606 -= var1 << (var2 ? 1 : 2);
         field_604 = 8;
         field_602 -= 2;
         return true;
      }
   }

   // $VF: renamed from: d (int, int, boolean) void
   public static final void method_1250(int var0, int var1, boolean var2) {
      int var3;
      if (((var3 = var1 & 63) < 10 || var3 > 80) && !var2) {
         if (var3 < 2) {
            field_604 = 6;
         } else if (var3 < 4) {
            field_604 = 13;
         } else if (var3 < 6) {
            field_604 = 12;
         } else if (var3 > 50) {
            field_604 = 9;
         } else {
            field_604 = 10;
         }
      } else {
         if (var3 >= 8 && (var3 < 16 || var3 >= 24)) {
            field_604 = var1 % 8;
         } else {
            field_604 = 15 + var1 % 3;
         }

         if ((var3 & 1) == 0) {
            field_602++;
         }

         field_605 = var1 % 3;
      }

      if ((var1 & 7) == 0) {
         method_455((int)System.currentTimeMillis());
         int var4 = method_683(var0, 128) ? -1 : 1;
         int var5 = field_304[var0] + var4 * 40 * (20 + method_456() % 50) / 100;
         int var6 = field_305[var0] - 68 * (30 + method_456() % 30) / 100;
         method_1216(var5, var6);
         method_1070(field_600, field_601);
      }
   }

   // $VF: renamed from: by (int) void
   private static final void method_1251(int var0) {
      if (var0 >= 10) {
         if (var0 < 20) {
            field_604 = 21 + (var0 - 10 >> 2);
            return;
         }

         if (var0 < 30) {
            field_604 = 23;
            return;
         }

         if (var0 < 40) {
            field_604 = 23 - (var0 - 30 >> 2);
            return;
         }
      }

      field_604 = 10;
   }

   // $VF: renamed from: a (int, javax.microedition.lcdui.Graphics, int, int, int, int, int) void
   private static void method_1252(int var0, Graphics var1, int var2, int var3, int var4, int var5, int var6) {
      if (method_683(var0, 32768)) {
         method_1253(var1, var2, var3, var4, var5, var6, var0);
      } else {
         if (method_683(var0, 65536)) {
            method_752(var1, var2, var3, var5);
         }
      }
   }

   // $VF: renamed from: c (javax.microedition.lcdui.Graphics, int, int, int, int, int, int) void
   private static void method_1253(Graphics var0, int var1, int var2, int var3, int var4, int var5, int var6) {
      byte var7 = field_308[var6];
      byte var8 = field_309[var6];
      int var9 = field_401[var8][var7];
      int var10 = field_402[var8][var7];
      boolean var11 = var4 == 0;
      method_1270(true, 158, var11);
      var9 += field_600;
      var10 += field_601;
      int var12 = var9 + (var11 ? 83 + field_394 : 42 - field_394);
      int var13 = var10 + 86;
      method_455(field_465 - var3);
      boolean var14 = (method_456() >> 6 & 15) > var5;
      int var15 = var1 - var4 * 9;
      int var16 = var2 - 9;
      int var17 = var15 - var12;
      int var18 = var16 - var13;
      if (var14) {
         if ((method_456() >> 5 & 31) > 16) {
            var17 += 9;
         } else {
            var17 -= 9;
         }
      }

      int var19 = 9 + var18;
      if (var3 == 16 && var8 == field_416) {
         method_1069(field_302[var6], field_303[var6]);
      }

      if (var3 < 16) {
         var16 -= method_151(var3 * 12, var18 * 10 / 7);
         var15 -= var3 * var17 >> 4;
      } else if (!var14) {
         if (var3 < 24) {
            var16 = var2 - method_151(24 - var3 << 4, var19);
            var15 -= var17;
         } else if (var3 < 36) {
            var15 -= var17 * (36 - var3) / 12;
            if (var3 < 32) {
               var16 = var2 - method_151(var3 - 24 << 5, 18);
            } else {
               var16 = var2 - method_151(var3 - 32 << 5, 9);
            }
         }
      } else if (var3 < 36) {
         var15 += -var17 + method_151((var3 - 16) * 128 / 20, var17);
         if (var3 < 32) {
            var16 = var2 - method_151((32 - var3) * 12, (9 + var18) * 10 / 7);
         } else {
            var16 = var2 - method_151(var3 - 32 << 5, 9);
         }
      }

      method_279(var0, -1438366652);
      int var20;
      int var21 = (var20 = 9 + var16 * 9 / var19 - 4) >> 1;
      method_317(var0, var15 - (var20 >> 1), var2, var20, var21);
      method_177(var0, 8, var15, var16);
      var20 = 0;
      if (var14 && var3 > 15 && var3 < 18) {
         var20 = var3 - 15;
      } else if (!var14 && var3 > 17 && var3 < 20) {
         var20 = var3 - 17;
      }

      method_200(var0, 9, var9 + (var11 ? field_394 : -field_394), var10 + var20 - field_395, var11 ? 1 : 0);
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int, int, byte, int, int) void
   private static void method_1254(Graphics var0, int var1, int var2, int var3, byte var4, int var5, int var6) {
      if (!field_612) {
         int var7 = var2 - 6;
         int var8 = var3 - 68;
         boolean var9;
         if (!(var9 = !method_683(var1, 8) && var4 == 100 || method_683(var1, 8) && field_465 - field_313[var1] <= var5) && var4 >= 100) {
            method_200(var0, 89, var7, var8, 1);
         } else {
            method_200(var0, 89, var7, var8, 0);
            method_1255(var0, var7, var8, var4, var6, var9);
         }
      }
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int, int, int, boolean) void
   private static void method_1255(Graphics var0, int var1, int var2, int var3, int var4, boolean var5) {
      if (!field_612) {
         int var6 = var5 ? method_151((field_465 << 5) % 256, 255) : 255;
         method_1230(var0, var3, var4, var6, var1 + 3, var2 + 3, 7, 1);
      }
   }

   // $VF: renamed from: o (javax.microedition.lcdui.Graphics, int, int, int) void
   private static void method_1256(Graphics var0, int var1, int var2, int var3) {
      if (!field_612) {
         int var4;
         if ((var4 = field_326[var1]) >= 0) {
            int var5;
            if ((var5 = field_465 - var4) > 80) {
               method_748(var1);
               return;
            }

            if (var5 >= 0) {
               int var6;
               int var7;
               boolean var8;
               int var9 = (var8 = (var7 = (var6 = field_325[var1]) >> 16) == 133 || var7 == 134 || var7 == 135) ? (13 - method_149(var5, 13)) * 4 / 13 : 0;
               int var10 = var2 - method_151(method_149(var5, 5) * 256 / 5, 5) + (var8 ? method_151(field_465 * 128, var9) : 0);
               int var11 = var3 - 68 + method_579(68, 0, var5, 5);
               method_200(var0, 129, var10, var11, var7 == 133 ? 1 : 0);
               method_200(var0, var7, var10, var11, var6 & 65535);
            }
         }
      }
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int, int, boolean) void
   private static void method_1257(Graphics var0, int var1, int var2, int var3, boolean var4) {
      int var5 = var1;
      int var6 = var2;
      int var7 = var4 ? -1 : 1;

      for (int var8 = 0; var8 <= var3; var8++) {
         method_200(var0, 61, var5 + var8 * field_532 * var7, var6 + var8 * field_531, var8 * 2 + (var4 ? 0 : 1));
      }
   }

   // $VF: renamed from: b (javax.microedition.lcdui.Graphics, int, int, int, int, int, boolean) void
   private static void method_1258(Graphics var0, int var1, int var2, int var3, int var4, int var5, boolean var6) {
      method_313(var0, var3);
      int var7 = field_549;
      int var8 = var1 + var4;
      int var9 = var2 + var5;
      int var10 = var8 + field_563 * (var6 ? -1 : 1);
      int var11 = var9 - (field_563 >> 1);
      method_277(var0, var8, var9, var10, var11 - var7, var10, var11);
      method_277(var0, var8, var9, var10, var11 - var7, var8, var9 - var7);
   }

   // $VF: renamed from: c (javax.microedition.lcdui.Graphics, int, int, int, int, int, boolean) void
   private static void method_1259(Graphics var0, int var1, int var2, int var3, int var4, int var5, boolean var6) {
      method_1264(var0, var1 + field_566 + var4 * (var6 ? 1 : -1), var2 + field_567 + var5, 3, 3, var3);
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int, int, int, int, int, int, int, int, int, int, boolean) void
   private static void method_1260(
      Graphics var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, int var11, boolean var12
   ) {
      int var13 = var6 * 60 / 100;
      int var14 = var6 - var13;
      int var15 = var1 + field_553 * (var12 ? -1 : 1);
      int var16 = var2 + field_554;
      if (var3 == 0) {
         int var17 = (var8 < 0 ? -var8 : var8) >> 1;
         int var18 = (var9 < 0 ? -var9 : var9) >> 1;
         int var19 = (var10 < 0 ? -var10 : var10) >> 1;
         int var21;
         int var20 = ((var21 = -var11) < 0 ? -var21 : var21) >> 1;
         method_313(var0, var4);
         method_277(var0, var1, var2 - var6, var15, var16 - var7, var15, var16 - var6);
         method_277(var0, var1, var2 - var6, var15, var16 - var7, var1, var1 - var7);
         method_277(var0, var8, var17 - var7, var1, var2 - var14, var1, var2 - var7);
         method_277(var0, var8, var17 - var7, var1, var2 - var14, var8, var17 - var14);
         method_277(var0, var10, var19 - var7, var9, var18 - var14, var9, var18 - var7);
         method_277(var0, var10, var19 - var7, var9, var18 - var14, var10, var19 - var14);
         method_277(var0, var15, var16 - var7, var11, var20 - var14, var11, var20 - var7);
         method_277(var0, var15, var16 - var7, var11, var20 - var14, var15, var16 - var14);
         method_313(var0, var5);
         method_277(var0, var8, var17 - var14, var1, var2, var1, var2 - var14);
         method_277(var0, var8, var17 - var14, var1, var2, var8, var17);
         method_277(var0, var10, var19 - var14, var9, var18, var9, var18 - var14);
         method_277(var0, var10, var19 - var14, var9, var18, var10, var19);
         method_277(var0, var15, var16 - var14, var11, var20, var11, var20 - var14);
         method_277(var0, var15, var16 - var14, var11, var20, var15, var16);
      } else {
         method_313(var0, var4);
         method_277(var0, var1, var2 - var6, var15, var16 - var14, var15, var16 - var6);
         method_277(var0, var1, var2 - var6, var15, var16 - var14, var1, var2 - var14);
         method_313(var0, var5);
         method_277(var0, var1, var2 - var14, var15, var16, var15, var16 - var14);
         method_277(var0, var1, var2 - var14, var15, var16, var1, var2);
      }

      method_1262(var0, var1, var15, var2 - var6 + 1, var16 - var6);
      if (var3 != 0) {
         method_1262(var0, var1, var15, var2 - 6, var16 - 6);
      } else {
         method_308(var0);
         method_1261(var0, var1, var2, var15, var16, var15, var11);
         method_1261(var0, var1, var2, var15, var16, var10, var9);
         method_1261(var0, var1, var2, var15, var16, var8, 0);
         method_309(var0);
      }
   }

   // $VF: renamed from: d (javax.microedition.lcdui.Graphics, int, int, int, int, int, int) void
   private static void method_1261(Graphics var0, int var1, int var2, int var3, int var4, int var5, int var6) {
      int var7;
      method_310(var0, var5 < var6 ? var5 : var6, -field_53, (var7 = var5 - var6) < 0 ? -var7 : var7, field_53 << 1);
      method_1262(var0, var1, var3, var2 - 6, var4 - 6);
   }

   // $VF: renamed from: r (javax.microedition.lcdui.Graphics, int, int, int, int) void
   private static void method_1262(Graphics var0, int var1, int var2, int var3, int var4) {
      method_313(var0, 15397588);
      method_312(var0, var1, var3, var2, var4);
      method_312(var0, var1, ++var3, var2, ++var4);
      var3++;
      var4++;
      method_313(var0, 12897202);
      method_312(var0, var1, var3, var2, var4);
      var3++;
      var4++;
      method_313(var0, 11976098);
      method_312(var0, var1, var3, var2, var4);
      method_312(var0, var1, ++var3, var2, ++var4);
      var3++;
      var4++;
      method_313(var0, 12897202);
      method_312(var0, var1, var3, var2, var4);
   }

   // $VF: renamed from: j (javax.microedition.lcdui.Graphics, int, int) void
   private static final void method_1263(Graphics var0, int var1, int var2) {
      method_1264(var0, var1 + field_566, var2 + field_567, 4, 4, -1);
   }

   // $VF: renamed from: g (javax.microedition.lcdui.Graphics, int, int, int, int, int) void
   private static void method_1264(Graphics var0, int var1, int var2, int var3, int var4, int var5) {
      int var6 = var3 * var4;

      for (int var7 = 0; var7 < var6; var7++) {
         int var8 = var7 % var3;
         int var9 = var7 / var4;
         int var10 = var1 + var8 * field_516 + var9 * field_518;
         int var11 = var2 + var8 * field_517 + var9 * field_519;
         int var12 = var5 >= 0 ? var5 : field_654[var7 + field_246] + 50;
         method_177(var0, var12, var10, var11);
      }
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, boolean, int, int) void
   private static final void method_1265(Graphics var0, int var1, boolean var2, int var3, int var4) {
      boolean var5 = method_683(var4, 8192);
      boolean var6 = method_683(var4, 16384);
      if (var5 || var6) {
         method_1267(var1);
         int var7 = field_600;
         int var8 = field_601;
         int var9 = var7 + (var2 ? -66 : -3);
         int var10 = var8 - 77 - 77 * var3 / 100;
         var9 += var2 ? 1 : 2;
         var10 -= 2;
         int var11 = var6 ? 1 : 0;
         method_200(var0, 163, var9, var10, var11 + (var2 ? 0 : 2));
      }
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, boolean) void
   private static final void method_1266(Graphics var0, int var1, boolean var2) {
      method_1267(var1);
      int var3 = field_600;
      int var4 = field_601 + 0;
      if (var1 < 2) {
         var3 += -field_527;
      } else {
         var3--;
      }

      var4 += -111 + field_528;
      if (var2) {
         method_200(var0, 59, var3, var4, 2 + (var1 < 2 ? 0 : 1));
      } else {
         int var5 = 3;

         while (--var5 >= 0) {
            method_200(var0, 59, var3, var4, (var5 << 1) + (var1 < 2 ? 0 : 1));
         }
      }
   }

   // $VF: renamed from: bz (int) void
   private static final void method_1267(int var0) {
      switch (var0) {
         case 0:
            field_600 = field_569 + 0;
            field_601 = field_558 + 0;
            return;
         case 1:
            field_600 = field_568 + 0;
            field_601 = field_557;
            return;
         case 2:
            field_600 = field_572 + 0;
            field_601 = field_557;
            return;
         case 3:
            field_600 = field_573 + 0;
            field_601 = field_558 + 0;
      }
   }

   // $VF: renamed from: dM () void
   public static final void method_1268() {
      if (!field_612) {
         if (!field_493) {
            Graphics var0 = field_51;
            boolean var1 = field_416 != field_408 && field_251 >= 0;
            int var2 = method_151(field_465 << 6, 4);
            int var3 = field_257;
            int var4 = method_600() + var2 - (var1 ? 0 : 9);
            int var5 = field_252;
            int var6 = field_252 >= 0 && var5 < field_280 && field_314[var5] == 6 ? 34 : 0;
            if (var5 >= field_287) {
               byte var7;
               if ((var7 = field_300[var5]) == 17) {
                  var6 = 0;
               } else if (var7 >= 7 && var7 <= 10) {
                  var6 -= 19 + 76 * field_479 / 4;
               } else {
                  var6 -= 19;
               }
            }

            method_200(var0, var1 ? 77 : 76, var3 + 2 + (var1 ? -var2 + 11 : -3), var4 + var6, var1 ? 1 : 0);
         }
      }
   }

   // $VF: renamed from: g (javax.microedition.lcdui.Graphics) void
   public static final void method_1269(Graphics var0) {
      byte var1 = field_416;
      int var2 = 10;

      while (--var2 >= 0) {
         if (field_396[var1][var2] != -1 && method_888(var1, var2, 1)) {
            int var4 = field_401[var1][var2];
            int var5 = field_402[var1][var2];
            if ((field_274 == 1 || field_274 == 2) && field_251 >= 0 && !method_629(field_251)) {
               method_200(var0, 80, var4, var5, field_465 + (var2 << 1));
            }

            method_177(var0, 79, var4, var5);
         }
      }
   }

   // $VF: renamed from: a (boolean, int, boolean) void
   public static final void method_1270(boolean var0, int var1, boolean var2) {
      if (var1 >= 0) {
         int var3 = method_181(var1);
         int var4 = method_182(var1);
         field_600 = 0;
         field_601 = 0;
         if (var0) {
            if (var1 == 158) {
               if (var2) {
                  field_600 = -var4 * 47 / 100;
               } else {
                  field_600 = -var4 * 20 / 100;
               }

               field_601 = -var4 * 77 / 100;
               return;
            }

            if (var1 == 157) {
               field_600 = -var3 * 68 / 100;
               field_601 = -var4 * 74 / 100;
               return;
            }

            if (var1 == 159) {
               field_600 = -var3 * 45 / 100;
               field_601 = -var4 * 70 / 100;
               return;
            }

            if (var1 == 161) {
               field_600 = var2 ? 0 : -var3 * 10 / 100;
               field_601 = var4 * 80 / 100;
               return;
            }

            if (var1 == 139) {
               field_601 = var4 * 10 / 100;
               return;
            }

            if (var1 == 140) {
               field_601 = var4 * 8 / 100;
               return;
            }

            if (var1 == 141) {
               field_600 = var3 * 6 / 100;
               field_601 = var4 * 8 / 100;
               return;
            }

            if (var1 == 142) {
               field_601 = var4 * 15 / 100;
               return;
            }

            if (var1 == 143) {
               field_601 = var4 * 10 / 100;
               return;
            }

            if (var1 == 144) {
               field_601 = var4 * 15 / 100;
               return;
            }

            if (var1 == 145) {
               field_600 = 0;
               field_601 = var4 * 10 / 100;
               return;
            }

            if (var1 == 146) {
               field_600 = var2 ? var3 * 12 / 100 : -var3 * 18 / 100;
               field_601 = var2 ? var4 * 8 / 100 : var4 * 12 / 100;
               return;
            }

            if (var1 == 148) {
               field_601 = var4 * 50 / 100;
               return;
            }

            if (var1 == 149) {
               field_600 = var3 * 15 / 100;
               field_601 = var4 * 60 / 100;
               return;
            }

            if (var1 == 150) {
               field_600 = var2 ? 0 : var3 * 20 / 100;
               field_601 = var4 * 65 / 100;
               return;
            }

            if (var1 == 151) {
               field_601 = var4 * 50 / 100;
               return;
            }

            if (var1 == 152) {
               field_600 = var3 * 10 / 100;
               field_601 = var4 * 10 / 100;
               return;
            }
         } else {
            if (var1 == 157) {
               field_600 = -var3 * 10 / 100;
               field_601 = 0;
               return;
            }

            if (var1 == 159) {
               field_600 = var3 * 10 / 100;
               field_601 = -var4 * 5 / 100;
            }
         }
      }
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int, int, int, int) boolean
   public static final boolean method_1271(Graphics var0, int var1, int var2, int var3, int var4, int var5) {
      method_278(var0, var1, var2, var3, var4, var5);
      return true;
   }

   // $VF: renamed from: aX (int) void
   public static final void method_1272(int var0) {
      int var1 = field_304[var0];
      int var2 = field_305[var0];
      method_1216(var1, var2);
      method_1072(field_600, field_601);
   }

   // $VF: renamed from: aW () boolean
   public static final boolean method_1273() {
      return true;
   }

   // $VF: renamed from: aX () boolean
   public static final boolean method_1274() {
      return false;
   }

   // $VF: renamed from: U () int
   public static final int method_1275() {
      int var0;
      if ((var0 = method_1276(field_52, 0, 400) * field_486) == 0) {
         field_716 = false;
      }

      if (var0 != 0) {
         method_413(true);
      }

      return var0;
   }

   // $VF: renamed from: i (int, int, int) int
   public static final int method_1276(int var0, int var1, int var2) {
      int var3;
      if ((var3 = field_715 ? method_579(var0, var1, method_402(), var2) : 0) != 0) {
         method_413(true);
      }

      return var3;
   }

   // $VF: renamed from: o (javax.microedition.lcdui.Graphics, int, int, int, int) void
   public static final void method_1277(Graphics var0, int var1, int var2, int var3, int var4) {
      int var5 = var4 >= 0 ? method_151((field_155 + var4 << 4) % 256, 32) : 32;
      byte var6 = 14;

      for (int var7 = 8; --var7 >= 0; var6 += 7) {
         method_279(var0, var3 | var5 << 24);
         method_317(var0, var1 - (var6 >> 1), var2 - (var6 >> 1), var6, var6);
         var5 >>= 1;
      }
   }

   // $VF: renamed from: e (boolean) boolean
   public static final boolean method_1278(boolean var0) {
      return method_1279(var0, method_402(), false);
   }

   // $VF: renamed from: a (boolean, int, boolean) boolean
   public static final boolean method_1279(boolean var0, int var1, boolean var2) {
      if ((!var0 || field_615) && (var0 || !field_615)) {
         int var3;
         if ((var3 = method_149(var1, 400)) >= 400) {
            if (var0) {
               field_615 = false;
            }

            return true;
         } else {
            Graphics var4 = field_51;
            int var5 = var2 ? 16777215 : 21;
            method_313(var4, var5);
            int var6 = (var0 ? 400 - var3 : var3) * field_52 / 400;
            method_315(var4, 0, 0, var6, field_53);
            int var7 = field_52 / 10;
            method_1271(var4, var6, 0, var7, field_53, -1442840576 | var5);
            method_1271(var4, var6 + var7, 0, var7, field_53, 1711276032 | var5);
            method_413(true);
            return false;
         }
      } else {
         return true;
      }
   }

   // $VF: renamed from: J (int, int) void
   public static final void method_1280(int var0, int var1) {
      Graphics var2 = field_51;
      if (RemasterArt.button(var2, var0, 0, field_52-var0-var1, field_53, false, "")) return;
      if (field_53 <= 24) {
         method_1281(var2, 66, 0, var0, var1);
      } else {
         method_308(var2);
         int var4 = 1 + (field_53 - 16) / 8;

         while (--var4 >= 0) {
            int var5 = 8 + var4 * 8;
            method_310(var2, 0, var5, field_52, 8);
            method_1281(var2, 66, var5 - 8, var0, var1);
         }

         method_310(var2, 0, 0, field_52, 12);
         method_1281(var2, 66, 0, var0, var1);
         method_310(var2, 0, field_53 - 12, field_52, 12);
         method_1281(var2, 66, field_53 - 24, var0, var1);
         method_309(var2);
      }
   }

   // $VF: renamed from: s (javax.microedition.lcdui.Graphics, int, int, int, int) void
   private static void method_1281(Graphics var0, int var1, int var2, int var3, int var4) {
      int var5 = var3;
      int var6;
      int var7;
      int var9 = (var7 = (var6 = field_52 - var3 - var4) - 26) / 13;

      while (--var9 >= 0) {
         method_200(var0, var1, var5 + (1 + var9) * 13, var2, 1);
      }

      if (var7 % 13 > 0) {
         method_200(var0, var1, var5 + var6 - 26, var2, 1);
      }

      method_177(var0, var1, var5, var2);
      method_200(var0, var1, var5 + var6 - 13, var2, 2);
   }

   // $VF: renamed from: a (long, int, int) long
   public static final long method_1282(long var0, int var2, int var3) {
      int var4 = (int)(var0 >> 32) & 65535;
      int var5 = (int)(var0 >> 48) & 65535;
      int var6 = (int)var0 & 65535;
      int var7 = (int)(var0 >> 16) & 65535;
      return method_67(var5 + var2, var4 + var3, var7, var6);
   }

   // $VF: renamed from: c (javax.microedition.lcdui.Graphics, int, int, int, int, int, int, int) void
   public static final void method_1283(Graphics var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7) {
      int var8 = var6 / var7;
      var8 = method_148(1, var8);
      int var9 = var6 / var8 + 1;

      for (int var10 = 0; var10 <= var8; var10++) {
         int var11 = var4 + var6 * var10 / (var8 + 1);
         int var12 = var8 - var10;
         int var13 = method_324(var1, var12, var2, var10);
         method_313(var0, var13);
         method_315(var0, var3, var11, var5, var9);
      }
   }

   // $VF: renamed from: f (int, int, int, int) void
   public static final void method_1284(int var0, int var1, int var2, int var3) {
      Graphics var4 = field_51;
      int var5 = var3 / 8;
      var5 = method_148(1, method_149(var5, 5));
      int var6 = var3 / var5 + 1;

      for (int var7 = 0; var7 <= var5; var7++) {
         int var8 = var2 + var3 * var7 / (var5 + 1);
         int var9 = var5 - var7;
         int var10 = method_324(var0, var9, var1, var7);
         method_313(var4, var10);
         method_315(var4, 0, var8, field_52, var6);
         if (var6 > 4) {
            method_319(var4, 0, var8 - 2, field_52 - 1);
         }
      }

      method_313(var4, var0);
      method_315(var4, 0, 0, field_52, var2);
      method_313(var4, var1);
      method_315(var4, 0, var2 + var3, field_52, field_53 - (var2 + var3));
   }

   // $VF: renamed from: f (java.lang.String) void
   public static final void method_1285(String var0) {
      int var1 = method_208(0, var0);
      int var2 = method_211(0);
      if (var1 < field_52 && var2 < field_53) {
         method_66(0, var0, 3);
      } else {
         var1 = method_208(2, var0);
         var2 = method_211(2);
         if (var1 < field_52 && var2 < field_53) {
            method_66(2, var0, 3);
         } else {
            method_332(field_51, 0, 0, field_52, field_53, var0, 1, 1, 3, true);
         }
      }
   }

   // $VF: renamed from: a (boolean, int) void
   public static final void method_1286(boolean var0, int var1) {
      method_1280(0, field_52 & 1);
      method_1287(var1, var0, false);
   }

   // $VF: renamed from: e (int, boolean, boolean) void
   public static final void method_1287(int var0, boolean var1, boolean var2) {
      int var3 = 0;
      switch (var0) {
         case 1:
            var3 = var2 ? 2 : 4;
            break;
         case 2:
            var3 = var2 ? 1 : 7;
            break;
         case 3:
         case 5:
         case 6:
         case 7:
         default:
            return;
         case 4:
            var3 = var2 ? 3 : 5;
            break;
         case 8:
            var3 = var2 ? 0 : 6;
      }

      method_200(field_51, var3, (field_52 >> 1) + 0, (field_53 >> 1) + 0, var1 ? 1 : 0);
   }

   // $VF: renamed from: aY () boolean
   public static final boolean method_1288() {
      return method_345() != field_613;
   }

   // $VF: renamed from: h (javax.microedition.lcdui.Graphics) void
   public static final void method_1289(Graphics var0) {
      method_1290(var0, false, false, null, null, false);
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, boolean, boolean, java.lang.String, java.lang.String, boolean) boolean
   public static final boolean method_1290(Graphics var0, boolean var1, boolean var2, String var3, String var4, boolean var5) {
      boolean var6 = false;
      int var7 = var5 ? method_381(true, var5) : 1;
      String var8;
      String var9;
      if (var2) {
         var8 = var3;
         var9 = var4;
      } else {
         var8 = method_405();
         var9 = method_406();
      }

      if (var8 != null) {
         int var10 = method_208(var7, var8) + 17;
         long var11 = method_67(4, 294, var10, 23);
         if (!var1) {
            var6 = false | method_1291(var0, var5, var11, var8);
         }
      }

      if (var9 != null) {
         int var13 = method_208(var7, var9) + 17;
         long var14 = method_67(236 - var13, 294, var13, 23);
         if (!var1) {
            var6 |= method_1291(var0, var5, var14, var9);
         }
      }

      return var6;
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, boolean, long, java.lang.String) boolean
   public static boolean method_1291(Graphics var0, boolean var1, long var2, String var4) {
      int var5 = var1 ? method_381(true, var1) : 1;
      method_61(var2);
      if(RemasterArt.button(var0,0,0,field_52,field_53,false,var4)){
         method_64();
         return false;
      }
      method_1280(0, 0);
      method_205(var5, var0, var4, field_52 >> 1, field_53 >> 1, 3);
      RemasterArt.button(var0, 0, 0, field_52, field_53, false, var4);
      method_64();
      return false;
   }

   // $VF: renamed from: x (int, int) int
   public static final int method_1292(int var0, int var1) {
      int var2 = (var0 & 0xFF0000) >> 16;
      int var3 = (var0 & 0xFF00) >> 8;
      int var4 = var0 & 0xFF;
      int var5 = (var1 & 0xFF0000) >> 16;
      int var6 = (var1 & 0xFF00) >> 8;
      int var7 = var1 & 0xFF;
      int var8 = var5 > 128 ? 255 - ((255 - (var5 - 128 << 1)) * (255 - var2) >> 8) : var5 * var2 << 1 >> 8;
      int var9 = var6 > 128 ? 255 - ((255 - (var6 - 128 << 1)) * (255 - var3) >> 8) : var6 * var3 << 1 >> 8;
      int var10 = var7 > 128 ? 255 - ((255 - (var7 - 128 << 1)) * (255 - var4) >> 8) : var7 * var4 << 1 >> 8;
      return var8 << 16 | var9 << 8 | var10;
   }

   // $VF: renamed from: aZ () boolean
   public static final boolean method_1293() {
      return false;
   }

   // $VF: renamed from: ba () boolean
   public static final boolean method_1294() {
      return false;
   }

   // $VF: renamed from: bb () boolean
   public static final boolean method_1295() {
      return method_1294();
   }

   // $VF: renamed from: bc () boolean
   public static final boolean method_1296() {
      return method_1295();
   }

   // $VF: renamed from: a (f, boolean) void
   public static final void method_1297(RichTextLayout var0, boolean var1) {
      byte var2 = 0;
      short var3 = 0;
      short var4 = 0;
      short var5 = 0;
      if (var1) {
         boolean var6 = false;
         var2 = 83;
         var3 = 82;
         var4 = 121;
         var5 = 181;
      } else {
         var2 = 36;
         var3 = 137;
         var4 = 168;
         var5 = 126;
      }

      long var13 = method_67(var2, var3, var4, var5);
      String var8 = RichTextLayout.method_9();
      var0.method_7(var13, 1, 2, 11);
      if (var8 != null) {
         var0.method_8(var8);
      }

      field_717 = var1;
   }

   // $VF: renamed from: a (int, int, int, int, int, int, int, int, int, boolean) void
   public static final void method_1298(int var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, boolean var9) {
      boolean var10 = var1 >= 0;
      int var11 = var4 - var3;
      int var13 = -method_184(var0) + (var9 ? method_182(var0) : 0) - var3;
      int var14 = var7 + var13;
      int var15 = var8 + var13 - var11;
      field_601 = var14 + var15 >> 1;
      if (var10) {
         int var16 = var2 - var1;
         int var18 = -method_183(var0) - var1;
         int var19 = var5 + var18;
         int var20 = var6 + var18 - var16;
         field_600 = var19 + var20 >> 1;
      }
   }

   // $VF: renamed from: dN () void
   public static final void method_1299() {
      method_437();
      method_413(true);
   }

   // $VF: renamed from: a (long, long, long, boolean, boolean, int, int, boolean) void
   public static final void method_1300(long var0, long var2, long var4, boolean var6, boolean var7, int var8, int var9, boolean var10) {
      method_1301(method_327(), var0, var2, var4, var8, var9, false, var6, var10);
   }

   // $VF: renamed from: a (f, long, long, long, int, int, boolean, boolean, boolean) boolean
   public static final boolean method_1301(RichTextLayout var0, long var1, long var3, long var5, int var7, int var8, boolean var9, boolean var10, boolean var11) {
      if (var11) {
         var8 = (field_53 - 181 >> 1) - 82;
      }

      if (var1 != 0L && method_1302(var1, var7, var8, var10, false, -1L)) {
         return false;
      } else if (var0 == null) {
         return false;
      } else {
         Graphics var12 = field_51;
         if (var0.field_0 == 1) {
            long var13 = var0.field_6;
            int var15 = method_68(var0.field_6) - 6;
            int var16 = method_69(var13) - 0;
            int var17 = method_70(var13) + 12;
            int var18 = method_71(var13) + 0;
            method_62(method_67(var15, var16, var17, var18), var7, var8);
            method_313(var12, 5200221);
            method_319(var12, 0, field_53 - 1, field_52);
            method_320(var12, field_52 - 1, 0, field_53);
            method_1271(var12, 0, 0, field_52, field_53, 855638016);
            method_64();
         }

         boolean var19;
         if ((var19 = method_1296()) != field_717) {
            method_1297(method_328(1), var19);
         }

         var0.method_1(var12, var7, var8);
         if (RichTextLayout.method_4()) {
            method_62(var5, var7, var8);
            if (var9) {
               method_1287(2, false, true);
            } else {
               method_1287(4, false, true);
            }

            method_64();
         }

         if (RichTextLayout.method_5()) {
            method_62(var3, var7, var8);
            if (var9) {
               method_1287(8, false, true);
            } else {
               method_1287(1, false, true);
            }

            method_64();
         }

         return false;
      }
   }

   // $VF: renamed from: a (long, int, int, boolean, boolean, long) boolean
   public static final boolean method_1302(long var0, int var2, int var3, boolean var4, boolean var5, long var6) {
      if (var4) {
         boolean var9 = method_403() == 66;
         int var10 = var6 >= 0L ? 200 : (var9 ? 700 : 500);
         int var11;
         if ((var11 = method_402()) <= var10) {
            int var12 = method_70(var0);
            int var13 = method_71(var0);
            int var14 = method_68(var0);
            int var15 = method_69(var0);
            int var16;
            int var17;
            if (var6 >= 0L) {
               int var18 = method_68(var6);
               int var19 = method_69(var6);
               int var20 = method_70(var6);
               int var21 = method_71(var6);
               var14 = method_579(var18, var14, var11, var10);
               var15 = method_579(var19, var15, var11, var10);
               var17 = method_579(var20, var12, var11, var10);
               var16 = method_579(var21, var13, var11, var10);
            } else {
               var17 = method_579(0, var12, var11, var10);
               var16 = method_579(0, var13, var11, var10);
               var14 += var12 - var17 >> 1;
               var15 += var13 - var16 >> 1;
            }

            var0 = method_67(var14, var15, var17, var16);
            method_413(true);
         }

         method_62(var0, var2, var3);
         method_1344(true, var5);
         method_64();
         return var11 <= var10;
      } else {
         method_62(var0, var2, var3);
         method_1344(true, var5);
         method_64();
         return false;
      }
   }

   // $VF: renamed from: a (boolean, boolean, long, boolean) void
   public static final void method_1303(boolean var0, boolean var1, long var2, boolean var4) {
      method_1300(6192724378386649L, var2, 32089289807167497L, var0, var1, 0, 0, var4);
   }

   // $VF: renamed from: aY (int) void
   public static final void method_1304(int var0) {
      method_1300(6192724378386649L, method_1296() ? 32088447993577481L : 32088684216778761L, 32089289807167497L, false, false, var0, 0, false);
   }

   // $VF: renamed from: s () java.lang.String
   public static String method_1305() {
      return method_133(259);
   }

   // $VF: renamed from: t () java.lang.String
   public static String method_1306() {
      return field_482;
   }

   // $VF: renamed from: u () java.lang.String
   public static String method_1307() {
      method_1018(349, true);
      return method_133(349);
   }

   // $VF: renamed from: v () java.lang.String
   public static String method_1308() {
      String var0 = null;
      String var1 = null;
      String var2 = null;
      String var3 = null;
      String var4 = null;
      String var5 = null;
      if (field_429 == 0) {
         var0 = method_464(field_458);
         var1 = method_463(field_430);
         String var6 = method_462(409, var0, var1, null, null, null, null, null, null);
         field_187.setLength(0);
         method_460(field_187, field_429 + 1, method_1534(), method_133(414 + field_431));
         if (method_1534() > 4) {
            field_187.append(method_462(408, method_133(field_277 ? 233 : 234), null, null, null, null, null, null, null));
            field_187.append('|');
         }

         field_187.append(var6);
         return field_187.toString();
      } else {
         if (field_429 == 1) {
            var0 = method_464(field_445 - field_443);
            var1 = method_464(field_455 - field_444);
            var2 = method_464(field_458);
            var3 = method_463(field_457);
            var4 = method_464(field_459);
            var5 = method_463(method_1007());
         } else if (field_429 == 2) {
            var0 = method_463(field_437);
            var1 = method_463(field_438 + field_439);
            var2 = method_463(field_435);
            var3 = method_463(field_436);
            var4 = method_463(field_452);
            var5 = method_463(field_437 + field_438 + field_439 + field_435 + field_436 + field_452);
         } else if (field_429 == 3) {
            var0 = method_463(field_440);
            var1 = method_463(field_441);
            var2 = method_463(field_453);
            var3 = method_463(field_454);
            var4 = method_463(field_442);
            var5 = method_463(field_440 + field_441 + field_453 + field_454 + field_442);
         } else if (field_429 == 4) {
            var0 = method_133(field_277 ? 233 : 234);
            var1 = method_463(field_452);
         }

         field_187.setLength(0);
         method_460(field_187, field_429 + 1, method_1534(), null);
         field_187.append(method_462(409 + field_429, var0, var1, var2, var3, var4, var5, null, null));
         if (field_429 == 4) {
            field_187.append('|');
            field_187.append('|');
            field_187.append(method_133(276 + method_632(field_466 - 1)));
         }

         return field_187.toString();
      }
   }

   // $VF: renamed from: w () java.lang.String
   public static String method_1309() {
      return method_133(273);
   }

   // $VF: renamed from: x () java.lang.String
   public static String method_1310() {
      return method_133(270);
   }

   // $VF: renamed from: y () java.lang.String
   public static String method_1311() {
      return method_133(271);
   }

   // $VF: renamed from: z () java.lang.String
   public static String method_1312() {
      return method_133(272);
   }

   // $VF: renamed from: A () java.lang.String
   public static String method_1313() {
      return method_1014() ? method_133(315) : method_133(field_466 >= 1 ? 276 + method_632(field_466) : 317 + field_479);
   }

   // $VF: renamed from: B () java.lang.String
   public static String method_1314() {
      return method_133(187 + field_145);
   }

   // $VF: renamed from: C () java.lang.String
   public static String method_1315() {
      return method_1334(field_146);
   }

   // $VF: renamed from: D () java.lang.String
   public final String method_1316() {
      String var1 = null;
      if (field_146 == 0) {
         String var2;
         if ((var2 = method_156("MIDlet-Version")) == null) {
            var2 = "N/A";
         }

         String var3;
         if ((var3 = method_156("MIDlet-Name")) == null) {
            var3 = "N/A";
         }

         var1 = method_462(3, var2, var3, null, null, null, null, null, null);
      }

      field_186.setLength(0);
      method_460(field_186, field_146 + 1, method_1335(), method_1315());
      if (field_146 == 0) {
         field_186.append(var1);
      } else {
         field_186.append(method_133(3 + field_146));
      }

      return field_186.toString();
   }

   // $VF: renamed from: E () java.lang.String
   public static String method_1317() {
      return method_133(260);
   }

   // $VF: renamed from: F () java.lang.String
   public static String method_1318() {
      return method_133(274);
   }

   // $VF: renamed from: G () java.lang.String
   public static String method_1319() {
      return method_133(275);
   }

   // $VF: renamed from: l (int) java.lang.String
   public static final String method_1320(int var0) {
      if (method_412(var0) == 41) {
         return method_1430();
      } else if (method_412(var0) == 40) {
         return method_1405();
      } else if (method_412(var0) == 39) {
         return method_1417();
      } else {
         return method_412(var0) == 33 ? method_482() : method_349(var0);
      }
   }

   // $VF: renamed from: aZ (int) void
   public static void method_1321(int var0) {
      int var1;
      if ((var1 = method_403()) == 114 || method_1590(var1) || method_802(var1)) {
         field_146 += var0;
      } else if (method_634(var1)) {
         method_758(var0);
      } else if (method_530(var1)) {
         method_760(var0);
      } else if (var1 == 46) {
         method_1003(var0);
      } else if (method_803(var1)) {
         method_841(var0);
      } else {
         method_942(var1, var0);
      }

      field_486 = var0;
      method_1049();
   }

   // $VF: renamed from: y (int, int) int
   public static int method_1322(int var0, int var1) {
      int var4 = (int)method_1325(var0) & 65535;
      int var5 = method_345();
      int var6 = method_347();
      if (field_618 && field_616 > var5) {
         field_616 = var5;
      }

      int var7 = 0;
      field_617 = 0;

      for (int var8 = field_616; var8 < var6; var8++) {
         int var9 = method_1339(var0, method_1320(var8), var1);
         if (var7 + var9 > var4 && (!field_618 || var8 > var5)) {
            break;
         }

         var7 += var9;
         field_617++;
      }

      while (var7 > var4) {
         int var10 = method_1339(var0, method_1320(field_616), var1);
         var7 -= var10;
         field_616++;
         field_617--;
      }

      boolean var11 = true;

      while (var7 < var4 && var11) {
         var11 = false;
         if (field_616 > 0) {
            int var12 = method_1339(var0, method_1320(field_616 - 1), var1);
            if (var7 + var12 <= var4) {
               var7 += var12;
               field_616--;
               field_617++;
               var11 = true;
            }
         }

         if (field_616 + field_617 < var6) {
            int var13 = method_1339(var0, method_1320(field_616 + field_617), var1);
            if (var7 + var13 <= var4) {
               var7 += var13;
               field_617++;
               var11 = true;
            }
         }
      }

      return var4 - var7;
   }

   // $VF: renamed from: b (int) long
   public static long method_1323(int var0) {
      switch (var0) {
         case 0:
            return 12103544267735303L;
         case 1:
            return 12103664526819563L;
         case 2:
            return 2533506733179117L;
         case 3:
            return 2533811675857062L;
         default:
            return 0L;
      }
   }

   // $VF: renamed from: c (int) long
   public static long method_1324(int var0) {
      switch (var0) {
         case 2:
            return 6192724378386649L;
         case 3:
            return 6193029321064594L;
         default:
            return 0L;
      }
   }

   // $VF: renamed from: d (int) long
   public static long method_1325(int var0) {
      switch (var0) {
         case 0:
            return 12103647346950357L;
         case 1:
            return 12103767606034617L;
         case 2:
            return 6192805982765235L;
         case 3:
            return 6193106630475886L;
         default:
            return 0L;
      }
   }

   // $VF: renamed from: a (int, boolean) long
   public static long method_1326(int var0, boolean var1) {
      if (var1) {
         switch (var0) {
            case 0:
               return 12103647346950193L;
            case 1:
               return 12103767606034481L;
            case 2:
               return 6192805982765102L;
            case 3:
               return 6193106630475822L;
            default:
               return 0L;
         }
      } else {
         switch (var0) {
            case 0:
               return 12103647346950174L;
            case 1:
               return 12103767606034462L;
            case 2:
               return 6192805982765081L;
            case 3:
               return 6193106630475801L;
            default:
               return 0L;
         }
      }
   }

   // $VF: renamed from: b (int, boolean) long
   public static long method_1327(int var0, boolean var1) {
      if (var1) {
         switch (var0) {
            case 0:
               return 13792522976231462L;
            case 1:
               return 19703617743487014L;
            case 2:
               return 13229688987189290L;
            case 3:
               return 13229989634900010L;
            default:
               return 0L;
         }
      } else {
         switch (var0) {
            case 0:
               return 13792522976231443L;
            case 1:
               return 19703617743486995L;
            case 2:
               return 13229688987189269L;
            case 3:
               return 13229989634899989L;
            default:
               return 0L;
         }
      }
   }

   // $VF: renamed from: e (int) long
   public static long method_1328(int var0) {
      switch (var0) {
         case 2:
            return 2533631273533465L;
         case 3:
            return 2533631273533465L;
         default:
            return 0L;
      }
   }

   // $VF: renamed from: f (int) long
   public static long method_1329(int var0) {
      switch (var0) {
         case 2:
            return 61361901406060569L;
         case 3:
            return 61361901406060569L;
         default:
            return 0L;
      }
   }

   // $VF: renamed from: g (int) long
   public static long method_1330(int var0) {
      switch (var0) {
         case 0:
            return 30399417745473559L;
         case 1:
            return 30399538004557847L;
         case 2:
            return 30399529414623255L;
         case 3:
            return 30399834357301271L;
         default:
            return 0L;
      }
   }

   // $VF: renamed from: h (int) long
   public static long method_1331(int var0) {
      switch (var0) {
         case 0:
            return 30400448537624599L;
         case 1:
            return 30400448537624599L;
         case 2:
            return 30400448537624599L;
         case 3:
            return 30400448537624599L;
         default:
            return 0L;
      }
   }

   // $VF: renamed from: c (int, boolean) long
   public static long method_1332(int var0, boolean var1) {
      if (var1) {
         switch (var0) {
            case 1:
               return 12103814842351643L;
            case 2:
               return 6192853216198681L;
            case 3:
               return 6193153863909401L;
            default:
               return 0L;
         }
      } else {
         switch (var0) {
            case 1:
               return 12103776187645979L;
            case 2:
               return 6192805971558425L;
            case 3:
               return 6193106619269145L;
            default:
               return 0L;
         }
      }
   }

   // $VF: renamed from: dO () void
   public static void method_1333() {
      field_146 = field_146 + method_1048(method_1335(), field_146);
   }

   // $VF: renamed from: m (int) java.lang.String
   public static String method_1334(int var0) {
      return method_133(0 + var0);
   }

   // $VF: renamed from: V () int
   public static int method_1335() {
      return 3;
   }

   // $VF: renamed from: W () int
   public static int method_1336() {
      return 6;
   }

   // $VF: renamed from: n (int) java.lang.String
   public static String method_1337(int var0) {
      return method_133(181 + var0);
   }

   // $VF: renamed from: a (int, java.lang.String, int) boolean
   public static final boolean method_1338(int var0, String var1, int var2) {
      long var3 = method_1327(var0, false);
      int var5 = method_211(var2);
      return method_333((int)(var3 >> 16) & 65535, 320, var1, var2, var2) > var5;
   }

   // $VF: renamed from: b (int, java.lang.String, int) int
   public static final int method_1339(int var0, String var1, int var2) {
      return method_1338(var0, var1, var2) ? method_1340(var0, true) : method_1340(var0, false);
   }

   // $VF: renamed from: b (int, boolean) int
   public static final int method_1340(int var0, boolean var1) {
      return (int)method_1326(var0, var1) & 65535;
   }

   // $VF: renamed from: R (int) int
   public static int method_1341(int var0) {
      int var1;
      if ((var1 = method_412(var0)) == 31) {
         return 536891392 | method_81();
      } else if (var1 == 32) {
         int var2 = method_82();
         return 536891392 | var2;
      } else {
         return 0;
      }
   }

   // $VF: renamed from: K (int, int) void
   public static final void method_1342(int var0, int var1) {
      method_1343(var0, var1, 0);
   }

   // $VF: renamed from: l (int, int, int) void
   public static final void method_1343(int var0, int var1, int var2) {
      int var3 = var0 == 0 ? 2 : 1;
      if (field_614 != method_403()) {
         field_616 = 0;
         field_614 = method_403();
      }

      int var4;
      if ((var4 = method_345()) != field_613) {
         field_618 = true;
      }

      field_613 = var4;
      int var5 = method_1322(var0, var3);
      int var6;
      if (var0 <= 1) {
         var2 += var5 / 2;
         var6 = 0;
      } else {
         long var10000 = method_1325(var0);
         long var7 = 0L;
         int var15 = (int)var10000 & 65535;
         boolean var9 = false;
         var6 = (var5 = var15 % 25) / 2;
      }

      method_62(method_1323(var0), var1, var2);
      if (var0 > 1) {
         method_61(method_1324(var0));
         method_1344(true, false);
         method_64();
      }

      if (field_616 > 0) {
         method_61(method_1330(var0));
         method_1286(false, 1);
         method_64();
      }

      if (field_616 + field_617 < method_347()) {
         long var12 = method_1331(var0);
         if (var0 <= 1) {
            var12 = method_1282(var12, 0, -var5);
         }

         method_61(var12);
         method_1286(false, 4);
         method_64();
      }

      int var13 = field_616 + field_617 - 1;
      int var8 = var6;

      for (int var14 = field_616; var14 <= var13; var14++) {
         method_1345(var0, var14, var8, var3);
         if (var14 == field_613) {
            if (method_501(var14)) {
               method_62(method_1328(var0), 0, var8);
               method_1287(8, false, false);
               method_64();
            }

            if (method_502(var14)) {
               method_62(method_1329(var0), 0, var8);
               method_1287(2, false, false);
               method_64();
            }
         }

         var8 += method_1339(var0, method_1320(var14), var3);
      }

      method_64();
   }

   // $VF: renamed from: c (boolean, boolean) void
   public static final void method_1344(boolean var0, boolean var1) {
      Graphics var2 = field_51;
      if (var0) {
         if (var1) {
            method_65(2173992);
         } else {
            method_308(var2);
            method_310(var2, 6, 6, field_52 - 12, field_53 - 12);
            int var3 = 1 + (field_52 - 12) / 25;
            int var4 = 1 + (field_53 - 12) / 45;
            int var5 = var3;

            while (--var5 >= 0) {
               int var6 = var4;

               while (--var6 >= 0) {
                  method_177(var2, 68, 6 + var5 * 25, 6 + var6 * 45);
               }
            }

            method_309(var2);
         }
      }

      if (field_52 > 12 && field_53 > 9) {
         method_313(var2, 1315860);
         method_319(var2, 2, 0, field_52 - 4);
         method_319(var2, 2, field_53 - 1, field_52 - 4);
         method_320(var2, 0, 2, field_53 - 4);
         method_320(var2, field_52 - 1, 2, field_53 - 4);
         method_313(var2, 6718863);
         method_314(var2, 1, 1, field_52 - 3, field_53 - 3);
         method_313(var2, 15790320);
         method_314(var2, 2, 2, field_52 - 5, field_53 - 5);
         method_313(var2, 12310496);
         method_314(var2, 3, 3, field_52 - 7, field_53 - 7);
         method_313(var2, 6718863);
         method_314(var2, 4, 4, field_52 - 9, field_53 - 9);
         method_313(var2, 2302755);
         method_314(var2, 5, 5, field_52 - 11, field_53 - 11);
         method_200(var2, 72, 0, 0, 0);
         method_200(var2, 72, field_52 - 6, 0, 1);
         method_200(var2, 72, field_52 - 6, field_53 - 6, 2);
         method_200(var2, 72, 0, field_53 - 6, 3);
      }
   }

   // $VF: renamed from: g (int, int, int, int) void
   public static final void method_1345(int var0, int var1, int var2, int var3) {
      boolean var4 = var1 == method_345();
      boolean var5 = method_412(var1) == 39;
      String var6 = method_1320(var1);
      int var7 = method_348(var1);
      boolean var8 = method_1338(var0, var6, var3);
      method_62(method_1326(var0, var8), 0, var2);
      String buttonLabel=var6;
      int optionType=var7 & -268435456;
      if(optionType==536870912 || optionType==268435456){
         String option;
         if(optionType==536870912){
            int level=var7 & 4095;
            option=method_133(level==0?310:311+4*level/5);
         }else option=method_133((var7&1)==0?310:309);
         field_186.setLength(0);field_186.append(method_133(308));
         method_153(field_186,0,var6);method_153(field_186,1,option);
         buttonLabel=field_186.toString();
      }
      int buttonInset=Math.min(3,field_53/8);
      if(RemasterArt.button(field_51,0,buttonInset,field_52,field_53-buttonInset*2,var4,buttonLabel)){
         TouchInput.addMenuItem(var1,field_51.getTranslateX(),field_51.getTranslateY()+buttonInset,field_52,field_53-buttonInset*2);
         if(var7==2)method_938(var0,var1,var8);
         method_64();
         return;
      }
      TouchInput.addMenuItem(var1, field_51.getTranslateX(), field_51.getTranslateY(), field_52, field_53);
      method_1346(var0, var5);
      if (var4) {
         method_1347();
      }

      method_61(method_1327(var0, var8));
      int var11 = method_208(var3, var6);
      int var12 = field_52 / 2 - var11 / 2;
      if ((var7 & -268435456) == 536870912) {
         int var13;
         String var14;
         if ((var13 = var7 & 4095) == 0) {
            var14 = method_133(310);
         } else {
            var13 = 4 * var13 / 5;
            var14 = method_133(311 + var13);
         }

         field_186.setLength(0);
         field_186.append(method_133(308));
         method_153(field_186, 0, var6);
         method_153(field_186, 1, var14);
         if (var8) {
            method_332(field_51, 0, 0, field_52, field_53, field_186.toString(), var3, var3, 3, true);
         } else {
            method_203(var3, field_186.toString(), field_52 >> 1, field_53 >> 1, 3);
         }
      } else if ((var7 & -268435456) == 268435456) {
         int var16 = var7 & 1;
         field_186.setLength(0);
         field_186.append(method_133(308));
         String var17 = var16 == 0 ? method_133(310) : method_133(309);
         method_153(field_186, 0, var6);
         method_153(field_186, 1, var17);
         if (var8) {
            method_332(field_51, 0, 0, field_52, field_53, field_186.toString(), var3, var3, 3, true);
         } else {
            method_203(var3, field_186.toString(), field_52 >> 1, field_53 >> 1, 3);
         }
      } else if (var8) {
         method_332(field_51, 0, 0, field_52, field_53, var6, var3, var3, 3, true);
      } else {
         method_203(var3, var6, var12, field_53 / 2, 6);
      }

      method_64();
      String modernLabel = ((var7 & -268435456) == 536870912 || (var7 & -268435456) == 268435456) ? field_186.toString() : var6;
      RemasterArt.button(field_51, 0, 0, field_52, field_53, var4, modernLabel);
      if (var7 == 2) method_938(var0, var1, var8);

      method_64();
   }

   // $VF: renamed from: j (int, boolean) void
   public static final void method_1346(int var0, boolean var1) {
      if (var0 == 0) {
         method_1356(field_51, var1);
      }
   }

   // $VF: renamed from: hI () void
   private static void method_1347() {
      method_1280(0, 0);
   }

   // $VF: renamed from: a (int, int, boolean, int) void
   public static final void method_1348(int var0, int var1, boolean var2, int var3) {
      if (var0 > 0) {
         method_1349(2815132020637719L, 8, var2, var3, false);
      }

      if (var0 < var1 - 1) {
         method_1349(58265702432636951L, 2, var2, var3, false);
      }
   }

   // $VF: renamed from: a (long, int, boolean, int, boolean) boolean
   public static final boolean method_1349(long var0, int var2, boolean var3, int var4, boolean var5) {
      method_62(var0, var4, 0);
      boolean var8 = false;
      if (var3 && var2 == method_157(field_486, 0)) {
         var8 = true;
      }

      method_1286(var8 && !var5, var2);
      method_64();
      return false;
   }

   // $VF: renamed from: ba (int) void
   public static final void method_1350(int var0) {
      if (var0 == 4) {
         method_65(21);
      } else if (var0 == 5) {
         method_1427();
      } else if (var0 != 1 && var0 != 2) {
         if (var0 == 3) {
            method_1219(field_416 == field_408);
         }
      } else {
         method_1351();
      }
   }

   // $VF: renamed from: dP () void
   public static final void method_1351() {
      method_1378(true);
   }

   // $VF: renamed from: bb (int) void
   public static final void method_1352(int var0) {
      method_1343(2, var0, 0);
   }

   // $VF: renamed from: a (java.lang.String, int, boolean) void
   public static final void method_1353(String var0, int var1, boolean var2) {
      method_1354(var0, var1, var2);
   }

   // $VF: renamed from: b (java.lang.String, int, boolean) void
   public static final void method_1354(String var0, int var1, boolean var2) {
      if (var0 != null) {
         Graphics var3 = field_51;
         method_62(15728693L, var1, 0);
         if (var2) {
            int var5 = 1 + field_52 / 30;

            while (--var5 >= 0) {
               method_177(var3, 67, var5 * 30, field_53 - 47 >> 1);
            }

            if (field_53 < 42) {
               method_313(var3, 8294807);
               method_319(var3, 0, field_53 - 1, field_52 - 1);
            }
         }

         method_64();
         method_62(562954263855156L, var1, 0);
         method_1285(var0);
         method_64();
      }
   }

   // $VF: renamed from: a (java.lang.String, boolean, long) void
   public static final void method_1355(String var0, boolean var1, long var2) {
      if (field_630 && method_1404()) {
         method_65(0);
         method_1412();
      } else {
         int var4 = method_333(176, 77, var0, 1, 1);
         if (field_473 || var4 >= 77) {
            if (method_327() != null) {
               method_1303(true, var1, 32088447993577481L, true);
            }
         } else {
            int var8 = (320 - var4) * 40 / 100;
            long var9 = method_67(32, var8, 176, var4);
            var8 -= 24;
            int var7 = var4 + 48;
            long var11 = method_67(8, var8, 224, var7);
            Graphics var13 = field_51;
            if (method_1302(var11, 0, 0, true, false, var2)) {
               method_413(false);
            } else {
               method_61(var9);
               boolean var14 = var4 <= method_211(1) * 3;
               method_332(var13, 0, 0, field_52, field_53, var0, 1, 1, 2 | (var14 ? 1 : 4), true);
               method_64();
            }
         }
      }
   }

   // $VF: renamed from: b (javax.microedition.lcdui.Graphics, boolean) void
   public static final void method_1356(Graphics var0, boolean var1) {
      int var2 = (field_52 - 20) / 62;
      int var3 = field_53 - 28 >> 1;
      method_308(var0);
      method_310(var0, 10, 0, field_52 - 20, field_53);
      int var4 = var2;

      while (--var4 >= 0) {
         method_200(var0, var1 ? 46 : 69, 10 + var4 * 62, var3, 1 + (var4 & 1));
      }

      method_200(var0, var1 ? 46 : 69, field_52 - 10 - 62, var3, 1);
      method_309(var0);
      method_200(var0, var1 ? 47 : 70, 0, var3, 0);
      method_200(var0, var1 ? 47 : 70, field_52 - 10, var3, 1);
   }

   // $VF: renamed from: L (int, int) void
   public static final void method_1357(int var0, int var1) {
      if (method_1273() || method_1288()) {
         method_1350(var0);
         method_1343(0, var1, 0);
         method_1289(field_51);
      }
   }

   // $VF: renamed from: a (java.lang.String, int, boolean, int, boolean) void
   public static final void method_1358(String var0, int var1, boolean var2, int var3, boolean var4) {
      if (method_1273() || method_1288()) {
         method_1350(var1);
         if (var2) {
            method_1380(var4);
         }

         method_1353(var0, var3, true);
         method_1342(2, var3);
         method_1289(field_51);
      }
   }

   // $VF: renamed from: a (java.lang.String, int, int, boolean) void
   public static final void method_1359(String var0, int var1, int var2, boolean var3) {
      if (method_1273() || method_1288()) {
         method_1350(var1);
         method_1352(var2);
         method_1354(var0, var2, true);
         method_1289(field_51);
      }
   }

   // $VF: renamed from: a (java.lang.String, int, boolean, boolean, long, boolean) void
   public static final void method_1360(String var0, int var1, boolean var2, boolean var3, long var4, boolean var6) {
      if (method_1273()) {
         method_1350(var1);
         if (var2) {
            method_1380(var3);
         }

         method_1303(false, false, var4, false);
         method_1354(var0, 0, true);
         method_1289(field_51);
      }
   }

   // $VF: renamed from: a (java.lang.String, int, int, int, boolean, boolean, int, int, boolean) void
   public static final void method_1361(String var0, int var1, int var2, int var3, boolean var4, boolean var5, int var6, int var7, boolean var8) {
      if (method_1273()) {
         method_1350(var3);
         method_1304(var6);
         method_1362(var6, false, -1);
         method_1348(var1, var2, var5, var6);
         method_1353(var0, var7, true);
         if (var4) {
            method_1289(field_51);
         }
      }
   }

   // $VF: renamed from: a (int, boolean, int) void
   public static final void method_1362(int var0, boolean var1, int var2) {
      int var3;
      if ((var3 = var2 >= 0 ? var2 : method_1363(var1)) >= 0) {
         if (method_1296()) {
            method_1242(field_51, var3, field_299[var3], 56 + var0, 150, false, false, false);
         } else {
            method_308(field_51);
            method_310(field_51, 0, 67, field_52, 58);
            method_1242(field_51, var3, field_299[var3], 120 + var0, 130, false, false, false);
            int var4;
            int var5 = (var4 = (field_52 >> 1) + var0) - 18;
            int var6 = var4 + 18;
            method_313(field_51, 3351091);
            method_319(field_51, var5, 124, var6);
            method_313(field_51, 2236962);
            method_319(field_51, var5, 123, var6);
            method_309(field_51);
         }
      }
   }

   // $VF: renamed from: c (boolean) int
   public static final int method_1363(boolean var0) {
      if (field_620 < 0 || field_299[field_620] < 0) {
         if (var0) {
            int var1 = method_152(field_283);
            int var2 = field_283;

            while (--var2 >= 0) {
               int var3 = (var1 + var2) % field_283;
               if (field_299[var3] >= 0) {
                  field_620 = var3;
                  break;
               }
            }
         } else {
            method_666();
            field_620 = method_152(100) < 60 ? method_673(0 + method_152(3), 1) : method_671(field_407, 0, 0);
            if (field_620 >= field_286 && field_620 <= field_289) {
               method_682(field_620, 1024, method_152(100) < 20, false);
            }

            field_428 = 1;
         }
      }

      return field_620;
   }

   // $VF: renamed from: c (java.lang.String, int, boolean) void
   public static final void method_1364(String var0, int var1, boolean var2) {
      if (method_1273()) {
         method_1350(var1);
         method_1353(var0, 0, true);
         method_1355(RichTextLayout.method_9(), false, -1L);
         method_1289(field_51);
      }
   }

   // $VF: renamed from: a (java.lang.String, java.lang.String, int, long, boolean) void
   public static final void method_1365(String var0, String var1, int var2, long var3, boolean var5) {
      if (method_1273()) {
         method_1350(var2);
         method_1353(var0, 0, true);
         method_1355(var1, false, var3);
         method_1289(field_51);
      }
   }

   // $VF: renamed from: dQ () void
   public static final void method_1366() {
      method_1219(field_416 == field_408);
      method_1289(field_51);
   }

   // $VF: renamed from: a (java.lang.String, java.lang.String, long, boolean) void
   public static final void method_1367(String var0, String var1, long var2, boolean var4) {
      if (method_1273()) {
         method_1219(field_416 == field_408);
         method_1353(var0, 0, true);
         method_1380(var4);
         method_1355(var1, false, var2);
         method_1289(field_51);
      }
   }

   // $VF: renamed from: a (java.lang.String, java.lang.String, byte) void
   public static final void method_1368(String var0, String var1, byte var2) {
      int var3 = method_1276(field_52, 0, 400);
      long var4 = method_1373(true, true, var0, var1, true, var2, false, false, true, var3, var3, true, false);
      method_62(6192724378386649L, var3, 0);
      method_63(method_68(var4), method_69(var4), method_70(var4), method_71(var4));
      method_1242(field_51, field_474, field_299[field_474], field_52 >> 1, method_1506(12), false, false, true);
      method_64();
      method_64();
   }

   // $VF: renamed from: dR () void
   public static final void method_1369() {
      field_615 = true;
      method_1584();
      method_413(true);
   }

   // $VF: renamed from: k (int, boolean) void
   public static final void method_1370(int var0, boolean var1) {
      if (method_1278(false)) {
         method_1371(var0, var1);
      }
   }

   // $VF: renamed from: l (int, boolean) void
   public static final void method_1371(int var0, boolean var1) {
      if (method_1273()) {
         method_65(21);
      }

      method_1372(var0);
   }

   // $VF: renamed from: bc (int) void
   public static final void method_1372(int var0) {
      Graphics var1 = field_51;
      String var2 = null;
      if (var0 >= 0) {
         var2 = method_133(var0);
      }

      int var3 = method_211(0);
      int var4 = field_52 >> 1;
      int var5 = 35 * field_53 / 100;
      Image var6;
      if ((var6 = method_185(64, 0)) != null) {
         method_177(var1, 64, var4, var5);
      }

      int var7 = 0;
      int var8 = field_53 / 10;
      int var9 = 45 * var8 / 100 + var5;
      if (method_185(65, 0) != null) {
         var8 = var3 * 172 / 100;
         var7 = method_151(field_155 << 7, method_148(1, var8 >> 5));
         var9 = 45 * var8 / 100 + var5;
         method_177(var1, 65, var4, var9 + var7 + 0);
      }

      if (var6 != null) {
         method_313(var1, 16777215);
         int var10 = var4 - 38;
         int var11 = var5 + 6;
         int var12 = var4 - 23;
         int var13 = var5 + 13;
         method_308(var1);
         int var14 = field_155 << 1;
         int var15 = var12 - var10 + 6;
         int var16 = var10 - 6 + (var15 - var14 % var15);
         method_310(var1, var16, var11, 6, 33);
         method_312(var1, var10, var11, var12, var13);
         method_309(var1);
      }

      int var17 = field_52 >> 1;
      int var18 = -var7 + var9 + (var8 >> 1) + (var3 >> 1);
      if (method_211(0) == method_211(1)) {
         var18 += method_211(0) >> 1;
      }

      if (var2 != null) {
         method_205(0, var1, var2, var17, var18, 3);
      }

      method_413(true);
   }

   // $VF: renamed from: a (boolean, boolean, java.lang.String, java.lang.String, boolean, byte, boolean, boolean, boolean, int, int, boolean, boolean) long
   public static final long method_1373(
      boolean var0,
      boolean var1,
      String var2,
      String var3,
      boolean var4,
      byte var5,
      boolean var6,
      boolean var7,
      boolean var8,
      int var9,
      int var10,
      boolean var11,
      boolean var12
   ) {
      if (method_415() && var0) {
         if (var1) {
            method_1219(field_416 == field_408);
            method_1380(var12);
         } else {
            method_1378(true);
         }
      }

      Graphics var15 = field_51;
      int var16 = method_402();
      if (var9 != 0 || var16 < 500) {
         method_413(true);
      }

      method_62(6192724378386649L, var9, 0);
      method_65(2236962);
      method_1344(false, false);
      int var17 = method_148(21, 28);
      int var18 = field_53 - var17 - 7;
      int var19 = field_52 - 12;
      int var20 = field_52 - var19 >> 1;
      int var21 = method_148(6, var4 ? 12 : 3);
      int var22 = var18 - var21;
      method_63(var20, var21, var19, var22);
      long var13 = method_67(var20, var21, var19, var22);
      method_1375(var15);
      method_64();
      int var23 = field_52 - 12;
      method_63(field_52 - var23 >> 1, var18, var23, var17);
      var3 = method_459(var3);
      method_1346(0, false);
      method_1374(var15, var3);
      method_64();
      method_64();
      if (var6 || var7) {
         method_1376(var6, var7, var9, var11);
      }

      method_1353(var2, var10, true);
      if (method_415() && var8) {
         method_1289(field_51);
      }

      if (var4) {
         method_63(26 + var9, 52, 94, 24);
         method_1377((byte)2, field_446, field_448, field_447);
         method_64();
         method_63(120 + var9, 52, 94, 24);
         method_1377(var5, field_449, field_451, field_450);
         method_64();
         method_177(var15, 88, 167 + var9, 76 - 3 * field_525 / 90);
      }

      return method_1025() ? 0L : var13;
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, java.lang.String) void
   public static final void method_1374(Graphics var0, String var1) {
      method_313(var0, 6718863);
      method_319(var0, 0, 0, field_52 - 1);
      method_319(var0, 0, field_53, field_52 - 1);
      method_313(var0, 12310496);
      method_319(var0, 0, 1, field_52 - 1);
      method_319(var0, 0, field_53 - 1, field_52 - 1);
      int var2;
      if ((var2 = method_208(1, var1)) < field_52 - 12) {
         method_66(1, var1, 3);
      } else {
         int var3 = field_52 + var2;
         method_205(1, var0, var1, var3 - ((method_401() - field_619 >> 5) + (field_52 >> 1)) % var3 - var2, field_53 >> 1, 6);
         method_413(false);
      }
   }

   // $VF: renamed from: i (javax.microedition.lcdui.Graphics) void
   public static final void method_1375(Graphics var0) {
      int var1 = field_53 + 1;
      method_313(var0, field_502[3]);
      method_315(var0, 0, 0, field_52, var1 - 1);
      int var2 = 4;

      while (--var2 >= 0) {
         int var3 = field_502[var2 % 4];
         method_313(var0, var3);
         int var4 = var1 / 8;
         int var5 = var2 == 2 ? var4 * 30 / 100 : 0;
         method_315(var0, 0, 0 + var2 * var4, field_52, var4 - var5);
         method_315(var0, 0, field_53 - (1 + var2) * var4 + var5, field_52, var4 - var5);
         int var6 = var3 | 855638016;
         method_1271(var0, 0, 0 + var2 * var4 - 8, field_52, var4 + 16, var6);
         method_1271(var0, 0, field_53 - (1 + var2) * var4 - 8, field_52, var4 + 16, var6);
      }

      method_313(var0, 2171426);
      method_315(var0, 0, 0, field_52, 3);
      method_315(var0, 0, field_53 - 3, field_52, 3);
   }

   // $VF: renamed from: a (boolean, boolean, int, boolean) void
   public static final void method_1376(boolean var0, boolean var1, int var2, boolean var3) {
      if (var0 && method_1349(2815132020637719L, 8, false, var2, var3)) {
         method_1321(-1);
      }

      if (var1 && method_1349(58265702432636951L, 2, false, var2, var3)) {
         method_1321(1);
      }
   }

   // $VF: renamed from: a (byte, byte[], int[], byte[]) void
   public static final void method_1377(byte var0, byte[] var1, int[] var2, byte[] var3) {
      method_1280(0, 0);
      Graphics var4 = field_51;
      int var5 = field_53 * 15 / 100;
      int var6;
      method_63(var6 = field_52 * 7 / 100, var5, field_52 - (var6 << 1), field_53 - (var5 << 1));
      if (!method_1271(var4, 0, 0, field_52, field_53, 1996488704)) {
         method_65(0);
      }

      method_64();
      int var8 = field_52 - 69 >> 1;
      if (var0 == 2) {
         method_177(var4, 85, var8, field_53 - 14 >> 1);
      } else {
         method_200(var4, 86, var8, field_53 - 14 >> 1, var0);
      }

      method_1228(var4, 13 + var8, 1 + (field_53 - 17 >> 1), var1, var2, var3);
   }

   // $VF: renamed from: n (boolean) void
   public static final void method_1378(boolean var0) {
      method_595(field_51, var0);
   }

   // $VF: renamed from: g (java.lang.String) void
   public static final void method_1379(String var0) {
      method_1380(false);
      method_1355(var0, true, -1L);
      method_1289(field_51);
   }

   // $VF: renamed from: o (boolean) void
   public static final void method_1380(boolean var0) {
      int var1 = var0 ? 187 : method_579(0, 187, method_402(), 500);
      method_1271(field_51, 0, 0, 240, 320, var1 << 24);
   }

   // $VF: renamed from: dS () void
   public static final void method_1381() {
      if (method_1273()) {
         method_1350(5);
         method_1428();
         method_1289(field_51);
      }
   }

   // $VF: renamed from: bd () boolean
   public static boolean method_1382() {
      return method_1383();
   }

   // $VF: renamed from: be () boolean
   public static final boolean method_1383() {
      return true;
   }

   // $VF: renamed from: bf () boolean
   public static final boolean method_1384() {
      return true;
   }

   // $VF: renamed from: bg () boolean
   public static boolean method_1385() {
      return method_1383() && !method_1384();
   }

   // $VF: renamed from: a (int, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String) int
   public static final int method_1386(int var0, String var1, String var2, String var3, String var4, String var5) {
      field_621 = method_401();
      field_622 = var0;
      field_623 = var1;
      field_624 = var2;
      field_625 = var3;
      field_626 = var4;
      field_627 = var5;
      field_628 = method_133(7);
      return field_621;
   }

   // $VF: renamed from: U (int) boolean
   public static final boolean method_1387(int var0) {
      return field_621 == var0;
   }

   // $VF: renamed from: dT () void
   public static void method_1388() {
      method_396(true);
   }

   // $VF: renamed from: dU () void
   public static void method_1389() {
      method_1391(field_623);
   }

   // $VF: renamed from: dV () void
   public static void method_1390() {
      method_1391(field_623);
   }

   // $VF: renamed from: j (java.lang.String) void
   private static final void method_1391(String var0) {
      field_629 = method_451(var0);
   }

   // $VF: renamed from: dW () void
   public static void method_1392() {
      method_396(false);
   }

   // $VF: renamed from: bh () boolean
   public static boolean method_1393() {
      return method_1395();
   }

   // $VF: renamed from: bi () boolean
   public static boolean method_1394() {
      return field_626 != null;
   }

   // $VF: renamed from: bC () boolean
   private static final boolean method_1395() {
      return field_629 == 1;
   }

   // $VF: renamed from: H () java.lang.String
   public static String method_1396() {
      return field_627;
   }

   // $VF: renamed from: I () java.lang.String
   public static String method_1397() {
      if (method_1383()) {
         return method_1395() ? field_625 : field_626;
      } else {
         return field_624;
      }
   }

   // $VF: renamed from: J () java.lang.String
   public static String method_1398() {
      return field_628;
   }

   // $VF: renamed from: dX () void
   public static void method_1399() {
      method_507();
   }

   // $VF: renamed from: bj () boolean
   public static boolean method_1400() {
      return true;
   }

   // $VF: renamed from: K () java.lang.String
   public static String method_1401() {
      return method_133(66);
   }

   // $VF: renamed from: bk () boolean
   public static boolean method_1402() {
      return method_1403();
   }

   // $VF: renamed from: bl () boolean
   public static final boolean method_1403() {
      return field_631;
   }

   // $VF: renamed from: bm () boolean
   public static final boolean method_1404() {
      return field_634;
   }

   // $VF: renamed from: L () java.lang.String
   public static final String method_1405() {
      return field_632;
   }

   // $VF: renamed from: dY () void
   public static final void method_1406() {
      if (!method_1651("/get-more-games-simple.txt")) {
         method_55();
      } else {
         field_631 = "TRUE".equals(method_1652("GetMoreGamesSimpleEnabled"));
         if (field_631) {
            String var1 = method_286();
            method_461("MenuItem-");
            field_186.append(var1);
            field_632 = method_1652(field_186.toString());
            method_461("Url-");
            field_186.append(var1);
            field_633 = method_1652(field_186.toString());
            field_634 = false;
         }
      }
   }

   // $VF: renamed from: dZ () void
   public static final void method_1407() {
      if (method_1404()) {
         field_635 = method_271(method_176("/gmg-ad.png"));
      }

      field_630 = true;
   }

   // $VF: renamed from: ea () void
   public static final void method_1408() {
      if (field_630) {
         if (method_1404()) {
            field_635 = null;
            System.gc();
         }

         field_630 = false;
      }
   }

   // $VF: renamed from: eb () void
   public static void method_1409() {
      field_636 = method_1386(4, field_633, method_133(130), method_133(6), method_133(131), method_133(132));
   }

   // $VF: renamed from: bn () boolean
   public static boolean method_1410() {
      return method_1387(field_636);
   }

   // $VF: renamed from: ec () void
   public static void method_1411() {
      field_636 = -1;
   }

   // $VF: renamed from: ed () void
   public static final void method_1412() {
      if (method_1404()) {
         method_1413();
      } else {
         method_1414();
      }
   }

   // $VF: renamed from: ee () void
   public static void method_1413() {
      if (method_1274()) {
         field_51.drawImage(field_635, 0, field_53 >> 1, 6);
      } else {
         int var0 = field_53;
         var0 -= 26;
         field_51.drawImage(field_635, field_52 >> 1, var0 >> 1, 3);
      }
   }

   // $VF: renamed from: ef () void
   public static void method_1414() {
      method_1364(null, 4, false);
   }

   // $VF: renamed from: bo () boolean
   public static boolean method_1415() {
      return method_1416();
   }

   // $VF: renamed from: bp () boolean
   public static final boolean method_1416() {
      return field_638;
   }

   // $VF: renamed from: M () java.lang.String
   public static final String method_1417() {
      return field_639;
   }

   // $VF: renamed from: eg () void
   public static final void method_1418() {
      if (!method_1651("/gmg-cat.txt")) {
         method_55();
      } else {
         field_638 = "TRUE".equals(method_1652("GetMoreGamesCatalogueEnabled"));
         if (field_638) {
            String var1 = method_286();
            method_461("MenuItem-");
            field_186.append(var1);
            field_639 = method_1652(field_186.toString());
            int var2;
            field_640 = new String[var2 = Integer.parseInt(method_1652("NumberOfPages"))];
            field_641 = new Image[var2];
            field_642 = new String[var2];

            for (int var3 = 0; var3 < var2; var3++) {
               method_461("Page-{0}-Image");
               method_153(field_186, 0, Integer.toString(var3 + 1));
               field_640[var3] = method_1652(field_186.toString());
               method_461("Page-{0}-Url-{1}");
               method_153(field_186, 0, Integer.toString(var3 + 1));
               method_153(field_186, 1, var1);
               field_642[var3] = method_1652(field_186.toString());
            }
         }
      }
   }

   // $VF: renamed from: eh () void
   public static final void method_1419() {
      for (int var0 = 0; var0 < field_640.length; var0++) {
         field_641[var0] = method_271(method_176("/" + field_640[var0]));
      }
   }

   // $VF: renamed from: ei () void
   public static final void method_1420() {
      if (field_637) {
         int var0 = field_641.length;

         while (--var0 >= 0) {
            field_641[var0] = null;
         }

         System.gc();
         field_637 = false;
      }
   }

   // $VF: renamed from: ej () void
   public static void method_1421() {
      if (!field_649) {
         field_643 = 0;
         field_644 = 0;
      }

      field_645 = -1;
      field_646 = 0;
      field_647 = 0;
      field_649 = false;
   }

   // $VF: renamed from: ek () void
   public static void method_1422() {
      if (field_646 == 0) {
         int var10000 = method_231();
         boolean var3 = false;
         int var4;
         if ((var4 = method_160(var10000)) != 0) {
            method_1423(var4);
            method_236();
            method_237();
         }
      } else {
         int var0;
         if ((var0 = method_402() - field_645) >= 1200) {
            field_646 = 0;
         } else {
            boolean var1 = false;
            field_647 = -field_646 * (422 * method_454(var0, 1200, 200, 900) >> 12);
         }
      }
   }

   // $VF: renamed from: bA (int) void
   private static void method_1423(int var0) {
      if (var0 != 0) {
         field_645 = method_402();
         field_646 = var0;
         field_647 = 0;
         field_644 = field_643;
         field_643 += var0;
         if (field_643 < 0) {
            field_643 = field_640.length - 1;
         } else {
            if (field_643 >= field_640.length) {
               field_643 = 0;
            }
         }
      }
   }

   // $VF: renamed from: el () void
   public static void method_1424() {
      field_648 = method_1386(5, field_642[field_643], method_133(130), method_133(6), null, method_133(132));
   }

   // $VF: renamed from: bq () boolean
   public static boolean method_1425() {
      return method_1387(field_648);
   }

   // $VF: renamed from: em () void
   public static void method_1426() {
      field_648 = -1;
      field_649 = true;
   }

   // $VF: renamed from: en () void
   public static final void method_1427() {
      method_65(16777215);
      int var0 = field_53 >> 1;
      method_1284(16777215, 12961221, var0, 58);
      var0 += 58;
      method_315(field_51, 0, var0, field_52, field_53 - var0);
   }

   // $VF: renamed from: eo () void
   public static final void method_1428() {
      Graphics var0 = field_51;
      int var1 = field_643;
      int var2 = 0;
      if (method_403() == 6) {
         if (field_646 == 0) {
            var1 = field_643;
            var2 = 0;
            int var3 = (field_53 >> 1) - 10;
            method_63(4, var3, 30, 54);
            boolean var4 = false;
            method_200(var0, 45, 0, 0, 0);
            method_64();
            method_63(206, var3, 30, 54);
            method_200(var0, 45, field_52 - 12 - 1 + 0, 0, 1);
            method_64();
         } else if (-field_646 * field_647 < 211) {
            var1 = field_644;
            var2 = field_647;
         } else {
            var1 = field_643;
            var2 = field_646 * 422 + field_647;
         }
      }

      int var6 = 0;
      int var7 = 0;
      if (field_641[var1] != null) {
         var7 = field_641[var1].getHeight();
         var6 = method_148(6, (field_53 >> 1) - (var7 >> 1));
         boolean var5 = false;
         var0.drawImage(field_641[var1], var2 + 120, var6, 17);
      }

      if (var1 == field_640.length - 1) {
         int var8 = var6 + (var7 * 7 >> 4);
         method_63(40 + var2, var8, 160, 244);
         method_332(var0, 0, 0, field_52, field_53, method_133(133), 3, 3, 17, true);
         method_64();
      }
   }

   // $VF: renamed from: ep () void
   public static void method_1429() {
      if (!method_1651("/free-content.txt")) {
         method_55();
      } else {
         field_650 = "TRUE".equals(method_1652("FreeContentEnabled"));
         if (field_650) {
            String var1 = method_286();
            method_461("MenuItem-");
            field_186.append(var1);
            field_651 = method_1652(field_186.toString());
            method_461("Url-");
            field_186.append(var1);
            field_652 = method_1652(field_186.toString());
         }
      }
   }

   // $VF: renamed from: N () java.lang.String
   public static String method_1430() {
      return field_651;
   }

   // $VF: renamed from: eq () void
   public static void method_1431() {
      field_653 = method_1386(4, field_652, null, method_133(6), method_133(129), method_133(128));
   }

   // $VF: renamed from: br () boolean
   public static boolean method_1432() {
      return method_1387(field_653);
   }

   // $VF: renamed from: er () void
   public static void method_1433() {
      field_653 = -1;
   }

   // $VF: renamed from: bs () boolean
   public static boolean method_1434() {
      return field_650;
   }

   // $VF: renamed from: z (int, int) int
   public static final int method_1435(int var0, int var1) {
      return var0 * 5 * 16 + var1 * 16;
   }

   // $VF: renamed from: es () void
   public static final void method_1436() {
      method_571(field_655, 2500, (byte)-1);
   }

   // $VF: renamed from: b (int, int, int, int, int, int, int) void
   public static final void method_1437(int var0, int var1, int var2, int var3, int var4, int var5, int var6) {
      var6 -= 107;
      int var7 = method_1441(var0, var1);

      for (int var8 = 0; var8 < 25 && field_655[var7] >= 0; var8++) {
         var7 += 5;
      }

      if (field_655[var7] < 0) {
         field_655[var7 + 0] = (byte)var2;
         field_655[var7 + 1] = (byte)var3;
         field_655[var7 + 2] = (byte)var4;
         field_655[var7 + 3] = (byte)var5;
         field_655[var7 + 4] = (byte)var6;
      }
   }

   // $VF: renamed from: et () void
   public static final void method_1438() {
      method_1443();
      method_1436();
      method_1444();
      method_1445();
      method_1446();
      method_1447();
   }

   // $VF: renamed from: h (javax.microedition.lcdui.Graphics, int, int, int) void
   public static final void method_1439(Graphics var0, int var1, int var2, int var3) {
      int var4 = method_1441(var1, var2);

      for (int var5 = 0; var5 < 25; var5++) {
         byte var6;
         if ((var6 = field_655[var4 + 0]) < 0) {
            return;
         }

         if (field_655[var4 + 1] == var3) {
            method_1440(var0, var6, field_655[var4 + 2], field_655[var4 + 3], field_655[var4 + 4] + 107);
         }

         var4 += 5;
      }
   }

   // $VF: renamed from: t (javax.microedition.lcdui.Graphics, int, int, int, int) void
   private static final void method_1440(Graphics var0, int var1, int var2, int var3, int var4) {
      int var5 = method_1217(field_553);
      switch (var1) {
         case 0:
            boolean var9 = false;
            int var11 = var2 * var5 / 100;
            method_1215(0, var11);
            var2 = field_600;
            var3 = field_601 - var3 * field_552 / 100;
            break;
         case 1:
            int var8 = var2 * var5 / 100;
            boolean var10 = false;
            method_1215(var8, 0);
            var2 = field_600;
            var3 = field_601 - var3 * field_552 / 100;
            break;
         case 2:
            int var6 = var2 * var5 / 100;
            int var7 = var3 * var5 / 100;
            method_1215(var6, var7);
            var2 = field_600;
            var3 = field_601;
      }

      method_200(var0, var4, var2, var3, var1 == 1 ? 1 : 0);
   }

   // $VF: renamed from: B (int, int) int
   private static int method_1441(int var0, int var1) {
      return var0 * 5 * 25 * 5 + var1 * 25 * 5;
   }

   // $VF: renamed from: a (byte, byte, byte, byte, byte, byte, byte, byte, byte, byte, byte, byte, byte, byte, byte, byte) void
   private static final void method_1442(
      byte var0,
      byte var1,
      byte var2,
      byte var3,
      byte var4,
      byte var5,
      byte var6,
      byte var7,
      byte var8,
      byte var9,
      byte var10,
      byte var11,
      byte var12,
      byte var13,
      byte var14,
      byte var15
   ) {
      field_654[field_656++] = var0;
      field_654[field_656++] = var1;
      field_654[field_656++] = var2;
      field_654[field_656++] = var3;
      field_654[field_656++] = var4;
      field_654[field_656++] = var5;
      field_654[field_656++] = var6;
      field_654[field_656++] = var7;
      field_654[field_656++] = var8;
      field_654[field_656++] = var9;
      field_654[field_656++] = var10;
      field_654[field_656++] = var11;
      field_654[field_656++] = var12;
      field_654[field_656++] = var13;
      field_654[field_656++] = var14;
      field_654[field_656++] = var15;
   }

   // $VF: renamed from: hJ () void
   private static final void method_1443() {
      field_656 = 0;
      method_1442(
         (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0
      );
      method_1442(
         (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0
      );
      method_1442(
         (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)1, (byte)1, (byte)0, (byte)0, (byte)1, (byte)1, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0
      );
      method_1442(
         (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1
      );
      method_1442(
         (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)1, (byte)1, (byte)2, (byte)2, (byte)1, (byte)1, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2
      );
      method_1442(
         (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0
      );
      method_1442(
         (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)2, (byte)2, (byte)0, (byte)0, (byte)2, (byte)2, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0
      );
      method_1442(
         (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2
      );
      method_1442(
         (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)1, (byte)1, (byte)2, (byte)2, (byte)1, (byte)1, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2
      );
      method_1442(
         (byte)1, (byte)2, (byte)2, (byte)1, (byte)1, (byte)2, (byte)2, (byte)1, (byte)1, (byte)2, (byte)2, (byte)1, (byte)1, (byte)2, (byte)2, (byte)1
      );
      method_1442(
         (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0
      );
      method_1442(
         (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0, (byte)0
      );
      method_1442(
         (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1
      );
      method_1442(
         (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1
      );
      method_1442(
         (byte)1, (byte)1, (byte)1, (byte)1, (byte)1, (byte)2, (byte)2, (byte)1, (byte)1, (byte)2, (byte)2, (byte)1, (byte)1, (byte)1, (byte)1, (byte)1
      );
      method_1442(
         (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2
      );
      method_1442(
         (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2
      );
      method_1442(
         (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2
      );
      method_1442(
         (byte)2, (byte)2, (byte)2, (byte)2, (byte)2, (byte)3, (byte)3, (byte)2, (byte)2, (byte)3, (byte)3, (byte)2, (byte)2, (byte)2, (byte)2, (byte)2
      );
      method_1442(
         (byte)3, (byte)3, (byte)3, (byte)3, (byte)3, (byte)3, (byte)3, (byte)3, (byte)3, (byte)3, (byte)3, (byte)3, (byte)3, (byte)3, (byte)3, (byte)3
      );
   }

   // $VF: renamed from: hK () void
   private static void method_1444() {
      method_1437(0, 0, 0, 0, 39, 124, 128);
      method_1437(0, 0, 0, 0, 64, 124, 128);
      method_1437(0, 0, 1, 0, 39, 124, 128);
      method_1437(0, 0, 1, 0, 64, 124, 128);
      method_1437(0, 0, 0, 0, 85, 82, 108);
      method_1437(0, 0, 0, 0, 90, 44, 107);
      method_1437(0, 0, 0, 0, 36, 89, 107);
      method_1437(0, 0, 0, 0, 82, 89, 123);
      method_1437(0, 0, 0, 0, 40, 89, 124);
      method_1437(0, 0, 2, 0, 10, 48, 121);
      method_1437(0, 0, 1, 0, 87, 70, 109);
      method_1437(0, 0, 1, 0, 85, 89, 123);
      method_1437(0, 0, 1, 0, 70, 86, 125);
      method_1437(0, 0, 1, 0, 50, 84, 126);
      method_1437(0, 0, 0, 0, 7, 85, 125);
      method_1437(0, 0, 1, 0, 40, 70, 108);
      method_1437(0, 1, 0, 0, 39, 124, 118);
      method_1437(0, 1, 0, 0, 64, 124, 118);
      method_1437(0, 1, 1, 0, 39, 124, 118);
      method_1437(0, 1, 1, 0, 64, 124, 118);
      method_1437(0, 1, 1, 1, 29, 69, 112);
      method_1437(0, 1, 1, 1, 55, 75, 112);
      method_1437(0, 1, 2, 0, 24, 19, 122);
      method_1437(0, 1, 2, 0, 50, 19, 122);
      method_1437(0, 1, 0, 0, 85, 82, 108);
      method_1437(0, 1, 0, 0, 90, 44, 107);
      method_1437(0, 1, 1, 0, 77, 111, 117);
      method_1437(0, 1, 2, 0, 11, 48, 120);
      method_1437(0, 1, 1, 0, 70, 86, 125);
      method_1437(0, 1, 1, 0, 50, 84, 126);
      method_1437(0, 1, 0, 0, 7, 85, 125);
      method_1437(0, 1, 1, 0, 40, 70, 108);
      method_1437(0, 2, 0, 0, 39, 124, 118);
      method_1437(0, 2, 0, 0, 64, 124, 118);
      method_1437(0, 2, 1, 0, 39, 124, 118);
      method_1437(0, 2, 1, 0, 64, 124, 118);
      method_1437(0, 2, 1, 1, 29, 69, 112);
      method_1437(0, 2, 1, 1, 55, 75, 112);
      method_1437(0, 2, 2, 0, 24, 19, 122);
      method_1437(0, 2, 2, 0, 50, 19, 122);
      method_1437(0, 2, 1, 0, 77, 111, 117);
      method_1437(0, 2, 2, 0, 11, 48, 120);
      method_1437(0, 2, 1, 0, 50, 84, 126);
      method_1437(0, 2, 0, 0, 104, 88, 115);
      method_1437(0, 3, 2, 0, 1, 5, 114);
      method_1437(0, 3, 2, 0, 51, 5, 114);
      method_1437(0, 3, 2, 0, 51, 70, 114);
      method_1437(0, 3, 2, 0, 1, 70, 114);
      method_1437(0, 3, 2, 0, 26, 70, 114);
      method_1437(0, 3, 2, 0, 21, -4, 111);
      method_1437(0, 3, 2, 0, 11, 47, 120);
      method_1437(0, 3, 1, 0, 107, 88, 115);
      method_1437(0, 3, 0, 0, 70, 111, 117);
      method_1437(0, 3, 0, 0, 43, 111, 117);
      method_1437(0, 3, 1, 0, 72, 111, 117);
      method_1437(0, 3, 1, 0, 45, 111, 117);
      method_1437(0, 3, 1, 0, 90, 85, 125);
      method_1437(0, 4, 0, 0, 39, 124, 118);
      method_1437(0, 4, 0, 0, 27, 124, 118);
      method_1437(0, 4, 0, 0, 64, 124, 118);
      method_1437(0, 4, 0, 0, 76, 124, 118);
      method_1437(0, 4, 1, 0, 39, 124, 118);
      method_1437(0, 4, 1, 0, 27, 124, 118);
      method_1437(0, 4, 1, 0, 64, 124, 118);
      method_1437(0, 4, 1, 0, 76, 124, 118);
      method_1437(0, 4, 1, 1, 29, 69, 112);
      method_1437(0, 4, 1, 1, 17, 69, 112);
      method_1437(0, 4, 1, 1, 55, 75, 112);
      method_1437(0, 4, 1, 1, 67, 75, 112);
      method_1437(0, 4, 2, 0, 26, 19, 122);
      method_1437(0, 4, 2, 0, 11, 19, 122);
      method_1437(0, 4, 2, 0, 47, 19, 122);
      method_1437(0, 4, 2, 0, 63, 19, 122);
      method_1437(0, 4, 0, 0, 104, 88, 115);
      method_1437(0, 4, 2, 0, 11, 36, 120);
   }

   // $VF: renamed from: hL () void
   private static void method_1445() {
      method_1437(1, 0, 2, 0, 11, 25, 121);
      method_1437(1, 0, 1, 0, 75, 80, 128);
      method_1437(1, 0, 1, 0, 35, 80, 118);
      method_1437(1, 0, 1, 0, 23, 80, 128);
      method_1437(1, 0, 1, 1, 26, 29, 112);
      method_1437(1, 0, 2, 0, 26, 13, 122);
      method_1437(1, 0, 1, 0, 76, 60, 126);
      method_1437(1, 0, 1, 0, 27, 61, 125);
      method_1437(1, 0, 1, 0, 43, 36, 107);
      method_1437(1, 0, 0, 0, 25, 50, 107);
      method_1437(1, 0, 1, 0, 13, 74, 108);
      method_1437(1, 0, 0, 0, 89, 111, 116);
      method_1437(1, 0, 0, 0, 45, 88, 123);
      method_1437(1, 0, 0, 0, 65, 88, 124);
      method_1437(1, 0, 0, 0, 37, 79, 108);
      method_1437(1, 0, 0, 0, 75, 40, 109);
      method_1437(1, 1, 2, 0, 12, 28, 120);
      method_1437(1, 1, 2, 0, 12, 17, 120);
      method_1437(1, 1, 1, 0, 75, 80, 118);
      method_1437(1, 1, 1, 0, 35, 80, 118);
      method_1437(1, 1, 1, 0, 23, 80, 118);
      method_1437(1, 1, 1, 1, 66, 29, 112);
      method_1437(1, 1, 1, 1, 26, 29, 112);
      method_1437(1, 1, 1, 1, 14, 29, 112);
      method_1437(1, 1, 2, 0, 26, 13, 122);
      method_1437(1, 1, 2, 0, 11, 13, 122);
      method_1437(1, 1, 2, 0, 66, 13, 122);
      method_1437(1, 1, 1, 0, 76, 60, 126);
      method_1437(1, 1, 1, 0, 27, 61, 125);
      method_1437(1, 1, 1, 0, 43, 36, 107);
      method_1437(1, 1, 0, 0, 25, 50, 107);
      method_1437(1, 1, 0, 0, 89, 118, 115);
      method_1437(1, 1, 0, 0, 37, 79, 108);
      method_1437(1, 2, 2, 0, 11, 11, 120);
      method_1437(1, 2, 1, 0, 75, 80, 118);
      method_1437(1, 2, 1, 0, 35, 80, 118);
      method_1437(1, 2, 1, 0, 23, 80, 118);
      method_1437(1, 2, 1, 1, 66, 29, 112);
      method_1437(1, 2, 1, 1, 26, 29, 112);
      method_1437(1, 2, 1, 1, 14, 29, 112);
      method_1437(1, 2, 2, 0, 26, 13, 122);
      method_1437(1, 2, 2, 0, 11, 13, 122);
      method_1437(1, 2, 2, 0, 66, 13, 122);
      method_1437(1, 2, 1, 0, 76, 60, 126);
      method_1437(1, 2, 1, 0, 27, 61, 125);
      method_1437(1, 2, 0, 0, 89, 118, 115);
      method_1437(1, 3, 2, 0, 11, 11, 120);
      method_1437(1, 3, 1, 0, 75, 80, 118);
      method_1437(1, 3, 1, 0, 35, 80, 118);
      method_1437(1, 3, 1, 0, 23, 80, 118);
      method_1437(1, 3, 1, 1, 66, 29, 112);
      method_1437(1, 3, 1, 1, 26, 29, 112);
      method_1437(1, 3, 1, 1, 14, 29, 112);
      method_1437(1, 3, 2, 0, 26, 13, 122);
      method_1437(1, 3, 2, 0, 11, 13, 122);
      method_1437(1, 3, 2, 0, 66, 13, 122);
      method_1437(1, 3, 1, 0, 76, 60, 126);
      method_1437(1, 3, 1, 0, 27, 61, 125);
      method_1437(1, 3, 0, 0, 89, 118, 115);
      method_1437(1, 3, 0, 0, 30, 40, 109);
      method_1437(1, 3, 1, 0, 72, 111, 117);
      method_1437(1, 3, 1, 0, 45, 111, 117);
      method_1437(1, 4, 2, 0, 11, 11, 120);
      method_1437(1, 4, 1, 0, 75, 80, 118);
      method_1437(1, 4, 1, 0, 35, 80, 118);
      method_1437(1, 4, 1, 0, 23, 80, 118);
      method_1437(1, 4, 0, 0, 75, 80, 118);
      method_1437(1, 4, 0, 0, 35, 80, 118);
      method_1437(1, 4, 1, 1, 66, 29, 112);
      method_1437(1, 4, 1, 1, 26, 29, 112);
      method_1437(1, 4, 1, 1, 14, 29, 112);
      method_1437(1, 4, 2, 0, 26, 13, 122);
      method_1437(1, 4, 2, 0, 11, 13, 122);
      method_1437(1, 4, 2, 0, 66, 13, 122);
      method_1437(1, 4, 0, 0, 89, 118, 115);
   }

   // $VF: renamed from: hM () void
   private static void method_1446() {
      method_1437(2, 0, 0, 0, 47, 77, 107);
      method_1437(2, 0, 0, 0, 5, 36, 107);
      method_1437(2, 0, 1, 0, 3, 43, 108);
      method_1437(2, 0, 1, 0, 60, 62, 107);
      method_1437(2, 0, 2, 0, 10, 86, 121);
      method_1437(2, 0, 0, 0, 15, 77, 118);
      method_1437(2, 0, 0, 0, 27, 77, 118);
      method_1437(2, 0, 0, 0, 39, 77, 128);
      method_1437(2, 0, 1, 0, 15, 77, 128);
      method_1437(2, 0, 1, 0, 27, 77, 128);
      method_1437(2, 0, 1, 0, 39, 77, 118);
      method_1437(2, 0, 1, 0, 30, 32, 112);
      method_1437(2, 0, 2, 0, 30, 15, 122);
      method_1437(2, 0, 1, 0, 72, 77, 128);
      method_1437(2, 0, 1, 0, 84, 77, 118);
      method_1437(2, 0, 1, 0, 96, 77, 128);
      method_1437(2, 0, 1, 0, 75, 32, 112);
      method_1437(2, 0, 2, 0, 73, 15, 122);
      method_1437(2, 0, 0, 0, 50, 51, 125);
      method_1437(2, 0, 0, 0, 65, 84, 126);
      method_1437(2, 0, 0, 0, 80, 60, 127);
      method_1437(2, 0, 1, 0, 72, 111, 117);
      method_1437(2, 0, 1, 0, 80, 111, 117);
      method_1437(2, 1, 0, 0, 47, 77, 107);
      method_1437(2, 1, 2, 0, 10, 86, 121);
      method_1437(2, 1, 0, 0, 15, 77, 118);
      method_1437(2, 1, 0, 0, 27, 77, 118);
      method_1437(2, 1, 0, 0, 39, 77, 128);
      method_1437(2, 1, 1, 0, 15, 77, 118);
      method_1437(2, 1, 1, 0, 27, 77, 128);
      method_1437(2, 1, 1, 0, 39, 77, 118);
      method_1437(2, 1, 1, 1, 30, 32, 112);
      method_1437(2, 1, 1, 1, 7, 32, 112);
      method_1437(2, 1, 2, 0, 30, 15, 122);
      method_1437(2, 1, 2, 0, 8, 15, 122);
      method_1437(2, 1, 1, 0, 72, 77, 128);
      method_1437(2, 1, 1, 0, 84, 77, 118);
      method_1437(2, 1, 1, 0, 96, 77, 128);
      method_1437(2, 1, 1, 1, 75, 32, 112);
      method_1437(2, 1, 2, 0, 73, 15, 122);
      method_1437(2, 1, 0, 0, 80, 60, 127);
      method_1437(2, 1, 1, 0, 72, 111, 117);
      method_1437(2, 1, 1, 0, 80, 111, 117);
      method_1437(2, 2, 2, 0, 10, 86, 120);
      method_1437(2, 2, 0, 0, 15, 77, 118);
      method_1437(2, 2, 0, 0, 27, 77, 118);
      method_1437(2, 2, 0, 0, 39, 77, 118);
      method_1437(2, 2, 1, 0, 15, 77, 118);
      method_1437(2, 2, 1, 0, 27, 77, 118);
      method_1437(2, 2, 1, 0, 39, 77, 118);
      method_1437(2, 2, 1, 1, 89, 32, 112);
      method_1437(2, 2, 1, 1, 64, 32, 112);
      method_1437(2, 2, 1, 1, 75, 32, 112);
      method_1437(2, 2, 1, 1, 30, 32, 112);
      method_1437(2, 2, 1, 1, 17, 32, 112);
      method_1437(2, 2, 1, 1, 7, 32, 112);
      method_1437(2, 2, 2, 0, 31, 15, 122);
      method_1437(2, 2, 2, 0, 17, 15, 122);
      method_1437(2, 2, 2, 0, 6, 15, 122);
      method_1437(2, 2, 1, 0, 72, 77, 118);
      method_1437(2, 2, 1, 0, 84, 77, 118);
      method_1437(2, 2, 1, 0, 96, 77, 118);
      method_1437(2, 2, 2, 0, 73, 15, 122);
      method_1437(2, 2, 2, 0, 62, 15, 122);
      method_1437(2, 2, 1, 0, 72, 111, 117);
      method_1437(2, 2, 1, 0, 80, 111, 117);
      method_1437(2, 3, 0, 0, 27, 58, 125);
      method_1437(2, 3, 0, 0, 50, 40, 127);
      method_1437(2, 3, 2, 0, 10, 86, 120);
      method_1437(2, 3, 0, 0, 15, 77, 128);
      method_1437(2, 3, 0, 0, 27, 77, 128);
      method_1437(2, 3, 0, 0, 39, 77, 118);
      method_1437(2, 3, 1, 0, 15, 77, 128);
      method_1437(2, 3, 1, 0, 27, 77, 128);
      method_1437(2, 3, 1, 0, 39, 77, 128);
      method_1437(2, 3, 1, 0, 35, 37, 113);
      method_1437(2, 3, 1, 1, 75, 32, 112);
      method_1437(2, 3, 1, 0, 72, 77, 128);
      method_1437(2, 3, 1, 0, 84, 77, 118);
      method_1437(2, 3, 1, 0, 96, 77, 128);
      method_1437(2, 3, 1, 0, 72, 111, 117);
      method_1437(2, 3, 1, 0, 80, 111, 117);
      method_1437(2, 3, 0, 0, 82, 118, 115);
      method_1437(2, 3, 2, 0, 73, 15, 122);
      method_1437(2, 3, 2, 0, 45, 70, 111);
      method_1437(2, 4, 0, 0, 30, 35, 113);
      method_1437(2, 4, 2, 0, 10, 86, 120);
      method_1437(2, 4, 0, 0, 15, 77, 118);
      method_1437(2, 4, 0, 0, 27, 77, 118);
      method_1437(2, 4, 0, 0, 39, 77, 128);
      method_1437(2, 4, 1, 0, 15, 77, 118);
      method_1437(2, 4, 1, 0, 27, 77, 118);
      method_1437(2, 4, 1, 0, 39, 77, 118);
      method_1437(2, 4, 1, 1, 64, 32, 112);
      method_1437(2, 4, 1, 1, 30, 32, 112);
      method_1437(2, 4, 1, 1, 17, 32, 112);
      method_1437(2, 4, 1, 1, 7, 32, 112);
      method_1437(2, 4, 2, 0, 31, 15, 122);
      method_1437(2, 4, 2, 0, 17, 15, 122);
      method_1437(2, 4, 2, 0, 6, 15, 122);
      method_1437(2, 4, 1, 0, 72, 77, 118);
      method_1437(2, 4, 1, 0, 84, 77, 128);
      method_1437(2, 4, 1, 0, 96, 77, 128);
      method_1437(2, 4, 1, 0, 72, 111, 117);
      method_1437(2, 4, 1, 0, 80, 111, 117);
      method_1437(2, 4, 0, 0, 82, 118, 115);
      method_1437(2, 4, 2, 0, 62, 15, 122);
   }

   // $VF: renamed from: hN () void
   private static void method_1447() {
      method_1437(3, 0, 1, 0, 32, 50, 110);
      method_1437(3, 0, 1, 0, 68, 50, 110);
      method_1437(3, 0, 1, 1, 27, 25, 112);
      method_1437(3, 0, 1, 1, 63, 25, 112);
      method_1437(3, 0, 0, 0, 52, 50, 110);
      method_1437(3, 0, 1, 0, 17, 42, 107);
      method_1437(3, 0, 1, 0, 41, 80, 108);
      method_1437(3, 0, 1, 0, 86, 89, 123);
      method_1437(3, 0, 1, 0, 80, 80, 107);
      method_1437(3, 0, 1, 0, 35, 15, 126);
      method_1437(3, 0, 0, 0, 53, 17, 125);
      method_1437(3, 0, 0, 0, 65, 67, 107);
      method_1437(3, 0, 0, 0, 41, 28, 108);
      method_1437(3, 0, 0, 0, 40, 83, 126);
      method_1437(3, 0, 0, 0, 20, 88, 123);
      method_1437(3, 0, 0, 0, 10, 88, 124);
      method_1437(3, 0, 0, 0, 10, 79, 107);
      method_1437(3, 0, 0, 0, 65, 112, 116);
      method_1437(3, 0, 1, 0, 51, 112, 116);
      method_1437(3, 1, 1, 0, 32, 50, 110);
      method_1437(3, 1, 1, 0, 68, 50, 110);
      method_1437(3, 1, 1, 1, 27, 25, 112);
      method_1437(3, 1, 1, 1, 63, 25, 112);
      method_1437(3, 1, 0, 0, 52, 50, 110);
      method_1437(3, 1, 1, 0, 17, 42, 107);
      method_1437(3, 1, 1, 0, 41, 80, 108);
      method_1437(3, 1, 1, 0, 35, 15, 126);
      method_1437(3, 1, 0, 0, 53, 17, 125);
      method_1437(3, 1, 0, 0, 65, 67, 107);
      method_1437(3, 1, 0, 0, 41, 28, 108);
      method_1437(3, 1, 0, 0, 40, 83, 126);
      method_1437(3, 1, 0, 0, 65, 112, 116);
      method_1437(3, 1, 1, 0, 51, 112, 116);
      method_1437(3, 2, 1, 0, 32, 50, 110);
      method_1437(3, 2, 1, 0, 68, 50, 110);
      method_1437(3, 2, 1, 1, 27, 25, 112);
      method_1437(3, 2, 1, 1, 63, 25, 112);
      method_1437(3, 2, 0, 0, 52, 50, 110);
      method_1437(3, 2, 0, 0, 69, 111, 117);
      method_1437(3, 2, 0, 0, 58, 111, 117);
      method_1437(3, 2, 1, 0, 54, 117, 115);
      method_1437(3, 3, 1, 0, 39, 40, 113);
      method_1437(3, 3, 1, 0, 65, 40, 113);
      method_1437(3, 3, 0, 0, 67, 50, 110);
      method_1437(3, 3, 0, 0, 37, 50, 110);
      method_1437(3, 3, 0, 0, 69, 111, 117);
      method_1437(3, 3, 0, 0, 58, 111, 117);
      method_1437(3, 3, 1, 0, 54, 118, 115);
      method_1437(3, 4, 1, 0, 39, 50, 110);
      method_1437(3, 4, 1, 0, 27, 50, 110);
      method_1437(3, 4, 1, 0, 63, 50, 110);
      method_1437(3, 4, 1, 0, 75, 51, 110);
      method_1437(3, 4, 1, 1, 33, 25, 112);
      method_1437(3, 4, 1, 1, 19, 25, 112);
      method_1437(3, 4, 1, 1, 70, 25, 112);
      method_1437(3, 4, 1, 1, 56, 25, 112);
      method_1437(3, 4, 0, 0, 67, 50, 110);
      method_1437(3, 4, 0, 0, 37, 50, 110);
      method_1437(3, 4, 0, 0, 69, 111, 117);
      method_1437(3, 4, 0, 0, 58, 111, 117);
      method_1437(3, 4, 1, 0, 54, 118, 115);
   }

   // $VF: renamed from: a (int, int, int, byte) void
   public static final void method_1448(int var0, int var1, int var2, byte var3) {
      if (var3 > 0) {
         int var6 = 40 + var2 * 20 - var1 * 5;
         int var7 = -2000 * var6 / 100;
         method_737(field_332, var0, var7);
         method_737(field_331, var0, -100);
      } else {
         method_737(field_331, var0, 200);
      }
   }

   // $VF: renamed from: b (int, int, int, byte) void
   public static final void method_1449(int var0, int var1, int var2, byte var3) {
      int var6 = var1 * ((var3 - 50) / 25);
      method_737(field_331, var0, var6 * 100);
      int var7 = method_148(1, (1 + var2 * 2 + var3 / 30) / 2);
      method_737(field_333, var0, -var7 * 40);
      int var8 = 5 + var2 + var1;
      method_737(field_332, var0, var8 * 100);
   }

   // $VF: renamed from: bd (int) void
   public static final void method_1450(int var0) {
      method_737(field_331, var0, -1000);
      method_737(field_332, var0, -1000);
   }

   // $VF: renamed from: be (int) void
   public static final void method_1451(int var0) {
      method_737(field_333, var0, 1000);
      method_737(field_331, var0, 1000);
   }

   // $VF: renamed from: a (int, int, int, byte, byte) void
   public static final void method_1452(int var0, int var1, int var2, byte var3, byte var4) {
      if (method_735(field_332, var0) != 100) {
         int var10000 = -method_148(2, 10 * (var1 * var3 - var2 * 10) / 100);
         int var7 = var10000 + var10000 * var4 / 200;
         method_737(field_331, var0, var7 * 100);
         method_737(field_332, var0, 100);
         int var8 = -method_148(0, var2 - var1 / 2);
         method_737(field_333, var0, var8 * 30);
      }
   }

   // $VF: renamed from: a (int, int, int, int, int, byte) void
   public static final void method_1453(int var0, int var1, int var2, int var3, int var4, byte var5) {
      int var9;
      method_1008(var9 = (35 + var1 * 20 - var2 * 5) * ((var5 << 1) + (100 - var3) + (100 - var4)) / 400);
      field_439 += var9;
      int var10 = 2 + (var1 + var2) * 2;
      method_737(field_332, var0, var10 * 100);
      method_737(field_331, var0, 1500 * (110 - var5) / 100);
      int var11 = -method_148(0, var2 - var1 / 2);
      method_737(field_333, var0, var11 * 60);
   }

   // $VF: renamed from: X () int
   public static final int method_1454() {
      return 40 + 60 * field_391 / 12;
   }

   // $VF: renamed from: eu () void
   public static final void method_1455() {
      int var0 = method_959();
      field_669 = 3333 * field_657[var0] / 100;
      field_670 = 1500 * field_658[var0] / 100;
      field_671 = 24 * field_659[var0] / 100;
   }

   // $VF: renamed from: ev () void
   public static final void method_1456() {
      method_805((byte)0, 50);
      method_805((byte)1, 100);
      method_805((byte)2, 150);
      method_805((byte)3, 350);
      method_805((byte)4, 800);
      method_805((byte)5, 1000);
      method_805((byte)6, 50);
      method_805((byte)7, 100);
      method_805((byte)8, 350);
      method_805((byte)9, 550);
      method_805((byte)10, 450);
      method_805((byte)11, 550);
      method_805((byte)12, 50);
      method_805((byte)13, 210);
      method_805((byte)14, 320);
      method_805((byte)15, 50);
      method_805((byte)16, 50);
      method_805((byte)17, 300);
      method_805((byte)18, 250);
      method_805((byte)19, 1500);
      method_805((byte)20, 100);
      method_805((byte)21, 350);
      method_805((byte)22, 550);
      method_805((byte)23, 850);
      method_805((byte)24, 300);
      method_805((byte)25, 500);
      method_805((byte)26, 1200);
      method_805((byte)27, 300);
      method_805((byte)28, 150);
      method_805((byte)29, 400);
      method_805((byte)30, 450);
      method_805((byte)31, 750);
      method_805((byte)32, 200);
      method_805((byte)33, 150);
      method_805((byte)34, 500);
      method_805((byte)35, 0);
      method_805((byte)36, 650);
      method_805((byte)37, 50);
      method_805((byte)38, 100);
      method_805((byte)39, 150);
      method_805((byte)40, 350);
      method_805((byte)41, 380);
      method_805((byte)42, 150);
      method_805((byte)44, 0);
      method_805((byte)45, 50);
      method_805((byte)46, 400);
      method_805((byte)47, 150);
      method_805((byte)48, 80);
      method_805((byte)49, 500);
   }

   // $VF: renamed from: ew () void
   public static final void method_1457() {
      method_808((byte)1, (byte)0, 6, 0, field_672);
      method_809((byte)1, (byte)1, 6, 1, 4, field_676);
      method_810((byte)1, (byte)2, 7, 1, 4, 9, field_684);
      method_810((byte)1, (byte)3, 7, 3, 5, 9, field_692);
      method_808((byte)1, (byte)4, 8, 1, field_680);
      method_809((byte)1, (byte)5, 8, 10, 1, field_688);
      method_809((byte)1, (byte)6, 8, 10, 2, field_696);
      method_809((byte)1, (byte)7, 8, 1, 4, field_700);
      method_810((byte)1, (byte)8, 8, 1, 4, 9, field_704);
      method_810((byte)1, (byte)9, 8, 10, 1, 4, field_708);
      method_807((byte)2, (byte)0, 20, field_673);
      method_808((byte)2, (byte)1, 20, 21, field_677);
      method_808((byte)2, (byte)2, 20, 22, field_685);
      method_809((byte)2, (byte)3, 20, 22, 23, field_693);
      method_808((byte)2, (byte)4, 20, 24, field_681);
      method_808((byte)2, (byte)5, 20, 25, field_689);
      method_808((byte)2, (byte)6, 20, 26, field_697);
      method_809((byte)2, (byte)7, 20, 21, 24, field_701);
      method_809((byte)2, (byte)8, 20, 22, 24, field_705);
      method_809((byte)2, (byte)9, 20, 21, 25, field_709);
      method_808((byte)3, (byte)0, 11, 12, field_674);
      method_809((byte)3, (byte)1, 11, 12, 13, field_678);
      method_810((byte)3, (byte)2, 11, 12, 13, 14, field_686);
      method_811((byte)3, (byte)3, 11, 12, 13, 14, 19, field_694);
      method_809((byte)3, (byte)4, 11, 15, 16, field_682);
      method_810((byte)3, (byte)5, 11, 15, 17, 18, field_690);
      method_811((byte)3, (byte)6, 11, 15, 17, 18, 19, field_698);
      method_810((byte)3, (byte)7, 11, 15, 13, 14, field_702);
      method_810((byte)3, (byte)8, 11, 15, 13, 19, field_706);
      method_810((byte)3, (byte)9, 11, 15, 17, 19, field_710);
      method_808((byte)4, (byte)0, 27, 28, field_675);
      method_808((byte)4, (byte)1, 27, 32, field_679);
      method_809((byte)4, (byte)2, 27, 32, 33, field_687);
      method_808((byte)4, (byte)3, 27, 34, field_695);
      method_808((byte)4, (byte)4, 27, 29, field_683);
      method_809((byte)4, (byte)5, 27, 29, 30, field_691);
      method_810((byte)4, (byte)6, 27, 29, 30, 31, field_699);
      method_808((byte)4, (byte)7, 27, 32, field_703);
      method_810((byte)4, (byte)8, 27, 32, 33, 29, field_707);
      method_809((byte)4, (byte)9, 27, 33, 30, field_711);
   }

   // $VF: renamed from: ex () void
   public static void method_1458() {
      method_1484(method_133(46), false, false);
   }

   // $VF: renamed from: ey () void
   public static void method_1459() {
      if (!method_1025()) {
         int var0 = method_1275();
         method_1361(method_133(46), field_146, method_1128(), 2, true, false, var0, field_716 ? var0 : 0, false);
      }
   }

   // $VF: renamed from: O () java.lang.String
   public static String method_1460() {
      return method_1134(field_146);
   }

   // $VF: renamed from: m (int, int, int) void
   public static final void method_1461(int var0, int var1, int var2) {
      field_713 = var2 > var0;
      field_714 = var2 < var1;
   }

   // $VF: renamed from: ez () void
   public static void method_1462() {
      method_595(field_51, false);
   }

   // $VF: renamed from: eA () void
   public static void method_1463() {
      method_1369();
   }

   // $VF: renamed from: eB () void
   public static void method_1464() {
      method_65(16777215);
   }

   // $VF: renamed from: eC () void
   public static void method_1465() {
      method_1370(201, false);
   }

   // $VF: renamed from: eD () void
   public static void method_1466() {
      method_1370(201, false);
   }

   // $VF: renamed from: eE () void
   public static void method_1467() {
      method_1370(201, false);
   }

   // $VF: renamed from: eF () void
   public static void method_1468() {
      int var0;
      if ((var0 = method_1276(field_52, 0, 400)) == 0) {
         field_715 = false;
      }

      method_1358(method_133(199), 3, true, var0, var0 == 0);
      method_1278(true);
   }

   // $VF: renamed from: eG () void
   public static void method_1469() {
      method_1219(field_416 == field_408);
      method_1380(true);
      method_1353(method_133(199), 0, true);
      method_1355(method_133(254), false, 6192724378386649L);
      method_1289(field_51);
   }

   // $VF: renamed from: eH () void
   public static void method_1470() {
      method_595(field_51, false);
      method_66(0, method_133(200), 3);
   }

   // $VF: renamed from: eI () void
   public static void method_1471() {
      method_1370(200, false);
   }

   // $VF: renamed from: eJ () void
   public static void method_1472() {
      method_1370(200, false);
   }

   // $VF: renamed from: eK () void
   public static void method_1473() {
      method_1370(-1, false);
   }

   // $VF: renamed from: eL () void
   public static void method_1474() {
      method_1370(200, false);
   }

   // $VF: renamed from: eM () void
   public static void method_1475() {
      method_1370(200, false);
   }

   // $VF: renamed from: eN () void
   public static void method_1476() {
      method_1350(1);
      method_413(false);
   }

   // $VF: renamed from: eO () void
   public static void method_1477() {
      int var0 = method_1276(field_52, 0, 400);
      if (method_487()) {
         method_1357(2, var0);
         method_1478();
      } else {
         method_1357(2, var0);
      }

      method_1278(true);
   }

   // $VF: renamed from: hO () void
   private static void method_1478() {
      String var0 = method_483();
      int var1 = field_52 - 12;
      byte var2 = 0;
      int var3 = method_208(0, var0);
      if (method_211(0) > 28 || var3 > var1) {
         var2 = 2;
         var3 = method_208(2, var0);
         if (method_211(2) > 28 || var3 > var1) {
            var2 = 1;
         }
      }

      method_331(field_51, 0, 0, field_52, 28, var0, var2, var2, 3);
   }

   // $VF: renamed from: eP () void
   public static void method_1479() {
      int var0;
      if ((var0 = method_1276(field_52, 0, 400)) == 0) {
         field_715 = false;
      }

      method_1359(method_133(44), 2, var0, false);
      method_1278(true);
   }

   // $VF: renamed from: eQ () void
   public static void method_1480() {
      method_1484(method_133(210), false, false);
   }

   // $VF: renamed from: eR () void
   public static void method_1481() {
      method_1359(method_133(53), 2, 0, false);
   }

   // $VF: renamed from: eS () void
   public static void method_1482() {
      boolean var0;
      int var1;
      if ((var1 = (var0 = field_510 == 0) ? method_1276(field_52, 0, 400) : 0) == 0) {
         field_715 = false;
      }

      int var2 = field_510 == 0 ? 2 : 3;
      method_1358(method_133(50), var2, !var0, var1, !var0);
   }

   // $VF: renamed from: eT () void
   public static void method_1483() {
      method_1365(null, method_133(244), 2, -1L, false);
   }

   // $VF: renamed from: a (java.lang.String, boolean, boolean) void
   public static final void method_1484(String var0, boolean var1, boolean var2) {
      if (var1) {
         method_1219(field_416 == field_408);
      } else {
         method_1351();
      }

      if (!field_716) {
         if (var2) {
            method_1380(true);
         }

         int var3 = field_52;
         int var4 = 0 + (var3 - method_1276(var3, 0, 300)) * -field_486;
         method_1300(6192724378386649L, 32088684216778761L, 32089289807167497L, false, false, var4, 0, false);
         method_1353(var0, 0, true);
      }

      method_1289(field_51);
   }

   // $VF: renamed from: eU () void
   public static void method_1485() {
      method_1486(method_133(207), field_146, method_1335());
   }

   // $VF: renamed from: a (java.lang.String, int, int) void
   public static final void method_1486(String var0, int var1, int var2) {
      if (!method_1025()) {
         int var3 = method_1275();
         method_1361(var0, var1, var2, 2, true, false, var3, field_716 ? var3 : 0, false);
      }
   }

   // $VF: renamed from: eV () void
   public static void method_1487() {
      method_1484(method_133(207), false, false);
   }

   // $VF: renamed from: eW () void
   public static void method_1488() {
      field_715 = true;
      field_716 = true;
      field_486 = 1;
      method_1119(field_510 != 0);
   }

   // $VF: renamed from: eX () void
   public static void method_1489() {
      field_716 = true;
      field_715 = true;
      field_486 = 1;
   }

   // $VF: renamed from: eY () void
   public static void method_1490() {
      if (method_403() == 101 && field_510 == 0) {
         field_715 = true;
         field_716 = true;
      } else {
         field_715 = false;
         field_716 = false;
      }
   }

   // $VF: renamed from: eZ () void
   public static void method_1491() {
      boolean var0;
      int var1 = (var0 = field_510 == 0) ? 2 : 3;
      method_1360(method_1337(field_145), var1, !var0, !var0, method_1296() ? 32088447993577481L : 32088684216778761L, false);
      method_1362(0, !var0, -1);
   }

   // $VF: renamed from: fa () void
   public static void method_1492() {
      method_1365(method_133(44), method_133(245), 2, 6192724378386649L, false);
   }

   // $VF: renamed from: fb () void
   public static void method_1493() {
      method_1370(202, false);
   }

   // $VF: renamed from: fc () void
   public static void method_1494() {
      method_1366();
      method_1278(true);
   }

   // $VF: renamed from: fd () void
   public static void method_1495() {
      int var0 = method_1276(field_52, 0, 400);
      method_1358(method_1539(), 3, true, var0, false);
   }

   // $VF: renamed from: fe () void
   public static void method_1496() {
      method_1497(true);
   }

   // $VF: renamed from: p (boolean) void
   public static final void method_1497(boolean var0) {
      if (!method_1025()) {
         String var1 = method_1540(field_712);
         boolean var2 = field_712 > 0;
         boolean var3 = field_712 < 3;
         int var4 = var0 ? method_1275() : 0;
         long var5 = method_1373(true, true, method_133(236), var1, true, (byte)1, var2, var3, true, var4, field_716 ? var4 : 0, false, !field_716);
         method_61(6192724378386649L);
         method_63(method_68(var5) + var4, method_69(var5), method_70(var5), method_71(var5));
         int var7 = method_993(field_712);
         method_177(field_51, 96 + (var7 - 11), field_52 >> 1, (field_53 >> 1) + 12);
         if (!method_557(field_712)) {
            int var8 = field_52 >> 1;
            int var9 = field_53 >> 1;
            String var10 = method_133(215);
            method_205(0, field_51, var10, var8, var9, 3);
         }

         method_64();
         method_64();
         method_1278(true);
      }
   }

   // $VF: renamed from: ff () void
   public static void method_1498() {
      method_1484(method_133(236), true, true);
   }

   // $VF: renamed from: fg () void
   public static void method_1499() {
      method_1367(null, method_133(field_480), -1L, false);
   }

   // $VF: renamed from: fh () void
   public final void method_1500() {
      if (!method_1025()) {
         method_1461(0, 2, field_358);
         method_1505(false, field_713, field_714, method_133(209), method_133(293 + field_358), true, true, false);
         method_1278(true);
         method_413(true);
      }
   }

   // $VF: renamed from: fi () void
   public static void method_1501() {
      method_1484(method_133(209), false, false);
   }

   // $VF: renamed from: fj () void
   public final void method_1502() {
      method_1461(0, 2, field_358);
      method_1505(false, field_713, field_714, method_133(209), method_133(293 + field_358), true, false, false);
      method_1379(method_1317());
   }

   // $VF: renamed from: fk () void
   public final void method_1503() {
      if (!method_1025()) {
         boolean var1 = field_426 > 0;
         boolean var2 = field_432 > 0;
         int var3 = 0;
         if (field_358 == 0) {
            var1 = false;
            if (field_426 > 4) {
               var3 = field_426 - 4;
            }
         } else {
            var2 = false;
            if (field_432 > 4) {
               var3 = field_432 - 4;
            }
         }

         int var4 = method_1505(true, var1, var2, method_133(223), method_133(224 + field_358), field_358 == 0, true, true);
         if (var3 > 0) {
            method_62(6192724378386649L, var4, 0);
            int var5;
            int var6 = (var5 = method_211(0)) << 1;
            int var7 = field_52 - var6;
            int var8 = (field_53 << 1) / 3;
            method_313(field_51, 1185304);
            method_1245(field_51, var6, var5 + 2, var7 - (var6 >> 1), var8 - (var5 >> 1));
            field_186.setLength(0);
            field_186.append('+');
            field_186.append(var3);
            method_203(0, field_186.toString(), var7, var8, 3);
            method_64();
         }

         method_1278(true);
      }
   }

   // $VF: renamed from: fl () void
   public static void method_1504() {
      method_1484(method_133(223), true, true);
   }

   // $VF: renamed from: a (boolean, boolean, boolean, java.lang.String, java.lang.String, boolean, boolean, boolean) int
   private static int method_1505(boolean var0, boolean var1, boolean var2, String var3, String var4, boolean var5, boolean var6, boolean var7) {
      int var8 = var6 ? method_1275() : 0;
      long var9 = method_1373(true, var0, var3, var4, var5, (byte)0, var1, var2, true, var8, field_716 ? var8 : 0, false, var7);
      method_62(6192724378386649L, var8, 0);
      method_63(method_68(var9), method_69(var9), method_70(var9), method_71(var9));
      int var11 = field_358;
      if (field_358 >= 0) {
         int var12 = 0;
         int var13 = 4;

         while (--var13 >= 0) {
            if (method_763(var11, var13) >= 0) {
               var12++;
            }
         }

         var13 = 0;
         GameClock.field_28.setSeed(field_358);
         int var15 = 4;

         while (--var15 >= 0) {
            byte var16;
            int var17;
            if ((var16 = method_763(var11, var15)) >= 0 && (var17 = field_299[var16]) >= 0) {
               int var18;
               int var19;
               if (((var18 = var12 - var13 - 1) & 1) == 0) {
                  var19 = (field_52 >> 1) + (var18 >> 1) * 32;
               } else {
                  var19 = (field_52 >> 1) - ((var18 >> 1) + 1) * 32;
               }

               int var20 = method_149(field_53 >> 6, 12);
               int var21 = var19 - 3 + method_152(6) + ((var12 & 1) == 1 ? 0 : 1) * 16;
               int var22 = method_149(field_53 >> 5, 12);
               int var24 = method_150(method_1506(12) + var22 - var18 * var22 + (var20 > 0 ? -(var20 >> 1) + method_152(var20) : 0), 78, field_53);
               method_1242(field_51, var16, var17, var21, var24, false, false, true);
               var13++;
            }
         }

         if (method_1202()) {
            int var26 = field_52 >> 1;
            int var27 = field_53 >> 1;
            String var28 = method_133(215);
            method_205(0, field_51, var28, var26, var27, 3);
         }
      }

      method_64();
      method_64();
      return var8;
   }

   // $VF: renamed from: S (int) int
   public static final int method_1506(int var0) {
      return (field_53 - 68 - var0 >> 1) + 68 - method_184(13) + var0;
   }

   // $VF: renamed from: fm () void
   public static void method_1507() {
      method_595(field_51, true);
      method_1379(method_1193());
      method_1278(true);
   }

   // $VF: renamed from: fn () void
   public final void method_1508() {
      method_1461(0, 2, field_358);
      method_1505(false, field_713, field_714, method_133(209), method_133(293 + field_358), true, false, false);
      method_1379(method_133(248));
   }

   // $VF: renamed from: fo () void
   public static void method_1509() {
      int var0 = method_1276(field_52, 0, 400);
      method_1510(method_133(211), true, field_513, true, var0, var0, false);
      method_1278(true);
      if (field_510 == 0) {
         method_413(false);
      }
   }

   // $VF: renamed from: a (java.lang.String, boolean, boolean, boolean, int, int, boolean) void
   public static final void method_1510(String var0, boolean var1, boolean var2, boolean var3, int var4, int var5, boolean var6) {
      method_1513(var0, var1, var2, var3, false, field_510 == 2 ? 3 : 2, var4, var5);
      method_1511(var4, field_600, field_601, field_483, field_484);
   }

   // $VF: renamed from: c (int, int, int, int, int) void
   public static final void method_1511(int var0, int var1, int var2, int var3, int var4) {
      Graphics var5 = field_51;
      if(var5.remaster("governor-office",new int[]{var0+var1,var2,var3,var4}))return;
      if (method_1296()) {
         boolean var11 = false;
         method_177(var5, -1, 52 + var0, 82);
      } else {
         int var6 = var1 + var0;
         var5.translate(var6, var2);
         int var10 = var4 - 52 >> 1;
         method_200(var5, 49, (var3 >> 1) - 80, var4 - var10, 0);
         method_200(var5, 49, var3 >> 1, var4 - var10, 1);
         var10 = var4 - 61 >> 1;
         method_177(var5, 48, var3 >> 1, var4 - var10);
         var5.translate(-var6, -var2);
      }
   }

   // $VF: renamed from: a (java.lang.String, boolean, boolean, boolean, boolean, int) void
   public static final void method_1512(String var0, boolean var1, boolean var2, boolean var3, boolean var4, int var5) {
      int var6 = method_1276(field_52, 0, 400);
      method_1513(var0, var1, var2, var3, var4, var5, var6, var6);
      int var7 = field_474;
      if (method_1296()) {
         if (var7 >= 0) {
            method_1242(field_51, var7, field_299[var7], var6 + 36 + 16, 217, false, false, true);
         }
      } else {
         int var8 = field_600 + var6;
         int var9 = field_601;
         int var10 = field_483;
         int var11 = field_484;
         int var12 = var10 - 93 >> 1;
         int var13 = var11 - 34 >> 1;
         if (field_471 == 335) {
            field_51.translate(var8, var9);
            int var14 = var10 >> 1;
            int var15 = var11 + 0;
            method_200(field_51, 129, var14, var15, 1);
            method_200(field_51, 133, var14, var15, 0);
            field_51.translate(-var8, -var9);
         } else if (field_471 == 323 || field_471 == 350) {
            field_51.translate(var8, var9);
            if (field_471 == 350) {
               method_1223(field_51, var7, -1, var12, var13, 0, method_151((method_402() >> 4) % 256, 100), 0, 0);
            } else {
               method_1223(field_51, var7, -1, var12, var13, 0, -1, -1, -1);
            }

            field_51.translate(-var8, -var9);
            method_413(false);
         } else if (field_471 == 325 || field_471 == 352) {
            field_51.translate(var8, var9);
            if (field_471 == 352) {
               method_1223(field_51, var7, -1, var12, var13, 1, 0, method_151((method_402() >> 4) % 256, 100), 0);
            } else {
               method_1223(field_51, var7, -1, var12, var13, 1, -1, -1, -1);
            }

            field_51.translate(-var8, -var9);
            method_413(false);
         } else if (field_471 != 326 && field_471 != 351 && field_471 != 348 && field_471 != 347) {
            method_1362(var6, false, var7);
         } else {
            field_51.translate(var8, var9);
            if (field_471 == 351) {
               method_1223(field_51, var7, -1, var12, var13, 2, 0, 0, method_151((method_402() >> 4) % 256, 100));
            } else {
               method_1223(field_51, var7, -1, var12, var13, 2, -1, -1, -1);
            }

            field_51.translate(-var8, -var9);
            method_413(false);
         }
      }
   }

   // $VF: renamed from: a (java.lang.String, boolean, boolean, boolean, boolean, int, int, int) void
   public static final void method_1513(String var0, boolean var1, boolean var2, boolean var3, boolean var4, int var5, int var6, int var7) {
      if (method_1273()) {
         method_1350(var5);
         if (var2) {
            method_1380(var3);
         }

         int var8 = method_1515();
         int var9 = method_1514();
         if (var1) {
            method_1300(6192724378386649L, method_1296() ? 32088447993577481L : 32088684216778761L, 32089289807167497L, var4, false, var6, 0, false);
         }

         if (!var4 || method_402() > 700) {
            method_1354(var0, var7, true);
         }

         method_1289(field_51);
         field_600 = 36;
         field_601 = var9;
         field_483 = 168;
         field_484 = var8;
         method_413(true);
      }
   }

   // $VF: renamed from: Y () int
   public static final int method_1514() {
      return 69;
   }

   // $VF: renamed from: Z () int
   public static final int method_1515() {
      return 56;
   }

   // $VF: renamed from: fp () void
   public static void method_1516() {
      method_1367(null, method_1153(), -1L, false);
   }

   // $VF: renamed from: fq () void
   public static void method_1517() {
      boolean var0 = field_471 == 351 || field_471 == 352;
      method_1512(method_133(field_477), true, true, var0, false, 3);
   }

   // $VF: renamed from: fr () void
   public static void method_1518() {
      method_1368(method_133(217), method_1310(), (byte)0);
   }

   // $VF: renamed from: fs () void
   public static void method_1519() {
      method_1368(method_133(218), method_1311(), (byte)1);
   }

   // $VF: renamed from: ft () void
   public static void method_1520() {
      method_595(field_51, true);
      method_1379(method_1192());
   }

   // $VF: renamed from: fu () void
   public static void method_1521() {
      method_1370(200, false);
   }

   // $VF: renamed from: fv () void
   public static void method_1522() {
      method_1370(200, false);
   }

   // $VF: renamed from: fw () void
   public static void method_1523() {
      method_595(field_51, true);
      method_1380(false);
      method_1300(6192724378386649L, 32088447993577481L, 32089289807167497L, true, false, 0, 0, true);
      method_1289(field_51);
      method_1278(true);
   }

   // $VF: renamed from: fx () void
   public static void method_1524() {
      method_1370(201, true);
   }

   // $VF: renamed from: fy () void
   public static void method_1525() {
      method_1370(201, true);
   }

   // $VF: renamed from: fz () void
   public static void method_1526() {
      method_595(field_51, true);
      method_1353(method_133(214), 0, true);
      method_1355(RichTextLayout.method_9(), false, 6192724378386649L);
      method_1289(field_51);
   }

   // $VF: renamed from: fA () void
   public static void method_1527() {
      method_1364(method_133(214), 2, false);
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int, int, int, int, int, boolean) void
   public static final void method_1528(Graphics var0, int var1, int var2, int var3, int var4, int var5, int var6, boolean var7) {
      method_1298(var1, -1, -1, var4, var5, -1, -1, 0, var6 - 1, var7);
      method_200(var0, var1, var3, field_601, var2);
   }

   // $VF: renamed from: fB () void
   public static void method_1529() {
      if (!method_1187() && !method_1117()) {
         method_407(5);
         return;
      }

      method_1367(null, method_1197(), -1L, true);
      method_1278(true);
   }

   // $VF: renamed from: fC () void
   public final void method_1530() {
      method_1531(true, false);
   }

   // $VF: renamed from: e (boolean, boolean) void
   private static void method_1531(boolean var0, boolean var1) {
      if (!method_1025()) {
         int var2 = var0 ? method_1275() : 0;
         int var3 = field_716 ? var2 : 0;
         method_1510(method_1532(), !var1, false, false, var2, var3, false);
         method_1376(field_429 > 0, field_429 < method_1534() - 1, var2, var1);
         method_1278(true);
      }
   }

   // $VF: renamed from: U () java.lang.String
   private static String method_1532() {
      return method_462(212, method_463(field_466), null, null, null, null, null, null, null);
   }

   // $VF: renamed from: fD () void
   public static void method_1533() {
      method_1484(method_1532(), false, false);
   }

   // $VF: renamed from: aa () int
   public static final int method_1534() {
      boolean var0 = method_632(field_466 - 1) >= 0;
      return 5 + (var0 ? 0 : -1);
   }

   // $VF: renamed from: fE () void
   public static void method_1535() {
      method_595(field_51, true);
      method_1380(false);
      method_1300(6192724378386649L, 32088447993577481L, 32089289807167497L, true, true, 0, 0, true);
      method_1289(field_51);
      method_1278(true);
      method_413(false);
   }

   // $VF: renamed from: fF () void
   public static void method_1536() {
      method_1535();
      method_413(true);
   }

   // $VF: renamed from: fG () void
   public static void method_1537() {
      int var0 = field_712;
      method_1538(method_462(237, method_1540(var0), method_463(method_933(var0)), null, null, null, null, null, null));
   }

   // $VF: renamed from: h (java.lang.String) void
   public static final void method_1538(String var0) {
      method_1497(false);
      method_1379(var0);
   }

   // $VF: renamed from: P () java.lang.String
   public static final String method_1539() {
      int var0 = method_985(Integer.MIN_VALUE, Integer.MIN_VALUE, field_252);
      return field_411[var0];
   }

   // $VF: renamed from: o (int) java.lang.String
   public static final String method_1540(int var0) {
      return method_133(228 + var0);
   }

   // $VF: renamed from: fH () void
   public static void method_1541() {
      method_932();
   }

   // $VF: renamed from: fI () void
   public static void method_1542() {
      int var0 = field_712;
      String var1 = method_462(238, method_463(method_933(var0) >> 1), null, null, null, null, null, null, null);
      method_1367(method_1539(), var1, 6192724378386649L, true);
   }

   // $VF: renamed from: fJ () void
   public static void method_1543() {
      method_1367(method_1539(), field_482, 6192724378386649L, true);
   }

   // $VF: renamed from: fK () void
   public static void method_1544() {
      method_1538(field_482);
   }

   // $VF: renamed from: fL () void
   public static void method_1545() {
      int var0 = method_601() ? 262 : 263;
      int var1 = method_1276(field_52, 0, 400);
      method_1358(method_133(var0), 3, true, var1, false);
   }

   // $VF: renamed from: fM () void
   public static void method_1546() {
      method_1367(null, method_133(-1), -1L, true);
   }

   // $VF: renamed from: fN () void
   public static void method_1547() {
      method_1367(null, method_462(243, method_463(2000), null, null, null, null, null, null, null), -1L, false);
   }

   // $VF: renamed from: fO () void
   public static void method_1548() {
      method_1367(null, field_482, -1L, true);
   }

   // $VF: renamed from: fP () void
   public static void method_1549() {
      method_1370(200, false);
   }

   // $VF: renamed from: fQ () void
   public static void method_1550() {
      method_1370(200, false);
   }

   // $VF: renamed from: fR () void
   public static void method_1551() {
      method_1370(200, false);
   }

   // $VF: renamed from: fS () void
   public static void method_1552() {
      method_1370(200, false);
   }

   // $VF: renamed from: fT () void
   public static void method_1553() {
      method_1364(null, field_622, false);
      method_1278(true);
   }

   // $VF: renamed from: fU () void
   public static void method_1554() {
      method_1364(null, field_622, false);
      method_1278(true);
   }

   // $VF: renamed from: fV () void
   public static void method_1555() {
      method_1364(null, 4, false);
   }

   // $VF: renamed from: fW () void
   public static void method_1556() {
      method_1370(200, false);
   }

   // $VF: renamed from: fX () void
   public static void method_1557() {
      method_1370(200, false);
   }

   // $VF: renamed from: fY () void
   public static void method_1558() {
      method_1381();
   }

   // $VF: renamed from: fZ () void
   public static void method_1559() {
      method_1370(200, false);
   }

   // $VF: renamed from: ga () void
   public static void method_1560() {
      method_1370(200, false);
   }

   // $VF: renamed from: gb () void
   public static void method_1561() {
      method_1364(method_133(66), 2, false);
      method_1278(true);
   }

   // $VF: renamed from: gc () void
   public static void method_1562() {
      method_1370(200, false);
   }

   // $VF: renamed from: gd () void
   public static void method_1563() {
      method_1370(200, false);
   }

   // $VF: renamed from: ge () void
   public static void method_1564() {
      method_1364(method_133(66), 2, false);
      method_1278(true);
   }

   // $VF: renamed from: gf () void
   public static void method_1565() {
      method_1370(200, false);
   }

   // $VF: renamed from: gg () void
   public static void method_1566() {
      method_1364(method_133(66), 2, false);
   }

   // $VF: renamed from: gh () void
   public static void method_1567() {
      method_1370(200, false);
   }

   // $VF: renamed from: gi () void
   public static void method_1568() {
      method_1364(null, field_622, false);
   }

   // $VF: renamed from: gj () void
   public static void method_1569() {
      method_1370(200, false);
   }

   // $VF: renamed from: gk () void
   public static void method_1570() {
      method_953(false, true);
      method_1379(method_133(259));
   }

   // $VF: renamed from: gl () void
   public static void method_1571() {
      method_868(true, true, true, true, false);
      method_1379(method_1146());
   }

   // $VF: renamed from: gm () void
   public static void method_1572() {
      method_883(method_133(255));
   }

   // $VF: renamed from: gn () void
   public static void method_1573() {
      method_1484(method_133(226), true, true);
   }

   // $VF: renamed from: go () void
   public static void method_1574() {
      method_883(field_482);
   }

   // $VF: renamed from: gp () void
   public static void method_1575() {
      method_868(true, true, true, false, true);
   }

   // $VF: renamed from: gq () void
   public static void method_1576() {
      method_1350(1);
      method_1278(true);
      method_413(false);
   }

   // $VF: renamed from: gr () void
   public static void method_1577() {
      method_535();
   }

   // $VF: renamed from: a (int, int, boolean, boolean, boolean, boolean) boolean
   private static boolean method_1578(int var0, int var1, boolean var2, boolean var3, boolean var4, boolean var5) {
      method_61(15728960L);
      method_65(0);
      if (var2) {
         field_51.drawImage(field_718, field_52 / 2, 0, 17);
      } else {
         field_51.drawImage(field_718, field_52 / 2, field_53 / 2, 3);
      }

      method_1289(field_51);
      method_64();
      if (var4 || var3) {
         field_615 = true;
         method_1279(true, var1, var5);
      }

      return var1 >= var0;
   }

   // $VF: renamed from: gs () void
   public static void method_1579() {
      field_718 = null;
   }

   // $VF: renamed from: gt () void
   public static void method_1580() {
      field_718 = null;
   }

   // $VF: renamed from: gu () void
   public static void method_1581() {
      field_718 = null;
   }

   // $VF: renamed from: V (int) boolean
   public static boolean method_1582(int var0) {
      return method_1578(2300, var0, false, true, false, true) && var0 > 0;
   }

   // $VF: renamed from: W (int) boolean
   public static boolean method_1583(int var0) {
      return method_1578(2000, var0, false, false, false, false) && var0 > 0;
   }

   // $VF: renamed from: gv () void
   public static final void method_1584() {
      method_1578(2300, method_402(), false, true, true, false);
   }

   // $VF: renamed from: X (int) boolean
   public static boolean method_1585(int var0) {
      field_232 = 1024;
      Graphics var1 = field_51;
      method_595(field_51, true);
      if (russianLogo == null) {
         russianLogo = method_271(method_176("/logo-ru.png"));
      }

      if (russianLogo != null) {
         var1.drawImage(russianLogo, field_52 >> 1, 76, 3);
      }

      method_1289(var1);
      field_615 = true;
      method_1279(true, var0, false);
      return var0 >= 2300;
   }

   // $VF: renamed from: gw () void
   public static void method_1586() {
      field_718 = null;
   }

   // $VF: renamed from: gx () void
   public static void method_1587() {
      field_718 = null;
   }

   // $VF: renamed from: gy () void
   public static void method_1588() {
      field_718 = null;
   }

   // $VF: renamed from: gz () void
   public static void method_1589() {
      method_595(field_51, true);
      method_413(true);
   }

   // $VF: renamed from: Y (int) boolean
   public static final boolean method_1590(int var0) {
      return var0 == 38;
   }

   // $VF: renamed from: bt () boolean
   public static boolean method_1591() {
      boolean var0;
      if (var0 = field_720 == 67108863) {
         field_720 = -1;
      }

      return var0;
   }

   // $VF: renamed from: gA () void
   public static final void method_1592() {
      field_720 = 0;
      field_721 = 0;
      int var0 = 3;

      while (--var0 >= 0) {
         field_722[var0] = 0;
      }

      field_723 = 0;
      field_724 = 0;
      field_725 = 0;
   }

   // $VF: renamed from: k (byte[], int) int
   public static final int method_1593(byte[] var0, int var1) {
      for (int var2 = 0; var2 < 80; var2++) {
         var1 = method_259(var0, var1, field_468[var2]);
      }

      var1 = method_259(var0, var1, field_720);
      var1 = method_258(var0, var1, field_721);
      int var7 = 3;

      while (--var7 >= 0) {
         var1 = method_258(var0, var1, field_722[var7]);
      }

      var1 = method_258(var0, var1, field_723);
      var1 = method_258(var0, var1, field_724);
      return method_258(var0, var1, field_725);
   }

   // $VF: renamed from: l (byte[], int) int
   public static final int method_1594(byte[] var0, int var1) {
      for (int var2 = 0; var2 < 80; var2++) {
         field_468[var2] = method_254(var0, var1);
         var1 += 4;
      }

      field_720 = method_254(var0, var1);
      var1 += 4;
      field_721 = method_252(var0, var1);
      var1++;

      for (int var7 = 3; --var7 >= 0; var1++) {
         field_722[var7] = method_252(var0, var1);
      }

      field_723 = method_252(var0, var1);
      field_724 = method_252(var0, ++var1);
      field_725 = method_252(var0, ++var1);
      return var1 + 1;
   }

   // $VF: renamed from: gB () void
   public static void method_1595() {
      field_726 = -1;
   }

   // $VF: renamed from: b (boolean, int, boolean) boolean
   public static final boolean method_1596(boolean var0, int var1, boolean var2) {
      if (field_463 && var0 && !method_1609(var1)) {
         method_1610(var1);
         if (field_726 == -1) {
            field_726 = var1;
            if (var2) {
               method_423(71);
            }

            method_479(14, -1, 100, false);
         }

         return true;
      } else {
         return false;
      }
   }

   // $VF: renamed from: ab () int
   public static final int method_1597() {
      int var0 = 0;
      int var1 = field_280;

      while (--var1 >= 0) {
         if (field_299[var1] >= 0) {
            var0++;
         }
      }

      return var0;
   }

   // $VF: renamed from: gC () void
   public static void method_1598() {
      method_1596(method_1597() >= 12, 15, true);
   }

   // $VF: renamed from: gD () void
   public static final void method_1599() {
      method_1596(field_723 >= 5, 13, true);
      if (field_726 == -1) {
         byte var0 = 0;
         int var1 = 3;

         while (--var1 >= 0) {
            var0 += field_722[var1];
         }

         method_1596(var0 >= 10, 10, true);
      }

      method_1596(field_722[1] >= 5, 11, true);
      method_1596(field_722[2] >= 1, 12, true);
   }

   // $VF: renamed from: bu () boolean
   public static final boolean method_1600() {
      boolean var0;
      boolean var1 = var0 = method_1618() == 1;

      for (int var2 = 4; !var1; var1 = var1 && method_1029(var2, 0)) {
         if (--var2 < 0) {
            break;
         }
      }

      method_1596(var1, 25, false);
      method_1596(var0, 24, false);
      method_1596(field_728 == 2 && field_727 <= 1, 23, false);
      method_1596(field_728 == 1 && field_727 <= 3, 22, false);
      method_1596(field_728 == 0 && field_727 <= 5, 21, false);
      method_1596(field_479 == 2 && field_457 >= 100000, 3, false);
      method_1596(field_721 >= 10, 0, false);
      method_1596(field_479 == 0 && field_466 >= 20, 14, false);
      method_1596(field_458 < 0, 20, false);
      method_1596(field_479 == 1 && field_457 >= 50000, 2, false);
      method_1596(field_479 == 0 && field_457 >= 30000, 1, false);
      method_1596(field_724 >= 5, 16, false);
      method_1596(field_725 >= 3, 19, false);
      return field_726 >= 0;
   }

   // $VF: renamed from: gE () void
   public static void method_1601() {
      if (!method_1025()) {
         method_1616();
      }
   }

   // $VF: renamed from: gF () void
   public static void method_1602() {
      method_1484(method_133(208), false, false);
   }

   // $VF: renamed from: gG () void
   public static void method_1603() {
      method_1607();
   }

   // $VF: renamed from: gH () void
   public static void method_1604() {
      method_1607();
   }

   // $VF: renamed from: gI () void
   public static void method_1605() {
      int var0 = method_1276(field_52, 0, 400);
      method_1510(method_133(208), true, false, true, var0, var0, true);
      method_413(false);
   }

   // $VF: renamed from: Q () java.lang.String
   public static String method_1606() {
      return method_133(75);
   }

   // $VF: renamed from: hP () void
   private static void method_1607() {
      int var0 = method_1276(field_52, 0, 400);
      method_1513(method_133(73), true, true, false, false, 3, var0, var0);
      if (method_1296()) {
         boolean var3 = false;
         field_51.translate(36, 82);
         method_1617(field_726, 38, var0);
         field_51.translate(-36, -82);
      } else {
         int var2 = field_600 + var0;
         field_51.translate(var2, field_601);
         method_1617(field_726, field_483, 0);
         field_51.translate(-var2, -field_601);
      }
   }

   // $VF: renamed from: gJ () void
   public static void method_1608() {
      field_615 = false;
      method_1219(field_416 == field_408);
      method_1380(true);
      method_1372(201);
   }

   // $VF: renamed from: Z (int) boolean
   public static final boolean method_1609(int var0) {
      return (field_720 & 1 << var0) > 0;
   }

   // $VF: renamed from: bf (int) void
   public static final void method_1610(int var0) {
      field_720 |= 1 << var0;
   }

   // $VF: renamed from: bv () boolean
   public static boolean method_1611() {
      return !method_970() && method_1600();
   }

   // $VF: renamed from: gK () void
   public static void method_1612() {
      method_1631(method_166(), 1);
   }

   // $VF: renamed from: R () java.lang.String
   public static String method_1613() {
      return method_1614(field_146);
   }

   // $VF: renamed from: p (int) java.lang.String
   public static final String method_1614(int var0) {
      method_460(field_186, var0 + 1, 26, method_133(102 + var0));
      field_186.append(method_133(76 + var0));
      return field_186.toString();
   }

   // $VF: renamed from: gL () void
   public static void method_1615() {
      field_146 = field_146 + method_1048(26, field_146);
   }

   // $VF: renamed from: gM () void
   public static final void method_1616() {
      int var0 = method_1275();
      method_1513(method_133(45), true, false, false, false, 2, var0, field_716 ? var0 : 0);
      method_1348(field_146, 26, false, var0);
      if (method_1296()) {
         boolean var2 = false;
         boolean var3 = false;
         field_51.translate(36, 82);
         method_1617(field_146, 42, var0);
         field_51.translate(-36, -82);
      } else {
         int var4 = field_600;
         int var5 = field_601;
         field_51.translate(var4, var5);
         method_1617(field_146, field_483, var0);
         field_51.translate(-var4, -var5);
      }

      method_1289(field_51);
   }

   // $VF: renamed from: n (int, int, int) void
   public static final void method_1617(int var0, int var1, int var2) {
      if (!method_1025()) {
         byte var3 = method_1296() ? 0 : field_719[var0];
         Graphics var4 = field_51;
         if (method_1609(var0)) {
            int var6 = 60 + (var1 - 120 >> 1) + var2;
            int var7 = -10 + method_151(method_402() * 20 / 100, 2);

            for (int var8 = 0; var8 <= var3; var8++) {
               method_200(var4, 35, var6, var7, var8 << 1);
               method_200(var4, 35, var6 + 60, var7, (var8 << 1) + 1);
            }

            int var13 = method_401() >> 7;
            method_455(var0 * 14050 + (var13 >> 3));
            int var9 = var7 + 24 >> 1;
            int var10 = 67 - var9;
            method_200(var4, 37, var6 - 24 + method_456() % 48, var9 + method_456() % var10, (var13 & 7) * 5 >> 3);
            var13 += 18;
            method_455(var6 + var7 + (var13 >> 3));
            method_200(var4, 37, var6 - 24 + method_456() % 48, var9 + method_456() % var10, (var13 & 7) * 5 >> 3);
         } else {
            int var11 = 40 + (var1 - 80 >> 1) + var2;
            boolean var12 = false;
            method_200(var4, 36, var11, 24, 1);
         }

         method_413(false);
      }
   }

   // $VF: renamed from: ac () int
   public static final int method_1618() {
      int var0 = 0;
      int var1 = method_1007();

      for (int var2 = 1; var2 <= 20; var2++) {
         int var3 = method_1028(var0);
         if (var1 > var3) {
            return var2;
         }

         var0++;
      }

      return -1;
   }

   // $VF: renamed from: S () java.lang.String
   public static String method_1619() {
      return method_1621(field_726);
   }

   // $VF: renamed from: T () java.lang.String
   public static String method_1620() {
      return method_1621(field_726);
   }

   // $VF: renamed from: q (int) java.lang.String
   public static final String method_1621(int var0) {
      int var1 = method_155(field_720);
      String var2 = method_133(74);
      field_186.setLength(0);
      method_460(field_186, var1, 26, method_133(102 + var0));
      field_186.append(var2);
      field_186.append(" \"");
      field_186.append(method_133(76 + var0));
      field_186.append("\"");
      return field_186.toString();
   }

   // $VF: renamed from: gN () void
   public static final void method_1622() {
      if (field_425 == 0) {
         field_723 = 0;
      }

      if (field_424 == 0) {
         field_724++;
      } else {
         field_724 = 0;
      }

      if (field_423 > 0) {
         field_725++;
      } else {
         field_725 = 0;
      }
   }

   // $VF: renamed from: bg (int) void
   public final void method_1623(int var1) {
      if (var1 == 1) {
         method_250("gd");
      } else if (var1 == 2) {
         method_249("gd");
      } else if (var1 == 4) {
         method_250("gf" + field_479);
      } else if (var1 == 8) {
         method_249("gf" + field_479);
      } else if (var1 != 16) {
         if (var1 == 32) {
            this.method_1624(field_142);
         } else if (var1 == 64) {
            method_1579();
         } else if (var1 == 128) {
            method_1407();
         } else if (var1 == 256) {
            method_1408();
         } else if (var1 == 512) {
            method_1419();
         } else {
            if (var1 == 1024) {
               method_1420();
            }
         }
      } else {
         field_479 = 0;
         field_146 = 0;
         method_507();
         method_588();
         int var2 = 4;

         while (--var2 >= 0) {
            method_250("gf" + var2);
         }

         method_250("gd");
      }
   }

   // $VF: renamed from: bB (int) void
   private void method_1624(int var1) {
      method_292(var1);
      method_481();
      method_1406();
      method_1418();
      method_1429();
   }

   // $VF: renamed from: aa (int) boolean
   public static boolean method_1625(int var0) {
      boolean var1;
      if (var1 = (field_729 & var0) != 0) {
         field_729 &= ~var0;
         field_75[1]++;
      }

      return var1;
   }

   // $VF: renamed from: bw () boolean
   public final boolean method_1626() {
      for (int var1 = 0; var1 < 32; var1++) {
         int var2;
         if (method_1625(var2 = 1 << var1)) {
            this.method_1623(var2);
            break;
         }
      }

      return field_729 == 0;
   }

   // $VF: renamed from: ad () int
   public static int method_1627() {
      int var0 = 0;
      int var1;
      if ((var1 = field_730 & 16777215) != 0) {
         field_729 |= var1;
         var0 = 0 + method_155(var1);
      }

      return var0;
   }

   // $VF: renamed from: gO () void
   public static void method_1628() {
      field_463 = true;
      method_580();
      method_1630();
   }

   // $VF: renamed from: gP () void
   public static void method_1629() {
      method_1631(method_166(), 5);
   }

   // $VF: renamed from: gQ () void
   public static void method_1630() {
      method_480();
      if (method_403() == 111 && !method_585(field_479)) {
         method_987();
      }
   }

   // $VF: renamed from: k (int, int) boolean
   public static boolean method_1631(int var0, int var1) {
      return method_1632(var0, var1, null, false);
   }

   // $VF: renamed from: a (int, int, int[], boolean) boolean
   public static boolean method_1632(int var0, int var1, int[] var2, boolean var3) {
      if (method_402() < 800) {
         return false;
      } else {
         field_730 = var1;
         if (var0 != 4 && !var3) {
            var0 = -5;
         }

         if (method_165(var0 | 16, var2)) {
            field_615 = method_403() != 107;
            field_730 = 0;
            method_423(81);
            return true;
         } else {
            if (method_402() > 10000) {
               method_80();
            }

            return false;
         }
      }
   }

   // $VF: renamed from: gR () void
   public static void method_1633() {
      int var0 = 0;
      if (field_416 == field_408) {
         var0 = 2952;
      } else {
         var0 = 392 | (field_479 == 0 ? 0 : 2560);
      }

      method_1631(var0 | 64, 0);
   }

   // $VF: renamed from: gS () void
   public static void method_1634() {
      method_1631(method_166(), 1);
   }

   // $VF: renamed from: gT () void
   public static void method_1635() {
      if (method_1631(method_166(), 16)) {
         method_475();
      }
   }

   // $VF: renamed from: gU () void
   public static void method_1636() {
      method_1631(104, 2);
   }

   // $VF: renamed from: gV () void
   public static void method_1637() {
      method_1205();
      if (method_1631(4, 64)) {
         System.gc();
      }
   }

   // $VF: renamed from: gW () void
   public static void method_1638() {
      if (method_1631(4, 0)) {
         System.gc();
      }
   }

   // $VF: renamed from: gX () void
   public static void method_1639() {
      method_1631(method_166(), 32);
   }

   // $VF: renamed from: gY () void
   public static void method_1640() {
      method_1631(method_166(), 0);
   }

   // $VF: renamed from: gZ () void
   public static void method_1641() {
      method_1631(method_166(), 8);
   }

   // $VF: renamed from: ha () void
   public static void method_1642() {
      method_1631(33554536, 0);
   }

   // $VF: renamed from: hb () void
   public static void method_1643() {
      method_1631(67108969, 0);
   }

   // $VF: renamed from: hc () void
   public static void method_1644() {
      method_1631(6291560, 128);
   }

   // $VF: renamed from: hd () void
   public static void method_1645() {
      method_1631(104, 256);
   }

   // $VF: renamed from: he () void
   public static void method_1646() {
      method_1632(10485769, 512, null, true);
   }

   // $VF: renamed from: hf () void
   public static void method_1647() {
      method_1632(-5, 1024, null, true);
   }

   // $VF: renamed from: hg () void
   public static void method_1648() {
      int var0 = field_479;
      if (!method_583(field_479)) {
         method_582(var0, true);
      }

      if (method_585(var0)) {
         method_584(var0, false);
      }

      method_1631(8200, 5);
   }

   // $VF: renamed from: hh () void
   public static void method_1649() {
      int var0 = field_479;
      if (!method_583(field_479)) {
         method_582(var0, true);
      }

      if (!method_585(var0)) {
         method_584(var0, true);
      }

      method_1631(104, 5);
   }

   // $VF: renamed from: hQ () void
   private static void method_1650() {
      if (field_731 == null) {
         field_731 = new String[64][2];
      }

      field_732 = 0;
   }

   // $VF: renamed from: b (java.lang.String) boolean
   public static boolean method_1651(String var0) {
      method_1650();
      InputStream var1 = null;

      try {
         int var2 = (var1 = web.Resources.open(method_176(var0))).read(field_76);
         var1.close();
         String var3;
         int var4 = (var3 = method_144(new String(field_76, 0, var2))).length();
         int var5 = 0;
         int var6 = 0;
         boolean var7 = false;

         int var10;
         do {
            int var8;
            if ((var8 = var3.indexOf(10, var6)) == -1) {
               var8 = var4;
               var7 = true;
            }

            String var9 = var3.substring(var6, method_149(var8, var4));
            var10 = 0;
            if (var9 != null) {
               var10 = var9.length();
               int var11;
               if (!var9.equals("") && !var9.startsWith("!") && (var11 = var9.indexOf(61)) != -1) {
                  String var12 = var9.substring(0, var11).trim();
                  String var13 = var9.substring(var11 + 1, var10).trim();
                  field_731[var5][0] = var12;
                  field_731[var5][1] = var13;
                  var5++;
               }
            } else {
               var7 = true;
            }
         } while ((var6 += var10 + 1) < var4 && !var7);

         field_732 = var5 + 1;
         return true;
      } catch (IOException var15) {
         if (var1 != null) {
            try {
               var1.close();
            } catch (IOException var14) {
            }
         }

         return false;
      }
   }

   // $VF: renamed from: f (java.lang.String) java.lang.String
   public static final String method_1652(String var0) {
      if (var0 == null) {
         return null;
      } else {
         for (int var1 = 0; var1 < field_732; var1++) {
            String var2 = field_731[var1][0];
            if (var0.equals(var2)) {
               return field_731[var1][1];
            }
         }

         return null;
      }
   }

   static {
      long var0 = 0L;
      long var2 = 16777216L;
      long var4 = 1263L;
      long var6 = 205882L;

      for (int var8 = 0; var8 < 128; var8++) {
         long var9 = var2;
         var2 -= (var4 * var2 >> 24) + (var6 * var0 >> 24);
         var0 += (var6 * var9 >> 24) - (var4 * var0 >> 24);
         field_74[var8 + 1] = (int)(var0 >> 8);
      }

      field_75 = new int[2];
      field_76 = new byte[47280];
      field_88 = false;
      field_104 = new byte[7][];
      field_106 = new Font[7];
      field_108 = -1;
      field_109 = 0;
      field_110 = -1;
      field_114 = new byte[64];
      field_115 = new byte[64];
      field_116 = new byte[64];
      char[] var10000 = new char[]{'1', '2', '3', '4', '5', '6', '7', '8', '9', '*', '0', '#'};
      int[] var12 = new int[]{49, 50, 51, 52, 53, 54, 55, 56, 57, 42, 48, 35};
      field_125 = new int[47280];
      field_126 = 16711935;
      field_138 = new RichTextLayout[3];
      field_139 = new short[20];
      field_147 = new Thread[4];
      field_149 = new String[17];
      field_156 = 0;
      field_161 = new byte[115][9];
      field_162 = new int[115];
      field_163 = new GameClock(null);
      field_164 = 0;
      field_165 = -1;
      field_166 = new int[6];
      field_167 = new int[16];
      field_170 = Integer.MAX_VALUE;
      field_181 = false;
      field_182 = -128;
      field_183 = new int[115];
      field_186 = new StringBuffer(1000);
      field_187 = new StringBuffer(1000);
      field_188 = 3;
      field_189 = 2;
      field_190 = 3;
      field_188 = 3;
      field_189 = 2;
      field_190 = 3;
      field_191 = field_188 * (field_189 + field_190);
      field_192 = new int[field_191];
      boolean var11 = false;
      field_192[0] = 28872;
      field_192[1] = 43300;
      field_192[2] = 43300;
      field_192[3] = 29400;
      field_192[4] = 29400;
      field_192[5] = 29400;
      field_192[6] = 17400;
      field_192[7] = 34900;
      field_192[8] = 34900;
      field_192[9] = 21200;
      field_192[10] = 21200;
      field_192[11] = 21200;
      field_192[12] = 32359;
      field_192[13] = 18876;
      field_192[14] = 18876;
      field_193 = new int[field_191];
      field_193[0] = 30;
      field_193[1] = 31;
      field_193[2] = 32;
      field_193[3] = 33;
      field_193[4] = 34;
      field_193[5] = 35;
      field_193[6] = 36;
      field_193[7] = 37;
      field_193[8] = 38;
      field_193[9] = 39;
      field_193[10] = 40;
      field_193[11] = 41;
      field_193[12] = 42;
      field_193[13] = 43;
      field_193[14] = 44;
      field_194 = -1;
      field_197 = -1;
      field_198 = -1;
      field_218 = new byte[40];
      field_237 = -1;
      field_238 = 0;
      field_239 = false;
      field_243 = -1;
      field_244 = false;
      field_247 = 136;
      field_248 = 256;
      field_249 = new long[8];
      field_250 = new long[8];
      field_292 = 0;
      field_293 = 1;
      field_294 = 2;
      field_295 = 3;
      field_296 = 4;
      field_297 = 5;
      field_355 = new byte[12];
      field_356 = new byte[5];
      field_357 = new byte[5];
      field_365 = new byte[]{0, 1, 3, 2, 4, 2, 3, 2};
      field_366 = 200;
      field_367 = new int[]{
         26,
         72,
         1,
         68,
         0,
         74,
         5,
         74,
         25,
         79,
         5,
         76,
         25,
         80,
         5,
         76,
         14,
         108,
         8,
         65,
         11,
         108,
         8,
         64,
         0,
         54,
         0,
         90,
         0,
         54,
         0,
         90,
         0,
         54,
         0,
         90,
         54,
         90,
         8,
         35,
         9,
         48,
         3,
         77,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         134,
         182,
         20,
         112,
         109,
         153,
         21,
         50,
         82,
         157,
         13,
         64,
         120,
         165,
         5,
         27,
         49,
         106,
         16,
         52,
         49,
         106,
         16,
         52,
         49,
         106,
         16,
         52,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         -1,
         0,
         0,
         -1,
         -1,
         10,
         90,
         -1,
         -1,
         39,
         90,
         -1,
         -1,
         22,
         90,
         -1,
         -1,
         37,
         90,
         -1,
         -1,
         1,
         90,
         -1,
         -1,
         34,
         90,
         -1,
         -1,
         41,
         89,
         -1,
         -1,
         1,
         90,
         -1,
         -1,
         0,
         0,
         -1,
         -1,
         19,
         90,
         -1,
         -1,
         49,
         90,
         -1,
         -1,
         40,
         87,
         -1,
         -1,
         19,
         90,
         -1,
         -1,
         54,
         89,
         -1
      };
      field_370 = new short[50];
      field_371 = new byte[field_366];
      field_384 = new byte[3];
      field_385 = new byte[3];
      field_386 = new int[3];
      field_394 = 24;
      field_395 = 12;
      field_404 = new int[]{16743174, 16743174, 12583167, 15654144, 3198214};
      field_405 = new int[]{62, 133, 56, 127, 31, 133, 2, 146, 74, 125, 73, 125, 73, 124, 74, 128, 77, 130, 79, 131};
      field_433 = new int[4];
      field_434 = new int[4];
      field_491 = false;
      field_493 = false;
      field_511 = new GameClock(method_404());
      field_514 = -44;
      field_515 = 0;
      field_516 = 46;
      field_517 = 23;
      field_518 = -46;
      field_519 = 23;
      field_520 = 8;
      field_521 = 36;
      field_522 = 18;
      field_523 = -36;
      field_524 = 18;
      field_525 = 90;
      field_526 = 46;
      field_527 = 65;
      field_528 = 32;
      field_529 = 6;
      field_530 = 3;
      field_531 = 24;
      field_532 = 48;
      field_533 = 27;
      field_534 = 38;
      field_535 = 13;
      field_536 = 48;
      field_537 = -106;
      field_538 = -35;
      field_539 = -34;
      field_540 = -70;
      field_545 = new int[]{-134, -113, -92, -63, -42, -21};
      field_546 = new int[]{-13, -24, -32, -48, -59, -66};
      field_547 = 21;
      field_548 = 92;
      field_520 >>= 1;
      field_564 = field_525 / 2;
      field_565 = field_526 / 2;
      field_541 = -field_539;
      field_542 = field_540;
      field_543 = -field_537;
      field_544 = field_538;
      field_279 = method_1217(method_148(1, 280 * field_525 / 90 / 100));
      field_549 = 75;
      field_550 = 10;
      field_551 = field_549 - 2;
      field_552 = (71 - field_534 << 2) - field_520;
      field_553 = 4 * field_516;
      field_554 = 4 * field_519;
      field_555 = -field_529;
      field_556 = -field_529 * 2 - field_527;
      field_557 = field_530;
      field_558 = field_557 * 2 + field_528;
      field_559 = -field_516 * 2;
      field_560 = -field_519 * 2;
      field_561 = field_559 + field_556 + field_529;
      field_562 = field_560 + field_558 - field_530;
      field_563 = 2 * field_516;
      field_566 = field_514;
      field_567 = field_515;
      field_568 = field_555;
      field_569 = field_556;
      field_570 = field_568 - field_527 + (field_550 >> 1);
      field_571 = field_569 - field_527 + (field_550 >> 1);
      field_572 = -field_555 - 2;
      field_573 = field_572 + field_529 + field_527;
      field_574 = field_572 + field_527 - (field_550 >> 1);
      field_575 = field_573 + field_527 - (field_550 >> 1);
      field_576 = new byte[]{0, 1, 2, 1};
      field_577 = 5;
      field_578 = 5;
      field_579 = 18;
      field_580 = 9;
      field_581 = 16;
      field_582 = 23;
      field_583 = 36;
      field_584 = 2;
      field_585 = 4;
      field_586 = 6;
      field_587 = 53;
      field_588 = 22;
      field_589 = 49;
      field_590 = 8;
      field_591 = 17;
      field_592 = 24;
      field_593 = 11;
      field_594 = 36;
      field_595 = 29;
      field_596 = 69;
      field_612 = false;
      field_614 = -1;
      field_654 = new byte[320];
      field_655 = new byte[2500];
      field_657 = new int[]{100, 150, 200, 220, 250, 300};
      field_658 = new int[]{100, 250, 300, 300, 350, 350};
      field_659 = new int[]{100, 250, 300, 350, 400, 450};
      field_660 = new int[]{2000, 4000, 3000, 5000, 4000, 4500, 8000, 15000, 6000};
      field_661 = new byte[3];
      field_661[0] = 2;
      field_661[1] = 3;
      field_661[2] = 4;
      field_662 = new int[]{0, 8000, 30000, 50000};
      field_663 = new int[]{0, 5000, 12000, 30000};
      field_664 = new byte[]{0, 1, 1, 2};
      field_665 = new int[]{0, 8000, 10000};
      field_666 = new byte[]{0, 1, 2};
      field_667 = new byte[]{-100, 0, 20, 50, 70};
      field_668 = new byte[]{
         5, 20, 18, 16, 14, 12, 10, 8, 6, 4, 30, 25, 20, 18, 15, 13, 10, 8, 7, 6, 30, 25, 20, 18, 15, 13, 10, 8, 7, 6, 18, 17, 16, 15, 14, 13, 12, 11, 10, 6
      };
      field_672 = 0;
      field_673 = 0;
      field_674 = 0;
      field_675 = 0;
      field_676 = 0;
      field_677 = 0;
      field_678 = 0;
      field_679 = 4;
      field_680 = 1;
      field_681 = 2;
      field_682 = 3;
      field_683 = 4;
      field_684 = 5;
      field_685 = 6;
      field_686 = 7;
      field_687 = 8;
      field_688 = 9;
      field_689 = 10;
      field_690 = 11;
      field_691 = 12;
      field_692 = 13;
      field_693 = 14;
      field_694 = 15;
      field_695 = 16;
      field_696 = 17;
      field_697 = 18;
      field_698 = 19;
      field_699 = 20;
      field_700 = method_148(field_676, field_680);
      field_701 = method_148(field_677, field_681);
      field_702 = method_148(field_678, field_682);
      field_703 = method_148(field_679, field_683);
      field_704 = method_148(field_680, field_684);
      field_705 = method_148(field_681, field_685);
      field_706 = method_148(field_682, field_686);
      field_707 = method_148(field_683, field_687);
      field_708 = method_148(field_688, field_676);
      field_709 = method_148(field_689, field_677);
      field_710 = method_148(field_690, field_678);
      field_711 = method_148(field_691, field_679);
      field_719 = new byte[]{2, 0, 1, 2, 0, 1, 1, 1, 2, 1, 0, 1, 2, 2, 0, 1, 1, 0, 1, 0, 0, 0, 1, 1, 2, 2};
      field_722 = new byte[3];
   }
}
