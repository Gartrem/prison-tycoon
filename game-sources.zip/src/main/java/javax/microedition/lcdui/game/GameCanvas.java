package javax.microedition.lcdui.game;
import javax.microedition.lcdui.*;
public abstract class GameCanvas extends Displayable {
  private final Image screen=Image.createImage(240,320);private final Graphics graphics=screen.getGraphics();
  protected GameCanvas(boolean suppressKeys){}
  public void setFullScreenMode(boolean full){} public Graphics getGraphics(){return graphics;}
  public void flushGraphics(){web.Browser.present(screen.handle);}
  public int getGameAction(int key){switch(key){case -1:case 50:return 1;case -2:case 56:return 6;case -3:case 52:return 2;case -4:case 54:return 5;case -5:case 53:return 8;default:return 0;}}
}
