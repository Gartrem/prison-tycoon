import javax.microedition.lcdui.Graphics;

// $VF: renamed from: f
public final class RichTextLayout {
   // $VF: renamed from: a int
   public int field_0;
   // $VF: renamed from: d int
   private int field_1;
   // $VF: renamed from: e int
   private int field_2;
   // $VF: renamed from: f int
   private int field_3;
   // $VF: renamed from: g int
   private int field_4;
   // $VF: renamed from: h int
   private int field_5;
   // $VF: renamed from: a long
   public long field_6;
   // $VF: renamed from: a boolean
   public boolean field_7 = false;
   // $VF: renamed from: b boolean
   public boolean field_8 = false;
   // $VF: renamed from: a java.lang.String
   private static String field_9;
   // $VF: renamed from: i int
   private static int field_10;
   // $VF: renamed from: b int
   public static int field_11;
   // $VF: renamed from: c int
   public static int field_12;
   // $VF: renamed from: j int
   private static int field_13;
   // $VF: renamed from: a short[]
   private static short[] field_14 = new short[512];
   // $VF: renamed from: k int
   private static int field_15;
   // $VF: renamed from: l int
   private static int field_16;
   // $VF: renamed from: m int
   private static int field_17;
   // $VF: renamed from: n int
   private static int field_18;
   // $VF: renamed from: o int
   private static int field_19;
   // $VF: renamed from: c boolean
   private static boolean field_20;
   // $VF: renamed from: d boolean
   private static boolean field_21;

   public RichTextLayout(int var1) {
      this.field_0 = var1;
   }

   // $VF: renamed from: c () boolean
   private static boolean method_0() {
      return false;
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Graphics, int, int) void
   public final void method_1(Graphics var1, int var2, int var3) {
      GameCore.method_62(this.field_6, var2, var3);
      int var4 = this.field_7 ? 17 : 20;
      GameCore.method_335(var1, 0, field_16 + field_17 + 1, field_9, field_13, field_14, -1, field_11, field_12, this.field_4, this.field_3, var4, field_21);
      GameCore.method_64();
   }

   // $VF: renamed from: a () void
   public final void method_2() {
      if (!method_3()) {
         for (int var1 = field_18; var1 < field_11 + field_12 - 1; var1++) {
            field_19 = field_19 + field_14[var1];
         }

         field_18 = field_11 + field_12 - 1;
      } else {
         if (field_17 > 0) {
            field_17 = 0;
         } else {
            field_11 = field_11 + field_12;
         }

         this.method_12();
      }

      field_15 = GameCore.method_401();
      GameCore.method_413(true);
   }

   // $VF: renamed from: d () boolean
   private static boolean method_3() {
      return true;
   }

   // $VF: renamed from: a () boolean
   public static boolean method_4() {
      return field_20;
   }

   // $VF: renamed from: b () boolean
   public static boolean method_5() {
      return field_11 > 0 || field_16 < -1;
   }

   // $VF: renamed from: a () int
   public final int method_6() {
      return (method_4() || !method_3()) && !method_0() ? this.field_5 : -128;
   }

   // $VF: renamed from: a (long, int, int, int) void
   public final void method_7(long var1, int var3, int var4, int var5) {
      this.field_6 = var1;
      this.field_1 = GameCore.method_70(var1);
      this.field_2 = GameCore.method_71(var1);
      this.field_3 = var3;
      this.field_4 = var4;
      field_11 = 0;
      field_13 = 0;
      field_20 = true;
      this.field_5 = var5;
      method_17();
   }

   // $VF: renamed from: a (java.lang.String) void
   public final void method_8(String var1) {
      field_9 = var1;
      field_10 = var1.length();

      char var3;
      for (int var2 = var1.length() - 1; var2 >= 0 && ((var3 = var1.charAt(var2)) == '|' || var3 == ' '); var2--) {
         field_10--;
      }

      field_21 = GameCore.method_338(var1);
      method_17();
      method_18();
      this.method_12();
   }

   // $VF: renamed from: a () java.lang.String
   public static String method_9() {
      return field_9;
   }

   // $VF: renamed from: b () void
   public static void method_10() {
      field_9 = null;
      field_10 = 0;
   }

   // $VF: renamed from: c () void
   public final void method_11() {
      this.method_14();
   }

   // $VF: renamed from: d () void
   private void method_12() {
      int var1 = field_16 + 1;
      field_12 = 0;
      method_13();
      int var2 = field_13;
      int var3 = -1;

      while (var2 < field_10 && var1 < this.field_2 && field_11 + field_12 < field_14.length) {
         var3 = GameCore.method_336(var3, field_9, var2, this.field_4, this.field_3);
         if (field_14[field_11 + field_12] < 0) {
            field_14[field_11 + field_12] = (short)GameCore.method_334(var3, this.field_1, field_9, var2);
         }

         var1 = var1 + GameCore.method_211(var3) + 0;
         if (this.field_0 == 1 ? var1 < this.field_2 : var1 <= this.field_2) {
            var2 += field_14[field_11 + field_12];
            if (this.field_0 != 1) {
               field_12++;
            }
         }

         int var4 = GameCore.method_148(0, var2 - field_14[field_11 + field_12 - 1]);
         int var5;
         if ((var5 = GameCore.method_337(field_9, 'p', var4, var2)) >= var4 && var5 < var2 && this.field_8) {
            break;
         }
      }

      if (var2 < field_10 && field_11 + field_12 < field_14.length) {
         method_16(true);
      } else {
         method_16(false);
      }
   }

   // $VF: renamed from: e () void
   private static void method_13() {
      field_13 = 0;

      for (int var0 = 0; var0 < field_11; var0++) {
         field_13 = field_13 + field_14[var0];
      }
   }

   // $VF: renamed from: f () void
   private void method_14() {
      int var1;
      if ((var1 = GameCore.method_241(field_15, 800)) >= 0) {
         int var2 = GameCore.method_231();
         this.method_19(var2, var1);
      }
   }

   // $VF: renamed from: g () void
   private void method_15() {
      int var1 = 0;
      int var2 = field_13;
      int var3 = GameCore.method_336(-1, field_9, var2, this.field_4, this.field_3);
      var1 = 0 + GameCore.method_211(var3) + 0;
      boolean var4 = false;

      while (var1 <= this.field_2 && field_11 > 0) {
         int var5 = var2 - field_14[field_11 - 1];
         int var6;
         if ((var6 = GameCore.method_337(field_9, 'p', var5, var2)) >= var5 && var6 < var2) {
            if (var4) {
               return;
            }

            var4 = true;
         }

         field_11--;
         var2 = var5;
         var3 = GameCore.method_336(-1, field_9, var5, this.field_4, this.field_3);
         var1 = var1 + GameCore.method_211(var3) + 0;
      }
   }

   // $VF: renamed from: a (boolean) void
   private static void method_16(boolean var0) {
      if (var0 != field_20) {
         field_20 = var0;
         GameCore.method_437();
      }
   }

   // $VF: renamed from: h () void
   private static void method_17() {
      for (int var0 = 0; var0 < field_14.length; var0++) {
         field_14[var0] = -1;
      }
   }

   // $VF: renamed from: i () void
   private static void method_18() {
      field_11 = 0;
      field_13 = 0;
      field_20 = true;
      field_16 = -1;
      field_17 = 0;
      field_18 = 0;
      field_19 = 0;
      field_15 = GameCore.method_401();
   }

   // $VF: renamed from: a (int, int) void
   private void method_19(int var1, int var2) {
      int var3 = field_11;
      if (var1 == 1) {
         if (this.field_8) {
            this.method_15();
         } else {
            field_11--;
         }
      } else if (var1 == 4) {
         if (this.field_8) {
            field_11 = field_11 + field_12;
         } else {
            field_11++;
         }
      }

      if (field_11 < 0) {
         field_11 = 0;
      } else if (field_11 > var3 && !method_4()) {
         field_11 = var3;
      }

      if (field_11 != var3) {
         this.method_12();
         GameCore.method_413(true);
         field_15 = var2;
      }
   }
}
