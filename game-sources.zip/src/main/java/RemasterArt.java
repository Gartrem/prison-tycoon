import javax.microedition.lcdui.Graphics;

/** Art hooks only. Original camera, draw order, simulation and hit regions stay in GameCore. */
public final class RemasterArt {
   private static int actors;
   private RemasterArt() {}

   public static boolean button(Graphics g, int x, int y, int w, int h, boolean selected, String label) {
      if (label == null) label = "";
      int[] args = new int[6 + label.length()];
      args[0]=x; args[1]=y; args[2]=w; args[3]=h; args[4]=selected?1:0; args[5]=0;
      for (int i=0;i<label.length();i++) args[6+i]=label.charAt(i);
      return g.remaster("button", args);
   }

   public static boolean suppressSprite(int sprite) { return actors > 0 && sprite >= 12 && sprite <= 26; }

   public static boolean sprite(Graphics g, int sprite, int x, int y, int w, int h, int frame, int transform) {
      return g.remaster("sprite", new int[]{sprite, x, y, frame, w, h, transform, GameCore.field_465});
   }

   public static boolean beginActor(Graphics g, int id, int seed, int x, int y, boolean inWorld, boolean portrait) {
      int activity = GameCore.field_314[id];
      if (activity == 33) return false;
      boolean modern = g.remaster("actor", new int[]{id, seed, x, y, activity,
         GameCore.method_683(id, 2) ? 1 : 0, GameCore.method_719(id), GameCore.method_720(id),
         id >= GameCore.field_286 ? 1 : 0, GameCore.field_465, portrait ? 1 : 0,
         GameCore.field_308[id], inWorld ? 1 : 0,
         GameCore.method_683(id,32768) ? 1 : GameCore.method_683(id,65536) ? 2 : 0,
         GameCore.field_465 - GameCore.field_317[id],
         GameCore.method_683(id,32)||GameCore.method_683(id,64) ? 1 : 0,
         GameCore.field_465 >> (GameCore.method_1057() ? 0 : 1),
         GameCore.field_310[id], GameCore.field_311[id],
         GameCore.field_302[id], GameCore.field_303[id], GameCore.field_309[id],
         x - 76 + GameCore.field_585, y - 57 + GameCore.field_586,
         GameCore.field_587, GameCore.field_588});
      if (modern) actors++;
      return modern;
   }

   public static void endActor(Graphics g) { actors--; }

   public static void beginFixture(Graphics g, int fixture, int type) {
      int activity = -1;
      // field_400 is the equipment's own entity ID, not the person using it.
      for (int id = 0; id < GameCore.field_287; id++) {
         if (GameCore.field_299[id] < 0 || GameCore.field_309[id] != GameCore.field_416
               || GameCore.field_308[id] != fixture || GameCore.method_683(id,2)) continue;
         int current = GameCore.field_314[id];
         if (current == 7 || current == 8 || current == 9 || current == 27) { activity = current; break; }
      }
      g.remaster("fixture", new int[]{fixture,type,activity >= 0 ? 1 : 0,activity,GameCore.field_465});
   }
}
