/** Cyrillic extension of the original bitmap fonts. Layout and drawing share metrics. */
public final class RussianFont {
    private RussianFont() {}
    public static boolean supports(char c) {
        return (c >= '\u0410' && c <= '\u044f') || c == '\u0401' || c == '\u0451';
    }
    public static int width(byte[] font, char c) {
        char upper = Character.toUpperCase(c);
        int base = font[1];
        return base + (upper == 'Ж' || upper == 'Ш' || upper == 'Щ' || upper == 'Ю' || upper == 'Ы' ? 1 : 0);
    }
    public static final String[] SYSTEM_TEXT = {
        "Игра приостановлена", "Включить звук?", "Загрузка", "Выбрать", "Выйти",
        "Продолжить", "Да", "Нет", "Далее", "Назад", "Принять", "Начать",
        "Поверните экран, чтобы продолжить игру.", "-е", "-е", "-е", "-е"
    };
}
