package com.nokia.mid.ui;
import javax.microedition.lcdui.Graphics;
public final class DirectUtils {public static Graphics getDirectGraphics(Graphics graphics){return graphics;}}
