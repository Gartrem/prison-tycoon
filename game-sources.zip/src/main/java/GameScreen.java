import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.game.GameCanvas;

// $VF: renamed from: d
public final class GameScreen extends GameCanvas {
   // $VF: renamed from: a javax.microedition.lcdui.Graphics
   private Graphics field_733;

   public GameScreen() {
      super(false);
      this.setFullScreenMode(true);
      this.field_733 = this.getGraphics();
   }

   public final void showNotify() {
      GameCore.method_389();
   }

   public final void hideNotify() {
      GameCore.method_390();
   }

   public final void keyPressed(int var1) {
      GameCore.method_243(var1);
   }

   public final void keyReleased(int var1) {
      GameCore.method_244(var1);
   }

   public final void sizeChanged(int var1, int var2) {
   }

   // $VF: renamed from: a () void
   public final void method_1653() {
      if (this.field_733 == null) {
         this.field_733 = this.getGraphics();
      }

      GameCore.method_392(this.field_733, 240, 320);
      this.flushGraphics();
   }

   // $VF: renamed from: a (javax.microedition.lcdui.Display) void
   public final void method_1654(Display var1) {
      var1.setCurrent(this);
   }
}
