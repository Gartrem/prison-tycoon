package javax.microedition.lcdui;
import javax.microedition.midlet.MIDlet;
public final class Display {
  private static Display instance=new Display(); private Displayable current;
  public static Display getDisplay(MIDlet game){return instance;}
  public void setCurrent(Displayable next){current=next; next.showNotify();}
  public Displayable getCurrent(){return current;} public boolean vibrate(int duration){return false;}
}
