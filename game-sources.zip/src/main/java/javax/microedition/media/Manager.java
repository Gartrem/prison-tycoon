package javax.microedition.media;
import java.io.*;
public final class Manager {public static Player createPlayer(InputStream input,String mime)throws IOException {ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buffer=new byte[4096];int count;while((count=input.read(buffer))>=0)out.write(buffer,0,count);return new Player(out.toByteArray(),mime);}}
