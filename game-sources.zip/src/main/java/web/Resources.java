package web;
import java.io.*;
import org.teavm.jso.*;
public final class Resources {
  @JSBody(params="path",script="return PrisonWeb.resource(path);")
  @JSByRef public static native byte[] bytes(String path);
  public static InputStream open(String path) { byte[] b=bytes(path); return b==null ? null : new ByteArrayInputStream(b); }
}
