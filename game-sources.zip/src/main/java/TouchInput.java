public final class TouchInput {
   private static final int MENU = 1;
   private static final int ENTITY = 2;
   private static final int FIXTURE = 3;
   private static final int LIMIT = 192;
   private static final int[] kind = new int[LIMIT];
   private static final int[] id = new int[LIMIT];
   private static final int[] x = new int[LIMIT];
   private static final int[] y = new int[LIMIT];
   private static final int[] width = new int[LIMIT];
   private static final int[] height = new int[LIMIT];
   private static int count;
   private static int state = -1;
   private static String lastAction = "none";

   private TouchInput() {}

   public static void beginFrame(int currentState) {
      count = 0;
      state = currentState;
   }

   private static void add(int targetKind, int targetId, int left, int top, int targetWidth, int targetHeight) {
      if (count >= LIMIT || targetWidth <= 0 || targetHeight <= 0) return;
      int right = Math.min(240, left + targetWidth);
      int bottom = Math.min(320, top + targetHeight);
      left = Math.max(0, left);
      top = Math.max(0, top);
      if (right <= left || bottom <= top) return;
      kind[count] = targetKind;
      id[count] = targetId;
      x[count] = left;
      y[count] = top;
      width[count] = right - left;
      height[count] = bottom - top;
      count++;
   }

   public static void addMenuItem(int item, int left, int top, int itemWidth, int itemHeight) {
      add(MENU, item, left, top, itemWidth, itemHeight);
   }

   public static void addEntity(int entity, int centerX, int baseY, boolean character) {
      if (character) add(ENTITY, entity, centerX - 25, baseY - 92, 50, 108);
      else add(ENTITY, entity, centerX - 34, baseY - 58, 68, 78);
   }

   public static void addFixture(int fixture, int centerX, int centerY) {
      add(FIXTURE, fixture, centerX - 30, centerY - 34, 60, 68);
   }

   private static boolean contains(int index, int tapX, int tapY) {
      return tapX >= x[index] && tapX < x[index] + width[index]
         && tapY >= y[index] && tapY < y[index] + height[index];
   }

   private static int nearest(int targetKind, int tapX, int tapY) {
      int best = -1;
      long bestDistance = Long.MAX_VALUE;
      for (int index = count - 1; index >= 0; index--) {
         if (kind[index] != targetKind || !contains(index, tapX, tapY)) continue;
         int centerX = x[index] + width[index] / 2;
         int centerY = y[index] + height[index] / 2;
         long dx = tapX - centerX;
         long dy = tapY - centerY;
         long distance = dx * dx + dy * dy;
         if (distance < bestDistance) {
            bestDistance = distance;
            best = index;
         }
      }
      return best;
   }

   private static int nearestWithin(int targetKind, int tapX, int tapY, int radius) {
      int best = -1;
      long bestDistance = (long)radius * radius + 1;
      for (int index = count - 1; index >= 0; index--) {
         if (kind[index] != targetKind) continue;
         int centerX = x[index] + width[index] / 2;
         int centerY = y[index] + height[index] / 2;
         long dx = tapX - centerX;
         long dy = tapY - centerY;
         long distance = dx * dx + dy * dy;
         if (distance < bestDistance) {
            bestDistance = distance;
            best = index;
         }
      }
      return best;
   }

   private static void activateFixture(int target) {
      GameCore.method_618(id[target]);
      GameCore.method_413(false);
      lastAction = "fixture:" + id[target];
      press(-5);
   }

   private static void press(int key) {
      GameCore.method_243(key);
      GameCore.method_244(key);
   }

   private static boolean pressSoft(boolean left) {
      if (left) {
         if (GameCore.method_407(0) || GameCore.method_407(5)) return true;
      } else if (GameCore.method_407(1) || GameCore.method_407(3)) {
         return true;
      }
      return false;
   }

   public static boolean tap(int tapX, int tapY) {
      tapX = Math.max(0, Math.min(239, tapX));
      tapY = Math.max(0, Math.min(319, tapY));

      if (tapY >= 294 && pressSoft(tapX < 120)) {
         lastAction = tapX < 120 ? "soft-left" : "soft-right";
         return true;
      }

      if (state == GameCore.method_403()) {
         int target = nearest(MENU, tapX, tapY);
         if (target >= 0) {
            GameCore.method_346(id[target]);
            lastAction = "menu:" + id[target];
            press(-5);
            return true;
         }

         if (state == 27) {
            if (GameCore.field_251 >= 0) {
               target = nearest(FIXTURE, tapX, tapY);
               if (target < 0 && tapY >= 36 && tapY < 286) {
                  target = nearestWithin(FIXTURE, tapX, tapY, 92);
               }
               if (target >= 0) {
                  activateFixture(target);
                  return true;
               }
            }

            target = nearest(ENTITY, tapX, tapY);
            if (target >= 0) {
               GameCore.method_619(GameCore.field_251, id[target]);
               GameCore.method_413(false);
               lastAction = "entity:" + id[target];
               press(-5);
               return true;
            }

            target = nearest(FIXTURE, tapX, tapY);
            if (target >= 0) {
               activateFixture(target);
               return true;
            }
         }
      }

      if (tapX < 44) {
         lastAction = "left";
         press(-3);
      } else if (tapX >= 196) {
         lastAction = "right";
         press(-4);
      } else {
         lastAction = "confirm";
         press(-5);
      }
      return true;
   }

   public static String diagnostics() {
      int menus = 0, entities = 0, fixtures = 0;
      for (int index = 0; index < count; index++) {
         if (kind[index] == MENU) menus++;
         else if (kind[index] == ENTITY) entities++;
         else if (kind[index] == FIXTURE) fixtures++;
      }
      String first = count == 0 ? "none" : kind[0] + ":" + id[0] + "@" + x[0] + "," + y[0] + "," + width[0] + "," + height[0];
      return "state=" + state + ", regions=" + count + ", menus=" + menus
         + ", entities=" + entities + ", fixtures=" + fixtures + ", selected=" + GameCore.field_251
         + ", cursor=" + GameCore.field_252 + ", mode=" + GameCore.field_274 + ", first=" + first + ", last=" + lastAction;
   }

   public static String target(int targetKind, int ordinal) {
      for (int index = 0; index < count; index++) {
         if (kind[index] == targetKind && ordinal-- == 0) {
            return id[index] + "," + x[index] + "," + y[index] + "," + width[index] + "," + height[index];
         }
      }
      return "";
   }
}
