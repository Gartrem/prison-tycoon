// $VF: renamed from: c
public final class AudioSpec {
   // $VF: renamed from: a int
   public final int field_29;
   // $VF: renamed from: f int
   private final int field_30;
   // $VF: renamed from: b int
   public final int field_31;
   // $VF: renamed from: c int
   public final int field_32;
   // $VF: renamed from: a boolean
   public final boolean field_33;
   // $VF: renamed from: d int
   public final int field_34;
   // $VF: renamed from: e int
   public final int field_35;

   public AudioSpec(int var1, int var2, int var3, int var4, boolean var5, int var6, int var7) {
      this.field_29 = var1;
      this.field_31 = var2;
      this.field_30 = var3;
      this.field_33 = var5;
      this.field_32 = var4;
      this.field_34 = var6;
      this.field_35 = var7;
   }

   // $VF: renamed from: a () java.lang.String
   public final String method_28() {
      switch (this.field_30) {
         case 1:
            return "audio/midi";
         case 2:
            return "audio/x-wav";
         case 3:
            return "audio/mpeg";
         case 4:
            return "audio/ogg";
         default:
            return null;
      }
   }
}
