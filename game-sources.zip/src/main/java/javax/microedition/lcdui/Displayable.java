package javax.microedition.lcdui;
public abstract class Displayable { public void showNotify(){} public void hideNotify(){} public int getWidth(){return 240;} public int getHeight(){return 320;} }
