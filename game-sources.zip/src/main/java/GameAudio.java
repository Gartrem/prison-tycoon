import java.io.ByteArrayInputStream;
import javax.microedition.media.Control;
import javax.microedition.media.Manager;
import javax.microedition.media.Player;
import javax.microedition.media.PlayerListener;
import javax.microedition.media.control.VolumeControl;

// $VF: renamed from: g
public final class GameAudio extends SoundChannel implements PlayerListener {
   // $VF: renamed from: a javax.microedition.media.Player
   private Player field_43;

   // $VF: renamed from: f () void
   public final void method_49() {
      byte[] var1 = (byte[])GameCore.field_61[super.field_36.field_29];

      try {
         ByteArrayInputStream var2;
         Player var3;
         method_50(var3 = Manager.createPlayer(var2 = new ByteArrayInputStream(var1), super.field_36.method_28()), super.field_36.field_33);
         var2.close();
         this.field_43 = var3;
      } catch (Exception var4) {
      }
   }

   // $VF: renamed from: e () void
   public final void method_48() {
      if (this.field_43 != null && this.field_43.getState() != 0) {
         this.field_43.close();
      }

      this.field_43 = null;
   }

   // $VF: renamed from: a () java.lang.Object
   public final Object method_46() {
      return this.field_43;
   }

   // $VF: renamed from: b (int) boolean
   public final boolean method_47(int var1) {
      try {
         this.field_43.setMediaTime(0L);
         this.method_40(var1);
         this.field_43.start();
         return true;
      } catch (Exception var2) {
         return false;
      }
   }

   // $VF: renamed from: d () void
   public final void method_45() {
      try {
         this.field_43.stop();
      } catch (Exception var1) {
      }
   }

   // $VF: renamed from: c (int) void
   public final void method_43(int var1) {
      Control var2;
      if (this.field_43.getState() != 100 && (var2 = this.field_43.getControl("VolumeControl")) != null) {
         ((VolumeControl)var2).setLevel(var1);
      }
   }

   // $VF: renamed from: b () boolean
   public final boolean method_44() {
      return this.field_43.getState() == 400;
   }

   public final void playerUpdate(Player var1, String var2, Object var3) {
      if ("deviceAvailable".equals(var2)) {
         GameCore.method_122(super.field_36.field_31);
      } else if (!"deviceUnavailable".equals(var2)) {
         if (!"endOfMedia".equals(var2)) {
            "volumeChanged".equals(var2);
         }
      }
   }

   // $VF: renamed from: a (javax.microedition.media.Player, boolean) void
   private static void method_50(Player var0, boolean var1) {
      var0.setLoopCount(var1 ? -1 : 1);

      try {
         var0.realize();
         var0.prefetch();
      } catch (Exception var2) {
      }
   }
}
