package javax.microedition.lcdui;
public final class Image {
  public final int handle,width,height;
  public Image(int handle,int width,int height){this.handle=handle;this.width=width;this.height=height;}
  public static Image createImage(int w,int h){return new Image(web.Browser.surface(w,h),w,h);}
  public static Image createImage(String path){int id=web.Browser.image(path);return new Image(id,web.Browser.width(id),web.Browser.height(id));}
  public static Image createRGBImage(int[] pixels,int w,int h,boolean alpha){return new Image(web.Browser.pixels(pixels,w,h,alpha),w,h);}
  public int getWidth(){return width;} public int getHeight(){return height;} public Graphics getGraphics(){return new Graphics(this);}
}
