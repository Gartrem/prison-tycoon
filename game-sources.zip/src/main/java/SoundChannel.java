// $VF: renamed from: b
public abstract class SoundChannel {
   // $VF: renamed from: a c
   public AudioSpec field_36;
   // $VF: renamed from: b int
   private int field_37;
   // $VF: renamed from: c int
   private int field_38;
   // $VF: renamed from: d int
   private int field_39;
   // $VF: renamed from: e int
   private int field_40;
   // $VF: renamed from: f int
   private int field_41;
   // $VF: renamed from: a int
   public int field_42;

   // $VF: renamed from: a (c) void
   public final void method_29(AudioSpec var1) {
      if (var1 != null) {
         this.method_48();
      }

      this.field_36 = var1;
      this.method_49();
   }

   // $VF: renamed from: a (boolean) void
   public final void method_30(boolean var1) {
      if (this.field_36 != null) {
         byte var2 = 0;
         if (this.field_36.field_31 != 0 && this.field_36.field_33 && this.field_37 != 3 && this.field_37 != 0) {
            var2 = 4;
         }

         this.method_37(0);
         this.field_37 = var2;
         if (var1) {
            this.method_48();
         }
      }
   }

   // $VF: renamed from: a () void
   public final void method_31() {
      if (this.field_37 == 4 && this.field_36 != null) {
         int var1 = this.field_36.field_31;
         if (this.field_36.field_31 == 1 && !GameCore.method_92()) {
            return;
         }

         if (var1 == 0 && !GameCore.method_94()) {
            return;
         }

         this.method_33(0, this.field_42);
      }
   }

   // $VF: renamed from: a (int, int) void
   public final void method_32(int var1, int var2) {
      if (this.field_38 == var2) {
         this.field_42 = var2;
         this.field_37 = var2 == 0 ? 0 : 2;
      } else if (this.field_37 == 4) {
         this.field_38 = var2;
      } else if (var1 != 0) {
         this.field_37 = 1;
         this.field_39 = this.field_38;
         this.field_42 = var2;
         this.field_40 = GameCore.method_401();
         this.field_41 = var1;
      } else {
         this.field_37 = 2;
         this.method_40(var2);
         this.field_42 = var2;
      }
   }

   // $VF: renamed from: a (int, int) boolean
   public final boolean method_33(int var1, int var2) {
      this.field_42 = var2;
      if (this.method_46() == null) {
         this.method_29(this.field_36);
      }

      if (var1 != 0) {
         this.field_37 = 1;
         this.field_39 = 0;
         this.field_38 = 0;
      } else {
         this.field_37 = 2;
         this.field_38 = var2;
      }

      boolean var3 = this.method_34(this.field_38);
      this.field_40 = GameCore.method_401();
      this.field_41 = var1;
      return var3;
   }

   // $VF: renamed from: a (int) boolean
   public final boolean method_34(int var1) {
      try {
         return this.method_47(var1);
      } catch (Exception var3) {
         return false;
      }
   }

   // $VF: renamed from: b () void
   public final void method_35() {
      try {
         this.field_38 = 0;
         this.method_45();
      } catch (Exception var1) {
      }
   }

   // $VF: renamed from: a (boolean) boolean
   public final boolean method_36(boolean var1) {
      return !var1 && this.field_37 == 4
         ? false
         : this.field_36 != null && (this.field_37 == 4 || this.field_37 != 0 && this.field_36.field_33 || this.method_46() != null && this.method_44());
   }

   // $VF: renamed from: a (int) void
   public final void method_37(int var1) {
      if (this.field_37 != 0) {
         if (this.field_37 == 4) {
            this.field_37 = 0;
         } else if (var1 != 0) {
            this.field_37 = 3;
            this.field_39 = this.field_38;
            this.field_40 = GameCore.method_401();
            this.field_41 = var1;
            this.field_42 = 0;
         } else {
            this.field_37 = 0;
            this.method_35();
         }
      }
   }

   // $VF: renamed from: a () int
   public final int method_38() {
      if (this.field_37 == 0) {
         return 0;
      } else {
         return this.field_37 == 3 && GameCore.method_401() > this.field_40 + (this.field_41 >> 1) ? 0 : this.field_36.field_32;
      }
   }

   // $VF: renamed from: a (int) int
   public final int method_39(int var1) {
      return GameCore.method_150(var1 * GameCore.method_128(this.field_36.field_31) / 4, 1, 100);
   }

   // $VF: renamed from: b (int) void
   public final void method_40(int var1) {
      this.field_38 = var1;
      this.method_43(this.method_39(var1));
   }

   // $VF: renamed from: c () void
   public final void method_41() {
      if (GameCore.method_109(this.field_36.field_31)) {
         this.method_40(this.field_38);
      }

      if (this.field_37 != 4 && this.field_38 != this.field_42) {
         if (this.field_41 == 0) {
            this.method_40(this.field_42);
         } else {
            this.method_40(
               this.field_39
                  + (this.field_42 - this.field_39) * GameCore.method_149(GameCore.method_401() - this.field_40, this.field_41) / this.field_41
            );
         }
      }

      if (this.field_37 == 1 && this.field_38 == this.field_42) {
         this.field_37 = 2;
      }

      if (this.field_37 == 3 && this.field_42 == 0 && this.field_38 == 0) {
         this.field_37 = 0;
         this.method_35();
      }
   }

   // $VF: renamed from: a () boolean
   public final boolean method_42() {
      return this.field_37 != 0 && this.field_37 != 4 && this.field_37 != 3 && !this.method_44();
   }

   // $VF: renamed from: c (int) void
   public abstract void method_43(int var1);

   // $VF: renamed from: b () boolean
   public abstract boolean method_44();

   // $VF: renamed from: d () void
   public abstract void method_45();

   // $VF: renamed from: a () java.lang.Object
   public abstract Object method_46();

   // $VF: renamed from: b (int) boolean
   public abstract boolean method_47(int var1);

   // $VF: renamed from: e () void
   public abstract void method_48();

   // $VF: renamed from: f () void
   public abstract void method_49();
}
