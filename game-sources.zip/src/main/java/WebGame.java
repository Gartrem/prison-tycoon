import org.teavm.jso.*;
public final class WebGame {
 private static GameCore game;
 public static void main(String[] args){game=new GameCore();game.startApp();}
 @JSExport public static void keyDown(int key){GameCore.touchCameraRoom=-1;if(GameCore.field_45!=null)GameCore.field_45.keyPressed(key);}
 @JSExport public static void keyUp(int key){if(GameCore.field_45!=null)GameCore.field_45.keyReleased(key);}
 @JSExport public static boolean tap(int x,int y){GameCore.touchCameraRoom=-1;return GameCore.field_45!=null&&TouchInput.tap(x,y);}
 @JSExport public static boolean panCamera(int dx,int dy){
  if(GameCore.method_403()!=27)return false;
  GameCore.touchCameraRoom=GameCore.field_416;
  GameCore.method_612(GameCore.field_265-dx,GameCore.field_266-dy);
  GameCore.method_1216(GameCore.field_600,GameCore.field_601);
  GameCore.field_263=GameCore.field_600;GameCore.field_264=GameCore.field_601;
  GameCore.method_621(GameCore.field_263,GameCore.field_264);
  GameCore.method_413(false);return true;
 }
 @JSExport public static String cameraPosition(){return GameCore.field_265+","+GameCore.field_266;}
 @JSExport public static void pause(){if(game!=null)game.pauseApp();}
 @JSExport public static void resume(){if(GameCore.field_45!=null)GameCore.field_45.showNotify();}
 @JSExport public static String diagnostics(){return "state="+GameCore.method_403()+", cash="+GameCore.field_445+", prison="+GameCore.field_479+", time="+GameCore.method_401();}
 @JSExport public static String language(){return GameCore.method_286();}
 @JSExport public static String touchDiagnostics(){return TouchInput.diagnostics();}
 @JSExport public static String touchTarget(int kind,int ordinal){return TouchInput.target(kind,ordinal);}
 /** Development-only sprite catalogue; does not change campaign state. */
 @JSExport public static String artSprite(int sprite,int frame){
  javax.microedition.lcdui.Image image=javax.microedition.lcdui.Image.createImage(384,384);
  javax.microedition.lcdui.Graphics g=image.getGraphics();
  GameCore.method_200(g,sprite,192,192,frame);
  return image.handle+","+GameCore.method_181(sprite)+","+GameCore.method_182(sprite)+","+GameCore.method_183(sprite)+","+GameCore.method_184(sprite);
 }
 @JSExport public static String modernSnapshot(){return ModernBridge.snapshot();}
 @JSExport public static boolean modernMenu(int item,int state){return ModernBridge.menu(item,state);}
 @JSExport public static boolean modernEntity(int id){return ModernBridge.entity(id);}
 @JSExport public static boolean modernFixture(int id){return ModernBridge.fixture(id);}
 @JSExport public static boolean modernRoom(int id){return ModernBridge.room(id);}
 @JSExport public static void modernContinue(boolean left){GameCore.modernContinue(left);}
 @JSExport public static void modernNavigate(int direction){ModernBridge.navigate(direction);}
 @JSExport public static void modernCancel(){ModernBridge.cancelSelection();}
 @JSExport public static String localizationAudit(){
  try {
   java.io.DataInputStream input=new java.io.DataInputStream(web.Resources.open("/prisru"));
   input.skipBytes(3);int count=input.readUnsignedShort(),maxLines=0,maxId=0;
   for(int i=0;i<count;i++){
    int id=input.readUnsignedShort();input.readUnsignedShort();String text=input.readUTF();
    int offset=0,lines=0,font=-1;
    while(offset<text.length()){
     font=GameCore.method_336(font,text,offset,0,1);
     int length=GameCore.method_334(font,200,text,offset);
     if(length<=0)return "FAIL: stalled line wrapping at string "+id;
     offset+=length;lines++;
    }
    if(lines>maxLines){maxLines=lines;maxId=id;}
   }
   input.close();return "strings="+count+", maxLines="+maxLines+", maxId="+maxId+", language="+language();
  }catch(Exception error){return "FAIL: "+error;}
 }
}
