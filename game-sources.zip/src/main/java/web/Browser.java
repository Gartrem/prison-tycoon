package web;
import org.teavm.jso.*;
public final class Browser {
  @JSBody(params={"id","kind","state","args"},script="return PrisonWeb.remaster ? PrisonWeb.remaster(id,kind,state,args) : false;") public static native boolean remaster(int id,String kind,int[] state,int[] args);
  @JSBody(params={"text","x","y"},script="if(PrisonWeb.recordText)PrisonWeb.recordText(text,x,y);") public static native void recordText(String text,int x,int y);
  @JSBody(params={"w","h"},script="return PrisonWeb.surface(w,h);") public static native int surface(int w,int h);
  @JSBody(params={"path"},script="return PrisonWeb.image(path);") public static native int image(String path);
  @JSBody(params={"id"},script="return PrisonWeb.width(id);") public static native int width(int id);
  @JSBody(params={"id"},script="return PrisonWeb.height(id);") public static native int height(int id);
  @JSBody(params={"pixels","w","h","alpha"},script="return PrisonWeb.pixels(pixels,w,h,alpha);") public static native int pixels(@JSByRef int[] pixels,int w,int h,boolean alpha);
  @JSBody(params={"id","op","state","args","text"},script="PrisonWeb.draw(id,op,state,args,text);") public static native void draw(int id,int op,int[] state,int[] args,String text);
  @JSBody(params={"id"},script="PrisonWeb.present(id);") public static native void present(int id);
  @JSBody(params={"text","size","bold"},script="return PrisonWeb.measure(text,size,bold);") public static native int measure(String text,int size,boolean bold);
  @JSBody(params={"name"},script="return PrisonWeb.readSave(name) || new Int8Array(0);") @JSByRef public static native byte[] readSave(String name);
  @JSBody(params={"name","data"},script="PrisonWeb.writeSave(name,data);") public static native void writeSave(String name,@JSByRef byte[] data);
  @JSBody(params={"data","mime"},script="return PrisonWeb.audio(data,mime);") public static native int audio(@JSByRef byte[] data,String mime);
  @JSBody(params={"id","op","value"},script="return PrisonWeb.audioControl(id,op,value);") public static native int audioControl(int id,int op,int value);
  @JSBody(script="PrisonWeb.exit();") public static native void exit();
}
