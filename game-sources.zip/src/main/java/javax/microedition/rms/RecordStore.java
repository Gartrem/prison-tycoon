package javax.microedition.rms;
import java.util.Arrays;
public final class RecordStore {
 private final String name;private byte[] data;
 private RecordStore(String name){this.name=name;data=web.Browser.readSave(name);if(data.length==0)data=null;}
 public static RecordStore openRecordStore(String name,boolean create){return new RecordStore(name);}
 public int getNumRecords(){return data==null?0:1;}
 public int getRecord(int id,byte[] target,int offset){System.arraycopy(data,0,target,offset,data.length);return data.length;}
 public int addRecord(byte[] input,int offset,int length){setRecord(1,input,offset,length);return 1;}
 public void setRecord(int id,byte[] input,int offset,int length){data=Arrays.copyOfRange(input,offset,offset+length);web.Browser.writeSave(name,data);}
 public void closeRecordStore(){}
}
