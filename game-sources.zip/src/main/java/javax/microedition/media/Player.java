package javax.microedition.media;
public final class Player implements javax.microedition.media.control.VolumeControl {
  private final int id;private int loops=1;private boolean closed=false;
  public Player(byte[] data,String mime){id=web.Browser.audio(data,mime);}
  public void realize(){}public void prefetch(){}public void setLoopCount(int count){loops=count;}
  public void setMediaTime(long time){web.Browser.audioControl(id,4,(int)(time/1000));}
  public void start(){web.Browser.audioControl(id,1,loops);}public void stop(){web.Browser.audioControl(id,2,0);}
  public void close(){stop();closed=true;}public int getState(){return closed?0:web.Browser.audioControl(id,0,0);}
  public Control getControl(String name){return this;}public int setLevel(int level){web.Browser.audioControl(id,3,level);return level;}
}
