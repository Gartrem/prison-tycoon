import java.util.Random;

// $VF: renamed from: e
public final class GameClock {
   // $VF: renamed from: a int
   public int field_22;
   // $VF: renamed from: a long
   private long field_23;
   // $VF: renamed from: b long
   private long field_24;
   // $VF: renamed from: c long
   private long field_25;
   // $VF: renamed from: b int
   private int field_26 = 0;
   // $VF: renamed from: a e
   private GameClock field_27;
   // $VF: renamed from: a java.util.Random
   public static Random field_28 = new Random();

   public GameClock(GameClock var1) {
      this.field_27 = var1;
   }

   // $VF: renamed from: b () long
   private static long method_20() {
      return System.currentTimeMillis();
   }

   // $VF: renamed from: a () long
   public static final long method_21() {
      return method_20();
   }

   // $VF: renamed from: a () int
   public static final int method_22() {
      return field_28.nextInt();
   }

   // $VF: renamed from: a () void
   public final void method_23() {
      long var1 = this.method_27();
      switch (this.field_26) {
         case 0:
            this.field_25 = var1;
            break;
         case 2:
            this.field_23 = this.field_23 + (var1 - this.field_24);
      }

      this.field_26 = 1;
      this.method_26();
   }

   // $VF: renamed from: b () void
   public final void method_24() {
      this.method_26();
      this.field_24 = this.method_27();
      this.field_26 = 2;
   }

   // $VF: renamed from: c () void
   public final void method_25() {
      this.field_22 = 0;
      this.field_24 = 0L;
      this.field_25 = 0L;
      this.field_23 = 0L;
      this.field_26 = 0;
   }

   // $VF: renamed from: d () void
   public final void method_26() {
      if (this.field_26 == 1) {
         long var1 = this.method_27();
         this.field_22 = (int)(var1 - this.field_25 - this.field_23);
      }
   }

   // $VF: renamed from: c () long
   private final long method_27() {
      return this.field_27 == null ? method_21() : this.field_27.field_22;
   }
}
