package javax.microedition.midlet;
public abstract class MIDlet {
  public abstract void startApp(); public abstract void pauseApp(); public abstract void destroyApp(boolean force);
  public void notifyDestroyed(){web.Browser.exit();}
  public boolean platformRequest(String url){return false;}
  public String getAppProperty(String name){
    switch(name){case "MIDlet-Name": return "Тюрьма Тикоон";case "MIDlet-Version": return "1.0.75";case "MIDlet-Vendor":return "THQ";case "Enable-Cheats":return "FALSE";case "Multi-Language-Options":return "ru"; default:return null;}
  }
}
