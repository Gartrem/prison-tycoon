package javax.microedition.lcdui;
public final class Font {
  public final int size; public final boolean bold;
  private Font(int style,int size){this.size=size==8?9:size==16?14:11;this.bold=(style&1)!=0;}
  public static Font getFont(int face,int style,int size){return new Font(style,size);}
  public int getHeight(){return size+3;} public int getBaselinePosition(){return size;}
  public int charWidth(char c){return web.Browser.measure(String.valueOf(c),size,bold);}
  public int charsWidth(char[] chars,int offset,int count){return web.Browser.measure(new String(chars,offset,count),size,bold);}
  public int substringWidth(String s,int offset,int count){return web.Browser.measure(s.substring(offset,offset+count),size,bold);}
  public int stringWidth(String s){return web.Browser.measure(s,size,bold);}
}
