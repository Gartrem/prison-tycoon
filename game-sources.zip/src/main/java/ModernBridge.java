/** Read-only presentation data and validated commands for the responsive browser UI.
 * The campaign, money, AI, unlocks and save format stay in GameCore. */
public final class ModernBridge {
   private ModernBridge() {}

   private static String quote(String value) {
      if (value == null) return "null";
      StringBuilder out = new StringBuilder("\"");
      for (int i = 0; i < value.length(); i++) {
         char c = value.charAt(i);
         if (c == '"' || c == '\\') out.append('\\').append(c);
         else if (c == '\n') out.append("\\n");
         else if (c == '\r') out.append("\\r");
         else if (c == '\t') out.append("\\t");
         else if (c >= 32) out.append(c);
      }
      return out.append('"').toString();
   }

   public static String snapshot() {
      int state = GameCore.method_403();
      int scratchX = GameCore.field_600, scratchY = GameCore.field_601;
      int scratchA = GameCore.field_483, scratchB = GameCore.field_484;
      StringBuilder out = new StringBuilder("{\"state\":").append(state);
      out.append(",\"cash\":").append(GameCore.field_445);
      out.append(",\"prison\":").append(GameCore.field_479);
      out.append(",\"room\":").append(GameCore.field_416);
      out.append(",\"outside\":").append(GameCore.field_408);
      out.append(",\"year\":").append(GameCore.field_466);
      out.append(",\"elapsed\":").append(GameCore.field_465);
      out.append(",\"yearStart\":").append(GameCore.field_467);
      out.append(",\"selected\":").append(GameCore.field_251);
      out.append(",\"cursor\":").append(GameCore.field_252);
      out.append(",\"fixture\":").append(GameCore.field_254);
      out.append(",\"mode\":").append(GameCore.field_274);
      out.append(",\"text\":").append(quote(RichTextLayout.method_9()));
      out.append(",\"left\":").append(quote(GameCore.method_405()));
      out.append(",\"right\":").append(quote(GameCore.method_406()));
      out.append(",\"menu\":[");
      int menus = GameCore.method_347();
      for (int i = 0; i < menus; i++) {
         if (i > 0) out.append(',');
         String menuText = GameCore.method_1320(i);
         int option = GameCore.method_348(i);
         if ((option & 0xf0000000) == 0x10000000) menuText += ": " + GameCore.method_133((option & 1) == 0 ? 310 : 309);
         else if ((option & 0xf0000000) == 0x20000000) {
            int volume = option & 4095;
            menuText += ": " + GameCore.method_133(volume == 0 ? 310 : 311 + 4 * volume / 5);
         }
         out.append("{\"id\":").append(i).append(",\"text\":").append(quote(menuText)).append('}');
      }
      out.append("],\"menuSelected\":").append(GameCore.method_345());
      appendDetail(out, state);
      out.append(",\"rooms\":[");
      boolean comma = false;
      if (GameCore.field_409 != null) for (int r = 0; r < GameCore.field_406; r++) {
         if (GameCore.field_409[r] < 0) continue;
         if (comma) out.append(','); comma = true;
         out.append("{\"id\":").append(r).append(",\"type\":").append(GameCore.field_409[r]);
         out.append(",\"kind\":").append(GameCore.method_994(GameCore.field_409[r]));
         out.append(",\"name\":").append(quote(GameCore.field_411[r]));
         out.append(",\"entity\":").append(GameCore.field_410[r]);
         out.append(",\"x\":").append(GameCore.field_412[r]).append(",\"y\":").append(GameCore.field_413[r]).append('}');
      }
      out.append("],\"entities\":["); comma = false;
      if (GameCore.field_299 != null) for (int i = 0; i < GameCore.field_284; i++) {
         if (GameCore.field_299[i] < 0) continue;
         if (comma) out.append(','); comma = true;
         out.append("{\"id\":").append(i).append(",\"type\":").append(GameCore.field_300[i]);
         out.append(",\"room\":").append(GameCore.field_309[i]);
         out.append(",\"x\":").append(GameCore.field_304[i]).append(",\"y\":").append(GameCore.field_305[i]);
         out.append(",\"gx\":").append(GameCore.field_306[i]).append(",\"gy\":").append(GameCore.field_307[i]);
         out.append(",\"prisoner\":").append(i < GameCore.field_280);
         out.append(",\"character\":").append(i < GameCore.field_287);
         if (i < GameCore.field_283) {
            out.append(",\"activity\":").append(GameCore.field_314[i]);
            out.append(",\"destination\":").append(GameCore.field_308[i]);
         }
         if (i < GameCore.field_280) {
            out.append(",\"aggression\":").append(GameCore.method_735(GameCore.field_331, i));
            out.append(",\"fatigue\":").append(GameCore.method_735(GameCore.field_332, i));
            out.append(",\"defiance\":").append(GameCore.method_735(GameCore.field_333, i));
            out.append(",\"risk\":").append(GameCore.field_329[i]);
            out.append(",\"sentence\":").append(GameCore.field_330[i]);
         }
         out.append('}');
      }
      out.append("],\"fixtures\":["); comma = false;
      int room = GameCore.field_416;
      if (GameCore.field_396 != null && room >= 0 && room < GameCore.field_406) for (int f = 0; f < 10; f++) {
         int type = GameCore.field_396[room][f];
         if (type < 0) continue;
         if (comma) out.append(','); comma = true;
         out.append("{\"id\":").append(f).append(",\"type\":").append(type);
         out.append(",\"x\":").append(GameCore.field_401[room][f]).append(",\"y\":").append(GameCore.field_402[room][f]);
         out.append(",\"gx\":").append(GameCore.field_397[room][f]).append(",\"gy\":").append(GameCore.field_398[room][f]);
         out.append(",\"occupant\":").append(GameCore.field_400[room][f]);
         out.append(",\"interactive\":").append(GameCore.method_888(room,f,1));
         out.append(",\"level\":").append(GameCore.field_399[room][f]);
         out.append(",\"upgrades\":["); boolean upgradeComma = false;
         for (int u = 0; u < 34; u++) if (GameCore.method_823(room,f,u)) {
            if (upgradeComma) out.append(','); upgradeComma = true; out.append(u);
         }
         out.append("]}");
      }
      GameCore.field_600 = scratchX; GameCore.field_601 = scratchY;
      GameCore.field_483 = scratchA; GameCore.field_484 = scratchB;
      return out.append("]}").toString();
   }

   private static void appendDetail(StringBuilder out, int state) {
      boolean previous = false, next = false;
      if (state == 18) {
         byte type = GameCore.field_373;
         boolean staff = GameCore.method_844(type);
         String description = GameCore.method_133(staff
            ? 394 + GameCore.method_852(type, (byte)GameCore.field_382) - 36
            : 353 + (type - 1) * 10 + GameCore.field_376);
         int cost = GameCore.method_851(GameCore.field_416, GameCore.field_372, type,
            GameCore.field_374, staff ? GameCore.field_382 : GameCore.field_376);
         previous = staff ? GameCore.field_382 > GameCore.method_843() : GameCore.field_377 >= 0;
         next = staff ? GameCore.field_382 < GameCore.method_842() : GameCore.field_378 >= 0;
         out.append(",\"detail\":{\"kind\":\"upgrade\",\"type\":").append(type)
            .append(",\"description\":").append(quote(description))
            .append(",\"cost\":").append(cost)
            .append(",\"page\":").append(quote(GameCore.field_383))
            .append(",\"status\":").append(quote(GameCore.field_482))
            .append(",\"statusCode\":").append(GameCore.field_481).append('}');
      } else if (state == 12) {
         previous = GameCore.field_479 > 0; next = GameCore.field_479 < 3;
         out.append(",\"detail\":{\"kind\":\"prison\",\"description\":")
            .append(quote(GameCore.method_133(285 + GameCore.field_479)))
            .append(",\"locked\":").append(!GameCore.method_560(GameCore.field_479)).append('}');
      } else if (state == 31 || state == 32) {
         previous = GameCore.field_712 > 0; next = GameCore.field_712 < 3;
         out.append(",\"detail\":{\"kind\":\"building\",\"description\":")
            .append(quote(GameCore.method_1540(GameCore.field_712)))
            .append(",\"cost\":").append(GameCore.method_933(GameCore.field_712))
            .append(",\"locked\":").append(!GameCore.method_557(GameCore.field_712)).append('}');
      } else if (state == 45 || state == 91 || state == 92 || state == 93) {
         previous = state == 45 ? GameCore.field_358 > 0 : GameCore.field_713;
         next = state == 45 ? GameCore.field_358 < (GameCore.field_432 > 0 ? 1 : 0) : GameCore.field_714;
         out.append(",\"detail\":{\"kind\":\"prisoners\",\"description\":")
            .append(quote(GameCore.method_133((state == 45 ? 224 : 293) + GameCore.field_358)))
            .append(",\"cost\":").append(GameCore.method_1010()).append(",\"people\":[");
         boolean comma = false;
         for (int i = 0; i < 4; i++) {
            int id = GameCore.method_763(GameCore.field_358, i);
            if (id < 0) continue;
            if (comma) out.append(','); comma = true;
            out.append(id);
         }
         out.append("]}");
      } else if (state == 35) {
         int room = GameCore.method_985(GameCore.field_259, GameCore.field_260, -1);
         if (room >= 0) {
            out.append(",\"detail\":{\"kind\":\"roomStats\",\"description\":")
               .append(quote(GameCore.field_411[room])).append(",\"values\":[");
            for (int i = 0; i < 5; i++) { if (i > 0) out.append(','); out.append(GameCore.method_804(room,i)); }
            out.append("]}");
         }
      } else if (state == 46) {
         previous = GameCore.field_429 > 0; next = GameCore.field_429 < GameCore.method_1534() - 1;
      } else if (state == 38) {
         previous = GameCore.field_146 > 0; next = GameCore.field_146 < 25;
      } else if (state == 60) {
         previous = GameCore.field_146 > 0; next = GameCore.field_146 < GameCore.method_1128() - 1;
      } else if (state == 114) {
         previous = GameCore.field_146 > 0; next = GameCore.field_146 < GameCore.method_1335() - 1;
      }
      out.append(",\"previous\":").append(previous).append(",\"next\":").append(next);
   }

   public static void navigate(int direction) {
      if (direction != -1 && direction != 1) return;
      // Revalidate after rapid taps, including the engine's intermediate animation states.
      StringBuilder data = new StringBuilder(); appendDetail(data, GameCore.method_403());
      if (data.indexOf(direction < 0 ? "\"previous\":true" : "\"next\":true") < 0) return;
      GameCore.method_1321(direction); GameCore.method_413(true);
   }

   public static void cancelSelection() {
      if (GameCore.method_403() != 27 || GameCore.field_251 < 0) return;
      GameCore.method_627(); GameCore.method_413(true);
   }

   public static void press(int code) { GameCore.method_243(code); GameCore.method_244(code); }

   public static boolean menu(int item, int expectedState) {
      if (GameCore.method_403() != expectedState || item < 0 || item >= GameCore.method_347()) return false;
      GameCore.method_346(item); press(-5); return true;
   }

   public static boolean entity(int entity) {
      if (GameCore.method_403() != 27 || entity < 0 || entity >= GameCore.field_284
         || GameCore.field_299[entity] < 0 || GameCore.field_309[entity] != GameCore.field_416) return false;
      GameCore.method_619(GameCore.field_251,entity); GameCore.method_413(false); press(-5); return true;
   }

   public static boolean fixture(int fixture) {
      int room = GameCore.field_416;
      if (GameCore.method_403() != 27 || fixture < 0 || fixture >= 10 || room < 0
         || GameCore.field_396[room][fixture] < 0 || !GameCore.method_888(room,fixture,1)) return false;
      GameCore.method_618(fixture); GameCore.method_413(false); press(-5); return true;
   }

   public static boolean room(int room) {
      if (GameCore.method_403() != 27 || GameCore.field_274 != 0 || room < 0 || room >= GameCore.field_406
         || GameCore.field_409[room] < 0) return false;
      GameCore.method_980((byte)room); GameCore.method_605(); GameCore.method_627(); GameCore.method_413(true); return true;
   }
}
